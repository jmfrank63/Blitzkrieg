gsd-state/          -> contents of .gsd (symlink to ~/.gsd/projects/<id>); restore as the project .gsd
gsd-logs-scripts/   -> ~/gsd-logs/ supervisor scripts (supervise5.sh is current)
gsd-patches/        -> patched files for ~/.gsd/agent/extensions/gsd/ and gsd-pi dist/resources/extensions/gsd/
