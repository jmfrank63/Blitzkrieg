# GSD Overrides

User-issued overrides that supersede plan document content.

---
## Override: 2026-10-05T03:28:34.069Z

**Change:** Steering after an independent review of M001 S01-S04 (fix commits b4be7df9c..0b37480f9 are already on the branch; read them).

The review found that slices marked complete are not done. Change the plan as follows, then continue:

1. Reopen S03 (ResourceModel). It is largely a shell: the item classes have no property tables (MFC has, for example, 48 properties for the weapon and 108 for the mesh tree items in Sources/src/editor), typed items serialise in a format that is not MFC's, and a node inserted through the bridge saves as `<>` (invalid XML). Port the property lists and the `operator&( IDataTree & )` serialisation of every MFC tree item faithfully (D-04, D-07), so every MFC project in Data/Editor/TestProjects and the fixtures opens, saves and reopens with equal content and MFC can read what the port writes.
2. D-07 fidelity: content-identical round trip is required for every project. Byte-identical output for a project opened and saved without edits is the goal: write with MFC's indentation and element order. Record in the spec whatever cannot be byte-identical, with the reason.
3. Comparator and goldens (S01/S03): every golden folder is empty, the comparator rejects real MFC projects, and it compares project XML instead of the exported game data. It must compare exported data (stats read by the engine's own reader, field by field, floats exact) against goldens generated from the MFC export, per D-11. Where an MFC export golden cannot be generated on this Linux machine, say so in the slice summary and keep the comparison ready for the win-home run; do not mark the comparison done.
4. DXT tolerance: re-measure on representative shipped textures (several DXT1, DXT3 and DXT5 `_c.dds` from Data, including alpha), not random noise; record the new numbers and use them as the gate.
5. Lock file: use MFC's `locked_<user>` as D-08 says, not `<path>.lock`; keep the atomic create from 0b37480f9.
6. Geometry: save it for every node that has it, not only the root, and make undo of a delete restore it.
7. Keep one sweep script, not both run-s02-sweep.sh and run-s03-sweep.sh. No sweep may classify a Map Editor tier failure as pre-existing.
8. Every task summary must cite commands that were really run in that task. Do not claim results from earlier tasks or other machines.

Note for the Map Editor tiers: map-editor-smoke and the auto tiers built on it fail when the real mouse pointer rests inside the hidden test window's screen area (the review saw this at 5ad96ec7f too). If they fail with the pointer over the window, that is the known test weakness. Make the smoke immune to the real pointer if that is cheap (for example, ignore the global mouse position while a script drives input); otherwise record it.
**Scope:** resolved
**Applied-at:** M001/S03+S04 replanned 2026-10-05 (S03 reopened T01-T08; S04 T07-T11; D006-D009)

---

## Override: 2026-10-05T06:01:52.328Z

**Change:** T08 (the S03 Linux sweep) has already been run by the maintainer: tools/zig/run-resource-sweep.sh at commit 27d03a607 (which also commits the uncommitted T05-T08 work), result in zig-out/local-test/resource_editor/resource-sweep.log: every tier PASS, VERDICT=PASS, 27 minutes. Do NOT start the sweep again: it outlives an agent session, which is why T08 got stuck three times. Read the log, check its tiers against the task's must-haves, write the T08 summary citing that log and commit 27d03a607 as the evidence, complete T08, then complete the slice. Rule for all future tasks: never start a long build or test (more than about 10 minutes) in the background and end the session; run it in the foreground with a timeout, or split it into smaller tiers.
**Scope:** resolved
**Applied-at:** M001/S03/T08 completed from the maintainer log at 27d03a607; S03 completed; D010 recorded

---

## Override: 2026-10-05T08:34:09.007Z

**Change:** S04/T11: the implementation is committed in b8d55b423. The maintainer ran the full sweep (tools/zig/run-resource-sweep.sh) on this machine after the T11 changes: all 18 tiers PASS, VERDICT=PASS, preview captures mesh 0.265 / sprite 0.307 / particle 0.287 non-black-non-magenta share; the log is ~/gsd-logs/sweep-S04-T11.log (copy of zig-out/local-test/resource_editor/resource-sweep.log). Do not rerun the sweep: an agent's foreground command is capped at 10 minutes (see AGENTS.md). Read the log, check the outputs, write T11-SUMMARY citing that maintainer run, and call gsd_task_complete.
**Scope:** resolved
**Applied-at:** M001/S04/T11 completed from the maintainer sweep log at b8d55b423; S04-PLAN and T11-PLAN annotated; covered by D010

---

## Override: 2026-10-05T08:37:50.929Z

**Change:** Steering after an independent review of M001 S04 (GPT-6-Luna, verified by the maintainer). Add these as fix tasks: reopen S04 if it is not yet complete, otherwise insert them at the start of S05 before its other tasks. Use model-appropriate small tasks; each runs only the tiers it touches (AGENTS.md), the maintainer runs the full sweep at slice end.

1. Export is not atomic (D-09). `Sources/src/EditorBridge/resource_bridge.cpp` around line 2318 moves staged files into the live export folder one by one; a failure halfway leaves a partial export and earlier files already replaced. Make the promotion all-or-nothing: back up every file that will be replaced, move all, and on any failure move every promoted file back and restore the backups. Add a test that forces a failure on the second file (e.g. a read-only or directory-in-the-way target) and proves the export root is byte-identical to before.
2. Geometry is written as private `_bk_geometry` elements (around line 345), which MFC cannot read; D-04/D-07 and the earlier steer require MFC to read what the port writes. For each geometry channel, find where MFC stores it (the owning item's fields and its `operator&( IDataTree & )` in Sources/src/editor, or a separate file) and serialise it exactly there, removing `_bk_geometry`. Where a channel truly has no MFC home, record that in the phase 6 spec with the reason. Tests: set -> save -> reopen through the MFC-layout reader, and the written XML contains no `_bk_geometry`.
3. The preview requirement says one particle source; the "particle" capture uses an `.eff` effect project. Add a particle-source preview kind and capture against the `.pcp` fixture with the same >= 1% non-black-non-magenta gate, commit the capture, update preview-scene.md. Keep the effect capture as an extra.
4. Add a save-over-an-existing-project case to test-resource-bridge (the destination exists before BkResSave), so the Windows CI run proves `std::filesystem::rename` replaces an existing file there.
**Scope:** resolved
**Applied-at:** M001/S05 planned 2026-10-05 with the fixes first (S04 was already complete): T01 atomic export, T02 save over existing, T03-T04 geometry in MFC layout, T05 particle-source preview, T06 wrap-up; D014. Closed by T06: all four items verified by the tiers run (test-resource-bridge, -model, -core, test-editor-bridge, test-editor-core); full sweep left to the maintainer.

---

## Override: 2026-10-05T13:08:07.899Z

**Change:** Steering after an independent review of M001 S06 (GPT-6-Luna, verified by the maintainer). Add these as small fix tasks at the start of the next slice, before its other tasks. Each runs only the tiers it touches (AGENTS.md); the maintainer runs the full sweep at slice end.

1. Squad formation direction uses the wrong angle convention. `Sources/editor/resource_app/squad_logic.zig` `arrowAngle` returns `atan2(dy, dx)` and `panels.zig` (around line 426) draws the arrow as (cos a, sin a). MFC's `CSquadFrame::UpdateFormationDirection` (Sources/src/editor/SquadFrm.cpp:577) defines the direction of `fFormationDir` as world (-sin a, +cos a), and `CalculateNewPositions` rotates slots with the same convention; MFC's screen Y also runs opposite to world Y. So an angle set in the port is stored about 90 degrees off and the game faces the squad the wrong way. Use MFC's convention everywhere the angle is computed, drawn and applied (a = atan2(-dx, dy) in world coordinates, after mapping screen to world with MFC's Y direction). Tests: pure-logic cases for the four axis directions against MFC's formulas; an auto-scenario step that drags the arrow to a known world point and checks the stored angle; slot rotation equals MFC's CalculateNewPositions for one formation.
2. S06 T05's summary describes preview captures, but they only exist under zig-out (the test deletes and recreates that folder). Commit the measured captures under tools/zig/fixtures/resource_editor/preview-scene/ like S04 did (and update preview-scene.md with the shares), or correct the summary to say where the evidence is. Do not claim committed evidence that is not in git.

Rejected review item, for the record: trench DDS gamma. MFC's SaveCompressedTexture (Sources/src/editor/SpriteCompose.cpp) applies CreateGammaCorrection, so the port applying gamma matches MFC; keep it.
**Scope:** resolved
**Applied-at:** M001/S07 replanned 2026-10-05 with the S06 review fixes first: T01 squad angle in MFC's convention (pure logic), T02 slot rotation equals CalculateNewPositions, T03 overlay drawing plus squad_arrow auto step, T04 commit the S06 preview captures (or correct the S06 T05 summary); former T01-T06 renumbered T05-T10; trench gamma kept; D016

---

## Override: 2026-10-05T14:22:40.841Z

**Change:** Small follow-up for the next slice (add one task at its start): Follow-up after the S07 review: the squad overlay's View maps world Y to screen Y without a flip, so the overlay may show the formation mirrored top-to-bottom compared with MFC's SquadFrm view (MFC projects with IScene::GetPos2 through the isometric camera). Input and drawing share the View, so the stored angle already matches the drawn arrow; this is about the picture only. First establish from MFC's camera/GetPos2 which screen direction world +Y takes. If it differs from the port, flip Y in View.toScreen/toWorld and the canvas origin in panels.zig, and update the app-logic tests and the resource-editor-auto squad steps that use screen coordinates; add a test that starts from a screen point above the zero point and checks the world direction. If it matches, record that in the spec and close.
**Scope:** resolved
**Applied-at:** M001/S08 (still planning, no tasks yet): S08-RESEARCH.md section 0 asks for this as T01, before the unit tasks; D018

---

## Override: 2026-10-05T14:40:02.475Z

**Change:** The S08 plan dropped the required task from S08-RESEARCH.md section 0 (D018: squad overlay screen Y direction matches MFC). D018 is not done: no task covers it and no commit touched squad_logic.zig View. Add it to S08 now as a task that runs next, before T02, with the scope in S08-RESEARCH.md section 0, and do not close the D018 override until that task is complete.
**Scope:** resolved
**Applied-at:** M001/S08 plan updated 2026-10-05: T07 (D018 squad overlay Y direction) added, ordered before T02 (T02-PLAN names T07 as its prerequisite); D018 amended. This override is applied to the plan; the D018 work itself stays open and is closed only by completing S08/T07, as T07-PLAN says.

---

## Override: 2026-10-05T17:05:27.289Z

**Change:** Small check for the next slice (fold into an early task, not a new slice): the object tile channels (resource_bridge.cpp TilesToGrid) refuse tiles left of or above (0,0). Load every shipped object's desc grids from Data (read-only, through ObjectTiles / LoadRPGStats' inverse, in a test that copies to zig-out/local-test) and report whether any yields a negative tile. If one does, carry a grid origin in the channel so such objects stay editable, with a round-trip test on that object; if none does, record that in the spec and keep the refusal.
**Scope:** resolved
**Applied-at:** M001/S10 (not yet planned): S10-RESEARCH.md section 0 asks for this as T01, before the building tasks; D021. S09 is already at its summarizing step, so it is not reopened. Applied to the plan 2026-10-06: D021 recorded, S10-RESEARCH section 0 names it as T01, S10 roadmap demo updated. The check itself stays open until S10/T01 completes.

---

## Override: 2026-10-05T18:27:16.980Z

**Change:** Small fix for the next slice (fold into its first task): the negative-tile scans in resource_bridge_test.cpp (S09Object::NegativeTiles for objects, and the S10 shipped-building scan around lines 5531-5561) print import_failed but never assert it, and only count a channel failure as negative when the message says 'left of or above'. A building or object that fails to import or read for any other reason is silently skipped. Make both scans fail on any import failure, missing root, or channel-read failure other than the expected negative-tile refusal, and assert the number checked equals the number of folders found. If some shipped items genuinely cannot be imported, list them by name in the test with the reason, so the count is still exact. Report the real counts in the task summary.
**Scope:** resolved
**Applied-at:** M001/S11 (not yet planned): S11-RESEARCH.md section 0 asks for this folded into T01; D022. Applied to the plan 2026-10-06. The change itself stays open until S11/T01 completes.

---

## Override: 2026-10-05T18:32:05.379Z

**Change:** The S11 plan dropped D022: no S11 task plan covers tightening the existing negative-tile scans (S09Object::NegativeTiles for objects and the S10 shipped-building scan in resource_bridge_test.cpp). Add a separate S11 task for D022 now, with its own task plan: both scans (and the new S11 bridge scan) fail on any import failure, missing root or channel-read failure other than the expected negative-tile refusal; checked count equals folders found; genuinely unimportable shipped items listed by name with the reason; real counts reported in the summary. Verify: zig build test-resource-bridge -Dtest-mode=run. Do not mark D022 resolved until that task is complete.
**Scope:** resolved
**Applied-at:** M001/S11: separate task S11/T06 (task plan T06-PLAN.md) covers D022 for objects, buildings and bridges; S11-PLAN must-haves and verification updated; D022 in DECISIONS.md points at T06. D022 itself stays open until S11/T06 completes.
**Applied-at:** M001/S11 plan updated 2026-10-06: T06 added with its own task plan (shared scan helper for objects, buildings and bridges, checked==folders, allow-list by name, real counts); D022 amended. D022 stays open until S11/T06 completes.

---

---

## Resolution: D022 (S11/T06, 2026-10-06)

**Change:** D022 is resolved. The shared scan S09Object::ScanNegativeTiles covers objects, buildings and bridges and passes under zig build test-resource-bridge -Dtest-mode=run (exit 0): objects checked=590 folders=590, buildings checked=194 folders=194 unimportable=12 (allow-listed, no bld RPG stats), bridges checked=21 folders=21. Superseding row D023 in DECISIONS.md.
**Scope:** resolved

## Override: 2026-10-05T19:20:43.173Z

**Change:** S11 T06 allow-listed 12 shipped buildings (europe/summer/e_ctownhouse01_1 ... e_townrailwaystation_4) as 'the shipped 1.xml holds no bld RPG stats (history only)'. That reason is false: e.g. Data/Buildings/europe/summer/e_house07_1/1.xml has a full <desc MaxHP="500" ...> after its <History> block, and e_house08_1 has the same History-then-desc layout and imports fine. These are real shipped buildings the Resource Editor must import (D-04/D-07). Add a task to the current slice (before its last task): find the actual cause for each of the 12 (compare with a working building field by field, e.g. which element or attribute the importer trips on), fix the building importer so they import, shrink the allow-list to only items with a verified, specific reason, and add a named round-trip test on at least one of the 12. Verify: zig build test-resource-bridge -Dtest-mode=run.
**Scope:** resolved
**Applied-at:** M001/S11: new task S11/T07 (task plan T07-PLAN.md) finds the real cause per building, fixes the building importer, shrinks the allow-list to verified specific reasons and adds a named round-trip test on at least one of the 12; T05 (the slice's last task) must not finish before T07 is complete. D023 in DECISIONS.md records the steer; D024 re-records the T06 resolution of D022 (its hand-written row was dropped by the DB regeneration) and points at D023. D023 itself stays open until S11/T07 completes.

---

---

## Resolution: D023 (S11/T07, 2026-10-06)

**Change:** D023 is resolved. All 12 allow-listed europe/summer buildings had a valid desc with an empty KeyName; the bld importer in resource_bridge.cpp used the empty name as its no-stats sentinel. It now uses the folder name as the label, so all 12 import and export field-equal. The building allow-list is empty (NEGTILES buildings checked=194 folders=194 negative=0 unimportable=0). Named round trip: ROUNDTRIP bld europe/summer/e_house07_1 585 fields, 0 differences. Verified with zig build test-resource-bridge -Dtest-mode=run (exit 0).
**Scope:** resolved
**Applied-at:** M001/S11/T07

---

## Override: 2026-10-05T21:56:21.582Z

**Change:** S12 closed with required controls still open, as its own PARITY rows say: B-06.3 Get particle info and B-06.4 simple/complex source toggle are 'not done: needs a follow-up task', and the S12 plan's must-haves also list the Effect direction control and whole-number child-position editing. Add these to the NEXT slice as separate tasks now, each with its own task plan (the planner has dropped research-only items twice): (1) Particle 'Get particle info' as MFC's CParticleFrame shows it; (2) Particle simple/complex source toggle in the toolbar, undoable, consistent with how the exporter derives the mode; (3) Effect direction and whole-number child-position editing, undoable, matching EffectFrm.cpp; (4) an auto path that drives the Function window with real pointer events (add, drag, delete a key through the displayed widget) and checks the stored keys plus undo/redo, since today only keyframe_logic is driven. Update the PARITY rows to done with evidence. Verify with plain zig build commands only.
**Scope:** resolved
**Applied-at:** M001/S13: separate tasks T01 (Get particle info), T02 (simple/complex toggle, undoable, equal to the exporter derivation), T03 (Effect direction and whole-number child positions), T04 (Function window auto path with real pointer events), each with its own task plan (S13-PLAN.md and tasks/T01-T10-PLAN.md rendered from the DB), before the terrain tasks T05-T10 (the former T01-T06, cross-references renumbered); T10 must not finish before T01-T04 are complete. Roadmap S13 demo updated (S12-ASSESSMENT.md). D027 in DECISIONS.md. Stays active until T01-T04 complete and B-06.3, B-06.4, B-08.3 and A-15/B-06.5 say done with evidence.

---

## Override: 2026-10-05T22:20:35.083Z

**Change:** resource-editor-auto took 383 s at the S12 sweep (45 s at S10, 295 s at S11) and S13 adds road/river/tileset blocks plus a Function-window pointer path. An agent's foreground command is capped at 10 minutes, so this tier will soon be unrunnable inside a task. Add a separate S13 task, with its own task plan, that runs before the S13 auto-scenario task (T10): split resource-editor-auto into per-editor build steps (e.g. resource-editor-auto-core, -wpn, -unt/-spt, -msh, -obt/-fnc, -bld, -bdg, -pcp/-eff, and the new 3rd/3rv/til), each under about 3 minutes, plus an aggregate resource-editor-auto that depends on all of them, so tasks run only the step they touch; keep every existing scenario action and expectation; add each new step to .github/workflows/cross-platform.yml where resource-editor-auto runs today and to tools/zig/run-resource-sweep.sh's tier list along with resource-editor-host-check and resource-editor-smoke. Verify with plain zig build commands only.
**Scope:** resolved
**Applied-at:** M001/S13: new task S13/T10 (T10-PLAN.md) splits resource-editor-auto into per-editor steps plus an aggregate and updates cross-platform.yml, run-resource-sweep.sh and the tier lists; the former T10 (til/3rd/3rv auto blocks) is now T11 and must not finish before T10. D028 in DECISIONS.md. Stays open until T10 completes.

---

## Override: 2026-10-06T01:55:55.383Z

**Change:** S13/T11: the work is committed (c8e7eef38, plus affe58ffd which commits headers and fixtures the earlier S13 task commits left out). Do NOT run tools/zig/run-resource-sweep.sh or any long multi-tier run and do not wait on a background monitor: per AGENTS.md the maintainer runs the full sweep, and is running it now on 4284d3c4d in a separate worktree. Run in the foreground only resource-editor-auto-til, resource-editor-auto-3rd and resource-editor-auto-3rv (each a few minutes), write T11-SUMMARY citing exactly those runs plus 'full sweep left to the maintainer', and call gsd_task_complete.
**Scope:** resolved
**Applied-at:** M001/S13/T11 2026-10-06: T11-PLAN and S13-PLAN annotated, D029 recorded; resource-editor-auto-til, -3rd and -3rv run in the foreground (exit 0 each) at 4284d3c4d; T11 completed citing those runs, full sweep left to the maintainer.

---

## Override: 2026-10-06T03:21:03.679Z

**Change:** S14 review fix, add as a separate task with its own task plan at the start of the next slice (the planner has dropped research-only items before): the Mission image view must follow CMissionFrame (Sources/src/editor/MissionFrm.cpp:206-226): when the Final map exists as .bzm or .xml, always show the project's map_h.dds, creating it with the minimap creation first if it is missing. Today docks.zig:532 / image_logic.zig:65 pass map.xml to BkEditorMinimapImage, which prefers map.tga, and BkResMissionMinimap is only called when decoding fails, so a project with both map.tga and a Final map shows map.tga and never generates the minimap. Give Mission its own path (keep TGA-first for the other image editors). Tests: a scratch mission with map.tga present and no map_h.dds shows a generated map_h.dds after selection; an auto step in resource-editor-auto-mip measures it. Verify with plain zig build commands only.
**Scope:** resolved
**Applied-at:** M001/S15 (still planning, no slice plan yet) 2026-10-06: separate task S15/T01 with its own task plan (tasks/T01-PLAN.md, rendered from the DB) covers the Mission image path, the minimap created first when map_h.dds is missing, the scratch-mission tests and the resource-editor-auto-mip step. S15-RESEARCH.md section 0 tells the planner to keep it as T01 and number the GUI tasks from T02. D032 in DECISIONS.md. The fix itself stays open until S15/T01 completes.

---

## Override: 2026-10-06T03:30:01.393Z

**Change:** The S15 plan dropped the S14 review fix (Mission image view must show the project's map_h.dds, creating it when missing, as CMissionFrame does at Sources/src/editor/MissionFrm.cpp:206-226; today map.tga wins and the minimap is never generated). Add it to S15 NOW as a separate task with its own task plan, run before the GUI tasks, with the scope and tests of the previous steer; do not mark the override resolved until that task is complete.
**Scope:** resolved
**Applied-at:** M001/S15 replanned 2026-10-06 before any task started: S15/T01 is the Mission image fix (D032 scope and tests) with its own task plan tasks/T01-PLAN.md, rendered from the DB; the GUI tasks are renumbered T02-T06, and T06 must not finish before T01. The S15-PLAN goal, must-haves, proof level and observability are updated, the roadmap S15 demo is updated, and D033/D034 are in DECISIONS.md (D034 re-records D033 after the earlier rewrite of the plan files was lost). This override is applied to the plan; the fix itself stays open until S15/T01 completes.

---

## Override: 2026-10-06T04:54:33.475Z

**Change:** S15 review fix, add to the next slice NOW as a separate task with its own task plan, before its other tasks (the planner has dropped research-only items three times): CUiScreen::Paste (Sources/src/ResourceModel/ui_screen.cpp:932) copies each window's ElementID unchanged, so a paste into a screen that already uses that ElementID gives two controls that send the same id in UI_NOTIFY_WINDOW_CLICKED. MFC's GUI editor has no copy/paste, so this is port behaviour to define: keep a pasted ElementID when it is unused in the target screen; when it collides, assign the next free ElementID (also inside pasted subtrees, keeping them unique among themselves) and report each reassignment in the status line/log; undo restores. Tests: paste into the same screen twice and check through the engine's UI reader that all ElementIDs of interactive controls are unique and the originals unchanged; paste into a screen without a collision keeps the ids. Verify with plain zig build commands only.
**Scope:** resolved
**Applied-at:** M001/S16 (plan-slice running) 2026-10-06: separate task S16/T01 with its own task plan (tasks/T01-PLAN.md, rendered from the DB) covers the paste ElementID rule (keep unused ids, next free id on collision including inside pasted subtrees, reassignments reported in status line and log, undo restores, redo deterministic) and the engine-reader tests (paste twice into the same screen: unique ids, originals unchanged; paste with no collision keeps ids). S16-RESEARCH.md section 0 tells the planner to keep it as T01 and number the other tasks from T02. D036 in DECISIONS.md (D035 already places it as S16/T01). The fix itself stays open until S16/T01 completes.

---

## Override: 2026-10-06T05:03:41.684Z

**Change:** Approval for S16/T07 (D-26/D035): Johannes approved deleting the old MFC editor on 2026-10-06, before the win-home hand try and MFC goldens, because it stays in git history and upstream. Do not block or wait at T07: delete it as the phase context describes once T01-T06 are done. Record in the spec and PARITY that the MFC goldens remain pending and are to be generated on win-home from a commit before the deletion (name that commit), so the golden comparison can still run later. Keep every test and fixture that does not need the MFC sources; the build must stay green on Linux after the deletion.
**Scope:** resolved
**Applied-at:** M001/S16/T07 plan updated 2026-10-06: T07-PLAN and S16-PLAN rewritten without the gate, D037 recorded, spec and PARITY notes added; the deletion itself runs at T07 after T01-T06, and T07 records the pre-deletion commit

---

## Override: 2026-10-06T05:18:14.900Z

**Change:** S16/T07 (delete the MFC editor) was dispatched in parallel with T01 and its subagent stopped at the old human gate. Two corrections: (1) T07 depends on T02, T03, T04, T05 and T06 — do not dispatch it until all of them are complete, and never in a parallel batch with them; record that dependency in the task graph. (2) The approval is already given and recorded as D037 (Johannes, 2026-10-06): it does NOT require the win-home goldens or a hand try first; the goldens will be generated later on win-home from the commit before the deletion. When T07 runs, clear its blocker and proceed per D037. Nothing was deleted, which was correct.
**Scope:** resolved
**Applied-at:** M001/S16 2026-10-06: T07 plan and S16-PLAN state the dependency on T02-T06 (never parallel with them) and the cleared gate per D037; D038 recorded. T07 itself runs after T06.

---

## Override: 2026-10-06T05:58:01.249Z

**Change:** MFC goldens now exist for 14 kinds (commit 734245b31: wpn mcp trc scp spt unt msh obt fnc bld pcp eff til mdc), made on win-home by the shipped reseditor.exe batch mode with <own_data><export_file_name>1.xml injected into a scratch copy of each fixture, so each golden folder holds MFC's files at its top level (1.xml, 1_c.dds, 1.san, ...). bdg 3rd 3rv mip chc cgc crash that editor (0xC0000005) and stay pending with that reason. test-resource-model-comparator now reports every golden file as 'the port did not export this file' because of layout only: the port exports under game-data folders (e.g. units/technics/common/entrenchment/trc/1.xml, objects/obt/1.xml, weapons/wpn.xml). Add a separate S16 task NOW, with its own task plan, that runs before T05: make CompareGoldenFolder align the two layouts — take the folder holding the port's main stats file as the port root, compare files by their path relative to that root, and map the port's main stats file to the golden's 1.xml where the port names it after the project (weapons) — then fix every real difference it reveals, field by field through the engine readers, or record a specific, verified reason per difference (e.g. the History block, MFC bugs we keep or deliberately do not copy) in the spec. msh reports 'no exporter' although S08 ported one: wire it. Record the 6 crashing kinds as pending-with-reason in PARITY. Report per kind: files compared, pass/fail. Verify with plain zig build commands only.
**Scope:** resolved
**Applied-at:** M001/S16 2026-10-06: separate task S16/T08 with its own task plan (tasks/T08-PLAN.md), ordered after T04 and before T05; T05 and T07 depend on it; D039. The comparator fix itself stays open until S16/T08 completes.

---

## Override: 2026-10-06T05:59:04.405Z

**Change:** Ordering for S16: T08 (align MFC goldens, fix or explain every difference) must complete before T05, T06 and T07. Record T05, T06 and T07 as depending on T08 in the task graph (T07 also depends on T02-T06 as stated before). Do not dispatch T05, T06 or T07 until T08 is complete.
**Scope:** resolved
**Applied-at:** M001/S16 2026-10-06: S16-PLAN and T05, T06, T07 plans state the dependency on T08 (T07 also on T02-T06); D040. T05-T07 are not dispatched until T08 is complete.

---

## Override: 2026-10-06T06:23:28.925Z

**Change:** Golden follow-up to S16/T08 (fold into T05, not a new slice): (1) The 'struct defaults' class is a fixture artefact, not an accepted difference: export-goldens.ps1 now (b?) lets MFC open and save each scratch fixture (-os) before exporting, so MFC writes its own cached <RPG>/<desc>; the goldens will be regenerated on win-home and committed by the maintainer. Do not record that class as accepted; mark wpn/trc/msh/obt/bld 'pending regeneration'. (2) Camera-dependent values (fnc origins, bld explosion noise, obt grids/packs) are not proven, so they must be 'pending' with that reason, not 'accepted'. Accepted is only for differences proven from MFC source and the golden bytes (e.g. %lg six-digit floats, the trc DXT5 solid-block encoding). Update PARITY and the spec accordingly.
**Scope:** resolved
**Applied-at:** M001/S16 2026-10-06: folded into T05 (T05-PLAN, S16-PLAN), D041, PARITY and spec amended; comparator code and the regenerated counts follow when T05 runs

---

## Override: 2026-10-06T06:34:53.449Z

**Change:** D-07 fidelity gap found with projects made by the MFC editor itself (commit 06a23287d, tools/zig/fixtures/resource_editor/mfc-new/: one empty project per editor, made by Johannes with the shipped reseditor.exe, byte-exact). MFC writes and reads <own_data> (export_dir/export_file_name plus frame data such as Front/Back/Begin/End for bridges) and the cached <RPG> stats block before History; it reads them unguarded on open, which is why the port-written bdg/mip/chc/cgc fixtures crash the shipped editor and why MFC's batch export of the other fixtures used struct defaults. Add a separate S16 task NOW with its own task plan, to run next and before T06 and T07: (1) every mfc-new project opens in the port, saves, and the saved bytes equal the input for an unedited save (D-07 goal; record any unavoidable difference with its reason); (2) the port's save writes <own_data> and the cached <RPG>/<desc> block in MFC's form and order for every kind, refreshed from the tree on each save, as CParentFrame::SaveFrame/SaveRPGStats do, so MFC can open every project the port writes; (3) re-save every fixture under tools/zig/fixtures/resource_editor/<ext>/project.<ext> through the port so they carry both blocks, and update the byte-identity expectations; (4) tests: each mfc-new project round-trips; each re-saved fixture contains own_data and RPG. The maintainer will then regenerate the MFC goldens on win-home from the re-saved fixtures. Verify with plain zig build commands only.
**Scope:** resolved
**Applied-at:** M001/S16 2026-10-06: separate task S16/T09 (tasks/T09-PLAN.md), ordered after T08 and before T05; T05, T06 and T07 depend on it; D042. The work itself runs when T09 is dispatched.

---

## Override: 2026-10-06T07:42:05.093Z

**Change:** Hold S16/T07 (delete the MFC editor): the maintainer is regenerating all 20 MFC goldens on win-home from the re-saved fixtures (44094bf22), and any differences they reveal must be traced against the MFC sources in Sources/src/editor before those are deleted. Do not dispatch T07 until a later steer explicitly releases it; if T05 and T06 finish first, stop and report T07 as waiting for the golden comparison (do not mark it blocked for approval: the approval D037 stands).
**Scope:** resolved
**Applied-at:** M001/S16 2026-10-06: S16-PLAN and T07-PLAN carry the hold, D043 recorded. Stays active until a later steer releases T07.

---

## Override: 2026-10-06T08:50:56.520Z

**Change:** New S16 task, add NOW as a separate task with its own task plan, sequence it before T07 (T07 stays on hold, D043). Context: the maintainer regenerated the MFC goldens from the re-saved fixtures (commit 3e98ebc19: 17 kinds, incl. mip chc cgc; bdg 3rd 3rv still crash MFC). test-resource-model-comparator (run at 3e98ebc19) reports pass=4 accepted=3 fail=0 pending=13, but much of 'pending' is stale or fixable: (1) Remove the stale pending rules: mip/chc/cgc now have goldens ('MFC crashed, none exists' is wrong); msh/obt/bld/wpn/trc 'pending regeneration' is wrong (regenerated with MFC's own cached stats via open-and-save). Compare them for real and fix or explain each difference. (2) Fix the fixtures so MFC exports their full content, each verified from MFC source and the golden: eff references a function particle 'particle-2key' that the installed data lacks (EffectFrm.cpp:215) - point it at a shipped particle or ship the particle in the fixture; scp golden holds only History because CSquadFrame::SaveRPGStats stops at MakeName (SquadFrm.cpp:198-216) for an unresolvable member - use a shipped unit; til needs editor\terrain\tilemask.tga in the editor data folder - add it to the fixture/scratch or document exactly which file the maintainer must place where; 3rd: texture terrain\sets\1\roads3d\road_asphalt01 does not exist in the shipped data (GOG paks have road_asphalt_city, road_asphalt_ground, road_asphalt_gravel, rail_road_grass/gravel) - use terrain\sets\1\roads3d\road_asphalt_city; 3rv: water\bottom does not exist (shipped: water\a_bottom, water\water) - use water\a_bottom; bdg crashes MFC already on open: compare its tree with tools/zig/fixtures/resource_editor/mfc-new/bridgetest.bdg (BridgeFrm.cpp:428-436 SpecificInit, 734-793 span parts back/front/bottom, 783 bottom sprite) and make every span carry its three part items and valid sprite references. Keep the port's tests green (update expectations where the fixture changes). (3) Camera-dependent values (fnc/bld/obt): reproduce MFC's IScene::GetPos2/GetPos3 with the editor's default camera (Scene/Camera.cpp, GraphicsEngine.cpp SetupViewport, as S08 T07 did) and compare; keep pending only what you cannot prove. The maintainer then re-runs export-goldens.ps1 on win-home. Verify with plain zig build commands only; report per kind.
**Scope:** resolved
**Applied-at:** M001/S16 2026-10-06: separate task S16/T10 (tasks/T10-PLAN.md), ordered after T09 and before T07; T07 depends on T10 and stays on hold; D044. The work itself runs when T10 is dispatched.

---

## Override: 2026-10-06T09:49:37.307Z

**Change:** Golden round 3 — add a separate S16 task NOW with its own task plan, sequenced before T07 (T07 stays on hold under D043; note: T07 was reopened by the maintainer because the previous run marked it complete without deleting anything — never complete T07 without performing it). New goldens for 18 kinds are committed (ae04873da), made from the T10 fixtures. Compare all 18 for real and fix or explain each difference. Remaining fixture problems MFC showed on win-home: (1) spt: MFC reports 'Can not find files total count 1 D:\...\spt\source\_.sprite-1frame.tga' — the sprite frame naming in the fixture does not match what CSpriteFrame expects (it searches '_.'+name); name/arrange the frame files as MFC's sprite editor does, so the golden carries the sprite. (2) 'Error: Some of files can not be opened art-16x16.tga' — art-16x16.tga is referenced by fnc and til; find which export opens it and why MFC's image loader rejects it (format, bit depth, RLE, size) and use art MFC can read. (3) 3rd and 3rv still crash MFC on export after the texture fix: MFC loads maps\road3d.xml / maps\river3d.xml and their terrain from the editor data folder (3dRoadFrm.cpp:243-289, 3dRiverFrm.cpp:204-225); the GOG install has them only inside data.pak; extend export-goldens.ps1's Place-EditorDataFile step to place the tracked Data/Maps/road3d.xml, river3d.xml and every file they reference (terrain set, textures) that the editor needs, and remove them afterwards; list the files in the script comment. (4) mip: the open-and-save step still crashes MFC (export from the unsaved fixture works) — find the cause in MissionFrm's open path and fix the fixture. (5) scp: replace the squad member USSR_Mosin with a unit present in the shipped GOG data (check Data/objects.xml against units that exist in the GOG paks) so the golden carries the squad. Keep the port's tests green. The maintainer then re-runs export-goldens.ps1 once more. Verify with plain zig build commands only; report per kind.
**Scope:** resolved
**Applied-at:** M001/S16 2026-10-06: separate task S16/T11 (tasks/T11-PLAN.md), ordered after T10 and before T07; T07 depends on T11 and stays on hold; D045. The work itself runs when T11 is dispatched.

---

## Override: 2026-10-06T09:54:42.313Z

**Change:** Golden round 3 — add a separate S16 task NOW with its own task plan, sequenced before T07 (T07 stays on hold under D043; note: T07 was reopened by the maintainer because the previous run marked it complete without deleting anything — never complete T07 without performing it). New goldens for 18 kinds are committed (ae04873da), made from the T10 fixtures. Compare all 18 for real and fix or explain each difference. Remaining fixture problems MFC showed on win-home: (1) spt: MFC reports 'Can not find files total count 1 D:\...\spt\source\_.sprite-1frame.tga' — the sprite frame naming in the fixture does not match what CSpriteFrame expects (it searches '_.'+name); name/arrange the frame files as MFC's sprite editor does, so the golden carries the sprite. (2) 'Error: Some of files can not be opened art-16x16.tga' — art-16x16.tga is referenced by fnc and til; find which export opens it and why MFC's image loader rejects it (format, bit depth, RLE, size) and use art MFC can read. (3) 3rd and 3rv still crash MFC on export after the texture fix: MFC loads maps\road3d.xml / maps\river3d.xml and their terrain from the editor data folder (3dRoadFrm.cpp:243-289, 3dRiverFrm.cpp:204-225); the GOG install has them only inside data.pak; extend export-goldens.ps1's Place-EditorDataFile step to place the tracked Data/Maps/road3d.xml, river3d.xml and every file they reference (terrain set, textures) that the editor needs, and remove them afterwards; list the files in the script comment. (4) mip: the open-and-save step still crashes MFC (export from the unsaved fixture works) — find the cause in MissionFrm's open path and fix the fixture. (5) scp: replace the squad member USSR_Mosin with a unit present in the shipped GOG data (check Data/objects.xml against units that exist in the GOG paks) so the golden carries the squad. Keep the port's tests green. The maintainer then re-runs export-goldens.ps1 once more. Verify with plain zig build commands only; report per kind.
**Scope:** resolved
**Applied-at:** M001/S16 2026-10-06: separate task S16/T11 (tasks/T11-PLAN.md), ordered after T10 and before T07; T07 depends on T11 and stays on hold; D045. The work itself runs when T11 is dispatched.

---

## Override: 2026-10-06T12:06:31.188Z

**Change:** Golden round 4 — add a separate S16 task NOW with its own task plan (T07 stays on hold under D043; never complete T07 without performing it). All 20 kinds now have an MFC golden (22a9eba5b; 3rd and 3rv were exported by hand in MFC's GUI because its batch export of 3D roads and rivers crashes even for projects MFC made itself — record that in the spec and PARITY). test-resource-model-comparator at 22a9eba5b: pass=9 accepted=7 fail=1 pending=3. (1) 3rd FAIL: VSODescription/SoilParams port 16, golden 0 — find in 3dRoadFrm.cpp (FillRPGStats/SaveRPGStats/ExportFrameData) how MFC computes or resets SoilParams on export and port that; road and river use the same VSO code path, so check rivers too. (2) spt and til: their goldens now carry the real export (spt: 1.san + 1_c/_h/_l.dds; til: 1_*.dds + crosset.xml + crosset_*.dds) — remove the stale pending rules and compare them for real. (3) scp: the golden still holds only History; the GOG data has USSR_Mosin (data.pak objects.xml lists it and Units/Humans/USSR/Mosin exists), so the cause is elsewhere in CSquadFrame::SaveRPGStats/MakeName (SquadFrm.cpp:198-216) — find it and fix the fixture so the next win-home run exports the squad; if it needs a win-home re-run, say exactly which kind. Fix or explain every difference with source-verified reasons. Verify with plain zig build commands only; report per kind.
**Scope:** resolved
**Applied-at:** none/none/none

---

## Override: 2026-10-06T12:11:36.156Z

**Change:** Golden round 4 — add a separate S16 task NOW with its own task plan (T07 stays on hold under D043; never complete T07 without performing it). All 20 kinds now have an MFC golden (22a9eba5b; 3rd and 3rv were exported by hand in MFC's GUI because its batch export of 3D roads and rivers crashes even for projects MFC made itself — record that in the spec and PARITY). test-resource-model-comparator at 22a9eba5b: pass=9 accepted=7 fail=1 pending=3. (1) 3rd FAIL: VSODescription/SoilParams port 16, golden 0 — find in 3dRoadFrm.cpp (FillRPGStats/SaveRPGStats/ExportFrameData) how MFC computes or resets SoilParams on export and port that; road and river use the same VSO code path, so check rivers too. (2) spt and til: their goldens now carry the real export (spt: 1.san + 1_c/_h/_l.dds; til: 1_*.dds + crosset.xml + crosset_*.dds) — remove the stale pending rules and compare them for real. (3) scp: the golden still holds only History; the GOG data has USSR_Mosin (data.pak objects.xml lists it and Units/Humans/USSR/Mosin exists), so the cause is elsewhere in CSquadFrame::SaveRPGStats/MakeName (SquadFrm.cpp:198-216) — find it and fix the fixture so the next win-home run exports the squad; if it needs a win-home re-run, say exactly which kind. Fix or explain every difference with source-verified reasons. Verify with plain zig build commands only; report per kind.
**Scope:** resolved
**Applied-at:** none/none/none

---

## Override: 2026-10-06T13:29:33.740Z

**Change:** Golden round 5 — add a separate S16 task NOW with its own task plan, before T07 (T07 stays on hold under D043; never complete T07 without performing it). (1) REAL PORT BUG, proven on win-home: MFC writes a bool tree value as <value type="8" flag="9" ...> but the port writes type="8" flag="8" (compare tools/zig/fixtures/resource_editor/mfc-new/roadtest.3rd with 3rd/project.3rd). MFC reads the port's bool as false: opening D:\...\3rd\project.3rd in MFC's Road editor shows 'Has dust effect' false although int_value="1", and its export gives SoilParams 0; MFC's own roadtest.3rd (flag=9, dust true) exports SoilParams 16 (check-roadtest.xml, 20:28). So the 3rd golden's SoilParams 0 is caused by the port's file, not an MFC defect; T12's 'pending, unproven' for 3rd is wrong. Find in MFC's CVariant/tree serialisation what flag means for each value type, make the port write exactly MFC's flag for every type (compare every <value type= flag=> pair across all mfc-new projects against the port's output), re-save all fixtures, update byte-identity expectations, and add a test that every bool written by the port carries MFC's flag. (2) Compare the new scp and til goldens (commit 4221882f8) for real and fix or explain each difference. (3) List exactly which kinds need a new win-home export after the re-save (batch via export-goldens.ps1, and 3rd/3rv by hand in MFC's GUI). Verify with plain zig build commands only; report per kind.
**Scope:** resolved
**Applied-at:** none/none/none

---

## Override: 2026-10-06T13:34:38.781Z

**Change:** Golden round 5 — add a separate S16 task NOW with its own task plan, before T07 (T07 stays on hold under D043; never complete T07 without performing it). (1) REAL PORT BUG, proven on win-home: MFC writes a bool tree value as <value type="8" flag="9" ...> but the port writes type="8" flag="8" (compare tools/zig/fixtures/resource_editor/mfc-new/roadtest.3rd with 3rd/project.3rd). MFC reads the port's bool as false: opening D:\...\3rd\project.3rd in MFC's Road editor shows 'Has dust effect' false although int_value="1", and its export gives SoilParams 0; MFC's own roadtest.3rd (flag=9, dust true) exports SoilParams 16 (check-roadtest.xml, 20:28). So the 3rd golden's SoilParams 0 is caused by the port's file, not an MFC defect; T12's 'pending, unproven' for 3rd is wrong. Find in MFC's CVariant/tree serialisation what flag means for each value type, make the port write exactly MFC's flag for every type (compare every <value type= flag=> pair across all mfc-new projects against the port's output), re-save all fixtures, update byte-identity expectations, and add a test that every bool written by the port carries MFC's flag. (2) Compare the new scp and til goldens (commit 4221882f8) for real and fix or explain each difference. (3) List exactly which kinds need a new win-home export after the re-save (batch via export-goldens.ps1, and 3rd/3rv by hand in MFC's GUI). Verify with plain zig build commands only; report per kind.
**Scope:** resolved
**Applied-at:** none/none/none

---

## Override: 2026-10-06T13:39:48.805Z

**Change:** Golden round 5 — add a separate S16 task NOW with its own task plan, before T07 (T07 stays on hold under D043; never complete T07 without performing it). (1) REAL PORT BUG, proven on win-home: MFC writes a bool tree value as <value type="8" flag="9" ...> but the port writes type="8" flag="8" (compare tools/zig/fixtures/resource_editor/mfc-new/roadtest.3rd with 3rd/project.3rd). MFC reads the port's bool as false: opening D:\...\3rd\project.3rd in MFC's Road editor shows 'Has dust effect' false although int_value="1", and its export gives SoilParams 0; MFC's own roadtest.3rd (flag=9, dust true) exports SoilParams 16 (check-roadtest.xml, 20:28). So the 3rd golden's SoilParams 0 is caused by the port's file, not an MFC defect; T12's 'pending, unproven' for 3rd is wrong. Find in MFC's CVariant/tree serialisation what flag means for each value type, make the port write exactly MFC's flag for every type (compare every <value type= flag=> pair across all mfc-new projects against the port's output), re-save all fixtures, update byte-identity expectations, and add a test that every bool written by the port carries MFC's flag. (2) Compare the new scp and til goldens (commit 4221882f8) for real and fix or explain each difference. (3) List exactly which kinds need a new win-home export after the re-save (batch via export-goldens.ps1, and 3rd/3rv by hand in MFC's GUI). Verify with plain zig build commands only; report per kind.
**Scope:** resolved
**Applied-at:** none/none/none

---

## Override: 2026-10-06T15:07:35.775Z

**Change:** Golden round 6 (last before T07) — add a separate S16 task NOW with its own task plan, before T07 (T07 stays on hold under D043; never complete T07 without performing it). All 20 MFC goldens are committed (last: 9c6f92f9e, 3rd and 3rv exported by hand in MFC's GUI). Comparator at 9c6f92f9e: pass=10 accepted=9 fail=0 pending=1 (3rd SoilParams). (1) 3rd: PROVEN upstream MFC bug, record as accepted with this reason: upstream C3DRoadCommonPropsItem::SetSoilParams (Sources/src/editor/3dRoadTreeItem.h at 7f0f4be5c) reads 'values[12].value = ( nVal & SVectorStripeObjectDesc::ESP_DUST != 0x0 )'; C++ parses that as nVal & (ESP_DUST != 0) == nVal & 1, so with ESP_DUST=0x10 and ESP_TRACE=0x01 MFC loads dust as false (and both flags as true when the trace bit is set) on every project load (LoadRPGStats -> GetRPGStats -> SetSoilParams); a new project shows dust true, saves SoilParams 16, and after reopening shows false and exports 0 (verified by Johannes on win-home with six test files). This repo fixed the precedence in aea2ebc4c; the port keeps the stored value (16) by decision of Johannes: 'we are not taking over this bug, we are going to fix it'. (2) Search the upstream MFC sources (git show 7f0f4be5c:...) for the same precedence pattern (x & FLAG != 0, x & FLAG == 0, and similar) in every editor; list each hit, say whether this repo already fixed it and whether the port behaves like the fixed form; record the list in the spec. (3) File-name case: Johannes decided the port keeps names and paths in the case written ('appropriate for modern OS'); MFC lowercases file names and stored paths on save. Record that decision in the spec, and make the golden comparator match MFC's lowercased file names to the port's names case-insensitively where needed. Then report the final per-kind table. Verify with plain zig build commands only.
**Scope:** resolved
**Applied-at:** M001/S16 2026-10-06: separate task S16/T14 (tasks/T14-PLAN.md), ordered after T13 and before T07; T07 depends on T14 and stays on hold; D048. The work itself runs when T14 is dispatched.

---

## Override: 2026-10-06T15:09:44.586Z

**Change:** Port batch export must work for every kind (Johannes: 'This will matter for our port, it should work there. I do not care about the original.'). Add a separate S16 task NOW with its own task plan, before T07 (T07 stays on hold under D043; never complete T07 without performing it). Today: resource-editor-batch (--batch-check) re-saves all 21 kinds with -os but exports only wpn; test-resource-bridge's BkResBatch case exports only mdc/wpn/pcp; resource-editor-batch is in neither .github/workflows/cross-platform.yml nor tools/zig/run-resource-sweep.sh. MFC's batch export crashes on 3rd/3rv (UpdateRoadView/UpdateRiverView dereference the GUI tree, null in batch) — the port must not have that class of bug: export must never depend on UI or view state. Do: (1) the batch (CLI --batch and BkResBatch, which the in-app Tools > Batch mode uses) exports every kind with an exporter, incl. 3rd and 3rv, from a folder of all fixtures with force, with no project open and with a project of the same kind open in the app; (2) each batch output equals the single export (BkResExport) of the same fixture byte for byte, and is read back by the engine's own reader; (3) a batch over a mixed folder reports per project and continues past a failing project; (4) add resource-editor-batch to CI and to the sweep script. Keep it under the 3-minute tier budget or split it. Verify with plain zig build commands only.
**Scope:** resolved
**Applied-at:** M001/S16 2026-10-06: separate task S16/T15 (tasks/T15-PLAN.md), ordered after T14 and before T07; T07 depends on T15 and stays on hold; D049. The work itself runs when T15 is dispatched.

---

## Override: 2026-10-06T16:12:07.764Z

**Change:** RELEASE of S16/T07 (lifts the hold D043). The golden comparison is complete: all 20 MFC goldens are committed and test-resource-model-comparator at b8aa895bb reports pass=10 accepted=10 fail=0 pending=0; the maintainer's full Linux sweep at b8aa895bb is VERDICT=PASS (41 tiers). Johannes approved the deletion (D037). Dispatch T07 now, alone, and perform it exactly as its plan says: record PRE_DELETE as the HEAD hash before the deletion commit, delete the MFC editor as the phase context describes, keep every test and fixture that does not need the MFC sources, keep the build green on Linux (run the touched tiers in the foreground), and record PRE_DELETE in the spec and PARITY as the commit from which MFC goldens can be regenerated. Never mark T07 complete unless the deletion was actually performed and committed.
**Scope:** resolved
**Applied-at:** none/none/none

---

## Override: 2026-10-06T16:52:41.833Z

**Change:** S16/T07 was performed in the release steer session: commit c6b4329c6 'chore(resource-editor): remove the MFC editor' deletes Sources/src/editor and both MFC editor.exe binaries, PRE_DELETE=b8aa895bb. Mark T07 complete from that commit (cite it; run the touched tiers in the foreground if you need evidence). Then, before or while completing the slice: replace the placeholder 'PRE_DELETE = <filled by S16/T07>' in docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md with b8aa895bb00efb2fdac28096656dcf26984e3f87, and correct the stale line saying bdg 3rd 3rv mip chc cgc goldens are missing (all 20 exist; 3rd and 3rv were exported by hand in MFC's GUI because MFC's batch export of them crashes). The maintainer runs the full sweep on c6b4329c6.
**Scope:** resolved
**Applied-at:** none/none/none

---

## Override: 2026-10-06T16:57:59.779Z

**Change:** Complete slice M001/S16 now, in this session. All 15 tasks are complete (T07 = c6b4329c6, the MFC deletion; PRE_DELETE=b8aa895bb). Auto-mode's complete-slice unit keeps being flagged as stuck before it starts, so do the complete-slice work here: write S16-SUMMARY.md and S16-UAT.md from the task summaries (cite only commands really run; the maintainer's full Linux sweep at b8aa895bb was VERDICT=PASS with 41 tiers, the one at c6b4329c6 is running), and call the GSD slice-completion tool so S16 is marked [x] in M001-ROADMAP.md. Do not reset the slice or re-run tasks. Commit with a conventional message.
**Scope:** resolved
**Applied-at:** none/none/none

---

## Override: 2026-10-06T17:20:29.189Z

**Change:** M001 validation is needs-attention. Johannes' decisions (2026-10-07): (a) the macOS/Windows hand try is deferred: 'we get it working with CI and then see' — record this as a decision, not as missing evidence; (b) CI: the cross-platform workflow now runs on feat/** pushes (d808f0805); run https://github.com/jmfrank63/Blitzkrieg/actions/runs/37502565127 is in progress — the maintainer will relay its result, do not claim it; (c) INTEX2 is not available anywhere (not on win-home, not found on the web); replace B-09.14 and B-14.5 with a third-party mod round trip on the AchtungPanzer2 mod, unpacked at /home/johannes/Downloads/achtung_panzer_2_ostfront/AchtungPanzer2/data (game data only, no editor projects; never commit or copy its files into the repo): a test tier, found through an environment variable such as BK_MOD_ROOT and reporting 'skipped: no mod' without it, that imports every resource of each importable kind from the mod (read-only, scratch copies under zig-out/local-test), exports it again and compares it with the mod's file field by field through the engine's own readers, listing differences with reasons; run it here with BK_MOD_ROOT set and report counts per kind. Plan this as remediation for M001 (a new slice or tasks), together with: refreshing the stale 06-PARITY header and the per-kind 'golden pending win-home' texts (all 20 goldens exist), and updating .planning/STATE.md to the real end state (S16 complete, MFC deleted in c6b4329c6, PRE_DELETE b8aa895bb, comparator pass=10 accepted=10 fail=0 pending=0, maintainer's full Linux sweep at c6b4329c6 VERDICT=PASS 41 tiers). Verify with plain zig build commands only.
**Scope:** resolved
**Applied-at:** M001/S17 2026-10-07: decisions D052 (hand try deferred until CI works; CI run 37502565127 relayed by the maintainer) and D053 (AchtungPanzer2 mod round trip replaces B-09.14/B-14.5); remediation slice S17 added to M001-ROADMAP (T01 tier, T02 real mod run with per-kind counts, T03 PARITY/spec/.planning/STATE.md refresh). The work itself runs when S17 is dispatched.

---

## Override: 2026-10-06T18:01:06.540Z

**Change:** S17 T02 accepted too much. Johannes' rule: port bugs are fixed, not accepted ('we are not taking over this bug, we are going to fix it'). Add a separate S17 task NOW with its own task plan, before T03, and fix these as PORT BUGS with tests: (1) cgc: an imported MapImage under scenarios\custom is exported with the project prefix added a second time - the export must write the path the game reads (round trip equal); (2) 3rv: the mod's MiniMapBorderColor is lost on import->export - keep every field the engine reader reads, even if MFC's river frame had no UI for it (store it, write it back unchanged); (3) unt and msh refuse import when KeyName is empty - same bug class S11/T07 fixed for buildings (an empty KeyName is a valid value, the import label comes from the folder); import them and round-trip them. Then (4) re-justify every remaining accept rule file by file, not class-level: for scp (0 of 86 equal), unt (0/67), msh (0/377), bdg (0/23), fnc and pcp list per file which fields differ and why; an accept rule is allowed only for a difference proven from the engine source or the mod's own bytes for that file (e.g. the mod's stats contradict its own .mod); anything else is a port bug to fix. Report the per-kind table again (found/imported/equal/accepted/failed) and the list of fixes. Verify with plain zig build commands only.
**Scope:** resolved
**Applied-at:** M001/S17 2026-10-07: D054 recorded; S17 replanned: new T03 (port-bug fixes plus per-file accept re-justification) before the docs task, which is now T04. T02 stays complete but its accept table is superseded by T03. The work runs when T03 is dispatched.

---

## Override: 2026-10-06T18:40:01.221Z

**Change:** CI on feat/resource-editor is red (run 37507439455 at 162a7f0a4; Windows MinGW passes). Add a separate S17 task NOW with its own task plan, before the docs task, to make every CI job green. Two causes, both reproduced by the maintainer: (1) Linux x86_64, Linux ARM (and very likely macOS arm64's 'Resource bridge tier') fail because .github/workflows/cross-platform.yml checks out a sparse tree (sparse-checkout list near the top of each job: only Data/Maps, Data/Terrain/sets/*/{tileset,crosset}.xml, Roads3D/Rivers xml, Data/Scenarios) while test-resource-model and test-resource-bridge read shipped Data (partys.xml / Player side lists, objects, units, weapons, effects, Editor/TestProjects, ...). Reproduce exactly: in /tmp/bk-cmp (a worktree already set to that sparse list) run 'zig build test-resource-model -Dtest-mode=run' -> CChapterCommonPropsItem/CCampaignCommonPropsItem 'Player side' combo count FAILs and an uncaught std::filesystem_error from a directory_iterator on a missing Data folder (abort). Fix: list in every job's sparse-checkout exactly the Data paths each resource tier needs (keep it minimal, no full Data), AND make no tier ever abort on a missing data folder (report a FAIL naming the missing path instead of an uncaught exception); prove it by running the tiers in the sparse /tmp/bk-cmp worktree with the new list (update that worktree's sparse list with 'git sparse-checkout set --no-cone --stdin'). (2) Windows MSVC fails 'Editor core tier': test-editor-core compiles its test for 'native' (ignores -Dtarget) and pulls in Dear ImGui via the editor kit, whose default IME hook needs imm32, which only the MapEditor exe links (build.zig ~9797); locally lld-link reports "could not open 'libimm32.a'". Fix: build the editor test tiers for the requested target and link imm32 (or define IMGUI_DISABLE_WIN32_DEFAULT_IME_FUNCTIONS for test builds) for Windows targets. You can reproduce Windows natively: ssh win-home; worktree D:\bk-ci (git -C D:\bk-ci fetch is not needed: run 'git -C C:\Users\jmfrank\source\repos\jmfrank63\Blitzkrieg fetch origin feat/resource-editor' then 'git -C D:\bk-ci checkout --detach FETCH_HEAD' after you commit and the maintainer pushes; or copy changed files with scp), Zig 0.16 at C:\Users\jmfrank\scoop\apps\zig\0.16.0\zig.exe (the default zig there is 0.17, do not use it); run e.g. 'zig build test-editor-core -Dtarget=x86_64-windows-msvc -Dtest-mode=run' in D:\bk-ci. Do not push; the maintainer pushes and relays the CI result. Verify with plain zig build commands only.
**Scope:** resolved
**Applied-at:** M001/S17 2026-10-07: D055 recorded; S17 replanned: new T04 (CI green on every job) before the docs task, which is now T05. The work itself runs when T04 is dispatched.

---

## Override: 2026-10-06T19:47:58.867Z

**Change:** CI follow-up to S17/T04 (add a separate S17 task NOW with its own task plan): run 37521060859 at c70116a62 — Windows MinGW now FAILS 'Editor core tier' (it passed before T04). Reproduced on win-home with zig 0.16 at C:\Users\jmfrank\scoop\apps\zig\0.16.0\zig.exe in D:\bk-ci: 'zig build test-editor-core -Dtarget=x86_64-windows-gnu -Dtest-mode=run' -> 'compile test Debug native': unable to find dynamic system library 'vcruntimed' (the test command carries -lvcruntimed). Causes: T04 links vcruntimed for editor_kit/editor_core/resource_core on every Windows target instead of only abi == .msvc, and the editor test tiers still compile for 'native' instead of the requested -Dtarget. Fix both: link MSVC runtime libraries only for abi == .msvc (and imm32 only where the target's toolchain provides it; for a GNU target either link imm32 the way the MapEditor exe already succeeds on MinGW, or define IMGUI_DISABLE_WIN32_DEFAULT_IME_FUNCTIONS), and build every test tier for the requested target. Prove on win-home over ssh (update D:\bk-ci with: git -C C:\Users\jmfrank\source\repos\jmfrank63\Blitzkrieg fetch origin feat/resource-editor; git -C D:\bk-ci reset --hard FETCH_HEAD — or scp your changed files into D:\bk-ci before the maintainer pushes) for both -Dtarget=x86_64-windows-gnu and -Dtarget=x86_64-windows-msvc, and on Linux for the native tiers. Do not push; the maintainer pushes and relays CI. Verify with plain zig build commands only.
**Scope:** resolved
**Applied-at:** none/none/none

---

## Override: 2026-10-06T19:53:04.333Z

**Change:** CI follow-up to S17/T04 (add a separate S17 task NOW with its own task plan): run 37521060859 at c70116a62 — Windows MinGW now FAILS 'Editor core tier' (it passed before T04). Reproduced on win-home with zig 0.16 at C:\Users\jmfrank\scoop\apps\zig\0.16.0\zig.exe in D:\bk-ci: 'zig build test-editor-core -Dtarget=x86_64-windows-gnu -Dtest-mode=run' -> 'compile test Debug native': unable to find dynamic system library 'vcruntimed' (the test command carries -lvcruntimed). Causes: T04 links vcruntimed for editor_kit/editor_core/resource_core on every Windows target instead of only abi == .msvc, and the editor test tiers still compile for 'native' instead of the requested -Dtarget. Fix both: link MSVC runtime libraries only for abi == .msvc (and imm32 only where the target's toolchain provides it; for a GNU target either link imm32 the way the MapEditor exe already succeeds on MinGW, or define IMGUI_DISABLE_WIN32_DEFAULT_IME_FUNCTIONS), and build every test tier for the requested target. Prove on win-home over ssh (update D:\bk-ci with: git -C C:\Users\jmfrank\source\repos\jmfrank63\Blitzkrieg fetch origin feat/resource-editor; git -C D:\bk-ci reset --hard FETCH_HEAD — or scp your changed files into D:\bk-ci before the maintainer pushes) for both -Dtarget=x86_64-windows-gnu and -Dtarget=x86_64-windows-msvc, and on Linux for the native tiers. Do not push; the maintainer pushes and relays CI. Verify with plain zig build commands only.
**Scope:** resolved
**Applied-at:** M001/S18/T01 (D056); re-issues of the 2026-10-06T19:47 steer, already covered by S18-PLAN and T01-PLAN
**Applied-at:** none/none/none

---

## Override: 2026-10-06T19:58:14.626Z

**Change:** CI follow-up to S17/T04 (add a separate S17 task NOW with its own task plan): run 37521060859 at c70116a62 — Windows MinGW now FAILS 'Editor core tier' (it passed before T04). Reproduced on win-home with zig 0.16 at C:\Users\jmfrank\scoop\apps\zig\0.16.0\zig.exe in D:\bk-ci: 'zig build test-editor-core -Dtarget=x86_64-windows-gnu -Dtest-mode=run' -> 'compile test Debug native': unable to find dynamic system library 'vcruntimed' (the test command carries -lvcruntimed). Causes: T04 links vcruntimed for editor_kit/editor_core/resource_core on every Windows target instead of only abi == .msvc, and the editor test tiers still compile for 'native' instead of the requested -Dtarget. Fix both: link MSVC runtime libraries only for abi == .msvc (and imm32 only where the target's toolchain provides it; for a GNU target either link imm32 the way the MapEditor exe already succeeds on MinGW, or define IMGUI_DISABLE_WIN32_DEFAULT_IME_FUNCTIONS), and build every test tier for the requested target. Prove on win-home over ssh (update D:\bk-ci with: git -C C:\Users\jmfrank\source\repos\jmfrank63\Blitzkrieg fetch origin feat/resource-editor; git -C D:\bk-ci reset --hard FETCH_HEAD — or scp your changed files into D:\bk-ci before the maintainer pushes) for both -Dtarget=x86_64-windows-gnu and -Dtarget=x86_64-windows-msvc, and on Linux for the native tiers. Do not push; the maintainer pushes and relays CI. Verify with plain zig build commands only.
**Scope:** resolved
**Applied-at:** M001/S18/T01 (D056); re-issues of the 2026-10-06T19:47 steer, already covered by S18-PLAN and T01-PLAN
**Applied-at:** none/none/none

---

## Override: 2026-10-06T20:03:29.594Z

**Change:** CI follow-up to S17/T04 (add a separate S17 task NOW with its own task plan): run 37521060859 at c70116a62 — Windows MinGW now FAILS 'Editor core tier' (it passed before T04). Reproduced on win-home with zig 0.16 at C:\Users\jmfrank\scoop\apps\zig\0.16.0\zig.exe in D:\bk-ci: 'zig build test-editor-core -Dtarget=x86_64-windows-gnu -Dtest-mode=run' -> 'compile test Debug native': unable to find dynamic system library 'vcruntimed' (the test command carries -lvcruntimed). Causes: T04 links vcruntimed for editor_kit/editor_core/resource_core on every Windows target instead of only abi == .msvc, and the editor test tiers still compile for 'native' instead of the requested -Dtarget. Fix both: link MSVC runtime libraries only for abi == .msvc (and imm32 only where the target's toolchain provides it; for a GNU target either link imm32 the way the MapEditor exe already succeeds on MinGW, or define IMGUI_DISABLE_WIN32_DEFAULT_IME_FUNCTIONS), and build every test tier for the requested target. Prove on win-home over ssh (update D:\bk-ci with: git -C C:\Users\jmfrank\source\repos\jmfrank63\Blitzkrieg fetch origin feat/resource-editor; git -C D:\bk-ci reset --hard FETCH_HEAD — or scp your changed files into D:\bk-ci before the maintainer pushes) for both -Dtarget=x86_64-windows-gnu and -Dtarget=x86_64-windows-msvc, and on Linux for the native tiers. Do not push; the maintainer pushes and relays CI. Verify with plain zig build commands only.
**Scope:** resolved
**Applied-at:** M001/S18/T01 (D056); re-issues of the 2026-10-06T19:47 steer, already covered by S18-PLAN and T01-PLAN
**Applied-at:** none/none/none

---

## Override: 2026-10-06T20:28:35.990Z

**Change:** Add a separate S18 task NOW with its own task plan: the ResourceModel does not compile for Windows MSVC. Reproduced by the maintainer on win-home (D:\bk-ci at c70116a62, zig 0.16 C:\Users\jmfrank\scoop\apps\zig\0.16.0\zig.exe, BK_REQUIRE_ENGINE=1, 'zig build test-editor-bridge -Dtarget=x86_64-windows-msvc -Dtest-mode=run'): 'expected unqualified-id' at std::min/std::max in Sources/src/ResourceModel/compose.cpp:491, items/building/building_export.cpp:412-432 and :589, items/bridge/bridge_export.cpp:255-257 (and more), and 'too few arguments provided to function-like macro invocation' plus an incompatible-operands error in items/stats_export.cpp:233 — windows.h's min/max macros. Fix it the way the engine already does for its own sources (check how existing Sources/src code avoids min/max macros: NOMINMAX on the ResourceModel/EditorBridge compile flags, or (std::min)(...) / std::max<T>(...)), across all of Sources/src/ResourceModel and Sources/src/EditorBridge, and add a cheap guard so it cannot come back (e.g. a Windows cross-compile of the ResourceModel library in a fast tier, or a grep-style lint test for bare std::min(/std::max( in those folders). Prove it natively on win-home over ssh: copy your changed files into D:\bk-ci (it is a detached worktree at c70116a62; 'git -C D:\bk-ci reset --hard <sha>' after the maintainer pushes, or scp the files), then run with the 0.16 zig for -Dtarget=x86_64-windows-msvc: test-resource-model, test-resource-bridge, test-editor-bridge (BK_REQUIRE_ENGINE=1) and test-editor-core; and -Dtarget=x86_64-windows-gnu test-editor-core. Before completing, 'git status' must show no file you touched as modified or untracked (AGENTS.md). Do not push; the maintainer pushes and relays CI. Verify with plain zig build commands only.
**Scope:** resolved
**Applied-at:** M001/S18/T02 (D057); 20:33 and 20:38 are re-issues of the 20:28 steer

---

## Override: 2026-10-06T20:33:41.323Z

**Change:** Add a separate S18 task NOW with its own task plan: the ResourceModel does not compile for Windows MSVC. Reproduced by the maintainer on win-home (D:\bk-ci at c70116a62, zig 0.16 C:\Users\jmfrank\scoop\apps\zig\0.16.0\zig.exe, BK_REQUIRE_ENGINE=1, 'zig build test-editor-bridge -Dtarget=x86_64-windows-msvc -Dtest-mode=run'): 'expected unqualified-id' at std::min/std::max in Sources/src/ResourceModel/compose.cpp:491, items/building/building_export.cpp:412-432 and :589, items/bridge/bridge_export.cpp:255-257 (and more), and 'too few arguments provided to function-like macro invocation' plus an incompatible-operands error in items/stats_export.cpp:233 — windows.h's min/max macros. Fix it the way the engine already does for its own sources (check how existing Sources/src code avoids min/max macros: NOMINMAX on the ResourceModel/EditorBridge compile flags, or (std::min)(...) / std::max<T>(...)), across all of Sources/src/ResourceModel and Sources/src/EditorBridge, and add a cheap guard so it cannot come back (e.g. a Windows cross-compile of the ResourceModel library in a fast tier, or a grep-style lint test for bare std::min(/std::max( in those folders). Prove it natively on win-home over ssh: copy your changed files into D:\bk-ci (it is a detached worktree at c70116a62; 'git -C D:\bk-ci reset --hard <sha>' after the maintainer pushes, or scp the files), then run with the 0.16 zig for -Dtarget=x86_64-windows-msvc: test-resource-model, test-resource-bridge, test-editor-bridge (BK_REQUIRE_ENGINE=1) and test-editor-core; and -Dtarget=x86_64-windows-gnu test-editor-core. Before completing, 'git status' must show no file you touched as modified or untracked (AGENTS.md). Do not push; the maintainer pushes and relays CI. Verify with plain zig build commands only.
**Scope:** resolved
**Applied-at:** M001/S18/T02 (D057); 20:33 and 20:38 are re-issues of the 20:28 steer

---

## Override: 2026-10-06T20:38:51.607Z

**Change:** Add a separate S18 task NOW with its own task plan: the ResourceModel does not compile for Windows MSVC. Reproduced by the maintainer on win-home (D:\bk-ci at c70116a62, zig 0.16 C:\Users\jmfrank\scoop\apps\zig\0.16.0\zig.exe, BK_REQUIRE_ENGINE=1, 'zig build test-editor-bridge -Dtarget=x86_64-windows-msvc -Dtest-mode=run'): 'expected unqualified-id' at std::min/std::max in Sources/src/ResourceModel/compose.cpp:491, items/building/building_export.cpp:412-432 and :589, items/bridge/bridge_export.cpp:255-257 (and more), and 'too few arguments provided to function-like macro invocation' plus an incompatible-operands error in items/stats_export.cpp:233 — windows.h's min/max macros. Fix it the way the engine already does for its own sources (check how existing Sources/src code avoids min/max macros: NOMINMAX on the ResourceModel/EditorBridge compile flags, or (std::min)(...) / std::max<T>(...)), across all of Sources/src/ResourceModel and Sources/src/EditorBridge, and add a cheap guard so it cannot come back (e.g. a Windows cross-compile of the ResourceModel library in a fast tier, or a grep-style lint test for bare std::min(/std::max( in those folders). Prove it natively on win-home over ssh: copy your changed files into D:\bk-ci (it is a detached worktree at c70116a62; 'git -C D:\bk-ci reset --hard <sha>' after the maintainer pushes, or scp the files), then run with the 0.16 zig for -Dtarget=x86_64-windows-msvc: test-resource-model, test-resource-bridge, test-editor-bridge (BK_REQUIRE_ENGINE=1) and test-editor-core; and -Dtarget=x86_64-windows-gnu test-editor-core. Before completing, 'git status' must show no file you touched as modified or untracked (AGENTS.md). Do not push; the maintainer pushes and relays CI. Verify with plain zig build commands only.
**Scope:** resolved
**Applied-at:** M001/S18/T02 (D057); 20:33 and 20:38 are re-issues of the 20:28 steer

---

## Override: 2026-10-06T20:44:06.563Z

**Change:** Add a separate S18 task NOW with its own task plan: the ResourceModel does not compile for Windows MSVC. Reproduced by the maintainer on win-home (D:\bk-ci at c70116a62, zig 0.16 C:\Users\jmfrank\scoop\apps\zig\0.16.0\zig.exe, BK_REQUIRE_ENGINE=1, 'zig build test-editor-bridge -Dtarget=x86_64-windows-msvc -Dtest-mode=run'): 'expected unqualified-id' at std::min/std::max in Sources/src/ResourceModel/compose.cpp:491, items/building/building_export.cpp:412-432 and :589, items/bridge/bridge_export.cpp:255-257 (and more), and 'too few arguments provided to function-like macro invocation' plus an incompatible-operands error in items/stats_export.cpp:233 — windows.h's min/max macros. Fix it the way the engine already does for its own sources (check how existing Sources/src code avoids min/max macros: NOMINMAX on the ResourceModel/EditorBridge compile flags, or (std::min)(...) / std::max<T>(...)), across all of Sources/src/ResourceModel and Sources/src/EditorBridge, and add a cheap guard so it cannot come back (e.g. a Windows cross-compile of the ResourceModel library in a fast tier, or a grep-style lint test for bare std::min(/std::max( in those folders). Prove it natively on win-home over ssh: copy your changed files into D:\bk-ci (it is a detached worktree at c70116a62; 'git -C D:\bk-ci reset --hard <sha>' after the maintainer pushes, or scp the files), then run with the 0.16 zig for -Dtarget=x86_64-windows-msvc: test-resource-model, test-resource-bridge, test-editor-bridge (BK_REQUIRE_ENGINE=1) and test-editor-core; and -Dtarget=x86_64-windows-gnu test-editor-core. Before completing, 'git status' must show no file you touched as modified or untracked (AGENTS.md). Do not push; the maintainer pushes and relays CI. Verify with plain zig build commands only.
**Scope:** resolved
**Applied-at:** M001/S18/T02 (D057); 20:44 is a re-issue of the 20:28 steer

---
