---
version: 1
models:
  research: claude-code/claude-sonnet-5-5
  planning: claude-code/claude-opus-5-5
  completion: claude-code/claude-sonnet-5-5
git:
  isolation: none
  auto_push: false
  push_branches: false
  manage_gitignore: false
verification_commands:
  - zig build install-game install-map-editor
  - zig build test-editor-core
verification_auto_fix: true
verification_max_retries: 2
auto_supervisor:
  soft_timeout_minutes: 40
  idle_timeout_minutes: 20
  hard_timeout_minutes: 90
auto_report: true
dynamic_routing:
  enabled: true
  allow_flat_rate_providers: true
  cross_provider: false
  escalate_on_failure: true
  tier_models:
    light: claude-code/claude-sonnet-5-5
    standard: claude-code/claude-sonnet-5-5
    heavy: claude-code/claude-opus-5-5
reactive_execution:
  enabled: false
  max_parallel: 2
---

Blitzkrieg Reloaded: portable port of the game and its editors. See AGENTS.md for project rules.
