# M001: Portable Resource Editor

**Vision:** Port the 64k-line MFC Blitzkrieg Resource Editor to the portable Zig+ImGui+C++ editor stack on macOS arm64, Windows x64 MSVC, and Linux x64. Keep the MFC-era export and tree-item code (correct by definition because it produced shipped Data/) in a new portable C++ library; add undo/redo everywhere, safe save, autosave + recovery, and Import-from-game-data. Extract the Map Editor's generics into a shared Zig kit on the way in. Delete the MFC editor on the way out, only after every parity row has evidence and Johannes approves hand try on macOS + Windows.

## Success Criteria

- `zig build install-resource-editor` succeeds on macOS arm64, Windows MSVC, and Linux x64
- `test-resource-{core,model,bridge}` green on their respective target sets; `resource-editor-{host-check,smoke,auto}` green on macOS and Windows in CI (and Linux locally)
- `test-resources-all` passes locally with 0 FAIL
- Every repo-owned golden compares equal in CI; every GOG golden compares equal on win-home
- `resource-editor-game-reads-it` passes with one resource per sub-editor kind on macOS locally
- Every 06-PARITY.md row is `done` with evidence or `no behaviour in MFC` with reason
- Map Editor Linux + macOS + Windows tiers remain green after kit extraction
- Johannes approves hand try on macOS release build and Windows release build
- MFC editor sources, `editor.exe`, `editor2.exe`, `A7.sln` entry, and `copyEditors` entry are deleted
- `.planning/STATE.md` is updated at milestone end

## Slices

- [x] **S01: S01** `risk:high` `depends:[]`
  > After this: On win-home: MFC `editor.exe` batch-exports repo-owned fixtures for every one of the 21 extensions to committed goldens under `tools/zig/fixtures/resource_editor/`. Locally: `tools/zig/fixtures/resource_editor/dxt-tolerance.json` holds measured max pixel delta and p99 for DXT1-3-5 between old encoder and `NDxt`; a captured preview-scene frame is checked in for 1 mesh unit, 1 sprite object, 1 particle source; a C++ XML round-trip test harness roundtrips every one of the 21 extensions idempotently. Spec amended with Linux-first-class target and user-data-root rule.

- [x] **S02: S02** `risk:high` `depends:[]`
  > After this: `Sources/editor/kit/` exists and compiles independently. MapEditor is cut over to import from the kit. On this Linux machine: every MapEditor tier (`test-editor-core`, `test-map-editor-view`, `test-map-editor-panels`, `test-map-editor-testlaunch`, `test-map-editor-auto`, `test-map-editor-engine`, `test-editor-bridge`, `map-editor-host-check`, `map-editor-smoke`, `map-editor-auto`, `map-editor-auto-m2`, `map-editor-m3-auto`, `map-editor-game-reads-it-m3`) is green. CI shows the same green on macOS + Windows after push.

- [x] **S03: S03** `risk:high` `depends:[]`
  > After this: `test-resource-model` passes on this Linux machine (CI for the other engine targets): every MFC tree item matches the inventory generated from Sources/src/editor; every Data/Editor/TestProjects project and fixture round-trips content-equal and an unedited save is byte-identical (exceptions listed in the spec); inserting each item type saves valid XML; the comparator reads exported data through the engine's own readers with exact floats and fails on unknown fields; MFC export goldens are pending for win-home, not counted done; dxt-tolerance.json measured on shipped DXT1/3/5 textures; one sweep script run-resource-sweep.sh.

- [x] **S04: S04** `risk:high` `depends:[]`
  > After this: `test-resource-bridge` and `test-resource-core` are green (core on all six targets, bridge on the five engine targets). Lock uses MFC's locked_<user>; geometry persists for every node and survives delete->undo; every command round-trips undo/redo; BkResPreview* captures a measured preview frame per kind.

- [x] **S05: S05** `risk:high` `depends:[]`
  > After this: `install-resource-editor` builds on macOS arm64, Windows MSVC, Linux x64. `resource-editor-host-check`, `-smoke`, `-auto` pass. The staged `ResourceEditor` sits beside `Game` and `MapEditor` in packages. Running it opens an empty project of any sub-editor kind; section A features (New/Open/Save with safe save + `.bak` + autosave + recovery + locking, MOD Settings, Export, PAK via native zip, Picture Options with `gamma.cfg`, Set Directories, Batch panel + CLI, Run Blitzkrieg via F7, Editors menu, inspector + reference pickers + multi-select + browse, thumbnail list + direction button + function-window docks, Import UI, Help showing shortcuts + spec link, About) all work on an in-repo fixture.

- [x] **S06: S06** `risk:medium` `depends:[]`
  > After this: For each of 4 kinds: committed golden parity (stats field-equal via comparator, `_h.dds` byte-identical, DDS within tolerance), import-and-export round trip for a shipped sample, undo/redo tests for every tool, a measured preview shot, one `BK_EDITOR_AUTO` scenario. Squad: formation drag + zero point + direction arrow all undoable. Weapon: shoot, damage, sound, effect, flash, craters trees all editable.

- [x] **S07: S07** `risk:medium` `depends:[]`
  > After this: For each: committed golden parity (.san byte-identical, DDS within tolerance, stats field-equal), import-and-export round trip (including every `.unt` in `Data/Old` + `WinSniper.unt`), undo/redo tests, preview shot showing Run/Stop playback, `BK_EDITOR_AUTO` scenario. Infantry Ack I/O either implemented (if intent clear) or 06-PARITY.md B-02.4 marked `no behaviour in MFC` with reason.

- [x] **S08: S08** `risk:high` `depends:[]`
  > After this: Captured 3D mesh preview per model variant (combat, install, transportable); locator pick selects the correct locator in the tree; golden parity on the in-repo `current.msh` fixture; import of a shipped unit then stats-only export is field-equal; undo/redo tests for locator move, platform selection, model switch; `BK_EDITOR_AUTO` scenario for unit edit then export then test launch.

- [x] **S09: S09** `risk:medium` `depends:[]`
  > After this: Grid tools (passability, zero, transparency, trans-lines) all undoable with set+get before and after state. Golden parity on repo fixtures; import-and-export round trip; preview shot showing grid + transparency overlay; auto scenario.

- [x] **S10: S10** `risk:high` `depends:[]`
  > After this: All point modes undoable with angle and cone handles. GOG `INTEX2 brandenburgertor/current.bld` exports equal to its MFC golden on win-home (committed as test name only; actual GOG files never committed). Repo fixture golden parity; import round trip; preview shot showing building + passability + points; auto scenario.

- [x] **S11: S11** `risk:medium` `depends:[]`
  > After this: Span marks placed and undoable; fire and smoke points undoable; segments, spans, states exported; golden parity on repo fixture; import round trip; preview shot; auto scenario.

- [x] **S12: S12** `risk:medium` `depends:[]`
  > After this: Keyframe editor edits (add, move, delete, reset, zoom) all undoable. Run and Stop + Camera switch work via auto scenario. Golden parity per sub-editor; import round trip; preview shot. Interpolate Vector Items either implemented or marked `no behaviour in MFC`.

- [x] **S13: S13** `risk:medium` `depends:[]`
  > After this: First the S12 follow-ups (D027): Get particle info shows the four GetInfo values; the particle simple/complex toolbar toggle is undoable and matches the export; Effect direction dock turns the running effect and child X/Y/Z edit as whole numbers, undoable; the auto run adds, drags and deletes a key through the displayed Function window with real pointer events and checks undo/redo; B-06.3, B-06.4, B-08.3, A-15, B-06.5 done with evidence. Then: tileset and crosset preview works; roads and rivers preview on their respective maps; wireframe toggle works; golden parity for each; import round trip; auto scenarios. Crosset edit mode either implemented or marked `no behaviour in MFC`.

- [x] **S14: S14** `risk:medium` `depends:[]`
  > After this: Place objectives and crosses by clicking the image; MinimapCreation reproduces a map image for Mission; .xml to .bzm map conversion for Mission; GOG `INTEX2 ardennen40/current.mip` exports equal to golden on win-home. Repo fixture golden parity for each; import round trip; auto scenario.

- [x] **S15: S15** `risk:high` `depends:[]`
  > After this: Place a button, move it, resize it, align, undo, redo, save. Launch the game with the edited `Data/UI/*.xml` as part of a mod; the game loads the edited screen cleanly on macOS (local) and Windows (CI auto and hand try). Auto scenario covers place then align then save then test-launch.

- [x] **S16: S16** `risk:high` `depends:[]`
  > After this: `test-resources-all` green locally with 0 FAIL. `resource-editor-game-reads-it` green with one resource per sub-editor kind. Johannes's approval on macOS release and Windows release. Deletion commits for `Sources/src/editor/`, `Sources/src/bin/editor.exe`, `Sources/src/editor/bin/editor2.exe`, `A7.sln` entry, `tools/zig/stage.zig` `copyEditors` entry. `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md` updated with Linux-first-class + user-data-root. `.planning/STATE.md` updated at milestone end.

- [x] **S17: S17** `risk:medium` `depends:[]`
  > After this: With -Dmod-root (or BK_MOD_ROOT) pointing at the AchtungPanzer2 data, zig build test-resource-mod-roundtrip imports every resource of each importable kind, re-exports it into zig-out/local-test and prints per-kind counts of equal, accepted-difference and failed resources, each difference with a reason. Without a mod root it prints 'skipped: no mod'. 06-PARITY, the spec and .planning/STATE.md show the real M001 end state.

- [x] **S18: S18** `risk:low` `depends:[]`
  > After this: On win-home, zig build test-editor-core -Dtest-mode=run passes for both -Dtarget=x86_64-windows-gnu and -Dtarget=x86_64-windows-msvc, and the Linux native tiers stay green.

## Boundary Map

### S01 to S02

Produces:
- `tools/zig/fixtures/resource_editor/dxt-tolerance.json` - measured max pixel delta and p99 for DXT1, DXT3, DXT5 between old `editor.exe` and `NDxt`
- `tools/zig/fixtures/resource_editor/<ext>/` - repo-owned fixture per extension with small generated source art, plus committed MFC golden exports produced on win-home
- Preview scene spike notes: a captured frame set and a short write-up of what camera/scene shape works for mesh, sprite, and particle
- Project-XML round-trip spike: a C++ test harness skeleton that proves the shape of the roundtrip is viable before `ResourceModel` is extracted

Consumes:
- Nothing (first slice; uses MFC `editor.exe` on win-home only)

### S02 to S03..S16

Produces:
- `Sources/editor/kit/` - the extracted shared Zig kit (history, files, settings, autosave, shipped, host, imgui, crt, auto, pictures, dialogs, testlaunch), with its own tests
- `Sources/editor/app/` (MapEditor) now importing from the kit - behaviour unchanged, every MapEditor tier green on Linux + macOS + Windows (CI)
- Public kit API surface documented in `Sources/editor/kit/README.md` or equivalent so S03..S15 can import without reading implementation

Consumes:
- The round-trip-spike confidence from S01

### S03 to S04, S06..S15

Produces:
- `Sources/src/ResourceModel/` - portable C++ library: variant, SProp, CTreeItem, factory, every item class, project XML load/save, references, per-sub-editor export skeleton
- `test-resource-model` tier green on the five engine targets
- Per-stats-type comparator (reads both sides with engine's own readers; fails on unknown fields)
- Build step `test-resource-model` wired into `build.zig` and `.github/workflows/cross-platform.yml`

Consumes:
- Fixtures + goldens from S01

### S04 to S05, S06..S15

Produces:
- `Sources/src/EditorBridge/resource_bridge.h` + implementation - `BkRes*` ABI covering Projects, Tree, References, Geometry edits, Export, MOD, Preview, Import
- `Sources/editor/resource_core/` - Zig headless library: document, generic + geometry commands, undo/redo, fake bridge for tests
- `test-resource-bridge` + `test-resource-core` tiers green
- `BkResPreview*` entry points proven to render a preview frame per the S01 spike

Consumes:
- `ResourceModel` (S03), kit history + files + settings (S02), fixtures (S01)

### S05 to S06..S15, S16

Produces:
- `Sources/editor/resource_app/` - Zig app, binary `ResourceEditor`
- All section A shared features: New/Open/Close/Save/Save As with safe save and `.bak`, Recent files, MOD Settings, Export, Compress MOD to PAK, Set Picture Options with `gamma.cfg`, View toggles, Direction Button, Function Window dock, Set Background Colour, Expand/Collapse all, Set Directories, Export RPG Stats Only, Batch Mode (dialog and CLI), Run Blitzkrieg (F7), Editors menu + combo, Help + About, project tree with rename and expand-state, insert/delete tree items (UI), inspector covering every DT_* domain type, 20 reference pickers, multi-select dialog, browse dialog, AI class combo, player sides combo, localisation items, thumbnail list dock, Import XML from game data (UI), engine preview wiring, autosave + crash recovery
- `install-resource-editor` + `resource-editor-host-check` + `-smoke` + `-auto` + `BK_EDITOR_AUTO` extensions
- Packaging (`stage.zig --resource-editor`)
- CI resource steps in `.github/workflows/cross-platform.yml`

Consumes:
- Bridge + core (S04), model (S03), kit (S02)

### S06..S15 to S16

Produces, per sub-editor:
- The sub-editor's model entries (tree item classes, properties, export) added to `ResourceModel`
- Its preview + overlays + tools (as undoable commands)
- Its toolbar entries in the app
- A golden comparison per repo-owned fixture
- Import-and-export round trip for shipped samples
- Core undo/redo tests for every tool
- A preview shot measured from the captured frame
- A `BK_EDITOR_AUTO` scenario
- Dead/intent-unclear MFC commands either implemented or marked "no behaviour in MFC" in 06-PARITY.md with reason

Consumes:
- Shared infrastructure from S02..S05

### S16 to (end)

Produces:
- `test-resources-all` green locally with 0 FAIL
- `resource-editor-game-reads-it` green with one resource per sub-editor kind
- Hand try approval from Johannes on macOS release and Windows release builds
- Deletion commits for `Sources/src/editor`, `Sources/src/bin/editor.exe`, `Sources/src/editor/bin/editor2.exe`, `A7.sln` entry, `stage.zig copyEditors` entry
- `.planning/STATE.md` updated

Consumes:
- Everything from S01..S15
