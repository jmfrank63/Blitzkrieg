# M001: Portable Resource Editor

**Gathered:** 2026-10-05
**Status:** Ready for planning

## Project Description

Port the MFC "Blitzkrieg Resource Editor" (`Sources/src/editor`, `editor.exe`, 64,028 lines: 135 `.cpp`, 125 `.h`, `editor.rc` 1,128 lines) to the portable editor stack as a new `ResourceEditor` executable built by `zig build` for macOS arm64, Windows x64 MSVC, and Linux x64. All 21 sub-editors (20 active + the switched-off GUI editor) are in scope, plus the shared features (projects, export, MOD settings, PAK, picture options, directories, batch mode, run game, reference pickers, property inspector), plus four features MFC lacked: undo/redo for every edit, safe save, autosave and crash recovery, and Import-from-game-data (the dead Ctrl+I). The shared generic plumbing of the Map Editor moves into a new Zig editor kit (`Sources/editor/kit`) first, with the Map Editor keeping all its tiers green on Linux, macOS and Windows.

The architecture mirrors the Map Editor: a Zig app (`Sources/editor/resource_app`, binary `ResourceEditor`), a Zig headless core (`Sources/editor/resource_core`), a C ABI bridge (`Sources/src/EditorBridge/resource_bridge.h`, prefix `BkRes*`, same library as the map bridge), and a new portable C++ library (`Sources/src/ResourceModel`) that owns the MFC-stripped tree-item framework, project XML load/save, references, and export per sub-editor. Previews are drawn as the window background through the engine's `IGFX::SetOverlay` path with ImGui on top, built from a real export into a temp preview storage mounted over data — so the preview itself exercises the export.

## Why This Milestone

### What problem this solves

The current Resource Editor is a 64k-line MFC Windows-only app, shipped as a checked-in `editor.exe` binary and copied into Windows packages only. Content authors cannot run it on macOS or Linux. It has no undo, no safe save, no autosave, and its "Import XML file" menu is dead. Its settings live in the Windows registry. It shells out to `zip.exe` for PAK. Most shipped resources have no project file, so re-exporting them against a modern mod stack is impossible without first porting the editor and adding Import.

### Why now

Phases 2–5 ported the Map Editor to the same portable stack and shipped it on Linux as well (merge `1d7264fd6`, M3 complete). The patterns, tiers, and CI are proven. Phase 6 is next in the planned sequence (resource editor → small tools → ELK → localisation / cloud sync / installer). Delaying would mean the Map Editor's shared infrastructure diverges from what the Resource Editor needs; extracting the kit now is cheaper than extracting it later.

## User-Visible Outcome

### When this milestone is complete, the user can:

- Launch `ResourceEditor` from a staged install on macOS arm64, Windows x64, or Linux x64 and see a window.
- Open an in-repo project of any of the 21 sub-editor kinds; the editor switches sub-editor by extension and remembers the last active.
- Edit any node or property, hit **Ctrl+Z**, and see the edit undone; redo it; save; the project file is byte-identical to a project that was never edited (idempotent save).
- Run **File → Import from game data** (Ctrl+I) on a shipped runtime resource folder and get a project of the right kind back, re-exportable; MFC's Ctrl+I was dead.
- Export the current project (Ctrl+E) into a mod folder; the game, launched by **Tools → Run Blitzkrieg** (F7) with `-mod=<exportMod>`, loads the resource and plays cleanly.
- Run `ResourceEditor --batch all <sourceDir> <destDir>` headlessly (no window, no GPU) and get a report of exported, skipped (up to date), and failed files, with a missing-`gamma.cfg` list.
- See the preview update live when editing properties; passability brush strokes, point moves, keyframe edits and formation drags are each one undoable gesture.
- Compress the current mod to a PAK (no `zip.exe`) and watch the game mount it.

### Entry point / environment

- Entry point: `ResourceEditor` executable (GUI subsystem on Windows, with `crt.attachParentConsole()` for automated modes). CLI batch mode: `ResourceEditor --batch <ext|all> <sourceDir> <destDir> [-f] [-os]`.
- Environment: macOS arm64 (home dev), Windows x64 MSVC (parity oracle on `win-home`), Linux x64 (this agent's native target).
- Live dependencies involved: SDL3, Dear ImGui, the Blitzkrieg engine C++ libraries (`Main`, `Scene`, `Anim`, `GFX/GFXGPU`, `Image`, `StreamIO`), a GPU for the preview tier (CI runners that lack a GPU report "skipped: no GPU device").

## Completion Class

- **Contract complete** means: `test-resource-core`, `test-resource-model`, `test-resource-bridge` and `test-resources-all` pass; every repo-owned fixture compares byte-equal (or within measured DXT tolerance) to its MFC golden; project XML round-trip is idempotent for every one of the 21 extensions; the per-stats-type comparator reads both sides with the engine's own readers.
- **Integration complete** means: `install-resource-editor` builds on all three platforms; `resource-editor-host-check`, `-smoke`, `-auto` pass; `resource-editor-game-reads-it` passes on macOS locally with one resource per sub-editor kind; the Map Editor's own tiers remain green on Linux, macOS, Windows after the kit extraction.
- **Operational complete** means: autosave fires on the configured schedule, crash recovery restores an unsaved project, project locking (`locked_<username>`) warns on a conflicting open; export writes to a staging folder and atomically moves on success, leaving the export folder untouched on failure; Johannes's hand try on macOS release and Windows release is approved.

## Final Integrated Acceptance

To call this milestone complete, we must prove:

- Johannes launches the release `ResourceEditor` on macOS, opens an in-repo mesh unit project, edits a locator position, undoes, redoes, saves, exports, hits F7, and the Game loads the exported mod and shows the unit.
- On Linux, the same loop with a different sub-editor (e.g. Weapon or Building) works end-to-end.
- On `win-home`, the same loop with a GOG `brandenburgertor` Building project exports equal to its MFC golden.
- `test-resources-all` sweeps every shipped resource through import and stats-only export locally with 0 FAIL.
- `resource-editor-game-reads-it` runs through one resource per sub-editor kind, the game loads each, plays, and exits cleanly.
- Every 06-PARITY.md row is marked `done` with evidence (test name, golden, shot) or `no behaviour in MFC` with the reason.
- The MFC `editor.exe`, `editor2.exe`, `Sources/src/editor/`, `A7.sln` entry, and `copyEditors` entry are gone.

Cannot be simulated: Johannes's hand try on the release build is human verification per the AGENTS.md "never claim a macOS or Windows result you did not see" rule.

## Architectural Decisions

> The phase has 29 approved decisions D-01..D-29 in `.planning/phases/06-resource-editor-portable-port/06-CONTEXT.md`. Those remain the source of truth and are not re-stated here. This section records only the newer-than-spec choices and planning decisions specific to M001. See `.gsd/DECISIONS.md` for the append-only decisions register.

### Linux x64 is a first-class target (D001)

**Decision:** `ResourceEditor` and the shared editor kit build and run on Linux x64 alongside macOS arm64/x64 and Windows x64 MSVC.

**Rationale:** The Map Editor Linux merge `1d7264fd6` proves the pattern. The agent machine is Linux; development and tests run natively here. AGENTS.md promotes Linux to a full target for all editors going forward. The spec's "Linux build of the app… deferred" note is superseded and will be amended in `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`.

**Alternatives Considered:**
- Keep Linux deferred — rejected: dev loop on this machine would be cross-compile only, and the Map Editor Linux pitfalls are already solved.

### User-data root under the shared kit (D002)

**Decision:** User content (projects, settings, recent files) lives under the kit's user-data root (`<UserRoot>resourceeditor/`), never beside the executable. Paths stored inside project files are relative where the project format allows.

**Rationale:** Editor cloud sync is deferred for all editors; this milestone must not block it. Putting user content under the kit's user-data root and keeping in-project paths relative where possible means the later cloud sync work can be added without rewriting what this milestone writes to disk. Spec D-10 already requires `<UserRoot>resourceeditor/resourceeditor.cfg`; D002 extends it from settings to all user content and to in-project path handling.

### One milestone with 16 slices mirroring the approved waves (D003)

**Decision:** M001 contains all 16 approved plans (06-01..06-16) as slices in the same wave order. No milestone split now.

**Rationale:** Spec D-27's wave table is the approved plan. Anti-reduction: plan the full scope. Wave-5 slices (S06..S15) can execute in parallel because each sub-editor registers through per-editor files. If GSD mechanics find the slice count unwieldy mid-flight, the natural fault line is waves 1–4 vs wave 5 vs wave 6 — reversible via `gsd_slice_replan` / new milestones.

### Platform verification honesty (D004)

**Decision:** Build and test natively on Linux here. macOS and Windows are verified by `.github/workflows/cross-platform.yml` after push. The parity oracle (MFC `editor.exe` goldens) runs by hand on `win-home` per sub-editor slice.

**Rationale:** AGENTS.md rule. Keeps slice/task verification honest and matches how the Map Editor milestones ran.

## Error Handling Strategy

- **Bridge:** every call returns `BkEditorStatus` and populates `BkEditorLastMessage`. No C++ exception crosses the Zig/C++ boundary. `NO_DEVICE` is kept separate from `BAD_ARGUMENT`.
- **Export:** writes to a staging folder; atomically moves into place only when the whole export succeeded. A failed export leaves the export folder as it was.
- **Save:** safe save — `<stem>.~save<ext>` → read back and compare → rename. On failure the original is untouched and the document stays dirty. One `.bak` per session holds the version from when the project was opened.
- **Autosave / recovery:** on autosave fail, keep the previous autosave; on crash recovery, offer the most recent autosave.
- **Project locking:** on open, write `locked_<username>`; on conflict, warn and offer read-only open or take over.
- **Unknown data:** a project that references an unknown class type keeps the unknown node through a save (preservation invariant from the Map Editor).
- **Missing graphics sources on Import:** export writes stats only and leaves existing exported graphics untouched; a warning is reported.
- **Missing `gamma.cfg`:** batch mode reports it per-file; interactive mode shows a dialog once per project and allows picture-options write.
- The editor never asserts on bad data.

## Risks and Unknowns

- **Model extraction difficulty** — `*Frm.cpp` files mix UI and export (BuildFrm 2,625 lines, BridgeFrm 2,592, MeshFrm 2,320). Guard: goldens per sub-editor before any UI work on the kind. Retire in: S03/S04 (framework), proven per sub-editor in S06..S15.
- **Missing source art for most shipped resources** — few projects + sources outside GOG. Guard: Import, repo-owned fixtures with generated art, GOG projects on win-home by path. Retire in: S01 fixtures + S03 import plumbing.
- **DXT encoder differences** between checked-in `editor.exe` and portable `NDxt` — measured tolerance (slice S01), `_h.dds` byte-identical.
- **Preview scene without terrain hitting renderer limits** — measured first in S01 using one mesh unit, one sprite object, one particle source (`BkEditorCaptureFrame`).
- **GUI editor format drift** — MFC had it switched off; the game's UI XML has moved on (Lua, scaling). Guard: GUI editor is the last sub-editor plan (S15) and edits the current format, proven by the game loading an edited screen.
- **Linux-only pitfalls regressing after kit extraction** — the Map Editor's Linux fixes (`rdynamic` + `$ORIGIN` rpath, 16 MiB worker stacks, hidden-window flags, ISFX stop-before-unload, case-insensitive `DataFile`) must move into the kit without regression. Guard: S02 keeps every Map Editor tier green on Linux as the acceptance.
- **Scale** — 21 sub-editors in 10 wave-5 slices. Mitigation: S01..S05 land the shared parts so each wave-5 slice is model + export + preview + tools only.
- **Platform claim honesty** — this machine cannot verify macOS or Windows. Mitigation: AGENTS.md rule; CI gates and win-home oracle do the verification.

## Existing Codebase / Prior Art

- `Sources/editor/core/{history,files,settings,autosave,shipped,fake_bridge}.zig` — move to the kit in S02.
- `Sources/editor/app/{host,crt,auto,smoke,pictures,testlaunch,panels}.zig` and `Sources/editor/imgui/*` — move to the kit in S02.
- `Sources/src/EditorBridge/bridge.{h,cpp}` — the map bridge; the resource bridge sits beside it in the same library. Reuses `BkEditorStart`/`Stop`, data-only start, `Guarded`, `ListInstalledMods`, mod switch, `SetOverlay`, `CaptureFrame`, `ObjectPicture`.
- `tools/zig/data_only_startup.cpp` — no-window startup used by the resource-file tier and by batch mode.
- `Sources/src/Image/ImageProcessor.cpp` — portable `Compress` / `CompressDXTN` (`NDxt`), `SaveImageAsDDS`, `CreateGammaCorrection`, called through `IImageProcessor` by the exports.
- `Sources/src/StreamIOZig/zip.zig` — the archive reader; format reference for the native PAK writer.
- `Sources/src/RandomMapGen/IB_Types.h` — `CSpritesPackBuilder` used by sprite-pack export.
- MFC sources to port into `ResourceModel`: `TreeItem.*`, `TreeItemFactory.cpp`, every `*TreeItem.cpp`; the export halves of `*Frm.cpp` (BuildFrm, BridgeFrm, MeshFrm, ParentFrame); `SpriteCompose.*`, `BuildCompose.*`, `MinimapCreation.*`, `common.*`, `Reference.cpp`, `UnitSide.cpp`, `localization.*`, `Track.cpp`, `ParticleSourceData.cpp`, `SmokinParticleSourceData.cpp`.
- Fixtures: `Data/Editor/TestProjects/` (one folder per editor, `manifest.json`); `WinSniper.unt` and 13 `.unt` in `Data/Old`; `Data/Units/Technics/German/Artillery/8_cm_GrWr34/current.msh`; GOG `INTEX2` `.bld` and `.mip` on win-home (by path only).
- Engine readers used by the goldens: `Main/GameDB.cpp` (`ReadRPGStats`, `GetAddStats`, `GetGameStats`), `Main/GameStats.h`, `Scene/ParticleSourceData.cpp`, `Scene/SmokinParticleSourceData.cpp`, `Scene/VisObjBuilder.cpp`, `Scene/TerrainInternal.cpp`, `Formats/fmtEffect.h`, `fmtTerrain.h`, `fmtVSO.cpp`, `Anim/AnimationManager`.

## Relevant Requirements

See `.gsd/REQUIREMENTS.md` for the full capability contract. All active R001..R032 are mapped to slices in this milestone; R100..R102 are deferred and R200 is out of scope.

Highlights:
- R001 Editor kit → S02
- R002 ResourceModel library → S03
- R003 Resource bridge + R004 resource core → S04
- R005 App shell + R007..R015 shared features → S05
- R006 21 sub-editors → S06..S15
- R018 Preview spike + R019 DXT tolerance + R020 Parity oracle → S01
- R021 Idempotent XML round-trip + R022 Stats comparator → S03
- R029 Linux first-class → S02 primary, enforced across the milestone
- R031 Delete MFC + R032 Final sweep → S16

## Scope

### In Scope

- All 21 sub-editors (20 active + GUI editor).
- All shared features (projects, export, MOD, PAK, picture options, directories, batch, run game, references, inspector).
- Four new-vs-MFC capabilities: undo/redo everywhere, safe save, autosave + recovery, Import from game data.
- Export RPG stats only (Ctrl+R) for every sub-editor (MFC had it for Infantry only).
- `ResourceModel` C++ library (new).
- Shared editor kit extraction from the Map Editor.
- `BkRes*` resource bridge.
- `resource_core` Zig library + `ResourceEditor` Zig app.
- Build and CI steps: `install-resource-editor`, `test-resource-{core,model,bridge}`, `resource-editor-{host-check,smoke,auto,game-reads-it}`, `test-resources-all`.
- Packaging via `stage.zig --resource-editor` on macOS, Windows, Linux.
- `BK_EDITOR_AUTO` extensions.
- Linux x64 build and tiers for ResourceEditor and the kit.
- Deletion of MFC `Sources/src/editor`, `editor.exe`, `editor2.exe`, `A7.sln` entry, `copyEditors` entry (end of milestone, after evidence).

### Out of Scope / Non-Goals

- New resource kinds or editing features beyond MFC parity (balancing views, mod diffs). Deferred to later phases.
- Editor cloud sync — deferred for all editors; this milestone must not block it (D002).
- Batch export directly into PAK (two-step stays as MFC).
- Removing `Common/LegacyUiCompat.h` — stays until phase 7 removes MFC ELK, its last user.
- Linux GPU runner in CI — the kit/core tier runs on Linux CI already; the engine/preview tier runs on macOS arm64 and Windows-MSVC GPU runners; Linux locally remains the dev target without a CI GPU runner for now.

## Technical Constraints

- CRLF for all text files (`.gitattributes`); new files CRLF.
- Match surrounding code style (naming, comment density, idiom). Zig doc comments explain *why* in plain sentences.
- Never `std::min`/`std::max` in C++ — use `Min`/`Max` from `Misc/Tools.h`.
- Never `zig fmt build.zig`; run `zig test tools/zig/build_hermeticity_test.zig` after editing it.
- Tests use only tracked data (`Data/`, `tools/zig/fixtures/`), copied to `zig-out/local-test/...`; never write into shipped `Data/`; never touch the user's own profile, saves, settings or cloud sync (redirect with `XDG_DATA_HOME` / `BK_*_SETTINGS` seams).
- "The game reads it unchanged" is proved by the engine's own readers or by the real Game, never by eyeballing.
- Graphics claims are proved by captured TGA/PNG measured by code, not judged from source.
- `BK_DEBUG_LOG=1` is required for `DebugTrace` output in release builds.
- Commit prefix: `feat(resource-editor): ...`, `fix(editor): ...`, `test(...)`, `docs(...)`. Agent does not push.
- Linux pitfalls to reuse: `rdynamic` + `$ORIGIN` rpath, 16 MiB worker stacks, hidden-window flags, ISFX stop-before-unload, case-insensitive `DataFile` resolution.
- `map_editor_platform` gating pattern is the template for `resource_editor_platform`.
- The C bridge is a flat C ABI with plain structs and fixed `char[64]` fields; integer handles; `BkEditorStatus` + `BkEditorLastMessage`; `Guarded` on every entry; no C++ exceptions cross the boundary.
- Undo of engine-computed changes puts back the recorded before/after state and never re-runs the engine function.
- GOG files and the AchtungPanzer2 mod are never committed.

## Integration Points

- `Sources/editor/kit` (new) — consumed by `MapEditor` (S02 cuts it in without behaviour change) and by `ResourceEditor` (S05 onwards). ELK (phase 7) consumes it later and needs the TGA icon decoder exported with no engine-bridge dependency.
- `Sources/src/ResourceModel` (new) — called from `Sources/src/EditorBridge/resource_bridge.cpp`. Built by `build.zig` for every target that builds the engine C++.
- `Sources/src/EditorBridge` — the resource bridge `BkRes*` sits in the same library as the map bridge, sharing lifecycle and overlay entry points.
- Game engine (`Main/GameDB.cpp`, `GameStats.h`, `Scene/*`, `Formats/*`, `Anim/AnimationManager`) — called by the goldens' per-type stats comparator; called by `IVisObjBuilder` when the preview is built from a real export.
- `tools/zig/stage.zig` — gains `--resource-editor`; in S16, drops the `editor.exe` from `copyEditors`.
- `.github/workflows/cross-platform.yml` — resource tiers appear next to the map editor's in `macos-platform` and `windows-platform` jobs; kit/core tier runs in all six matrix jobs.
- `.planning/STATE.md` — updated at the end of S16.
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md` — the parity grid; every row filled with evidence by its owning sub-editor slice.
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md` — amended with the Linux-first-class change (D001) and user-data-root rule (D002).

## Testing Requirements

Seven tiers, mirroring the Map Editor with one addition:

| Tier | Needs | Runs on | Owner slice |
|---|---|---|---|
| Kit + core (Zig) | nothing | all six CI targets | S02 + S04 |
| Resource file (C++) | data-only startup | the five targets that build the engine C++ | S03 |
| Resource bridge | data-only startup | the five engine targets | S04 |
| Engine / preview (C++) | hidden SDL window + GPU | macOS arm64, Windows-MSVC in CI; "skipped: no GPU device" elsewhere | S04 / S05 |
| Editor app (`--check`/`--smoke`) | the editor + a window | macOS and Windows in CI; locally also Linux | S05 |
| Editor app `auto` | the editor + a window | macOS locally; Windows and Linux locally | S05 and every sub-editor slice |
| Game reads it | the game + a window | macOS locally | S16 (every sub-editor slice contributes one scenario) |
| Parity oracle | MFC `editor.exe` | win-home, by hand | S01 and sub-editor slices |

Specific scenarios:

- Resource-file tier: every project fixture opens and re-saves idempotently; every repo-owned fixture exports equal to its golden; import of a sample of shipped resources per kind then stats-only export reproduces the shipped `1.xml` field-for-field; local `test-resources-all` sweeps every shipped resource through import and stats-only export with 0 FAIL.
- Core tier: every command (SetProp, InsertNode, DeleteNode, MoveNode, every geometry command) round-trips through undo/redo in isolation against the fake bridge.
- Bridge tier: every `BkRes*` entry is `Guarded`, bad arguments return `BAD_ARGUMENT`, no device returns `NO_DEVICE`, no C++ exceptions cross the boundary.
- Preview tier: the S01 spike produces captured frames for 1 mesh unit, 1 sprite object, 1 particle source; downstream per-sub-editor shots compare within the measured DXT tolerance; `_h.dds` byte-identical.
- Editor app `--check`/`--smoke`: window opens, no crash on shutdown, settings written to the test seam.
- `resource-editor-auto`: open → edit → undo → save → export → shot → compare → test-launch → quit, scripted via `BK_EDITOR_AUTO`.
- `resource-editor-game-reads-it`: the Game launched with the exported mod loads one resource per sub-editor kind (units on a test map, UI through `BK_AUTO_UI`), shoots or exercises the resource, and exits cleanly.
- Hand try: Johannes approves release builds on macOS arm64 and Windows x64.

## Acceptance Criteria

See **Final Integrated Acceptance** above. Per-slice acceptance is in the roadmap (`M001-ROADMAP.md`) under each slice's demo line and the slice CONTEXT when written.

## Open Questions

- Debounced-preview-rebuild schedule — Claude's discretion per spec; defaults to the Map Editor's debounce if measured in S01.
- DXT pixel tolerance value — measured in S01, not guessed; captured as a committed JSON artifact so downstream slices consume a fixed number.
- Fixture art generator shape — Claude's discretion; must be repo-owned and small.
- ImGui layout micro-details and toolbar icons — Claude's discretion in S05.
- Recovery-copy naming — Claude's discretion in S05.
- Whether S06..S15 run in parallel worktrees or sequentially — Claude's discretion; parallelism is possible because sub-editors register through per-editor files.

## Assumptions

Autonomous judgments made during planning, each with reasoning:

- **Linux x64 is a first-class target for the Resource Editor** (newer-than-spec instruction in the milestone brief overrides spec "Linux… deferred" note). *Reason:* Map Editor Linux merge `1d7264fd6` proves the pattern; this machine is Linux; the newer instruction wins per AGENTS.md.
- **One milestone with 16 slices**, not 2 or 3. *Reason:* the phase spec is one phase with a single exit; anti-reduction rule; wave-5 slices can parallelise. Reversible via `gsd_slice_replan` + new milestones if needed.
- **Slice numbers map 1:1 to plan numbers** (S01 = 06-01, …, S16 = 06-16). *Reason:* traceability. The parity grid in `06-PARITY.md` already attributes each row to a plan number, so same-number slices make status tracking trivial.
- **User content lives under the kit's user-data root** (`<UserRoot>resourceeditor/`), not beside the executable; in-project paths are relative where the format allows. *Reason:* editor cloud sync is deferred for all editors; this layout keeps the door open at zero cost today.
- **No `DISCUSSION-MANIFEST.json` is written.** *Reason:* protocol says single-milestone projects skip it.
- **The parity oracle (MFC `editor.exe`) runs on `win-home` only, by hand**, once per sub-editor slice. *Reason:* AGENTS.md rule; the oracle produces the goldens, which are committed and outlive the MFC editor.
- **`gpu-device-probe` + "skipped: no GPU device"** replaces hard failures on GPU-less runners. *Reason:* Map Editor pattern; this is already the house rule.
- **The resource bridge lives in the same `EditorBridge` library** as the map bridge (not a separate library), with a new header `resource_bridge.h`. *Reason:* spec D-03; shares `BkEditorStart`/`Stop`, overlay, capture — splitting the library would duplicate code.
- **Wave-5 slices (S06..S15) can execute in parallel** because each sub-editor registers through per-editor files (per spec D-27). *Reason:* explicit spec affordance; the planner records the dependency only on S05 (app shell), not on sibling sub-editors.
- **`test-resources-all` is a local-only sweep** (runs where shipped `Data/` lives in full). *Reason:* spec test tiers table says "local".
- **Spec amendment is a slice-level action.** *Reason:* AGENTS.md says "record the change in the spec" when this file or a milestone context changes a spec decision. S01 is the first slice that materially cares about Linux (goldens + fixtures), so it carries the spec amendment task.
- **`.planning/STATE.md` update is a S16 task**, part of the deletion & handoff work.
