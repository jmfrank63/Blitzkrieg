---
verdict: needs-attention
remediation_round: 0
---

# Milestone Validation: M001

## Success Criteria Checklist
- [ ] `install-resource-editor` on macOS arm64, Windows MSVC, Linux x64 | Linux green (S05, S16 T05). macOS/Windows CI steps wired (`cross-platform.yml` ~466, ~926) but no green run seen; runs 37507439455 and 37521060859 were red, 37502565127 unreported.
- [ ] `test-resource-{core,model,bridge}` green; `resource-editor-{host-check,smoke,auto}` green on macOS + Windows CI and Linux | All exit 0 on Linux (S05, S16 T05, S18). win-home ran only `test-editor-core` (S18, likely cached). No macOS/Windows CI seen.
- [x] `test-resources-all` 0 FAIL locally | S16 T05 exit 0; maintainer sweep VERDICT=PASS (41 tiers) at b8aa895bb. Sweep after the MFC deletion (c6b4329c6) not seen.
- [ ] Repo goldens equal in CI; GOG goldens equal on win-home | Comparator pass=10 accepted=10 fail=0 pending=0 over 20 goldens, Linux only. GOG goldens (B-09.14, B-14.5) never produced; replaced by AchtungPanzer2 mod round trip (D053, S17: 1879 resources, 0 failed).
- [ ] `resource-editor-game-reads-it` per kind on macOS | All 21 kinds on Linux (10 via the real Game, 11 via the engine reader). No macOS run.
- [x] Every 06-PARITY row done or `no behaviour in MFC` | All 160 A/B rows done or no-behaviour; header lists the hand try as the one open item.
- [ ] MapEditor tiers green on 3 platforms | Linux green (S02, S16 T05); not re-run at S18 closeout; macOS/Windows not seen.
- [ ] Johannes hand-try approval on macOS + Windows release | Deferred (D052).
- [x] MFC editor sources, editor.exe, editor2.exe, A7.sln entry, copyEditors entry deleted | c6b4329c6 (PRE_DELETE b8aa895bb). `copyEditors` remains for ExcelExporter/ELK only, editor row removed.
- [ ] `.planning/STATE.md` updated at milestone end | Updated in S16 but stale: says S17 in progress, no S18, frontmatter `current_phase: 05`, `last_updated: 2026-10-03`.

## Slice Delivery Audit
| Slice | SUMMARY | Delivered | Notes |
|---|---|---|---|
| S01 | yes | DXT tolerance, 21-ext fixtures, preview spike, XML round-trip harness, spec amendments | MFC goldens arrived late (S16) |
| S02 | yes | Kit (12 modules + README), MapEditor cut over | 8 pre-existing engine-tier failures fixed later (green in S16 T05) |
| S03 | yes | ResourceModel, 217 classes / 423 props, comparator, 23 projects byte-identical | "MFC reads port's XML" win-home check never shown done |
| S04 | yes | BkRes* ABI, resource_core, preview frames per kind | Linux only |
| S05 | yes | ResourceEditor app, section A, host-check/smoke/auto, packaging | A-13/A-16/A-17 finished in S16 T02 |
| S06–S15 | yes | All 21 sub-editors: model, undoable tools, round trips, auto scenarios, PARITY rows | Weapon no preview shot (D015); .til preview/import refused; .eff import refused (no MFC reverse path) |
| S16 | yes | test-resources-all green, game-reads-it 21 kinds, goldens compared, MFC deleted, STATE.md | Hand try deferred (D052) |
| S17 | yes | test-resource-mod-roundtrip (AchtungPanzer2: 1609 equal, 270 accepted, 0 failed) | Uncommitted files later committed in aacfdc40a |
| S18 | yes | MinGW/MSVC test-tier target fix; win-home test-editor-core exit 0 both targets | Likely cache-served; map-editor tiers not re-run |

All 18 slices have summaries; none reports a blocker.

## Cross-Slice Integration
| Boundary | Producer Summary | Consumer Summary | Status |
|---|---|---|---|
| S01 → S02 | S01 produced dxt-tolerance.json, 21 fixture dirs, preview-scene spike, XML harness (21/21) | S03 uses DXT gate + fixtures; S04 replaces spike frames | Honored (goldens late, S16) |
| S02 → S03..S16 | Kit + README, MapEditor cut over | S04/S05+ use history, settings, autosave, host, auto, testlaunch; MapEditor green S16 T05 | Honored |
| S03 → S04, S06..S15 | ResourceModel, comparator, build/CI wiring | Bridge built on model; S06–S15 add exporters/importers | Honored |
| S04 → S05, S06..S15 | resource_bridge.h, resource_core, BkResPreview* | S05 reuses bridge; S07/S09/S12/S13/S15 extend ABI | Honored |
| S05 → S06..S16 | resource_app, section A (partial), CI, packaging | Per-kind toolbars/docks/auto blocks; S16 T02 completes A-13/16/17 | Honored late |
| S06..S15 → S16 | Per-kind deliverables, goldens pending win-home | S16: 20 goldens pass=10 accepted=10 fail=0; game-reads-it 21 kinds | Honored; GOG goldens replaced by S17 (D053/D054) |
| S16 → end | test-resources-all green, MFC deleted c6b4329c6, STATE.md rewritten | Milestone close | Gap: hand try not approved (D052), macOS/Windows CI unseen, STATE.md stale |

End-to-end flow traced: fixture (S01) → ResourceModel load/export (S03) → BkRes* bridge (S04) → ResourceEditor app edit/undo/save/export (S05, S06–S15) → resource-editor-game-reads-it with real Game / engine reader (S16) on Linux.

## Requirement Coverage
COVERED (Linux evidence): R001, R002, R003, R004, R007, R008, R009, R010, R011, R012, R013, R015, R016, R017, R018, R019, R022, R023, R026, R027, R028, R029, R030.

PARTIAL:
- R005 app shell: only Linux seen.
- R006 21 sub-editors: 10 goldens "accepted" with explained differences (til/mip explanations unproven); weapon no preview shot; tileset preview refused.
- R014 import: refused for .eff and .til (reasons recorded).
- R020 oracle/goldens: GOG goldens replaced by mod round trip (D053), 3rd/3rv goldens exported by hand.
- R021 XML round trip: "MFC reads port's XML" win-home check never evidenced.
- R024 build/CI: no macOS/Windows CI run seen.
- R025 packaging: staging not seen on macOS/Windows.
- R031 MFC deleted: done, but preconditions (hand try, post-deletion sweep) unmet.
- R032 final sweep exit: hand try outstanding, post-deletion sweep unseen, 11 kinds proved only by engine reader.

MISSING: none.

## Verification Class Compliance
| Class | Planned Check | Evidence | Verdict |
|---|---|---|---|
| Contract | test-resource-core/model/bridge, test-resources-all, golden comparison per sub-editor, XML round trip for 21 extensions, stats comparator | Linux: all exit 0 (S16 T05, S18). XML round trip 21 PASS plus unknown-node preservation (S01 T03). Comparator 20 goldens pass=10 accepted=10 fail=0. Not seen on other targets in CI. GOG goldens replaced (D053). | Partial (Linux only) |
| Integration | install-resource-editor on 3 platforms; host-check/smoke/auto in CI; resource steps in `cross-platform.yml`; `stage.zig --resource-editor` packaging; MapEditor tiers green | Steps in workflow (Windows ~464-578, macOS ~926-1015); `--resource-editor` at `stage.zig:101`. Linux green. Recorded CI runs red (37507439455, 37521060859) or unreported (37502565127); no green CI after S18 fix. | Gap |
| Operational | Autosave, crash recovery, locking `locked_<user>`, atomic export, safe save, headless batch, `.bak` | S04 T02 safe save, S04 T07 lock, S05 T06 export rollback, S05 lifecycle (.bak/autosave/recovery), S16 T15 batch 21 kinds byte-identical. Linux. | Covered (Linux) |
| UAT | Johannes hand try on macOS and Windows release builds with approval | Deferred by D052; PARITY header and STATE.md list it open. | Gap |


## Verdict Rationale
All three reviewers returned NEEDS-ATTENTION, none FAIL. Linux evidence is strong: every tier is green, 20 goldens fail=0, game-reads-it covers 21 kinds, and every PARITY row is closed. What's still open is evidence on other platforms and from people, not engineering: no green macOS/Windows CI run has been seen, Johannes's hand try is deferred (D052), the GOG goldens were replaced by the mod round trip (D053), and .planning/STATE.md is stale.
