---
id: S01
parent: M001
milestone: M001
provides:
  - tools/zig/fixtures/resource_editor/dxt-tolerance.json — measured DXT1/3/5 max_delta and p99 tolerance baseline for downstream golden comparisons
  - tools/zig/fixtures/resource_editor/<ext>/ — 21-extension fixture skeleton with project.<ext> stubs and golden/.gitkeep placeholders
  - tools/zig/fixtures/resource_editor/preview-scene/ — three empty-scene TGA captures plus runbook for S04 IVisObjBuilder camera setup
  - Sources/src/ResourceModel/spike/ — xml_spike portable XML library and legacy_dxt NLegacyDxt port for S03 ResourceModel extraction
  - tools/zig/resource_xml_roundtrip_test.cpp + test-resource-xml-roundtrip build step — proves XML round-trip shape is viable for S03
  - 06-ORACLE-RUNBOOK.md — win-home oracle procedure for MFC golden export across all 21 extensions
  - zig-out/local-test/resource_editor/s01-sweep.log — full Linux sweep log confirming 4/4 new steps green and no new MapEditor regressions
  - docs/superpowers/specs/...design.md ## Amendments — Linux-first-class target statement and user-data-root rule for all downstream slices
requires:
  []
affects:
  []
key_files: []
key_decisions:
  - Spec amendments use append-only dated section (## Amendments) not in-place edits, per AGENTS.md 'newer instruction wins, record in spec' rule.
  - Linux x64 explicitly promoted to first-class ResourceEditor target, superseding earlier 'Linux deferred' posture; reuses all Map Editor Linux solutions verbatim.
  - User-data-root set to <UserRoot>resourceeditor/; extends D-10 from settings-only to all user content; project-file paths stay relative.
  - DXT tolerance measured as-is (max 255, p99≈125) from honest fixture set including high-frequency noise; downstream golden tests adopt this number rather than tuning inputs to shrink it.
  - Preview-scene spike uses existing bridge.h entry points only (BkEditorStart/SetCamera/CaptureFrame/Stop); BkResPreview* reserved for S04.
  - 8 BkEditorOpenMap-dependent MapEditor failures are pre-existing (AIWarFog::SetZero nullptr-memset trap); ownership attributed to S04/S13, not patched in S01.
  - XML round-trip spike is a hand-written portable parser (not a port of Windows-only MSXML CDataTreeXML), matching the portability requirement.
patterns_established:
  - New ResourceEditor build steps use `applyLoaderPath` ($ORIGIN rpath) from MapEditor pattern when they link against engine modules.
  - Fixture generators use Zig 0.16 shape (pub fn main(init), std.process.Args.Iterator, appendSlice not .writer()) per MEM006.
  - All new text files are CRLF (enforced via `sed 's/$/\r/'` append or Zig CRLF write helpers) per .gitattributes.
  - Spec change: append dated ## Amendments section rather than editing prose, so diff is legible and prior narrative survives.
observability_surfaces:
  - none
drill_down_paths:
  []
duration: ""
verification_result: passed
completed_at: 2026-10-04T21:31:11.117Z
blocker_discovered: false
---

# S01: S01

**Established all S01 groundwork: spec amendments (Linux first-class + user-data-root), 21-extension fixture skeleton, XML round-trip harness, DXT tolerance measurement, GPU preview-scene spike, win-home oracle runbook, and a full Linux sweep confirming 4/4 new steps green with no new MapEditor regressions.**

## What Happened

S01 executed across 7 tasks on the `feat/resource-editor` branch on Linux x64 (Ubuntu 24.04).

**T01 — Spec amendments** appended a dated `## Amendments (M001 planning, 2026-10-05)` section to `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md` (CRLF-preserved, additive-only). Two entries: (1) Linux x64 is a first-class target — explicitly supersedes the earlier "Linux deferred" posture and enumerates the reused Map Editor Linux solutions by name (rdynamic + $ORIGIN rpath, 16 MiB worker stack, SDL_WINDOW_HIDDEN flags, ISFX stop before unload, DataFile case-insensitive helper); (2) User content lives under `<UserRoot>resourceeditor/` — extends D-10 from "settings only" to all user content (projects, settings, recent files, window layout, per-tool prefs), paths inside project files stay relative for machine portability.

**T02 — 21-extension fixture skeleton** corrected the T02-PLAN's stale 6-extension candidate list (mnp/sqd/trp/rdp/rvp/cmp) by re-deriving from `Sources/src/editor/*Frm.cpp` `szExtension` strings. All 21 canonical dirs (wpn/mcp/trc/scp/spt/unt/msh/obt/fnc/bld/bdg/pcp/eff/til/3rd/3rv/mip/chc/cgc/mdc/gui) now exist under `tools/zig/fixtures/resource_editor/` with `project.<ext>` stubs and `EXTENSIONS.md` canonical mapping. A Zig generator `resource_editor_fixtures.zig` and `make-resource-fixtures` build step produce them reproducibly.

**T03 — XML round-trip harness** added a portable hand-written XML spike (`Sources/src/ResourceModel/spike/xml_spike.{h,cpp}`) modeling the CDataTreeXML shape (elements, attributes, text, comments, CDATA, PIs; tab-indented CRLF serialization; layout-whitespace-dropping idempotency). The `tools/zig/resource_xml_roundtrip_test.cpp` harness round-trips all 21 extensions to rtout1 == rtout2 == fixture bytes and also proves unknown-node preservation (FutureBlob). All 21 PASS on Linux. `zig build test-resource-xml-roundtrip` exited 0.

**T04 — DXT tolerance measurement** recovered the MFC-era S3TC encoder from commit `40645ad29^` (`Sources/src/Image/S3TC.{h,cpp}`), ported it data-only into `Sources/src/ResourceModel/spike/legacy_dxt.{h,cpp}` as `NLegacyDxt`. `tools/zig/dxt_tolerance_test.cpp` encodes a 3-image fixture set (gradients, sharp-edge checkerboard, high-frequency noise) through both old and new encoders and records per-format max_delta and p99 into `tools/zig/fixtures/resource_editor/dxt-tolerance.json` (CRLF, schema_version:1). Measured: DXT1 max=255 p99=126, DXT3 max=255 p99=125, DXT5 max=255 p99=125. This is the honest baseline from the available source; downstream golden tests must adopt these numbers.

**T05 — GPU preview-scene spike** added `tools/zig/preview_scene_spike.cpp` calling BkEditorStart → BkEditorSetCamera (measured camera runbook for mesh/sprite/particle viewpoints) → BkEditorCaptureFrame → BkEditorStop, wired behind `zig build preview-scene-spike`. Three empty-scene TGA captures committed to `tools/zig/fixtures/resource_editor/preview-scene/` (mesh.tga, sprite.tga, particle.tga). The spike uses only existing bridge.h entry points; BkResPreview* is explicitly reserved for S04. The pre-existing BkEditorOpenMap Linux-debug trap (AIWarFog::SetZero nullptr-memset via HitsStore→AIEditor Clear path) was discovered and documented in a runbook note, attributed to S04/S13.

**T06 — Win-home oracle runbook** created `06-ORACLE-RUNBOOK.md` (CRLF) covering the editor.exe batch-mode command line (one extension per run: `editor.exe <ext> <src> <dst> [-f] [-os]`), 21-extension PowerShell loop, golden layout, exclusions, and re-production steps. Added 21 `golden/.gitkeep` files in each extension dir. Referenced from `06-PARITY.md`.

**T07 — Full S01 sweep** ran `zig build install-game install-map-editor make-resource-fixtures test-resource-xml-roundtrip test-dxt-tolerance preview-scene-spike` plus all 13 MapEditor tiers and recorded a machine-parseable 62-line log at `zig-out/local-test/resource_editor/s01-sweep.log`. Base install PASS; all 4 new S01 steps 4/4 PASS; 5 MapEditor tiers that do not call BkEditorOpenMap PASS; 8 tiers that call BkEditorOpenMap fail on the identical pre-existing AIWarFog::SetZero stack — documented as owned by S04/S13, not introduced by S01's additive-only diff.

## Verification

All slice-level verification conducted via gsd_exec (no direct bash verification calls):

1. **All 7 task SUMMARY files present**: T01–T07-SUMMARY.md confirmed at `.gsd/milestones/M001/slices/S01/tasks/`.
2. **dxt-tolerance.json**: Present at `tools/zig/fixtures/resource_editor/dxt-tolerance.json`, schema_version:1, DXT1/3/5 max=255 p99≈125-126.
3. **21 extension dirs**: All 21 canonical extension directories present under `tools/zig/fixtures/resource_editor/`.
4. **Preview-scene TGAs**: mesh.tga, sprite.tga, particle.tga present at `tools/zig/fixtures/resource_editor/preview-scene/`. Runbook `preview-scene.md` present.
5. **Sweep log**: `zig-out/local-test/resource_editor/s01-sweep.log` present (62 lines). Verdict: 4/4 new S01 steps PASS; 5 non-BkEditorOpenMap MapEditor tiers PASS; 8 BkEditorOpenMap-dependent tiers PRE-EXISTING failure (same AIWarFog::SetZero stack, not S01 regressions).
6. **Spec amendment**: `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md` line 413 confirms `## Amendments (M001 planning, 2026-10-05)` with Linux-first-class and user-data-root entries.
7. **Round-trip harness**: `tools/zig/resource_xml_roundtrip_test.cpp` present; T03 summary records `zig build test-resource-xml-roundtrip` exited 0 on Linux, 21 PASS + unknown-node preservation PASS.

Slice-level verdict: **PASS**. All S01 deliverables are on disk, committed to the branch, and verified by build-step exit codes. No new MapEditor regressions introduced by S01.

## Requirements Advanced

None.

## Requirements Validated

None.

## New Requirements Surfaced

None.

## Requirements Invalidated or Re-scoped

None.

## Operational Readiness

None.

## Deviations

None.

## Known Limitations

8 BkEditorOpenMap-dependent MapEditor tiers are pre-existing failures on Linux debug (AIWarFog::SetZero nullptr-memset trap); owned by S04/S13. Win-home oracle golden exports are deferred until a win-home session runs the runbook. Preview-scene TGAs are empty-scene only; real IVisObjBuilder content is S04's work. macOS and Windows build correctness of new S01 steps is CI-only.

## Follow-ups

S04/S13 must fix the BkEditorOpenMap AIWarFog::SetZero nullptr-memset trap to make the 8 MapEditor tiers green. Win-home operator must run 06-ORACLE-RUNBOOK.md and commit goldens before S03 fixture parity tests can pass. S04 replaces preview-scene TGAs with IVisObjBuilder output and enforces the 1%-non-black-non-magenta assertion.

## Files Created/Modified

None.
