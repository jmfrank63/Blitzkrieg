---
estimated_steps: 3
estimated_files: 24
skills_used: []
---

# T06: Win-home parity-oracle runbook and committed-golden layout

Why: The slice promises "after this: on win-home, MFC `editor.exe` batch-exports repo-owned fixtures for every one of the 21 extensions to committed goldens." The Linux agent cannot run `editor.exe` — the maintainer runs it on win-home. The runbook must be specific enough that the maintainer can produce the goldens unattended, and the committed-golden layout must be stable so S03..S15 can read them.

Do: write `.planning/phases/06-resource-editor-portable-port/06-ORACLE-RUNBOOK.md` that specifies: (a) the exact command line to invoke `editor.exe --batch all <src> <dst>` on win-home (confirm the command line from `Sources/src/editor/BatchModeDialog.cpp` and from spec D-15), (b) the input tree layout (the 21 fixture directories under `tools/zig/fixtures/resource_editor/<ext>/`), (c) the output layout the maintainer must commit back (`tools/zig/fixtures/resource_editor/<ext>/golden/`, one golden tree per extension), (d) the exclusions (GOG mod goldens live on win-home only — never committed), (e) a checklist the maintainer can tick off per extension, (f) how to re-produce goldens when fixtures change (regenerate fixtures, re-run batch, commit new goldens). Add a `tools/zig/fixtures/resource_editor/<ext>/golden/.gitkeep` for each extension so the committed-golden path is reserved before win-home writes into it. Reference the runbook from `06-PARITY.md`'s plan-map section with a single line pointing to the new file.

Done when: `06-ORACLE-RUNBOOK.md` exists and lists exactly 21 extensions with their expected golden sub-paths; a `.gitkeep` exists under each `tools/zig/fixtures/resource_editor/<ext>/golden/` directory; `06-PARITY.md` references the runbook.

## Inputs

- `Sources/src/editor/BatchModeDialog.cpp`
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`
- `tools/zig/fixtures/resource_editor/EXTENSIONS.md`

## Expected Output

- `.planning/phases/06-resource-editor-portable-port/06-ORACLE-RUNBOOK.md`
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`
- `tools/zig/fixtures/resource_editor/wpn/golden/.gitkeep`
- `tools/zig/fixtures/resource_editor/mnp/golden/.gitkeep`
- `tools/zig/fixtures/resource_editor/trc/golden/.gitkeep`
- `tools/zig/fixtures/resource_editor/sqd/golden/.gitkeep`
- `tools/zig/fixtures/resource_editor/spt/golden/.gitkeep`
- `tools/zig/fixtures/resource_editor/unt/golden/.gitkeep`
- `tools/zig/fixtures/resource_editor/msh/golden/.gitkeep`
- `tools/zig/fixtures/resource_editor/obt/golden/.gitkeep`
- `tools/zig/fixtures/resource_editor/fnc/golden/.gitkeep`
- `tools/zig/fixtures/resource_editor/bld/golden/.gitkeep`
- `tools/zig/fixtures/resource_editor/bdg/golden/.gitkeep`
- `tools/zig/fixtures/resource_editor/mcp/golden/.gitkeep`
- `tools/zig/fixtures/resource_editor/eff/golden/.gitkeep`
- `tools/zig/fixtures/resource_editor/til/golden/.gitkeep`
- `tools/zig/fixtures/resource_editor/trp/golden/.gitkeep`
- `tools/zig/fixtures/resource_editor/rdp/golden/.gitkeep`
- `tools/zig/fixtures/resource_editor/rvp/golden/.gitkeep`
- `tools/zig/fixtures/resource_editor/mip/golden/.gitkeep`
- `tools/zig/fixtures/resource_editor/chc/golden/.gitkeep`
- `tools/zig/fixtures/resource_editor/cmp/golden/.gitkeep`
- `tools/zig/fixtures/resource_editor/mdc/golden/.gitkeep`
- `tools/zig/fixtures/resource_editor/gui/golden/.gitkeep`

## Verification

test -f .planning/phases/06-resource-editor-portable-port/06-ORACLE-RUNBOOK.md
