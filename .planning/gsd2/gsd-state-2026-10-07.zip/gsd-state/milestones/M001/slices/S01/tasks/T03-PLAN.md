---
estimated_steps: 3
estimated_files: 4
skills_used: []
---

# T03: C++ project-XML round-trip harness: parse and re-serialise every extension idempotently

Why: Spec D-07 requires MFC project XML read and written unchanged for all 21 extensions, with unknown-node preservation. Before `ResourceModel` is extracted in S03 and before any sub-editor is built on top, we need a round-trip harness that proves the shape of the round trip is viable. This is the project-XML spike called out in the slice goal.

Do: add `tools/zig/resource_xml_roundtrip_test.cpp` that drives the ported MFC XML parse / serialise code paths. The MFC XML flow lives in `Sources/src/editor/common.cpp` (`operator&( IDataTree & )` glue) and the tree items (`TreeItem.cpp`, `TreeItem.h`); port the minimum shim (XML parse/serialise + variant + glue) into `Sources/src/ResourceModel/spike/xml_spike.{cpp,h}` so the harness can link against portable code only (no MFC, no Windows API). The harness: for each of the 21 fixture projects, (a) parse into an in-memory tree, (b) serialise to `.rtout1`, (c) re-parse the `.rtout1`, (d) re-serialise to `.rtout2`, (e) `memcmp` `.rtout1` and `.rtout2`. The harness also plants an unknown `<FutureBlob attr="x">body</FutureBlob>` node into a copy of each fixture and asserts it survives round trip (preservation test). Wire a new `test-resource-xml-roundtrip` build step that runs the harness and sets its executable's rpath per AGENTS.md Linux pitfalls (`$ORIGIN` rpath on Linux, `rdynamic` if the harness ends up loading engine modules — should not be needed here, but keep the pattern). Resolve any `DataFile` paths case-insensitively.

Done when: `zig build test-resource-xml-roundtrip` exits 0 locally, logging `PASS <ext>` for each of the 21 extensions and `PASS <ext> unknown-node preservation` for each. On any FAIL the harness exits non-zero and prints the first diverging byte offset plus a hex context window.

## Inputs

- `Sources/src/editor/common.cpp`
- `Sources/src/editor/common.h`
- `Sources/src/editor/TreeItem.cpp`
- `Sources/src/editor/TreeItem.h`
- `tools/zig/editor_bridge_test.cpp`
- `tools/zig/fixtures/resource_editor/EXTENSIONS.md`
- `tools/zig/fixtures/resource_editor/wpn/project.wpn`

## Expected Output

- `tools/zig/resource_xml_roundtrip_test.cpp`
- `Sources/src/ResourceModel/spike/xml_spike.cpp`
- `Sources/src/ResourceModel/spike/xml_spike.h`
- `build.zig`

## Verification

zig build test-resource-xml-roundtrip

## Observability Impact

Signals: harness writes PASS/FAIL per extension to stderr with a byte-offset of the first divergence on failure; writes `zig-out/local-test/resource_editor/roundtrip/<ext>.rtout1` and `.rtout2` on failure so an agent can diff them with the fixture directly.
