---
id: T05
parent: S01
milestone: M001
key_files:
  - tools/zig/preview_scene_spike.cpp
  - tools/zig/fixtures/resource_editor/preview-scene/preview-scene.md
  - tools/zig/fixtures/resource_editor/preview-scene/.gitkeep
  - tools/zig/fixtures/resource_editor/preview-scene/mesh.tga
  - tools/zig/fixtures/resource_editor/preview-scene/sprite.tga
  - tools/zig/fixtures/resource_editor/preview-scene/particle.tga
  - build.zig
key_decisions:
  - Spike captures on the engine's empty default scene instead of opening a shipped map, because D-16 says the preview scene is an empty IScene with no terrain, and because BkEditorOpenMap hits a pre-existing Linux-debug trap (CArray2D::SetZero memset(nullptr, 0, 0) in AIWarFog/HitsStore/AIEditor Clear path) that also fails test-editor-bridge on this host today - not opening a map keeps the spike aligned with the spec AND avoids a dependency on a pre-existing engine issue.
  - Non-black-non-magenta pixel share is LOGGED per capture, not asserted, for T05. The empty default scene reads ~0.248 (clear colour is non-black), which would make a 1% assertion pass trivially. The runbook explicitly leaves the hard assertion to S04 once IVisObjBuilder places real mesh/sprite/particle objects; the hard assertion the spike enforces today is only that every capture wrote a readable TGA.
  - No new bridge C ABI surface was added. The spike rides on BkEditorStart / BkEditorScreenSize / BkEditorSetCamera / BkEditorCaptureFrame / BkEditorStop - every one of them already in bridge.h and already measured by the engine tier - because the preview-scene bridge path (BkResPreviewBegin / BkResPreviewShow) is explicitly S04's work per the design (D-16) and must not be invented here before S04 has measured what it needs.
duration: 
verification_result: passed
completed_at: 2026-10-04T21:02:44.488Z
blocker_discovered: false
---

# T05: Added a GPU-hosted preview-scene spike (BkEditorStart + camera + BkEditorCaptureFrame) with a measured-camera runbook, wired behind `zig build preview-scene-spike`, and captured three empty-scene TGAs on Linux for S04 to replace with real IVisObjBuilder output.

**Added a GPU-hosted preview-scene spike (BkEditorStart + camera + BkEditorCaptureFrame) with a measured-camera runbook, wired behind `zig build preview-scene-spike`, and captured three empty-scene TGAs on Linux for S04 to replace with real IVisObjBuilder output.**

## What Happened

T05's purpose was to pin down the preview scene before any sub-editor depends on it: a measured camera, a captured frame per preview kind (mesh / sprite / particle), and a committed runbook that S04 inherits. The deliverables are `tools/zig/preview_scene_spike.cpp` (a C++ harness that follows the composer-roundtrip pattern - hidden SDL, BkEditorStart, honest skip on NO_DEVICE / no-video / BK_REQUIRE_ENGINE), `tools/zig/fixtures/resource_editor/preview-scene/preview-scene.md` (the runbook, documenting the measured camera parameters, the scene shape per kind, the pixel-share semantics and the S04 hand-off), the three captured TGAs (`mesh.tga`, `sprite.tga`, `particle.tga`), a `.gitkeep` and the `zig build preview-scene-spike` wiring in `build.zig` (via a one-liner call to the existing `addEngineHostedTool`). Three key design calls fell out of the measurement work. (1) The spike does NOT open a map. D-16 says the preview scene is an empty IScene with no terrain (except for S13's road/river); opening a map also hits a pre-existing Linux-debug trap in `CArray2D::SetZero` where `memset(nullptr, 0, 0)` is called before the AI war fog is sized (same trap `test-editor-bridge` hits today on this host, so the trap is logged in the runbook as a Linux-only fix S04/S13 inherits, not a T05 blocker). (2) The non-black-non-magenta pixel share is LOGGED but not asserted: on an empty default scene, every capture reads ~0.248 (the engine clears to a non-black colour), which does meet the plan's 1% floor by accident. Treating it as a hard assertion today would make the spike pass trivially; treating it as informational tells S04 to promote it to an assertion once IVisObjBuilder places a real mesh / sprite / particle. (3) The three per-kind captures are deliberately identical on today's empty scene (no object differs between them yet); the runbook names each by its fixture path (unt/project.unt, spt/project.spt, eff/project.eff) so when S04 wires `BkResPreviewBegin`, the three captures diverge against the measured camera that is already pinned down. The spike runs clean on this Linux agent (ran, PASS, exit 0, ~3.4 s), produces three well-formed 640x480 32-bpp top-row-first TGAs and a human-readable `spike.log` under `zig-out/local-test/preview-scene/`; those three TGAs are copied into the fixtures directory so a reader without the engine built can see the shape. Camera envelope recorded: 640x480 window, yaw 45° (game default, D-12), world-units-per-tile 32.0, anchor at the engine's CCamera default when no map is open.

## Verification

Ran `zig build preview-scene-spike` on Linux (Ubuntu 24.04 x86_64, SDL_GPU on PulseAudio). The step compiled the harness, staged it beside Game, started the engine, measured the screen (640x480), called BkEditorSetCamera and BkEditorCaptureFrame three times with the mesh / sprite / particle labels, read each captured TGA back and measured its non-black-non-magenta share (0.247917 for each of the three on the empty default scene). The harness exited 0 (PASS). Verified the TGA layout independently with a Python script: all three files are TGA type 2 (uncompressed truecolor), 640x480, 32 bpp, descriptor 0x28 (top-left origin, 8-bit alpha). Also confirmed the harness compiles everywhere by the same addEngineHostedTool recipe that composer-roundtrip-test uses - the compile step is identical, only the source file name differs; a dry `zig build --help` lists the new step. Did not test the no-GPU skip path on this host (this host does have a GPU and SDL_GPU came up); the code path is the same as random-missions-test, composer-roundtrip-test and editor-bridge-test, each of which exercises SkipOrFail in CI.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build preview-scene-spike` | 0 | pass | 3384ms |
| 2 | `python3 header-check mesh.tga sprite.tga particle.tga` | 0 | pass | 50ms |
| 3 | `zig build --help | grep preview-scene` | 0 | pass | 200ms |

## Deviations

The task plan asks the harness to build each object through IVisObjBuilder from the committed fixtures; the shipping bridge has no IVisObjBuilder entry point yet (D-16 schedules BkResPreviewBegin / BkResPreviewShow for S04). The spike therefore captures the engine's empty default scene with the mesh/sprite/particle LABELS and fixture pointers already in place, so S04 only has to add the preview-scene bridge calls and swap three lines. The runbook names this hand-off explicitly.

## Known Issues

BkEditorOpenMap triggers a null-pointer sanitizer trap (`memset(nullptr, 0, 0)` in `CArray2D::SetZero`, Sources/src/Misc/2Darray.h:33) on Linux Zig 0.16 debug builds. The trap is in the AI editor's Clear path (AIEditorInternal.cpp:444 → AILogicInternal.cpp:130 → GlobalObjects.cpp:72 → HitsStore.cpp:53 → AIWarFog SetZero). test-editor-bridge hits the same trap today on this host. The preview-scene spike works around it by not opening a map (the preview scene is specified as mapless anyway). S04 or S13 must fix the trap before adding `maps\\road3d` / `maps\\river3d` preview terrain to the spike - a one-line guard in 2Darray.h on the memset would suffice.

## Files Created/Modified

- `tools/zig/preview_scene_spike.cpp`
- `tools/zig/fixtures/resource_editor/preview-scene/preview-scene.md`
- `tools/zig/fixtures/resource_editor/preview-scene/.gitkeep`
- `tools/zig/fixtures/resource_editor/preview-scene/mesh.tga`
- `tools/zig/fixtures/resource_editor/preview-scene/sprite.tga`
- `tools/zig/fixtures/resource_editor/preview-scene/particle.tga`
- `build.zig`
