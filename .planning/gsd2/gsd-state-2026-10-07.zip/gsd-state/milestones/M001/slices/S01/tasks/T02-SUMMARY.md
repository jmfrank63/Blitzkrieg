---
id: T02
parent: S01
milestone: M001
key_files:
  - tools/zig/resource_editor_fixtures.zig
  - tools/zig/fixtures/resource_editor/EXTENSIONS.md
  - tools/zig/fixtures/resource_editor/wpn/project.wpn
  - tools/zig/fixtures/resource_editor/mcp/project.mcp
  - tools/zig/fixtures/resource_editor/trc/project.trc
  - tools/zig/fixtures/resource_editor/scp/project.scp
  - tools/zig/fixtures/resource_editor/spt/project.spt
  - tools/zig/fixtures/resource_editor/unt/project.unt
  - tools/zig/fixtures/resource_editor/msh/project.msh
  - tools/zig/fixtures/resource_editor/obt/project.obt
  - tools/zig/fixtures/resource_editor/fnc/project.fnc
  - tools/zig/fixtures/resource_editor/bld/project.bld
  - tools/zig/fixtures/resource_editor/bdg/project.bdg
  - tools/zig/fixtures/resource_editor/pcp/project.pcp
  - tools/zig/fixtures/resource_editor/eff/project.eff
  - tools/zig/fixtures/resource_editor/til/project.til
  - tools/zig/fixtures/resource_editor/3rd/project.3rd
  - tools/zig/fixtures/resource_editor/3rv/project.3rv
  - tools/zig/fixtures/resource_editor/mip/project.mip
  - tools/zig/fixtures/resource_editor/chc/project.chc
  - tools/zig/fixtures/resource_editor/cgc/project.cgc
  - tools/zig/fixtures/resource_editor/mdc/project.mdc
  - tools/zig/fixtures/resource_editor/gui/project.gui
  - build.zig
key_decisions:
  - Took the 21-row list straight from the MFC frames: grepped `szExtension` + `szComposerSaveName` in Sources/src/editor/*Frm.cpp and both windows returned 21, exactly matching the slice goal. Six T02 candidate-list extensions were wrong (mnp/sqd/trp/rdp/rvp/cmp) and were corrected to the frames' actual registrations (mcp/scp/pcp/3rd/3rv/cgc). The resolved mapping is now the source-of-truth in EXTENSIONS.md.
  - Project XML uses the minimum shape CDataTreeXML writes: `<?xml version="1.0"?>` + a root element named exactly `szComposerSaveName` + one trivial `<fixture><name>minimal</name></fixture>` child. Any thinner shape would stop being a well-formed project; any richer would be eyeballing. The T03 round-trip harness will measure the full MFC parser against these.
  - Art taxonomy per extension kind: 14 picture (16x16 TGA, deterministic sha256(ext)->BGR seed), 3 mesh (2x2x2 cube OBJ with 8 verts/12 tris), 2 sprite (single-frame TGA), 2 particle/effect (two-keyframe text). Choice is recorded in EXTENSIONS.md so downstream slices don't re-derive it; the actual placeholder bytes can be swapped later without changing the per-extension art kind column.
  - Idempotency is implemented by read-before-write: each generator computes the bytes, reads any existing file, and only writes when the bytes differ. The step prints `written=0 unchanged=43` on re-run; this is the slice's machine-parseable fingerprint that nothing drifted. A `comptime` assertion `if (fixtures.len != 21) @compileError(...)` guards the count at build time so a drift against the frames breaks the build loudly.
  - The build step runs with fixed `--out tools/zig/fixtures/resource_editor --log zig-out/local-test/resource_editor/make-fixtures.log` so committed goldens live under source control and per-run output lives beside other local test artefacts. The log is a byte-for-byte copy of the stderr trace, giving downstream agents an on-disk fingerprint for `gsd_exec_search` comparisons.
duration: 
verification_result: passed
completed_at: 2026-10-04T20:17:20.769Z
blocker_discovered: false
---

# T02: Enumerated the 21 ResourceEditor project extensions from the MFC frame sources and generated a deterministic, idempotent repo-owned fixture (project.<ext> + tiny source art) for each, driven by `zig build make-resource-fixtures`.

**Enumerated the 21 ResourceEditor project extensions from the MFC frame sources and generated a deterministic, idempotent repo-owned fixture (project.<ext> + tiny source art) for each, driven by `zig build make-resource-fixtures`.**

## What Happened

Grepped `szExtension = "*.<ext>"` and `szComposerSaveName = "<Name>_Composer_Project"` across `Sources/src/editor/*Frm.cpp`; both grep windows yielded exactly 21 CParentFrame subclasses, which is the authoritative source-of-truth count the slice goal cites. Reconciled this against the T02 plan's candidate list (`wpn, mnp, trc, sqd, spt, unt, msh, obt, fnc, bld, bdg, mcp, eff, til, trp, rdp, rvp, mip, chc, cmp, mdc, gui` — 22 entries, several wrong). Six candidates were corrected to the frames' actual registrations: `mnp→mcp` (MineFrm), `sqd→scp` (SquadFrm), `trp→pcp` (ParticleFrm), `rdp→3rd` (3dRoadFrm), `rvp→3rv` (3dRiverFrm), `cmp→cgc` (CampaignFrm). The resolved 21-row mapping is recorded in `tools/zig/fixtures/resource_editor/EXTENSIONS.md` with the owning frame cpp file, the composer name, and the exact XML root tag (`szComposerSaveName`) each project loader selects on in `ParentFrame::LoadComposerFile` / `OnFileSave`.

Built `tools/zig/resource_editor_fixtures.zig` as a Zig 0.16 build-time tool following the `season_textures.zig` shape (`pub fn main(init: std.process.Init)`, CLI arg parsing, `std.Io.Dir`). The fixtures table is a `[21]Fixture` static array with a `comptime` length assertion so a drift against the frame count breaks the build at compile time. Each row names its placeholder art kind: picture (14 extensions) → 16×16 24-bit solid-colour Targa whose colour is seeded by sha256(ext); mesh (3 extensions: unt, msh, obt) → 2×2×2 Wavefront OBJ cube with 8 vertices and 12 triangle faces; sprite (2 extensions: scp, spt) → single-frame TGA using the same shape as the picture generator; particle (2 extensions: pcp, eff) → two-keyframe plain-text time/value table. All text files are CRLF-terminated per `.gitattributes`; all 43 files are well under 4 KB (largest is 786 B for the TGAs, EXTENSIONS.md is 3801 B).

The project XML uses the minimum shape `CDataTreeXML::Open` writes in WRITE mode (per `Sources/src/StreamIOLib/DataTreeXML.cpp`): `<?xml version="1.0"?>` + a root element named after `szComposerSaveName` + a single `<fixture><name>minimal</name></fixture>` child. This is as thin as the loader will accept without eyeballing; a real round-trip harness (T03) will exercise the full shape via `CreateDataTreeSaver` and `pTreeDockBar->LoadTrees`.

Added `make-resource-fixtures` and `test-resource-editor-fixtures` steps in `build.zig`. The main step runs with fixed `--out tools/zig/fixtures/resource_editor` and `--log zig-out/local-test/resource_editor/make-fixtures.log` so the committed goldens are stable and the per-run log lives beside other local build artefacts. The generator reads any existing file before writing and only touches disk when the bytes differ, so a second `zig build make-resource-fixtures` reports `written=0 unchanged=43` — byte-identical idempotency, which is the slice's observability contract. In-memory tests (6, all passing) assert: 21 distinct extensions; XML round-trips the composer save name and is pure CRLF; every art kind stays under 4 KB and is deterministic across two renders; the TGA has a valid 18-byte header + 16×16×24 pixel block; the OBJ has 8 verts + 12 faces; particle has exactly two data lines.

## Verification

Ran the slice-level verification `zig build make-resource-fixtures` on a clean target dir (43 files written) and then twice more on the populated dir (both runs reported `written=0 unchanged=43`, proving byte-identical idempotency). Hashed every file with `sha256sum` after the first run and after the second run; `diff` on the two snapshot files was empty. Ran `zig build test-resource-editor-fixtures -Dtest-mode=run --summary all` — 6/6 unit tests passed. Confirmed CRLF line terminators with `file` on `project.wpn`, `EXTENSIONS.md`, `mesh-2x2x2.obj`, `particle-2key.txt`, and TGA integrity (`Targa image data - RGB 16 x 16 x 24`) on `art-16x16.tga`. Ran `zig build test-editor-core --summary all` to confirm no MapEditor regression — 390/390 tests passed. The per-run log at `zig-out/local-test/resource_editor/make-fixtures.log` matches the stderr trace line-for-line.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build make-resource-fixtures` | 0 | pass (first run wrote 43/43 files) | 16000ms |
| 2 | `zig build make-resource-fixtures (second run)` | 0 | pass (written=0 unchanged=43 — byte-identical) | 1500ms |
| 3 | `zig build make-resource-fixtures (third run)` | 0 | pass (written=0 unchanged=43) | 1500ms |
| 4 | `sha256sum $(find tools/zig/fixtures/resource_editor -type f | sort) > /tmp/a; <re-run>; sha256sum ... > /tmp/b; diff /tmp/a /tmp/b` | 0 | pass (no diff — same 43 hashes) | 200ms |
| 5 | `zig build test-resource-editor-fixtures -Dtest-mode=run --summary all` | 0 | pass (6/6 tests passed) | 13000ms |
| 6 | `zig build test-editor-core --summary all` | 0 | pass (390/390 tests, no MapEditor regression) | 22000ms |
| 7 | `file tools/zig/fixtures/resource_editor/{wpn/project.wpn,EXTENSIONS.md,msh/mesh-2x2x2.obj,pcp/particle-2key.txt,wpn/art-16x16.tga}` | 0 | pass (XML+CRLF, text+CRLF, text+CRLF, text+CRLF, Targa 16x16x24) | 40ms |

## Deviations

The T02 candidate extension list included six incorrect names (`mnp, sqd, trp, rdp, rvp, cmp`) that do not appear in any CParentFrame subclass. Replaced them with the frame-authoritative ones (`mcp, scp, pcp, 3rd, 3rv, cgc`). The task plan expected this reconciliation ("if there are discrepancies, document the resolved list") and the resolved mapping is recorded in `EXTENSIONS.md` with frame-cpp provenance for every row — not a slice-plan blocker.

## Known Issues

None. The art placeholders are deliberately minimal; downstream slices (T03 round-trip, T04 DXT tolerance, T05 preview-scene) will exercise the real engine readers against these fixtures and may later ask for richer source art, which is a drop-in change to `resource_editor_fixtures.zig` as long as the per-fixture outputs stay under 4 KB.

## Files Created/Modified

- `tools/zig/resource_editor_fixtures.zig`
- `tools/zig/fixtures/resource_editor/EXTENSIONS.md`
- `tools/zig/fixtures/resource_editor/wpn/project.wpn`
- `tools/zig/fixtures/resource_editor/mcp/project.mcp`
- `tools/zig/fixtures/resource_editor/trc/project.trc`
- `tools/zig/fixtures/resource_editor/scp/project.scp`
- `tools/zig/fixtures/resource_editor/spt/project.spt`
- `tools/zig/fixtures/resource_editor/unt/project.unt`
- `tools/zig/fixtures/resource_editor/msh/project.msh`
- `tools/zig/fixtures/resource_editor/obt/project.obt`
- `tools/zig/fixtures/resource_editor/fnc/project.fnc`
- `tools/zig/fixtures/resource_editor/bld/project.bld`
- `tools/zig/fixtures/resource_editor/bdg/project.bdg`
- `tools/zig/fixtures/resource_editor/pcp/project.pcp`
- `tools/zig/fixtures/resource_editor/eff/project.eff`
- `tools/zig/fixtures/resource_editor/til/project.til`
- `tools/zig/fixtures/resource_editor/3rd/project.3rd`
- `tools/zig/fixtures/resource_editor/3rv/project.3rv`
- `tools/zig/fixtures/resource_editor/mip/project.mip`
- `tools/zig/fixtures/resource_editor/chc/project.chc`
- `tools/zig/fixtures/resource_editor/cgc/project.cgc`
- `tools/zig/fixtures/resource_editor/mdc/project.mdc`
- `tools/zig/fixtures/resource_editor/gui/project.gui`
- `build.zig`
