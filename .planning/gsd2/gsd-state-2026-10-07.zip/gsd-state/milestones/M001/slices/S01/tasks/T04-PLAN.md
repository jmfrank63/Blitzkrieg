---
estimated_steps: 3
estimated_files: 5
skills_used: []
---

# T04: Measure DXT tolerance between the MFC-era encoder and NDxt (DXT1/DXT3/DXT5)

Why: Spec D-11 says DDS files must decode within a *measured* tolerance against the MFC golden. R019 pins the measurement to this slice. Without a committed `dxt-tolerance.json`, downstream golden tests have no credible pass/fail bar.

Do: identify the MFC-era DXT encoder path. The MFC editor's DDS writer in `Sources/src/editor/` eventually calls into either an in-tree encoder or into `nvDXT`-style code; grep `Sources/src/editor/` and `Sources/src/Image/` for DXT1/DXT3/DXT5 encoding entry points, pick the one `editor.exe` was built against, and port the encoder as data-only C++ into `Sources/src/ResourceModel/spike/legacy_dxt.cpp` under a `kLegacyDxt` namespace. Add `tools/zig/dxt_tolerance_test.cpp` that: (a) generates a deterministic 256x256 RGBA8 test image set (3 images: smooth gradient, high-frequency noise, sharp mask) seeded from a fixed PRNG, (b) encodes each with both encoders for DXT1, DXT3, DXT5, (c) decodes both with `NDxt::Decode`, (d) computes per-pixel absolute delta across all 4 channels, writes `max_delta` and `p99` (99th percentile) per format into `tools/zig/fixtures/resource_editor/dxt-tolerance.json` with schema `{"schema_version":1,"formats":{"DXT1":{"max_delta":N,"p99":M},"DXT3":{...},"DXT5":{...}}}`. Wire `zig build test-dxt-tolerance`. The test is deterministic: re-run writes an identical JSON.

Done when: `tools/zig/fixtures/resource_editor/dxt-tolerance.json` exists with all three formats populated; `zig build test-dxt-tolerance` exits 0 and the JSON is byte-identical on re-run.

## Inputs

- `Sources/src/Image/DxtCodec.h`
- `Sources/src/Image/DxtCodec.cpp`
- `Sources/src/editor/common.cpp`

## Expected Output

- `tools/zig/dxt_tolerance_test.cpp`
- `Sources/src/ResourceModel/spike/legacy_dxt.cpp`
- `Sources/src/ResourceModel/spike/legacy_dxt.h`
- `tools/zig/fixtures/resource_editor/dxt-tolerance.json`
- `build.zig`

## Verification

zig build test-dxt-tolerance

## Observability Impact

Signals: the test writes per-format histograms to `zig-out/local-test/resource_editor/dxt/histogram-<fmt>.csv` so an agent debugging a future golden regression can see the full distribution, not just max/p99. Failure visibility: on any encode/decode fault, stderr prints the format, image name, and the pixel coordinates where the delta was first observed.
