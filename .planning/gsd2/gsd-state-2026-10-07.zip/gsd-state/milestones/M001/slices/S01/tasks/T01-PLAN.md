---
estimated_steps: 3
estimated_files: 1
skills_used: []
---

# T01: Amend the spec: Linux first-class and user-data-root rule

Why: AGENTS.md requires that when a milestone context overrides the spec, the newer instruction wins AND the change is recorded in the spec. D001 made Linux a first-class M001 target and D002 fixed where user content lives; both override the spec's "Linux deferred" note and extend D-10. Nothing downstream should start reading the fixture / oracle plan until the spec reflects reality.

Do: open `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`, add a dated `## Amendments (M001 planning, 2026-10-05)` section at the end. Record two entries: (1) "Linux x64 is a first-class target for `ResourceEditor` and the shared editor kit; the Map Editor's Linux solutions (`rdynamic`, `$ORIGIN` rpath, 16 MiB worker stacks, hidden-window flags, ISFX stop-before-unload, case-insensitive `DataFile`) are reused." (2) "User content (projects, settings, recent files) lives under `<UserRoot>resourceeditor/`; paths stored inside project files are relative where the project format allows. This extends D-10 to all user content." Reference MEM001, MEM002, D001, D002. Do not rewrite existing spec sections; append only.

Done when: the file ends with the Amendments section containing both entries; CRLF line endings preserved; grep for `Amendments (M001 planning` succeeds.

## Inputs

- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`
- `.gsd/DECISIONS.md`
- `.planning/phases/06-resource-editor-portable-port/06-CONTEXT.md`

## Expected Output

- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`

## Verification

grep -q "Amendments (M001 planning" docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md
