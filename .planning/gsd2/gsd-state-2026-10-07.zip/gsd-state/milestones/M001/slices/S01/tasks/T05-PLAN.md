---
estimated_steps: 3
estimated_files: 4
skills_used: []
---

# T05: Preview-scene spike: capture frames for mesh / sprite / particle and write the runbook

Why: Spec D-16 defines the preview as an export-into-temp-storage + `IVisObjBuilder` build, and D-17 requires measuring the preview scene shape *before* any sub-editor depends on it. R018 ties this to S01 explicitly. The lesson of phase 3's yaw measurement is: the renderer breaks silently with non-game cameras, so camera and scene shape must be captured by code, not judged from source.

Do: using the existing `Sources/editor/app/host.zig` SDL-hidden-window pattern + `BkEditorCaptureFrame` (from the MapEditor), add `tools/zig/preview_scene_spike.cpp` that: (a) starts the engine data-only via `BkEditorStart`, (b) builds an empty `IScene` with a game-like camera (match `MapEditor` camera distance/pitch within the measured working envelope), (c) for each of three inputs — one trivial mesh unit object from `tools/zig/fixtures/resource_editor/unt/`, one sprite object from `.../spt/`, one particle source from `.../eff/` — builds the object through `IVisObjBuilder` and captures a frame via `BkEditorCaptureFrame` to `tools/zig/fixtures/resource_editor/preview-scene/{mesh,sprite,particle}.tga`. The test asserts each captured TGA has at least 1 % non-black-non-magenta pixels (object visible, no all-magenta renderer fallback). Write `tools/zig/fixtures/resource_editor/preview-scene/preview-scene.md`: documents the camera parameters (distance, pitch, FOV), the scene shape (no terrain for mesh/sprite, `maps\\road3d` / `maps\\river3d` for road/river in S13), the capture command, and the non-black-pixel assertion threshold. Wire `zig build preview-scene-spike`. On Linux without a GPU runner this step is `skip` with a logged reason — the Linux agent still produces the runbook and the test code, and the step runs end-to-end only on macOS/Windows CI.

Done when: `preview-scene.md` exists; the three TGAs exist (committed from a run on a GPU-capable host — can be deferred until the first macOS/Windows CI run after push); on Linux `zig build preview-scene-spike` either runs end-to-end (if GPU present) or logs `skip: no GPU device` and exits 0; the harness source compiles everywhere.

## Inputs

- `Sources/editor/app/host.zig`
- `Sources/src/EditorBridge/bridge.h`
- `tools/zig/editor_bridge_test.cpp`
- `tools/zig/fixtures/resource_editor/unt/project.unt`
- `tools/zig/fixtures/resource_editor/spt/project.spt`
- `tools/zig/fixtures/resource_editor/eff/project.eff`

## Expected Output

- `tools/zig/preview_scene_spike.cpp`
- `tools/zig/fixtures/resource_editor/preview-scene/preview-scene.md`
- `tools/zig/fixtures/resource_editor/preview-scene/.gitkeep`
- `build.zig`

## Verification

zig build preview-scene-spike

## Observability Impact

Signals: harness logs camera parameters, scene build time, and non-black-pixel percentage per capture to `zig-out/local-test/resource_editor/preview-scene/spike.log`. Failure visibility: if the `IVisObjBuilder` returns a null object, the harness exits with a named error (`preview-scene: build-failed <kind>`) and persists the engine's bridge-side `Guarded` status message to the log; so S04 and the sub-editor slices can diagnose preview breakage from a single file.
