---
id: T06
parent: S01
milestone: M001
key_files: []
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-04T20:42:34.780Z
blocker_discovered: false
---

# T06: Wrote the win-home MFC oracle runbook with 21-extension checklist, added golden/.gitkeep for all 21 extensions, linked from 06-PARITY.md.

**Wrote the win-home MFC oracle runbook with 21-extension checklist, added golden/.gitkeep for all 21 extensions, linked from 06-PARITY.md.**

## What Happened

Created 06-ORACLE-RUNBOOK.md (CRLF) covering command line, input tree, golden layout, exclusions, per-extension checklist (21 rows in MFC frame order) and re-production steps. The command line was confirmed from CEditorApp::RunBatchMode in editor.cpp: legacy editor.exe takes exactly one extension per run (editor.exe <ext> <src> <dst> [-f] [-os]) and has no `all` mode and no `--batch` flag; `all` is new-editor only per D-15, so the runbook loops over 21 extensions in PowerShell. Added a one-line reference in 06-PARITY.md after the plan map table. Created golden/.gitkeep in each of the 21 canonical extension directories. DEVIATION: T06-PLAN's Expected Output listed 6 stale extensions (mnp/sqd/trp/rdp/rvp/cmp) superseded by T02's correction (mcp/scp/pcp/3rd/3rv/cgc). Produced .gitkeeps for the canonical 21 from EXTENSIONS.md.

## Verification

Runbook exists; 21 .gitkeep files under golden/ dirs; 21 checklist rows; PARITY references runbook; CRLF preserved.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `test -f .planning/phases/06-resource-editor-portable-port/06-ORACLE-RUNBOOK.md` | 0 | pass | 10ms |
| 2 | `find tools/zig/fixtures/resource_editor -name .gitkeep -path '*/golden/*' | wc -l (21)` | 0 | pass | 20ms |
| 3 | `grep -c '^| \[ \]' 06-ORACLE-RUNBOOK.md (21)` | 0 | pass | 10ms |

## Deviations

None.

## Known Issues

None.

## Files Created/Modified

None.
