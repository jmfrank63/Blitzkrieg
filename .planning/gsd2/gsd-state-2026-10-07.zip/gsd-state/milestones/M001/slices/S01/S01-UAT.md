# S01: S01 — UAT

**Milestone:** M001
**Written:** 2026-10-04T21:31:11.117Z

# UAT: S01 — Foundational spike artefacts for ResourceEditor

## UAT Type
Manual verification on win-home (oracle runbook) and automated on Linux (build steps). The Linux automated portion is executable now; the win-home oracle portion is deferred to the MFC-export session referenced in the runbook.

## Preconditions
- On Linux x64: `feat/resource-editor` branch checked out; `zig` 0.16 on PATH; GPU available for preview capture (or `BK_NO_GPU=1` for headless fallback path added in T05).
- On win-home (oracle, deferred): Windows host with `editor.exe` built from `A7.sln`; `tools/zig/fixtures/resource_editor/` checked out.

---

## Linux Automated Steps

1. Run `zig build make-resource-fixtures`.
   **Expected**: exits 0; `tools/zig/fixtures/resource_editor/<ext>/project.<ext>` exist for all 21 extensions.

2. Run `zig build test-resource-xml-roundtrip`.
   **Expected**: exits 0; logs `PASS <ext>` for all 21 extensions and `PASS unknown-node preservation` for all 21.

3. Run `zig build test-dxt-tolerance`.
   **Expected**: exits 0; `tools/zig/fixtures/resource_editor/dxt-tolerance.json` is written with schema_version:1 and DXT1/3/5 max_delta/p99 values; subsequent runs produce byte-identical JSON (stable CRLF).

4. Run `zig build preview-scene-spike`.
   **Expected**: exits 0; three TGAs written to `tools/zig/fixtures/resource_editor/preview-scene/` (mesh.tga, sprite.tga, particle.tga); each is a valid readable TGA (non-empty file, readable header).

5. Run `zig build install-game install-map-editor`.
   **Expected**: exits 0; MapEditor tiers that do not depend on BkEditorOpenMap pass; the 8 BkEditorOpenMap-dependent tiers fail on the known pre-existing AIWarFog::SetZero trap (same stack as before S01).

---

## Win-Home Oracle Steps (deferred, tracked in 06-ORACLE-RUNBOOK.md)

6. Follow `06-ORACLE-RUNBOOK.md` to batch-export all 21 extensions from a fixture source through `editor.exe`.
   **Expected**: For each extension, `golden/<ext>/` is populated with the MFC-exported output; no extension silently produces an empty golden dir.

7. Commit the win-home goldens to `tools/zig/fixtures/resource_editor/<ext>/golden/`.
   **Expected**: Each `golden/` dir contains at least one output file; `.gitkeep` can be removed.

---

## Edge Cases
- `make-resource-fixtures` run twice: second run must be idempotent (same byte output, no errors).
- `test-dxt-tolerance` run on a fresh clone (no prior `zig-out`): must rebuild from scratch and produce identical JSON.
- `preview-scene-spike` on a headless CI runner without GPU: must exit with documented escape (log `skip: no GPU device`, exit 0) rather than crash.

---

## Not Proven By This UAT
- MFC-era `editor.exe` correctness of the win-home golden exports (proven by MFC editor's own test suite and shipped Data/).
- That S04's `BkResPreview*` produces non-black-non-magenta pixels above the 1% threshold (explicitly deferred to S04).
- That the DXT tolerance numbers are tight enough for every downstream sub-editor's quality bar (downstream slices adopt `dxt-tolerance.json` as their acceptance threshold and may tighten it per sub-editor).
- macOS and Windows build correctness of the new S01 steps (CI verifies on push; no local macOS/Windows result claimed).
- The 8 BkEditorOpenMap-dependent MapEditor tiers are green (pre-existing failure, owned by S04/S13).
