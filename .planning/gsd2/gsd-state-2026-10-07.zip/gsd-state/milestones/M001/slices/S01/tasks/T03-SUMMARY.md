---
id: T03
parent: S01
milestone: M001
key_files: []
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-04T20:43:11.065Z
blocker_discovered: false
---

# T03: Portable C++ project-XML round-trip harness: all 21 ResourceEditor fixtures round-trip byte-idempotently and preserve an unknown FutureBlob node.

**Portable C++ project-XML round-trip harness: all 21 ResourceEditor fixtures round-trip byte-idempotently and preserve an unknown FutureBlob node.**

## What Happened

Added a portable XML spike (Sources/src/ResourceModel/spike/xml_spike.{h,cpp}) that models the tree CDataTreeXML (MSXML) reads and writes: elements, attributes, text, comments, CDATA and PIs, with tab-indented CRLF serialisation. Layout whitespace is dropped on parse, so re-serialising is idempotent. The harness tools/zig/resource_xml_roundtrip_test.cpp covers the canonical 21 extensions from EXTENSIONS.md. For each it parses the fixture, serialises to rtout1, re-parses, serialises to rtout2, and requires rtout1 == rtout2 and rtout1 == fixture bytes. It then plants an unknown <FutureBlob attr="x">body</FutureBlob> under the root and checks the same round trip plus that the node, its attribute and its body survive. On failure it prints the first diverging byte offset with a hex window and writes <ext>.rtout1/.rtout2 under zig-out/local-test/resource_editor/roundtrip. Fixture paths resolve case-insensitively (DataFile-style helper). build.zig gained the test-resource-xml-roundtrip step, using the shared applyLoaderPath ($ORIGIN rpath on Linux). It needs no rdynamic because no engine modules are loaded. Assumption: the spike is a hand-written portable parser, not a port of the MSXML-based CDataTreeXML, because the MSXML code is Windows-only. The failure path (non-zero exit with hex context) was written but not exercised with a deliberately broken fixture. Only Linux was run; macOS and Windows are untested.

## Verification

zig build test-resource-xml-roundtrip exited 0 on Linux x64, logging PASS for each of the 21 extensions and PASS unknown-node preservation for each, then ALL PASS.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-xml-roundtrip` | 0 | pass | 17900ms |

## Deviations

None.

## Known Issues

None.

## Files Created/Modified

None.
