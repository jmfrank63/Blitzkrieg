---
estimated_steps: 3
estimated_files: 1
skills_used: []
---

# T07: Sweep: run every S01 build step + MapEditor tiers on Linux and record the greens

Why: Slice closure. The slice ships four build steps (`make-resource-fixtures`, `test-resource-xml-roundtrip`, `test-dxt-tolerance`, `preview-scene-spike`) and must not break the MapEditor's existing Linux tiers (AGENTS.md: any change to shared editor code must keep every tier green). Downstream S02 kit extraction depends on the Map Editor tiers staying green through this slice.

Do: run `zig build install-game install-map-editor` to confirm the base builds. Run each of the new steps: `zig build make-resource-fixtures`, `zig build test-resource-xml-roundtrip`, `zig build test-dxt-tolerance`, `zig build preview-scene-spike`. Run the MapEditor tiers listed in AGENTS.md: `test-editor-core`, `test-map-editor-view`, `test-map-editor-panels`, `test-map-editor-testlaunch`, `test-map-editor-auto`, `test-map-editor-engine`, `test-editor-bridge`, `map-editor-host-check`, `map-editor-smoke`, `map-editor-auto`, `map-editor-auto-m2`, `map-editor-m3-auto`, `map-editor-game-reads-it-m3`. Capture a summary into `zig-out/local-test/resource_editor/s01-sweep.log` listing each step and its exit code. If any MapEditor tier regresses, stop and fix in this task (do not defer).

Done when: `zig-out/local-test/resource_editor/s01-sweep.log` lists every step above with exit code 0; no MapEditor tier regressed; the four new build steps all pass locally (preview-scene-spike may `skip: no GPU device` on a headless Linux agent — that counts as pass for Linux).

## Inputs

- `build.zig`
- `tools/zig/resource_editor_fixtures.zig`
- `tools/zig/resource_xml_roundtrip_test.cpp`
- `tools/zig/dxt_tolerance_test.cpp`
- `tools/zig/preview_scene_spike.cpp`

## Expected Output

- `zig-out/local-test/resource_editor/s01-sweep.log`

## Verification

test -f zig-out/local-test/resource_editor/s01-sweep.log

## Observability Impact

Signals: the sweep log is the single source of truth for S01's local-green claim. Each line is `<step> exit=<N>` plus a per-step duration. Future agents reopening the slice can diff this log against a fresh re-run to see which step regressed.
