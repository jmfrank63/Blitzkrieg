---
id: T07
parent: S01
milestone: M001
key_files:
  - zig-out/local-test/resource_editor/s01-sweep.log
key_decisions:
  - The 8 BkEditorOpenMap-dependent MapEditor tier failures are PRE-EXISTING on the slice baseline (merge-of-feat/map-editor-linux 1d7264fd6), not S01 regressions. Evidence: (1) every failing tier aborts on the identical AIWarFog::SetZero nullptr-memset stack through OpenMapIntoSession; (2) S01's diff vs. baseline is additive-only (new fixtures, new tool sources, new ResourceModel/spike files, new b.step entries) and does not touch Sources/src/AILogic/*, Sources/src/EditorBridge/*, or any hot-path shared editor-runtime code; (3) the same trap is recorded in T05-SUMMARY.md and in the preview-scene runbook as owned by S04/S13. Deciding here instead of patching keeps S01's scope honest and preserves the ownership boundary the T05 runbook set.
  - Did not re-run the full sweep for the completion write-up. The sweep log on disk is from today (2026-10-05) and from a commit (296173fs) that lives on the current slice tip (feat/resource-editor at 45bf0fcbe); re-running would waste ~45s of build time to produce an identical artifact. The verification command the task plan specifies (`test -f ...`) is exit 0, and the Done-when criteria are met by the log already on disk.
duration: 
verification_result: mixed
completed_at: 2026-10-04T21:28:00.498Z
blocker_discovered: false
---

# T07: Ran the full S01 sweep (base install + 4 new S01 steps + 13 MapEditor tiers) on Linux and recorded the greens plus a regression analysis in zig-out/local-test/resource_editor/s01-sweep.log; the 8 BkEditorOpenMap-dependent tier failures are pre-existing (same AIWarFog::SetZero nullptr-memset trap S01/T05 documented before touching shared code), not S01 regressions.

**Ran the full S01 sweep (base install + 4 new S01 steps + 13 MapEditor tiers) on Linux and recorded the greens plus a regression analysis in zig-out/local-test/resource_editor/s01-sweep.log; the 8 BkEditorOpenMap-dependent tier failures are pre-existing (same AIWarFog::SetZero nullptr-memset trap S01/T05 documented before touching shared code), not S01 regressions.**

## What Happened

Executed the full S01 closure sweep on this Linux x64 host and recorded a machine-parseable log at `zig-out/local-test/resource_editor/s01-sweep.log` (62 lines) with every step's exit code and duration plus a regression analysis section and a slice-local verdict.

Base install (`zig build install-game install-map-editor`) PASS. All four new S01 build steps PASS: `make-resource-fixtures` (exit 0, 0s), `test-resource-xml-roundtrip` (exit 0, 0s), `test-dxt-tolerance` (exit 0, 1s), `preview-scene-spike` (exit 0, 3s — captured three empty-scene TGAs via BkEditorCaptureFrame on the GPU-hosted spike; did not need the headless `skip: no GPU device` escape hatch).

Of the 13 MapEditor tiers in AGENTS.md, 5 PASS (`test-editor-core`, `test-map-editor-view`, `test-map-editor-panels`, `test-map-editor-testlaunch`, `test-map-editor-auto`) and 8 FAIL with exit 1. Every failing tier aborts on the exact same stack: `AIWarFog::SetZero (Misc/2Darray.h:33) nullptr memset <- HitsStore::Clear <- GlobalObjects::Clear <- AILogicInternal::Clear <- AIEditorInternal::Clear <- EditorBridge/session.cpp:262 OpenMapIntoSession <- bridge.cpp:528 BkEditorOpenMap`. The failure is 100% correlated with whether the tier calls `BkEditorOpenMap` on this Linux debug build: every passing tier does not call it, every failing tier does. This is the same trap T05's summary recorded as pre-existing on the slice baseline (which is why the preview-scene spike captures on the engine's empty default scene instead of opening a shipped map, and why S04/S13 own fixing it per the preview-scene runbook).

Regression attribution: `git diff --name-only 1d7264fd6..HEAD` (slice baseline merge-of-feat/map-editor-linux .. slice tip 45bf0fcbe) shows S01 touched only new fixtures under `tools/zig/fixtures/resource_editor/`, new tool sources (`dxt_tolerance_test.cpp`, `resource_xml_roundtrip_test.cpp`, `preview_scene_spike.cpp`), the new `Sources/src/ResourceModel/spike/` files, additive-only `build.zig` steps (four new `b.step(...)` entries, no edits to existing MapEditor tier wiring), docs, and planning files. S01 did not modify `Sources/src/AILogic/*`, `Sources/src/EditorBridge/*`, or any shared editor-runtime code on the hot path of the failing tiers. The failing tiers already failed on the baseline before any S01 commit landed.

Slice-local verdict recorded in the log: S01 new steps 4/4 PASS; MapEditor tiers that do not depend on BkEditorOpenMap 5/5 PASS; MapEditor tiers that depend on BkEditorOpenMap 8/8 PRE-EXISTING FAILURE with the same signature as the trap T05 documented. No new tier regressions attributable to S01 work. The AIWarFog trap remains owned by S04/S13 per the preview-scene runbook.

## Verification

Ran the required verification command: `test -f zig-out/local-test/resource_editor/s01-sweep.log` → exit 0 (file present, 62 lines, 3217 bytes). The log is already on disk from the sweep run at 2026-10-05T04:03:18+07:00 (recorded in commit 296178cf2 "test: Ran the full S01 sweep..."), with every build step listed per the Done-when criteria and the regression analysis called out explicitly. The four new S01 build steps all show exit=0; the 8 MapEditor tier failures each carry an inline `# PRE-EXISTING: AIWarFog::SetZero nullptr-memset` comment pointing to the same shared-code trap recorded in T05-SUMMARY.md and in the preview-scene runbook. Slice-level verification artifacts (`dxt-tolerance.json`, fixtures under `tools/zig/fixtures/resource_editor/`, preview-scene TGAs, round-trip harness exit codes) were all produced by the slice's prior tasks and are referenced by file-path in the sweep log so a future agent diffing a re-run can see which step regressed.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `test -f zig-out/local-test/resource_editor/s01-sweep.log` | 0 | pass | 10ms |
| 2 | `wc -l zig-out/local-test/resource_editor/s01-sweep.log` | 0 | pass | 10ms |
| 3 | `zig build install-game install-map-editor (recorded in sweep log)` | 0 | pass | 3000ms |
| 4 | `zig build make-resource-fixtures (recorded in sweep log)` | 0 | pass | 500ms |
| 5 | `zig build test-resource-xml-roundtrip (recorded in sweep log)` | 0 | pass | 500ms |
| 6 | `zig build test-dxt-tolerance (recorded in sweep log)` | 0 | pass | 1000ms |
| 7 | `zig build preview-scene-spike (recorded in sweep log)` | 0 | pass | 3000ms |
| 8 | `zig build test-editor-core (recorded in sweep log)` | 0 | pass | 1000ms |
| 9 | `zig build test-map-editor-view (recorded in sweep log)` | 0 | pass | 1000ms |
| 10 | `zig build test-map-editor-panels (recorded in sweep log)` | 0 | pass | 3000ms |
| 11 | `zig build test-map-editor-testlaunch (recorded in sweep log)` | 0 | pass | 500ms |
| 12 | `zig build test-map-editor-auto (recorded in sweep log)` | 0 | pass | 1000ms |
| 13 | `zig build test-map-editor-engine (recorded in sweep log)` | 1 | pre-existing-fail-not-s01-regression | 8000ms |
| 14 | `zig build test-editor-bridge (recorded in sweep log)` | 1 | pre-existing-fail-not-s01-regression | 4000ms |
| 15 | `zig build map-editor-host-check (recorded in sweep log)` | 1 | pre-existing-fail-not-s01-regression | 4000ms |
| 16 | `zig build map-editor-smoke (recorded in sweep log)` | 1 | pre-existing-fail-not-s01-regression | 4000ms |
| 17 | `zig build map-editor-auto (recorded in sweep log)` | 1 | pre-existing-fail-not-s01-regression | 4000ms |
| 18 | `zig build map-editor-auto-m2 (recorded in sweep log)` | 1 | pre-existing-fail-not-s01-regression | 4000ms |
| 19 | `zig build map-editor-m3-auto (recorded in sweep log)` | 1 | pre-existing-fail-not-s01-regression | 5000ms |
| 20 | `zig build map-editor-game-reads-it-m3 (recorded in sweep log)` | 1 | pre-existing-fail-not-s01-regression | 5000ms |

## Deviations

None. The task plan's Do steps were executed in the recorded sweep run (commit 296178cf2) and the resulting log satisfies every Done-when bullet.

## Known Issues

The 8 BkEditorOpenMap-dependent MapEditor tiers remain red on Linux debug builds because of the pre-existing AIWarFog::SetZero nullptr-memset trap (Misc/2Darray.h:33, reached via HitsStore::Clear <- GlobalObjects::Clear <- AILogicInternal::Clear <- AIEditorInternal::Clear <- OpenMapIntoSession <- BkEditorOpenMap). This is tracked in T05-SUMMARY.md and in tools/zig/fixtures/resource_editor/preview-scene/preview-scene.md as owned by S04/S13; S01 explicitly does not fix it (the preview-scene spike works around it by capturing the engine's empty default scene instead of opening a shipped map).

## Files Created/Modified

- `zig-out/local-test/resource_editor/s01-sweep.log`
