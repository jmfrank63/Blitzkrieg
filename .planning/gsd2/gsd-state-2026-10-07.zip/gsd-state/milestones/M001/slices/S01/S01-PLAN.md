# S01: Parity oracle, DXT tolerance, preview-scene spike, project-XML round-trip spike

**Goal:** Lay the measured foundations M001 needs before any sub-editor begins: a repo-owned fixture per extension (21 extensions), a project-XML round-trip C++ harness that proves every extension round-trips idempotently, a measured DXT tolerance (max pixel delta and p99 for DXT1/DXT3/DXT5) between the MFC-era encoder and portable `NDxt`, a preview-scene spike with captured frames for 1 mesh unit + 1 sprite object + 1 particle source, and the spec amendment that records Linux as a first-class target and `<UserRoot>resourceeditor/` as the user-data-root. The parity-oracle procedure for win-home (MFC `editor.exe` batch-exports fixtures to committed goldens) is specified in a runbook; the goldens themselves are produced by hand on win-home and checked in from there, since the Linux agent cannot run MFC `editor.exe`.
**Demo:** On win-home: MFC `editor.exe` batch-exports repo-owned fixtures for every one of the 21 extensions to committed goldens under `tools/zig/fixtures/resource_editor/`. Locally: `tools/zig/fixtures/resource_editor/dxt-tolerance.json` holds measured max pixel delta and p99 for DXT1-3-5 between old encoder and `NDxt`; a captured preview-scene frame is checked in for 1 mesh unit, 1 sprite object, 1 particle source; a C++ XML round-trip test harness roundtrips every one of the 21 extensions idempotently. Spec amended with Linux-first-class target and user-data-root rule.

## Must-Haves

- `tools/zig/fixtures/resource_editor/<ext>/project.<ext>` exists for each of the 21 project extensions with small generated source art.
- `test-resource-xml-roundtrip` (new) passes locally: every fixture project parses, re-serialises, and compares equal after a second round-trip, including unknown-node preservation.
- `tools/zig/fixtures/resource_editor/dxt-tolerance.json` exists with measured `max_delta` and `p99` fields per format for DXT1/DXT3/DXT5, produced by a reproducible test step (`test-dxt-tolerance`).
- `tools/zig/fixtures/resource_editor/preview-scene/{mesh,sprite,particle}.tga` + a `preview-scene.md` runbook describing the camera/scene shape and the capture command.
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md` has an "Amendments (M001 planning)" section recording D001 (Linux first-class) and D002 (user-data-root rule for all user content, with relative paths inside projects where the format allows).
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md` has a win-home runbook reference, with the full runbook in `06-ORACLE-RUNBOOK.md`, describing how to produce the 21 committed goldens from MFC `editor.exe` and the exact paths under `tools/zig/fixtures/resource_editor/<ext>/golden/`.
- All new C++ compiles under `zig build` with the existing engine-target set (five engine targets); the Linux build is green locally.
- MapEditor tiers listed in AGENTS.md remain green locally (unchanged touch surface).

## Proof Level

- This slice proves: contract — this slice measures and documents; downstream slices build on the oracle, fixtures, tolerance, preview-scene shape and round-trip harness it ships. No production app behaviour is produced here.

## Integration Closure

Upstream consumed: MFC project source in `Sources/src/editor/` (ported sections only read for shape; no code moved yet); portable `NDxt` in `Sources/src/Image/DxtCodec.{h,cpp}`; MFC-era DXT encoder (identified in this slice, usually inside `Sources/src/editor/` DDS writer code or the `blck` encoder); `tools/zig/editor_bridge_test.cpp` helpers (`DataFile`, hidden-window flags). New wiring introduced: `test-resource-xml-roundtrip`, `test-dxt-tolerance`, `preview-scene-spike`, and `make-resource-fixtures` build steps in `build.zig`, plus a `tools/zig/resource_editor_fixtures.zig` helper. Remaining before milestone usable end-to-end: everything downstream (S02..S16); this slice only closes the foundation gap.

## Verification

- New build steps produce their artifacts under `zig-out/local-test/resource_editor/` and `tools/zig/fixtures/resource_editor/`; the DXT measurement writes a stable JSON schema that downstream slices read programmatically; the round-trip harness logs per-extension PASS/FAIL on stderr with exit code 0/1; the preview-scene spike captures TGAs via `BkEditorCaptureFrame` and asserts non-black pixel coverage in the test. All results are machine-parseable, not eyeballed.

## Tasks

- [x] **T01: Amend the spec: Linux first-class and user-data-root rule** `est:20m`
  Why: AGENTS.md requires that when a milestone context overrides the spec, the newer instruction wins AND the change is recorded in the spec. D001 made Linux a first-class M001 target and D002 fixed where user content lives; both override the spec's "Linux deferred" note and extend D-10. Nothing downstream should start reading the fixture / oracle plan until the spec reflects reality.
  - Files: `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`
  - Verify: grep -q "Amendments (M001 planning" docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md

- [x] **T02: Enumerate the 21 extensions and generate repo-owned source art per fixture** `est:3h`
  Why: Every downstream golden / round-trip / preview test needs a fixture per extension. The repo-owned fixtures must use *generated* small source art, never shipped Data, and never GOG files. Downstream tasks (T03..T06, S02..S16) all depend on these paths existing.
  - Files: `tools/zig/resource_editor_fixtures.zig`, `tools/zig/fixtures/resource_editor/EXTENSIONS.md`, `tools/zig/fixtures/resource_editor/wpn/project.wpn`, `tools/zig/fixtures/resource_editor/mnp/project.mnp`, `tools/zig/fixtures/resource_editor/trc/project.trc`, `tools/zig/fixtures/resource_editor/sqd/project.sqd`, `tools/zig/fixtures/resource_editor/spt/project.spt`, `tools/zig/fixtures/resource_editor/unt/project.unt`, `tools/zig/fixtures/resource_editor/msh/project.msh`, `tools/zig/fixtures/resource_editor/obt/project.obt`, `tools/zig/fixtures/resource_editor/fnc/project.fnc`, `tools/zig/fixtures/resource_editor/bld/project.bld`, `tools/zig/fixtures/resource_editor/bdg/project.bdg`, `tools/zig/fixtures/resource_editor/mcp/project.mcp`, `tools/zig/fixtures/resource_editor/eff/project.eff`, `tools/zig/fixtures/resource_editor/til/project.til`, `tools/zig/fixtures/resource_editor/trp/project.trp`, `tools/zig/fixtures/resource_editor/rdp/project.rdp`, `tools/zig/fixtures/resource_editor/rvp/project.rvp`, `tools/zig/fixtures/resource_editor/mip/project.mip`, `tools/zig/fixtures/resource_editor/chc/project.chc`, `tools/zig/fixtures/resource_editor/cmp/project.cmp`, `tools/zig/fixtures/resource_editor/mdc/project.mdc`, `tools/zig/fixtures/resource_editor/gui/project.gui`, `build.zig`
  - Verify: zig build make-resource-fixtures

- [x] **T03: C++ project-XML round-trip harness: parse and re-serialise every extension idempotently** `est:5h`
  Why: Spec D-07 requires MFC project XML read and written unchanged for all 21 extensions, with unknown-node preservation. Before `ResourceModel` is extracted in S03 and before any sub-editor is built on top, we need a round-trip harness that proves the shape of the round trip is viable. This is the project-XML spike called out in the slice goal.
  - Files: `tools/zig/resource_xml_roundtrip_test.cpp`, `Sources/src/ResourceModel/spike/xml_spike.cpp`, `Sources/src/ResourceModel/spike/xml_spike.h`, `build.zig`
  - Verify: zig build test-resource-xml-roundtrip

- [x] **T04: Measure DXT tolerance between the MFC-era encoder and NDxt (DXT1/DXT3/DXT5)** `est:4h`
  Why: Spec D-11 says DDS files must decode within a *measured* tolerance against the MFC golden. R019 pins the measurement to this slice. Without a committed `dxt-tolerance.json`, downstream golden tests have no credible pass/fail bar.
  - Files: `tools/zig/dxt_tolerance_test.cpp`, `Sources/src/ResourceModel/spike/legacy_dxt.cpp`, `Sources/src/ResourceModel/spike/legacy_dxt.h`, `tools/zig/fixtures/resource_editor/dxt-tolerance.json`, `build.zig`
  - Verify: zig build test-dxt-tolerance

- [x] **T05: Preview-scene spike: capture frames for mesh / sprite / particle and write the runbook** `est:5h`
  Why: Spec D-16 defines the preview as an export-into-temp-storage + `IVisObjBuilder` build, and D-17 requires measuring the preview scene shape *before* any sub-editor depends on it. R018 ties this to S01 explicitly. The lesson of phase 3's yaw measurement is: the renderer breaks silently with non-game cameras, so camera and scene shape must be captured by code, not judged from source.
  - Files: `tools/zig/preview_scene_spike.cpp`, `tools/zig/fixtures/resource_editor/preview-scene/preview-scene.md`, `tools/zig/fixtures/resource_editor/preview-scene/.gitkeep`, `build.zig`
  - Verify: zig build preview-scene-spike

- [x] **T06: Win-home parity-oracle runbook and committed-golden layout** `est:1h30m`
  Why: The slice promises "after this: on win-home, MFC `editor.exe` batch-exports repo-owned fixtures for every one of the 21 extensions to committed goldens." The Linux agent cannot run `editor.exe` — the maintainer runs it on win-home. The runbook must be specific enough that the maintainer can produce the goldens unattended, and the committed-golden layout must be stable so S03..S15 can read them.
  - Files: `.planning/phases/06-resource-editor-portable-port/06-ORACLE-RUNBOOK.md`, `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`, `tools/zig/fixtures/resource_editor/wpn/golden/.gitkeep`, `tools/zig/fixtures/resource_editor/mnp/golden/.gitkeep`, `tools/zig/fixtures/resource_editor/trc/golden/.gitkeep`, `tools/zig/fixtures/resource_editor/sqd/golden/.gitkeep`, `tools/zig/fixtures/resource_editor/spt/golden/.gitkeep`, `tools/zig/fixtures/resource_editor/unt/golden/.gitkeep`, `tools/zig/fixtures/resource_editor/msh/golden/.gitkeep`, `tools/zig/fixtures/resource_editor/obt/golden/.gitkeep`, `tools/zig/fixtures/resource_editor/fnc/golden/.gitkeep`, `tools/zig/fixtures/resource_editor/bld/golden/.gitkeep`, `tools/zig/fixtures/resource_editor/bdg/golden/.gitkeep`, `tools/zig/fixtures/resource_editor/mcp/golden/.gitkeep`, `tools/zig/fixtures/resource_editor/eff/golden/.gitkeep`, `tools/zig/fixtures/resource_editor/til/golden/.gitkeep`, `tools/zig/fixtures/resource_editor/trp/golden/.gitkeep`, `tools/zig/fixtures/resource_editor/rdp/golden/.gitkeep`, `tools/zig/fixtures/resource_editor/rvp/golden/.gitkeep`, `tools/zig/fixtures/resource_editor/mip/golden/.gitkeep`, `tools/zig/fixtures/resource_editor/chc/golden/.gitkeep`, `tools/zig/fixtures/resource_editor/cmp/golden/.gitkeep`, `tools/zig/fixtures/resource_editor/mdc/golden/.gitkeep`, `tools/zig/fixtures/resource_editor/gui/golden/.gitkeep`
  - Verify: test -f .planning/phases/06-resource-editor-portable-port/06-ORACLE-RUNBOOK.md

- [x] **T07: Sweep: run every S01 build step + MapEditor tiers on Linux and record the greens** `est:1h30m`
  Why: Slice closure. The slice ships four build steps (`make-resource-fixtures`, `test-resource-xml-roundtrip`, `test-dxt-tolerance`, `preview-scene-spike`) and must not break the MapEditor's existing Linux tiers (AGENTS.md: any change to shared editor code must keep every tier green). Downstream S02 kit extraction depends on the Map Editor tiers staying green through this slice.
  - Files: `zig-out/local-test/resource_editor/s01-sweep.log`
  - Verify: test -f zig-out/local-test/resource_editor/s01-sweep.log

## Files Likely Touched

- docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md
- tools/zig/resource_editor_fixtures.zig
- tools/zig/fixtures/resource_editor/EXTENSIONS.md
- tools/zig/fixtures/resource_editor/wpn/project.wpn
- tools/zig/fixtures/resource_editor/mnp/project.mnp
- tools/zig/fixtures/resource_editor/trc/project.trc
- tools/zig/fixtures/resource_editor/sqd/project.sqd
- tools/zig/fixtures/resource_editor/spt/project.spt
- tools/zig/fixtures/resource_editor/unt/project.unt
- tools/zig/fixtures/resource_editor/msh/project.msh
- tools/zig/fixtures/resource_editor/obt/project.obt
- tools/zig/fixtures/resource_editor/fnc/project.fnc
- tools/zig/fixtures/resource_editor/bld/project.bld
- tools/zig/fixtures/resource_editor/bdg/project.bdg
- tools/zig/fixtures/resource_editor/mcp/project.mcp
- tools/zig/fixtures/resource_editor/eff/project.eff
- tools/zig/fixtures/resource_editor/til/project.til
- tools/zig/fixtures/resource_editor/trp/project.trp
- tools/zig/fixtures/resource_editor/rdp/project.rdp
- tools/zig/fixtures/resource_editor/rvp/project.rvp
- tools/zig/fixtures/resource_editor/mip/project.mip
- tools/zig/fixtures/resource_editor/chc/project.chc
- tools/zig/fixtures/resource_editor/cmp/project.cmp
- tools/zig/fixtures/resource_editor/mdc/project.mdc
- tools/zig/fixtures/resource_editor/gui/project.gui
- build.zig
- tools/zig/resource_xml_roundtrip_test.cpp
- Sources/src/ResourceModel/spike/xml_spike.cpp
- Sources/src/ResourceModel/spike/xml_spike.h
- tools/zig/dxt_tolerance_test.cpp
- Sources/src/ResourceModel/spike/legacy_dxt.cpp
- Sources/src/ResourceModel/spike/legacy_dxt.h
- tools/zig/fixtures/resource_editor/dxt-tolerance.json
- tools/zig/preview_scene_spike.cpp
- tools/zig/fixtures/resource_editor/preview-scene/preview-scene.md
- tools/zig/fixtures/resource_editor/preview-scene/.gitkeep
- .planning/phases/06-resource-editor-portable-port/06-ORACLE-RUNBOOK.md
- .planning/phases/06-resource-editor-portable-port/06-PARITY.md
- tools/zig/fixtures/resource_editor/wpn/golden/.gitkeep
- tools/zig/fixtures/resource_editor/mnp/golden/.gitkeep
- tools/zig/fixtures/resource_editor/trc/golden/.gitkeep
- tools/zig/fixtures/resource_editor/sqd/golden/.gitkeep
- tools/zig/fixtures/resource_editor/spt/golden/.gitkeep
- tools/zig/fixtures/resource_editor/unt/golden/.gitkeep
- tools/zig/fixtures/resource_editor/msh/golden/.gitkeep
- tools/zig/fixtures/resource_editor/obt/golden/.gitkeep
- tools/zig/fixtures/resource_editor/fnc/golden/.gitkeep
- tools/zig/fixtures/resource_editor/bld/golden/.gitkeep
- tools/zig/fixtures/resource_editor/bdg/golden/.gitkeep
- tools/zig/fixtures/resource_editor/mcp/golden/.gitkeep
- tools/zig/fixtures/resource_editor/eff/golden/.gitkeep
- tools/zig/fixtures/resource_editor/til/golden/.gitkeep
- tools/zig/fixtures/resource_editor/trp/golden/.gitkeep
- tools/zig/fixtures/resource_editor/rdp/golden/.gitkeep
- tools/zig/fixtures/resource_editor/rvp/golden/.gitkeep
- tools/zig/fixtures/resource_editor/mip/golden/.gitkeep
- tools/zig/fixtures/resource_editor/chc/golden/.gitkeep
- tools/zig/fixtures/resource_editor/cmp/golden/.gitkeep
- tools/zig/fixtures/resource_editor/mdc/golden/.gitkeep
- tools/zig/fixtures/resource_editor/gui/golden/.gitkeep
- zig-out/local-test/resource_editor/s01-sweep.log
