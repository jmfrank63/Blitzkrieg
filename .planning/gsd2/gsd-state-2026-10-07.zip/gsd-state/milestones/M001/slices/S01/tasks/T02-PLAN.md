---
estimated_steps: 3
estimated_files: 25
skills_used: []
---

# T02: Enumerate the 21 extensions and generate repo-owned source art per fixture

Why: Every downstream golden / round-trip / preview test needs a fixture per extension. The repo-owned fixtures must use *generated* small source art, never shipped Data, and never GOG files. Downstream tasks (T03..T06, S02..S16) all depend on these paths existing.

Do: produce a canonical list of the 21 project extensions by reading `Sources/src/editor/*Frm.cpp` (each sub-editor's frame registers its extension) and `Sources/src/editor/ParentFrame.cpp`. The 21 extensions are candidates: `wpn, mnp, trc, sqd, spt, unt, msh, obt, fnc, bld, bdg, mcp, eff, til, trp, rdp, rvp, mip, chc, cmp, mdc, gui` — reconcile this against the frames; if there are discrepancies, document the resolved list in `tools/zig/fixtures/resource_editor/EXTENSIONS.md` with a one-sentence source-of-truth note (which frame class owns which extension). For each extension, create `tools/zig/fixtures/resource_editor/<ext>/project.<ext>` containing a minimal valid `<X>_Composer_Project` XML (model: use MFC's own XML shape, read from `Sources/src/editor/common.cpp`'s `operator&( IDataTree & )` glue; put only a root item with 1 trivial child). Add tiny generated source art next to each project: a 16x16 solid-colour TGA for picture-type kinds, a 2x2x2 trivial OBJ-shape placeholder for mesh kinds, a one-frame sprite for sprite kinds, a two-keyframe source for particle/effect kinds. Keep every file under 4 KB. Document the generator (deterministic, seed-free) in `tools/zig/resource_editor_fixtures.zig` as a `zig build make-resource-fixtures` step, so the fixtures are regeneratable from source.

Done when: `tools/zig/fixtures/resource_editor/EXTENSIONS.md` lists exactly 21 extensions with their owning sub-editor; `project.<ext>` exists for each of the 21 extensions; `zig build make-resource-fixtures` regenerates them idempotently (byte-identical re-run).

## Inputs

- `Sources/src/editor/ParentFrame.cpp`
- `Sources/src/editor/common.cpp`
- `Sources/src/editor/common.h`
- `Sources/src/editor/WeaponFrm.cpp`
- `Sources/src/editor/MineFrm.cpp`
- `Sources/src/editor/BuildFrm.cpp`
- `Sources/src/editor/BridgeFrm.cpp`
- `Sources/src/editor/MeshFrm.cpp`
- `Sources/src/editor/FenceFrm.cpp`
- `Sources/src/editor/MissionFrm.cpp`
- `Sources/src/editor/ChapterFrm.cpp`
- `Sources/src/editor/CampaignFrm.cpp`
- `Sources/src/editor/MedalFrm.cpp`
- `Sources/src/editor/GUIFrame.cpp`
- `Sources/src/editor/ObjectFrm.cpp`
- `Sources/src/editor/EffectFrm.cpp`
- `Sources/src/editor/3dRoadFrm.cpp`
- `Sources/src/editor/3dRiverFrm.cpp`
- `build.zig`

## Expected Output

- `tools/zig/resource_editor_fixtures.zig`
- `tools/zig/fixtures/resource_editor/EXTENSIONS.md`
- `tools/zig/fixtures/resource_editor/wpn/project.wpn`
- `tools/zig/fixtures/resource_editor/mnp/project.mnp`
- `tools/zig/fixtures/resource_editor/trc/project.trc`
- `tools/zig/fixtures/resource_editor/sqd/project.sqd`
- `tools/zig/fixtures/resource_editor/spt/project.spt`
- `tools/zig/fixtures/resource_editor/unt/project.unt`
- `tools/zig/fixtures/resource_editor/msh/project.msh`
- `tools/zig/fixtures/resource_editor/obt/project.obt`
- `tools/zig/fixtures/resource_editor/fnc/project.fnc`
- `tools/zig/fixtures/resource_editor/bld/project.bld`
- `tools/zig/fixtures/resource_editor/bdg/project.bdg`
- `tools/zig/fixtures/resource_editor/mcp/project.mcp`
- `tools/zig/fixtures/resource_editor/eff/project.eff`
- `tools/zig/fixtures/resource_editor/til/project.til`
- `tools/zig/fixtures/resource_editor/trp/project.trp`
- `tools/zig/fixtures/resource_editor/rdp/project.rdp`
- `tools/zig/fixtures/resource_editor/rvp/project.rvp`
- `tools/zig/fixtures/resource_editor/mip/project.mip`
- `tools/zig/fixtures/resource_editor/chc/project.chc`
- `tools/zig/fixtures/resource_editor/cmp/project.cmp`
- `tools/zig/fixtures/resource_editor/mdc/project.mdc`
- `tools/zig/fixtures/resource_editor/gui/project.gui`
- `build.zig`

## Verification

zig build make-resource-fixtures

## Observability Impact

Signals added: the `make-resource-fixtures` step writes per-extension log lines to stderr showing bytes written and a hash digest, so an agent can diff the fixtures between runs. Inspection: `zig-out/local-test/resource_editor/make-fixtures.log` holds the last run's output; the hash digest in `tools/zig/fixtures/resource_editor/EXTENSIONS.md` is the stable fingerprint.
