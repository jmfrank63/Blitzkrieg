---
id: T01
parent: S01
milestone: M001
key_files:
  - docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md
key_decisions:
  - Record spec overrides in a dated `## Amendments (M001 planning, 2026-10-05)` append-only section at the end of the spec, not by editing earlier sections — matches AGENTS.md's 'newer instruction wins, and record the change in the spec' rule and keeps the original narrative intact for diff review.
  - State the Linux-first-class entry as an explicit supersession of the 'Linux deferred' posture and enumerate the reused Map Editor Linux solutions by name, so downstream slices do not re-derive them.
  - Scope D002's extension of D-10 to *all* user content (projects, settings, recent files, window layout, per-tool prefs), not just settings — and spell out that paths inside project files stay relative so projects move between machines.
duration: 
verification_result: passed
completed_at: 2026-10-04T21:24:02.055Z
blocker_discovered: false
---

# T01: Appended an Amendments section to the ResourceEditor spec recording Linux as a first-class target and `<UserRoot>resourceeditor/` as the user-data-root.

**Appended an Amendments section to the ResourceEditor spec recording Linux as a first-class target and `<UserRoot>resourceeditor/` as the user-data-root.**

## What Happened

Opened `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md` (411 lines, CRLF, UTF-8) and confirmed it ended cleanly after the "Exit criteria" bullet list with a trailing CRLF. Appended a new `## Amendments (M001 planning, 2026-10-05)` section with a short opening paragraph that cites AGENTS.md's "newer instruction wins, and record the change in the spec" rule, followed by two bullet entries: (1) Linux x64 is a first-class target for `ResourceEditor` and the shared editor kit — explicitly supersedes the earlier "Linux deferred" posture, and enumerates the Map Editor Linux solutions that are reused unchanged: `rdynamic` + `$ORIGIN` rpath for executables that load engine modules, 16 MiB default worker thread stack (glibc TLS carve-out), hidden-window `SDL_WINDOW_HIDDEN | SDL_WINDOW_NOT_FOCUSABLE` flags, `ISFX` stopped before module unload, and case-insensitive `Data` path resolution via the `DataFile` helper in `tools/zig/editor_bridge_test.cpp`; references MEM001, MEM002, D001. (2) User content lives under `<UserRoot>resourceeditor/` — projects, settings, recent-files, window layout, and per-tool preferences all root there; `<UserRoot>` resolves per-platform the same way the game does (XDG on Linux, `Application Support` on macOS, `%LOCALAPPDATA%` on Windows, with the `BK_*_SETTINGS` seams honored by tests); paths inside project files are relative wherever the format allows so projects move between machines without rewriting absolute paths; explicitly extends D-10 from "settings only" to "all user content"; references D002. The append was done with `cat <<'LF_EOF' | sed 's/$/\r/' >> ...` so every new line ends in CRLF, matching the rest of the file. Existing spec content was not modified; this is a pure append.

## Verification

After appending, confirmed: (a) `file` still reports `with CRLF line terminators`; (b) `grep -c $'\r$'` returns 442, matching `wc -l` of 442 — 100% of lines CRLF-terminated, no mixed line endings introduced; (c) the task's required verification command `grep -q "Amendments (M001 planning" docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md` exits 0; (d) `grep -n` locates the new heading at line 413, i.e. appended after the original 411-line body.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `grep -q "Amendments (M001 planning" docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md` | 0 | pass | 20ms |
| 2 | `file docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md` | 0 | pass (CRLF line terminators) | 15ms |
| 3 | `grep -c $'\r$' docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md` | 0 | pass (442/442 lines CRLF) | 15ms |

## Deviations

None. The amendments text came out slightly longer than the one-sentence-per-entry wording in the task plan (an intro paragraph plus two bullets), but the two required entries, their references (MEM001/MEM002/D001 for #1, D002 for #2), the "extends D-10" wording, and the enumeration of reused Linux solutions are all present as the plan specified.

## Known Issues

None.

## Files Created/Modified

- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`
