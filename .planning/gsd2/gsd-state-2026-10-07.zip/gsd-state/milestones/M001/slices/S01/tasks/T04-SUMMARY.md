---
id: T04
parent: S01
milestone: M001
key_files:
  - Sources/src/ResourceModel/spike/legacy_dxt.h
  - Sources/src/ResourceModel/spike/legacy_dxt.cpp
  - tools/zig/dxt_tolerance_test.cpp
  - tools/zig/fixtures/resource_editor/dxt-tolerance.json
  - build.zig
key_decisions:
  - The 'MFC-era encoder' in the T04 plan is `Sources/src/Image/S3TC.{h,cpp}` as of commit 40645ad29^ (removed in that commit, replaced by NDxt). Recovered via git and ported as data-only C++; this is the only honest 'legacy vs modern' baseline available in the tree.
  - Dropped unused S3TC paths (DXT2/DXT4, 3-colour-mode colour-key encoding, raw-RGB fallback) in the port. None are reachable from the plan's SurfaceDesc API (DXT1/3/5 encode/decode on ARGB8888). Keeping them would be dead code the measurement never exercises.
  - Wrote the tolerance JSON with CRLF to match `.gitattributes eol=crlf`. An LF draft would be non-idempotent after a fresh checkout on Linux (git materialises CRLF per the attribute; a subsequent test run would then overwrite with LF). The CRLF choice keeps `test-dxt-tolerance` byte-stable across clean checkouts.
  - Reported the measured tolerance as-is (max 255, p99 ≈ 125-126 on the three-image fixture set) rather than restricting the input set to make the number smaller. The plan explicitly requires a high-frequency noise image, and the point of R019/D-11 is a *measured* number; downstream golden tests must adopt the measurement, not the other way around.
duration: 
verification_result: passed
completed_at: 2026-10-04T20:50:00.466Z
blocker_discovered: false
---

# T04: Measured DXT1/3/5 tolerance between the ported MFC-era S3TC encoder and the shipping NDxt encoder; committed a deterministic tolerance JSON and per-format histograms behind `zig build test-dxt-tolerance`.

**Measured DXT1/3/5 tolerance between the ported MFC-era S3TC encoder and the shipping NDxt encoder; committed a deterministic tolerance JSON and per-format histograms behind `zig build test-dxt-tolerance`.**

## What Happened

Identified the MFC-era DXT encoder: the plan pointed at Sources/src/Image/DxtCodec.* / editor/common.cpp, but DxtCodec IS NDxt — the historical S3TC encoder was removed in commit 40645ad29 ('S3TC removal'). Recovered the pre-removal `Sources/src/Image/S3TC.{h,cpp}` via `git show 40645ad29^:...` and ported it as data-only C++ (no MFC/Windows types: BYTE/DWORD/WORD → uint8_t/uint16_t/uint32_t, `__int64` → uint64_t, `Min<T>` → std::min, dropped `UNREFERENCED_PARAMETER` and `Zero`) into Sources/src/ResourceModel/spike/legacy_dxt.cpp under namespace NLegacyDxt. The algorithm is kept bit-identical to the legacy encoder so the measurement is honest: truncating 565 pack, truncating DXT3 alpha nibble, luma = R+G+B endpoint selection, collided-endpoint nudging to force the 4-colour DXT1 palette, and the DXT5 min==max alpha nudge. Only unused S3TC paths (DXT2/DXT4, three-colour mode for colour-key input, the raw-RGB fallback) were dropped — none are reachable from the simplified SurfaceDesc API the test uses.

Added tools/zig/dxt_tolerance_test.cpp that generates three deterministic 256x256 ARGB8888 images (smooth gradient, LCG-seeded high-frequency noise, sharp circular mask with RGB banding), encodes each with both NLegacyDxt::Encode and NDxt::Encode for DXT1/3/5, decodes both outputs through NDxt::Decode, and collects per-channel absolute deltas across all 4 channels into a 256-bin histogram. max_delta is the top nonzero bin; p99 is the smallest D such that ≥ ceil(total*0.99) of the collected per-channel deltas are ≤ D. The result is written to tools/zig/fixtures/resource_editor/dxt-tolerance.json with the schema `{"schema_version":1,"formats":{"DXT1":{"max_delta":N,"p99":M},"DXT3":{...},"DXT5":{...}}}`. CRLF line endings (matches `.gitattributes` so a fresh checkout matches a re-run byte-for-byte; the earlier LF draft would have been non-idempotent after checkout normalisation on Linux). Per-format histograms land in zig-out/local-test/resource_editor/dxt/histogram-{DXT1,DXT3,DXT5}.csv for the observability surface the plan asked for. Any encode fault prints format + image name + first offending pixel (x,y) + both decoded ARGB words to stderr before exiting with code 2.

The measured numbers are DXT1 max=255 p99=126, DXT3 max=255 p99=125, DXT5 max=255 p99=125. The large tail is driven entirely by the noise image: the two encoders use different luma weights (equal R+G+B vs 299/587/114 BT.601) to pick block endpoints, so on random-colour blocks the chosen palette flips completely between the two encoders. This is the honest measured contract; downstream golden tests must either tolerate the full 0..255 range on noise-like content or restrict their inputs to the gradient/mask regime where the delta stays low.

Wired `zig build test-dxt-tolerance` in build.zig next to `test-resource-xml-roundtrip`, with the Linux `$ORIGIN` rpath, no engine modules loaded, Debug `-std=c++17` on POSIX and `cppflags_debug` on windows_x64. Verified: `zig build test-dxt-tolerance` exits 0, writes a 248-byte JSON (sha256 ee79d582b98ecb3096f3740c234e5bcb08774898f1e7706fa5f6771b08a206b5); re-run writes a byte-identical file; `zig build test-resource-xml-roundtrip` still passes (all 21 extensions × 2 checks).

Captured a project memory (MEM007) recording where the legacy encoder lives in history, the four algorithmic divergences from NDxt that drive the tolerance, and the measured numbers, so a future author doesn't have to re-derive them.

## Verification

Ran `zig build test-dxt-tolerance` twice: exit 0 both times; stderr prints per-format max_delta and p99 (DXT1 255/126, DXT3 255/125, DXT5 255/125) plus a `delta>=32` diagnostic for the first large-delta pixel in each format. Diffed the JSON output across the two runs — byte identical (sha256 ee79d582b98ecb3096f3740c234e5bcb08774898f1e7706fa5f6771b08a206b5). Confirmed the on-disk file is CRLF (hex 7b 0d 0a …) so it matches `.gitattributes eol=crlf` after a fresh checkout and the test stays idempotent. Verified three histogram CSVs exist under zig-out/local-test/resource_editor/dxt/. Ran `zig build test-resource-xml-roundtrip` to confirm the new build-graph node did not break siblings — ALL PASS (21 extensions × 2 checks). All inputs and outputs are tracked git paths, no shipped Data/ was touched.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-dxt-tolerance` | 0 | pass | 4200ms |
| 2 | `zig build test-dxt-tolerance (re-run; diff against prior output)` | 0 | pass (byte-identical JSON, sha256 ee79d582b98ecb3096f3740c234e5bcb08774898f1e7706fa5f6771b08a206b5) | 3800ms |
| 3 | `zig build test-resource-xml-roundtrip` | 0 | pass (21/21 extensions, 2 checks each) | 5200ms |

## Deviations

The plan's input list named `Sources/src/editor/common.cpp` as a candidate for the legacy encoder; it has no DXT code (only a DDS extension helper). The real encoder was in `Sources/src/Image/S3TC.{h,cpp}` and was removed before this task started. Recovered from git history (commit 40645ad29^) rather than touching the deleted path. No slice-contract change.

## Known Issues

The measured max_delta=255 and p99 ≈ 125 are driven by the noise fixture: equal-weight luma vs BT.601 luma pick radically different endpoints on random-colour blocks. Downstream golden tests consuming this JSON must either accept the full range on noise-like inputs or filter to lower-frequency content. Not a defect — the plan asked for high-frequency noise and the number is the honest contract — but it is a load-bearing fact for anyone writing the golden tier later.

## Files Created/Modified

- `Sources/src/ResourceModel/spike/legacy_dxt.h`
- `Sources/src/ResourceModel/spike/legacy_dxt.cpp`
- `tools/zig/dxt_tolerance_test.cpp`
- `tools/zig/fixtures/resource_editor/dxt-tolerance.json`
- `build.zig`
