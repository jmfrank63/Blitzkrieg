---
estimated_steps: 4
estimated_files: 15
skills_used: []
---

# T02: Particle simple/complex source toolbar toggle, undoable, equal to the exporter derivation

Why: 06-PARITY B-06.4 is 'not done: simple/complex toggle in the UI (exporter derives it from the complex source item, S12 T01); needs a follow-up task'. Hard steer D027 item (2).
MFC behaviour (Sources/src/editor/ParticleFrm.cpp): ID_PARTICLE_SOURCE is a checkbox toolbar button (UpdateSourceTypeTB) enabled when a tree exists; OnSwitchParticleSourceType flips bComplexSource and UpdateSourceType expands the complex-source and complex items and collapses the simple source/props items (or the reverse). LoadRPGStats sets the mode from KeyData's ComplexParticleSource flag. MFC kept the mode in the frame; the port has no frame state, so the exporter derives it (particle_export.cpp ~265: complex when the complex source item exists and its particle name, value 0, is non-empty; see the comment in particle_export.h).
Do: (1) One source of truth: expose the derivation as a single function in the model (e.g. IsComplexSource(root) in items/particle/particle.h/.cpp) and make particle_export.cpp call it, so UI state and export can never disagree. (2) Bridge: BkResParticleSourceMode(session, out complex) and BkResParticleSetSourceMode(session, complex, name). Switching to complex sets the complex source's particle name (value 0) to the given non-empty name (the app offers the last name used in this session, else asks); an empty name is refused with a message. Switching to simple clears that value. Each switch is one undo step through the existing document change/undo path (as a property edit), so undo/redo restores the mode and the value. Document, CRLF. (3) Tests in resource_bridge_test.cpp: on the pcp fixture the mode read back equals the exporter's choice (export, read the written KeyData ComplexParticleSource flag back through the engine's operator&) in both directions; undo and redo flip it back and forth; refused for non-pcp sessions and for an empty complex name. (4) Mirror in resource_core bridge.zig, fake_bridge.zig, resource_app c_bridge.zig with a core test. (5) App: checkbox toolbar button for pcp shown checked when complex, enabled with an open project; toggling expands/collapses the tree items as UpdateSourceType does (pure logic for which items expand, with an app-logic test). (6) scenario.zig verb (e.g. do=source_mode:complex|simple) with a predicate on the bridge's mode and the exported flag; the pcp block of resource-editor-auto toggles, exports, undoes and redoes. (7) Update 06-PARITY.md B-06.4 to done with evidence. Keep CRLF.
Done when: verify exits 0 and B-06.4 says done with evidence.

## Inputs

- `Sources/src/editor/ParticleFrm.cpp`
- `Sources/src/ResourceModel/items/particle/particle.h`
- `Sources/src/ResourceModel/items/particle/particle_export.h`
- `Sources/src/ResourceModel/items/particle/particle_export.cpp`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `tools/zig/fixtures/resource_editor/pcp/project.pcp`

## Expected Output

- `Sources/src/ResourceModel/items/particle/particle.h`
- `Sources/src/ResourceModel/items/particle/particle_export.cpp`
- `Sources/src/EditorBridge/resource_bridge.h`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `Sources/editor/resource_app/scenario.zig`
- `build.zig`
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`

## Verification

zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model -Dtest-mode=run && zig build test-resource-core -Dtest-mode=run && zig build test-resource-app-logic -Dtest-mode=run && zig build install-resource-editor && zig build resource-editor-auto && zig build resource-editor-smoke

## Observability Impact

Source-mode refusals name the reason; the auto step prints the mode and the exported flag after each switch, undo and redo.
