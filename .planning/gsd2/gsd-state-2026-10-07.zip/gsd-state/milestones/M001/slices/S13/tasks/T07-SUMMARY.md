---
id: T07
parent: S13
milestone: M001
key_files:
  - Sources/src/ResourceModel/items/tileset/tileset_export.cpp
  - Sources/src/ResourceModel/items/tileset/tileset_export.h
  - Sources/src/ResourceModel/items/tileset/tileset.cpp
  - Sources/src/EditorBridge/resource_bridge.cpp
  - Sources/src/EditorBridge/resource_bridge_test.cpp
  - tools/zig/fixtures/resource_editor/til/golden/README.md
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-06T00:32:49.121Z
blocker_discovered: false
---

# T07: Tileset (.til) exporter ported from ComposeTiles writes tileset xml, crosset xml and DXT atlases; tile index pools on insert/delete; .til import from game data refused with the reason.

**Tileset (.til) exporter ported from ComposeTiles writes tileset xml, crosset xml and DXT atlases; tile index pools on insert/delete; .til import from game data refused with the reason.**

## What Happened

Resumed with the exporter (tileset_export.{h,cpp}), the index pools in tileset.{h,cpp}, the exporter registration, the bridge hooks (insert takes a free index, open assigns missing ones, editor data dir passed to exporters) and the import refusal already on disk but never built. Fixed the build (Scene/Builders.h pulled GFX types; used RandomMapGen/Builders.h with forward declarations for the two GFX buffer types). Added S13Til::Fixture to resource_bridge_test.cpp and changed the old 'til not ported yet' assertion. Tests cover: tileset xml, crosset.xml and _c/_l/_h textures written; engine STilesetDesc/SCrossetDesc readers; AIClasses inversion with the water bit; normal-and-flipped tile gives entries 2i and 2i+1 with the engine's cumulative ranges; tile 0 pixels equal the masked art within the DXT1 gate (worst delta 3, gate 43) and an empty slot stays dark; second forced export byte-identical; free-index pool for tiles and crosset tiles (two inserts distinct, delete frees, reinsert reuses, restore keeps the index); missing TGA warning naming art-16x16.tga with the export still written; import refusal message; GOLDEN til pending. Updated til/golden/README.md.

## Verification

All four verify commands exit 0. Full resource-editor sweep left to the maintainer. macOS and Windows not run.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 120000ms |
| 2 | `zig build test-resource-model -Dtest-mode=run` | 0 | pass | 60000ms |
| 3 | `zig build test-resource-model-comparator -Dtest-mode=run` | 0 | pass | 30000ms |
| 4 | `zig build test-resource-core -Dtest-mode=run` | 0 | pass | 30000ms |

## Deviations

Free-index pools are derived from the tree (lowest unused index) instead of a stored list; same result as MFC's pool and nothing to keep in step through undo. Exported file name follows the project's stored export name (1.xml by default), not tileset.xml; shipped projects store tileset.xml.

## Known Issues

None.

## Files Created/Modified

- `Sources/src/ResourceModel/items/tileset/tileset_export.cpp`
- `Sources/src/ResourceModel/items/tileset/tileset_export.h`
- `Sources/src/ResourceModel/items/tileset/tileset.cpp`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `tools/zig/fixtures/resource_editor/til/golden/README.md`
