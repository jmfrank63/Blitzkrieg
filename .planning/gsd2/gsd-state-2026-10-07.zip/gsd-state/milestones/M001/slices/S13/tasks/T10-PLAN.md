---
estimated_steps: 3
estimated_files: 5
skills_used: []
---

# T10: Split resource-editor-auto into per-editor build steps plus an aggregate

Why: resource-editor-auto took 383 s at the S12 sweep (45 s at S10, 295 s at S11), and S13 adds road/river/tileset blocks and a Function-window pointer path. A foreground command is capped at 10 minutes, so the single tier would soon be unrunnable inside a task (hard steer, D028). Runs before the auto-scenario task T11.
Do: (1) In build.zig, replace the single resource_auto_schedule string with one schedule constant per editor, cut at the existing block comments: core (new, open, edit, undo, save, export, pack, import, run_game: the frames before the S06 block), -wpn/-unt/-spt (S06 stats sub-editors and S07 sprite, split so each stays under about 3 minutes), -msh (S08 Unit), -obt/-fnc (S09 Object and Fence), -bld (S10), -bdg (S11), -pcp/-eff (S12), plus the T01-T04 additions already in the pcp/eff blocks (pointer-driven Function window path included); name the steps resource-editor-auto-core, -wpn, -unt, -spt, -msh, -obt, -fnc, -bld, -bdg, -pcp, -eff (merge two editors into one step where a pair is far below 3 minutes, and say so in the step description). Reserve empty-until-T11 slots resource-editor-auto-til, -3rd and -3rv with the same helper so T11 only fills in their schedules. (2) One helper builds a step from a schedule: its own auto_dir under zig-out/local-test/resource_editor/auto-NAME, its own mod folder names, BK_EDITOR_AUTO set to that schedule only, the smoke dependency of today's step, and the autoshot cleanup. Steps that need earlier state copy their fixtures themselves (every existing block already copies a tracked fixture into {dir}), so each runs alone. Frame numbers may stay as they are; the scenario ends when its schedule does. (3) Keep every existing scenario action and expectation: the concatenated per-editor schedules must equal today's string. Add a unit check, as a comptime assertion or a small test, that the concatenation of the per-step constants in order equals the old whole. (4) Aggregate resource-editor-auto depends on every per-editor step, serialized in order so two engines never start at once. (5) Record each step's elapsed time in the step description or the task summary; each should be under about 3 minutes on this machine. (6) Add every new step to .github/workflows/cross-platform.yml next to each existing 'Resource editor auto' step (Windows and macOS, with the same -D flags) as its own named step, and to tools/zig/run-resource-sweep.sh's TIERS list together with resource-editor-host-check and resource-editor-smoke (the sweep ran only the aggregate or neither; list the per-editor steps so a failure names the editor). Keep the aggregate in CI as well. (7) Note the split in the spec docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md and in AGENTS.md's tier list. Keep CRLF.
Done when: every per-editor step exits 0 on its own, each in about 3 minutes or less, and the aggregate resource-editor-auto exits 0. The aggregate is the long run; if it exceeds the 10-minute foreground cap, record that and run the steps individually.

## Inputs

- `build.zig`
- `tools/zig/run-resource-sweep.sh`
- `.github/workflows/cross-platform.yml`
- `.gsd/OVERRIDES.md`

## Expected Output

- `build.zig`
- `tools/zig/run-resource-sweep.sh`
- `.github/workflows/cross-platform.yml`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`
- `AGENTS.md`

## Verification

zig build install-resource-editor && zig build resource-editor-auto-core && zig build resource-editor-auto-wpn && zig build resource-editor-auto-unt && zig build resource-editor-auto-spt && zig build resource-editor-auto-msh && zig build resource-editor-auto-obt && zig build resource-editor-auto-fnc && zig build resource-editor-auto-bld && zig build resource-editor-auto-bdg && zig build resource-editor-auto-pcp && zig build resource-editor-auto-eff && zig build resource-editor-smoke && zig build resource-editor-host-check
