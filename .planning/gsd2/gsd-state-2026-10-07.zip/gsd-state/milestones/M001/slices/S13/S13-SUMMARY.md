---
id: S13
parent: M001
milestone: M001
provides:
  - (none)
requires:
  []
affects:
  []
key_files: []
key_decisions: []
patterns_established:
  - (none)
observability_surfaces:
  - none
drill_down_paths:
  []
duration: ""
verification_result: passed
completed_at: 2026-10-06T02:06:09.354Z
blocker_discovered: false
---

# S13: S13

**S12 follow-ups (particle info, simple/complex toggle, effect direction dock, real-pointer Function window auto) plus tileset, road and river sub-editors with previews, wireframe, import/export and auto scenarios.**

## What Happened

T01-T04 closed the S12 follow-ups (D027): BkResGetParticleInfo with the four-pane status bar; an undoable particle simple/complex source toggle sharing one IsComplexSource derivation with the exporter; the Effect Direction dock driving the .eff preview with whole-number child X/Y/Z edits (B-08.3); and auto drivers for the Function window curve widget using real SDL pointer and key events (add, drag, delete, undo, redo, handle pixels measured). T05-T09 added the 3D Road/River exporters and importers (shipped round trip over 40 files, 0 unimportable), road and river previews on their maps with a wireframe toggle and a river that plays, the tileset (.til) exporter ported from ComposeTiles with tile index pools, Import terrains/crossets and add-tile bridge calls, and terrain thumbnail lists with crosset mode. Tileset preview and .til import from game data are refused with the reason recorded. T10 split resource-editor-auto into 14 per-editor steps (D028) and T11 filled til/3rd/3rv with measured shots (road solid 93.8% drawn vs wireframe 30.7%; river animated and stopped), closing under D029 with PARITY B-18..B-20 filled and B-06.4 closed.

## Verification

Run on Linux x64 in this unit via gsd_exec, all exit 0: test-resource-bridge, test-resource-model, test-resource-model-comparator, test-resource-core, test-resource-app-logic, test-editor-core, test-editor-bridge (-Dtest-mode=run); install-resource-editor; resource-editor-auto-til, -3rd, -3rv (auto PASS with 29, 34 and 33 actions, run with the session's Wayland display); resource-editor-smoke; resource-editor-host-check. git status clean. Not run: aggregate resource-editor-auto, the other per-editor autos, map-editor-host-check and map-editor-smoke in this unit; the full sweep is left to the maintainer. No macOS or Windows result is claimed.

## Requirements Advanced

None.

## Requirements Validated

None.

## New Requirements Surfaced

None.

## Requirements Invalidated or Re-scoped

None.

## Operational Readiness

None.

## Deviations

None.

## Known Limitations

Full sweep (tools/zig/run-resource-sweep.sh) left to the maintainer. The S13 plan file carries a hand-added note about T11 that a re-render from the database may drop. GUI tiers need the user's Wayland session env, which gsd_exec does not inherit.

## Follow-ups

None.

## Files Created/Modified

None.
