---
estimated_steps: 3
estimated_files: 6
skills_used: []
---

# T09: App: tileset thumbnail docks with crosset mode, wireframe toggle, river Run/Stop, til toolbar

Why: B-18.1..B-18.4, B-19.2, B-20.2 and S05's open A-13 limitation for wireframe: users see tiles, add them, import, and toggle wireframe in the app.
Do: (1) Pure logic first in a new Sources/editor/resource_app/terrain_logic.zig wired into test-resource-app-logic as grid_logic.zig is in build.zig: crosset mode is derived from the selected tree item exactly as TileTreeItem.cpp:443/1109/1227 SwitchToEditCrossetsMode (Crossets item, crosset props item or crosset tiles item -> crossets; terrain side -> terrains); the all-tiles list shows the project's terrains or crossets directory (loaded lazily once, as GetLoadedFlag), the selected list shows the active item's tiles; double-click maps to BkResTileSetAddTile on the active item. Tests for the mode switch per item type and for the add target. Reuse the existing thumbnail helpers in docks_logic.zig (thumbnailDecodePath, fitThumbnail, sortThumbnailNames, isThumbnailPicture). (2) docks.zig/panels.zig/main.zig: for til show the two thumbnail lists in place of the scene preview (PreviewSync shows the T06 refusal once, not repeatedly), toolbar Import terrains / Import crossets with a file dialog calling BkResTileSetImport. The ID_EDIT_CROSSETS button is not added (no handler in MFC; recorded in T10). (3) For 3rd/3rv: a Wireframe check (View menu and toolbar, enabled when a project is open, as ID_SWITCH_WIREFRAME) calling BkResPreviewWireframe, reset on kind switch; for 3rv Run/Stop via the existing PreviewSync playback; road shows no Run. (4) App-logic tests for any new pure logic.
Done when: verify exits 0 and opening the til, 3rd and 3rv fixtures in resource-editor-smoke does not regress.

## Inputs

- `Sources/src/editor/TileTreeItem.cpp`
- `Sources/src/editor/TileSetFrm.cpp`
- `Sources/editor/resource_app/docks.zig`
- `Sources/editor/resource_app/docks_logic.zig`
- `Sources/editor/resource_app/grid_logic.zig`
- `Sources/editor/resource_app/panels.zig`
- `Sources/editor/resource_app/main.zig`
- `Sources/editor/resource_app/c_bridge.zig`

## Expected Output

- `Sources/editor/resource_app/docks.zig`
- `Sources/editor/resource_app/docks_logic.zig`
- `Sources/editor/resource_app/terrain_logic.zig`
- `Sources/editor/resource_app/panels.zig`
- `Sources/editor/resource_app/main.zig`
- `build.zig`

## Verification

zig build test-resource-app-logic -Dtest-mode=run && zig build test-resource-core -Dtest-mode=run && zig build install-resource-editor && zig build resource-editor-smoke && zig build resource-editor-host-check

## Observability Impact

The til preview refusal is shown once; app-logic tests name the crosset-mode case that fails.
