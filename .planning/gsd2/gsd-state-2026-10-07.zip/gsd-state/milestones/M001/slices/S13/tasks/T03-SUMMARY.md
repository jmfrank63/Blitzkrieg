---
id: T03
parent: S13
milestone: M001
key_files: []
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-05T23:13:33.806Z
blocker_discovered: false
---

# T03: Effect Direction dock now drives .eff preview via BkResEffectSetDirection/GetDirection (UpdateEffectAngle matrix, view state), child X/Y/Z positions edit as whole numbers, with bridge, core, app-logic and auto coverage; B-08.3 done.

**Effect Direction dock now drives .eff preview via BkResEffectSetDirection/GetDirection (UpdateEffectAngle matrix, view state), child X/Y/Z positions edit as whole numbers, with bridge, core, app-logic and auto coverage; B-08.3 done.**

## What Happened

Bridge: added BkResEffectSetDirection/GetDirection (default 45 degrees, reset on project open, not undoable, applied through the running effect's SetEffectDirection) and BkResEffectDirectionMatrix exposing UpdateEffectAngle's math. Child position props were already integer DT_DEC; tests pin that a fractional text keeps its integer part, each edit reads back, undo/redo restore, and the exporter writes vPos unchanged. Zig: mirrored in bridge.zig, fake_bridge.zig and c_bridge.zig with a core test; docks_logic got turnEffect, syncEffectAngle and angleOfDegrees with a test; the existing Direction dock now drives .eff projects (needle reads the bridge's stored angle). scenario.zig gained do=effect_direction, expect=effect_angle and '_' for a space in property tokens; resource-editor-auto has an eff block (X_position edit, direction 90 and 0, undo, redo, export). Also fixed main.zig's drawPreviewMenuItems call to pass the lifecycle. 06-PARITY B-08.3 updated to done with evidence.

## Verification

All commands of the task's Verify line ran green: test-resource-bridge, test-resource-model, test-resource-core, test-resource-app-logic, install-resource-editor, resource-editor-auto (PASS, 735 actions over 551 frames), resource-editor-smoke.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 0ms |
| 2 | `zig build test-resource-model -Dtest-mode=run` | 0 | pass | 20510ms |
| 3 | `zig build test-resource-core -Dtest-mode=run` | 0 | pass | 640ms |
| 4 | `zig build test-resource-app-logic -Dtest-mode=run` | 0 | pass | 610ms |
| 5 | `zig build install-resource-editor` | 0 | pass | 0ms |
| 6 | `zig build resource-editor-auto` | 0 | pass | 0ms |
| 7 | `zig build resource-editor-smoke` | 0 | pass | 5590ms |

## Deviations

None.

## Known Issues

None.

## Files Created/Modified

None.
