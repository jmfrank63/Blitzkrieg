---
estimated_steps: 3
estimated_files: 14
skills_used: []
---

# T07: Tileset exporter (ComposeTiles) and til import refusal

Why: B-18.5 and B-18.6. FindExporter("til") is null; CTileSetFrame::LoadRPGStats only re-inits the index pools, so there is no import from game data.
Do: (1) Add Sources/src/ResourceModel/items/tileset/tileset_export.{h,cpp} with ExportTileSet ported line for line from CTileSetTreeRootItem::ComposeTiles (Sources/src/editor/TileTreeItem.cpp ~50-430) and CTileSetFrame::ExportFrameData (TileSetFrm.cpp). Tile atlas: 256 wide, height NextPow2((maxTileIndex/7)*32+16); tile i: nMod7=i%7, <4 -> x=nMod7*64,y=(i/7)*32, else x=(nMod7-4)*64+32,y=(i/7)*32+16; each source TGA modulated by the tile mask Data/Editor/Terrain/tilemask.tga (read-only, resolved case-insensitively from the export context's data root, as MFC read it from the editor directory) with the engine Image module's ModulateColorFrom/CopyFromAB via image_export.h LoadPicture. STilesetDesc per terrain: name, crosset number, priority, passability, microtexture, sound volume, sound refs, looped sound, canEntrench, soil params (replicate the |= on a default field), AIClasses inverted with bit 31 = water, tiles with fProbTo, flipped state (normal index*2, flipped *2+1, both two entries), FillTileMaps(256,sizeY,tilemaps,true). Write <name>.xml root "tileset" via NStatsExport::WriteStats and the atlas via SaveCompressedTexture (image_export.h). Crosset only if crosset tiles exist: rows (n+6)/7, index mapping (nCrossIndex/2)%7 and nCrossIndex/14, the whiteout pass with stride 256 (bug-compatible p[y*256+x]), DXT5/ARGB4444 forced via the lowFormat overload, crosset.xml root "crosset" with SCrossetDesc. Missing TGAs become outcome warnings naming each file; tileset continues, crosset breaks, as MFC; output still written. Register {"til",&ExportTileSet} in exporter.cpp, declare in stats_export.h, add the .cpp to build.zig's ResourceModel list. Check shipped Data/Terrain/sets/1 names (tileset_c/_h/_l.dds, crosset_c/_h/_l.dds) match what SaveCompressedTexture writes. (2) Port the free-index pools (InitFreeTerrainIndexes/InitFreeCrossetIndexes, Get/RemoveFree*Index in TileSetFrm.cpp) into the model (tileset.{h,cpp}) so inserting a CTileSetTilePropsItem / CCrossetTilePropsItem assigns a free nTileIndex/nCrossIndex and deleting frees it; these non-prop members persist via ReadData/WriteData (verify the model already round-trips them). Hook it where the bridge inserts items so BkResInsert of tile props uses the pool. (3) BkResImportFromGame for kind 13 answers REFUSED: 'importing .til from game data is refused: no reverse path in MFC (CTileSetFrame::LoadRPGStats only rebuilds index pools)'. (4) Tests in resource_bridge_test.cpp: tools/zig/fixtures/resource_editor/til/project.til (extend via resource_editor_fixtures.zig if it lacks terrain and crosset tiles pointing at its art-16x16.tga, copied to zig-out/local-test) exports tileset xml + DDS and crosset xml + DDS; second forced export byte-identical; xml read back through STilesetDesc/SCrossetDesc operator& equals tree values (AIClasses, tiles, flips); decoded atlas pixels at the computed tile positions match the masked source within the dxt_gate tolerance (dxt-tolerance.json); a missing TGA yields a warning naming it; inserting two tiles gives distinct indexes, delete then insert reuses the freed index, undo/redo restore indexes; import refusal message; 'GOLDEN til pending'; update til/golden/README.md. Keep new files CRLF.
Done when: verify exits 0.

## Inputs

- `Sources/src/editor/TileTreeItem.cpp`
- `Sources/src/editor/TileSetFrm.cpp`
- `Sources/src/ResourceModel/items/tileset/tileset.h`
- `Sources/src/ResourceModel/items/tileset/tileset.cpp`
- `Data/Editor/Terrain/tilemask.tga`
- `Sources/src/ResourceModel/image_export.h`
- `Sources/src/ResourceModel/dxt_gate.h`
- `tools/zig/fixtures/resource_editor/dxt-tolerance.json`
- `tools/zig/fixtures/resource_editor/til/project.til`
- `tools/zig/fixtures/resource_editor/til/art-16x16.tga`
- `Data/Terrain/sets/1/tileset.xml`
- `Data/Terrain/sets/1/crosset.xml`

## Expected Output

- `Sources/src/ResourceModel/items/tileset/tileset_export.h`
- `Sources/src/ResourceModel/items/tileset/tileset_export.cpp`
- `Sources/src/ResourceModel/items/tileset/tileset.h`
- `Sources/src/ResourceModel/items/tileset/tileset.cpp`
- `Sources/src/ResourceModel/items/stats_export.h`
- `Sources/src/ResourceModel/exporter.cpp`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `tools/zig/fixtures/resource_editor/til/golden/README.md`
- `build.zig`

## Verification

zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model -Dtest-mode=run && zig build test-resource-model-comparator -Dtest-mode=run && zig build test-resource-core -Dtest-mode=run

## Observability Impact

Tileset export warnings list each missing TGA; GOLDEN til pending line; til import refusal message.
