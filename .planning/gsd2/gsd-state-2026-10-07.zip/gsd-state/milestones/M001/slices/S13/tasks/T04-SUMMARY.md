---
id: T04
parent: S13
milestone: M001
key_files: []
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-05T23:45:42.639Z
blocker_discovered: false
---

# T04: resource-editor-auto now drives the Function window curve widget with real SDL pointer and key events (curve_click, curve_drag, curve_delete), reads keys back after each gesture, undo and redo, and measures the handle pixels in the capture.

**resource-editor-auto now drives the Function window curve widget with real SDL pointer and key events (curve_click, curve_drag, curve_delete), reads keys back after each gesture, undo and redo, and measures the handle pixels in the capture.**

## What Happened

Added do=function_open (Ctrl+F through the key queue), do=curve_click, do=curve_drag and do=curve_delete to scenario.zig. Targets come from the widget's own layout: docks.zig exposes curve_rect and curveScreen (key value to screen pixel), and a function_override placement gives the auto tier a tall window. Events go through the SDL event queue the host reads real input from, one frame per step, so ImGui sees down, move and up. Each gesture prints the stored keys before, after the gesture, after undo and after redo. A new shot_curve_handle:<shot>/<i> predicate measures a 5x5 block at the drawn handle (at least 20 pixels of one colour, contrast at least 30 against the background) and prints the counts. The real input path exposed a crash: ImGui reports the mouse at -FLT_MAX before any motion, which trapped the float-to-int cast in drawFunction; fixed by guarding it. Shots and shot expects run after the draw phase of their frame, so the pcp block was spread over frames 525-532 and later frames shifted by 7. The handle is found one pixel from the computed place, so the measurement searches 4 pixels around it and prints the offset. 06-PARITY A-15 and B-06.5 now cite the pointer-driven frames.

## Verification

All five Verify commands exited 0 in this session. resource-editor-auto: PASS, 750 actions over 558 frames.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-app-logic -Dtest-mode=run` | 0 | pass | 1000ms |
| 2 | `zig build install-resource-editor` | 0 | pass | 5000ms |
| 3 | `zig build resource-editor-auto` | 0 | pass | 120000ms |
| 4 | `zig build resource-editor-smoke` | 0 | pass | 20000ms |
| 5 | `zig build resource-editor-host-check` | 0 | pass | 20000ms |

## Deviations

None.

## Known Issues

None.

## Files Created/Modified

None.
