---
estimated_steps: 4
estimated_files: 12
skills_used: []
---

# T01: Particle Get particle info (CParticleFrame::GetParticleInfo and status bar)

Why: 06-PARITY B-06.3 is 'not done: Get particle info (S12 T05 did not port it); needs a follow-up task'. Hard steer D027 item (1).
MFC behaviour to port (Sources/src/editor/ParticleFrm.cpp): ID_GET_PARTICLE_INFO toolbar button (enabled when a project tree exists, OnUpdateGetParticleInfo) calls GetParticleInfo(): it writes the effect description of the current tree (CreateEffectDescriptionFile, simple or complex source), builds it through IVisObjBuilder as SGVOT_EFFECT, takes the last particle source of IEffectVisObj::GetParticleEffects, casts it to IParticleSourceWithInfo (Sources/src/Scene/PFX.h; CKeyBasedParticleSource and CSmokinParticleSource implement it) and stores SParticleSourceInfo fMaxCount, fMaxSize, fAverageSize, fAverageCount. OnUpdateStatusBar then shows four panes: 'Max particles %g', 'Size %g', 'Average size %g', 'Average count %g'.
Do: (1) Bridge: add BkResParticleInfo(session, out struct with the four floats) in Sources/src/EditorBridge/resource_bridge.h/.cpp. It runs the real pcp exporter (particle_export.cpp) into the preview staging folder, builds the effect through the engine's IVisObjBuilder exactly as the existing pcp preview does, calls GetInfo on the last source, and returns the four values. Refuse with a specific message for a kind other than pcp, or when no source is built (name the reason, e.g. the complex source's missing particle). Document the call, CRLF. (2) Test in resource_bridge_test.cpp: the pcp fixture (tools/zig/fixtures/resource_editor/pcp/project.pcp, copied to zig-out/local-test) returns fMaxCount > 0 and finite sizes; changing a density/lifetime key through the bridge changes fMaxCount; a non-pcp session is refused with the message. (3) Mirror in Sources/editor/resource_core/bridge.zig, fake_bridge.zig (fixed values for tests) and Sources/editor/resource_app/c_bridge.zig with a core test. (4) App: a 'Get particle info' toolbar button for pcp, enabled when a project is open, and a status bar showing the four values with MFC's labels and %g formatting (pure formatting in a logic file with an app-logic test). (5) scenario.zig: a verb (e.g. do=particle_info) plus a predicate that the four values are present and fMaxCount > 0; add it to the pcp block of resource-editor-auto in build.zig. (6) Update 06-PARITY.md B-06.3 to done with the test names and auto frame numbers. Keep CRLF.
Done when: verify exits 0 and B-06.3 says done with evidence.

## Inputs

- `Sources/src/editor/ParticleFrm.cpp`
- `Sources/src/editor/ParticleFrm.h`
- `Sources/src/Scene/PFX.h`
- `Sources/src/Scene/KeyBasedParticleSource.h`
- `Sources/src/Scene/SmokinParticleSource.h`
- `Sources/src/ResourceModel/items/particle/particle_export.cpp`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `tools/zig/fixtures/resource_editor/pcp/project.pcp`

## Expected Output

- `Sources/src/EditorBridge/resource_bridge.h`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `Sources/editor/resource_core/bridge.zig`
- `Sources/editor/resource_core/fake_bridge.zig`
- `Sources/editor/resource_app/c_bridge.zig`
- `Sources/editor/resource_app/scenario.zig`
- `build.zig`
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`

## Verification

zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-core -Dtest-mode=run && zig build test-resource-app-logic -Dtest-mode=run && zig build install-resource-editor && zig build resource-editor-auto && zig build resource-editor-smoke

## Observability Impact

BkResParticleInfo refusals name the reason; the auto pcp step prints the four values.
