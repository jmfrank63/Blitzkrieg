---
estimated_steps: 3
estimated_files: 9
skills_used: []
---

# T08: Import terrains / Import crossets bridge calls and tile-add ABI

Why: B-18.2 and the thumbnail double-click (B-18.3) need bridge entry points. OnImportTerrains (TileSetFrm.cpp:557) and OnImportCrossets (:782) read a tileset-editor xml plus a matching .tga atlas and cut it into tiles under the project's terrain/crosset directories, adding tile-props items; the double-click on a thumbnail adds a CTileSetTilePropsItem (GetFreeTerrainIndex) or CCrossetTilePropsItem (GetFreeCrossetIndex) to the active terrain/crosset item.
Do: (1) Add to resource_bridge.h/.cpp: BkResTileSetImport(session, path, crossets) porting both handlers (writes cut tiles into the project folder only, never Data/; one undoable step as a single document change, matching how BkResImportFromGame records its edit), and BkResTileSetAddTile(session, parent_node, picture_path) adding the right props item with a pooled index (T07 pool) as one undoable command; BAD_ARGUMENT for a parent that is not a terrain/crosset item. Document both, CRLF. (2) A tracked fixture pair (small tileset-editor xml + .tga) under tools/zig/fixtures/resource_editor/til/import/ produced by resource_editor_fixtures.zig (shipped Data holds only DDS). (3) Tests in resource_bridge_test.cpp: import terrains and crossets from the fixture adds the expected items and tile files with distinct indexes; undo removes them, redo restores; add-tile then undo frees the index; bad parent refused. (4) Mirror both calls in Sources/editor/resource_core/bridge.zig, fake_bridge.zig and Sources/editor/resource_app/c_bridge.zig with core tests.
Done when: verify exits 0.

## Inputs

- `Sources/src/editor/TileSetFrm.cpp`
- `Sources/src/editor/TileTreeItem.cpp`
- `Sources/src/ResourceModel/items/tileset/tileset.h`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/editor/resource_core/bridge.zig`
- `Sources/editor/resource_core/fake_bridge.zig`
- `Sources/editor/resource_app/c_bridge.zig`

## Expected Output

- `Sources/src/EditorBridge/resource_bridge.h`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `tools/zig/resource_editor_fixtures.zig`
- `tools/zig/fixtures/resource_editor/til/import/terrains.xml`
- `tools/zig/fixtures/resource_editor/til/import/terrains.tga`
- `Sources/editor/resource_core/bridge.zig`
- `Sources/editor/resource_core/fake_bridge.zig`
- `Sources/editor/resource_app/c_bridge.zig`

## Verification

zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-core -Dtest-mode=run && zig build test-resource-app-logic -Dtest-mode=run

## Observability Impact

Import and add-tile refusals name the bad parent or missing file.
