---
estimated_steps: 4
estimated_files: 14
skills_used: []
---

# T03: Effect direction dock and whole-number child-position editing

Why: 06-PARITY B-08.3 is 'not done: direction arrow dock and effect angle/position editing (S12 T05 did not port them); needs a follow-up task'. Hard steer D027 item (3); the S12 plan's must-haves listed both.
MFC behaviour: Sources/src/editor/EffectFrm.cpp. ID_SHOW_DIRECTION_BUTTON shows/hides the DirectionButtonDock; SpecificInit/SpecificClearBeforeBatchMode set the angle to 45 degrees; UpdateEffectAngle (called after Run and on angle change) does nothing unless running, else fAlpha = -angle + 45deg, wrapped below 2pi, quaternion about axis (-1/sqrt2, 1/sqrt2, 0), SetEffectDirection on the running effect. The angle lives in the dock, not the project, so it is view state (D027) and is not saved or undone. Child positions: Sources/src/editor/EffTreeItem.cpp GetPosition of CEffectAnimationPropsItem / CEffectMeshPropsItem / CEffectMayaPropsItem / function-particle props read values[1..3] (X, Y, Z); check each prop's type in EffTreeItem.cpp InitDefaultValues and port it.
Do: (1) Model/bridge: child X/Y/Z of every effect child props item edit as whole numbers: the model's prop types match MFC's (fix item definitions in items/effect/effect.{h,cpp} if they differ), the bridge rejects or rounds non-integer input as MFC's integer edit does (state which in the doc comment), each edit is one undo step; the exporter writes vPos from them unchanged (effect_export.cpp). (2) Bridge: BkResEffectSetDirection(session, angle_radians) storing the view angle (default 45 deg, reset on project open/kind switch as SpecificClearBeforeBatchMode) and, while the effect preview is running, applying UpdateEffectAngle's exact math through the running effect's SetEffectDirection; BkResEffectGetDirection returns it. Not an undo step. (3) Tests in resource_bridge_test.cpp: set X/Y/Z on a sprite child, export, read SEffectDesc back through operator& and see the integers in vPos; undo/redo restore; a fractional input behaves as documented; direction: the matrix for angles 0, 45, 90 deg equals the MFC formula (expose the pure math in a helper tested directly) and two preview captures at different angles differ by a measured pixel count when the effect has a visible source (use or build a fixture that does). (4) Mirror in resource_core bridge.zig, fake_bridge.zig, resource_app c_bridge.zig with a core test. (5) App: a Direction dock for eff (View menu entry, as ID_SHOW_DIRECTION_BUTTON) with an arrow drag control whose angle maps as CDirectionButtonDockBar does (pure logic in a logic file with app-logic tests); the property grid edits X/Y/Z as integers. (6) scenario.zig verbs (e.g. do=effect_direction:<deg>, prop edit of X) and an eff block step in resource-editor-auto: set direction while running, two shots differ; edit a child position, export, undo, redo. (7) Update 06-PARITY.md B-08.3 to done with evidence. Keep CRLF.
Done when: verify exits 0 and B-08.3 says done with evidence.

## Inputs

- `Sources/src/editor/EffectFrm.cpp`
- `Sources/src/editor/EffectFrm.h`
- `Sources/src/editor/EffTreeItem.cpp`
- `Sources/src/editor/EffTreeItem.h`
- `Sources/src/editor/DirectionButtonDock.h`
- `Sources/src/ResourceModel/items/effect/effect.h`
- `Sources/src/ResourceModel/items/effect/effect_export.cpp`
- `tools/zig/fixtures/resource_editor/eff/project.eff`

## Expected Output

- `Sources/src/EditorBridge/resource_bridge.h`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `Sources/editor/resource_app/docks.zig`
- `Sources/editor/resource_app/docks_logic.zig`
- `Sources/editor/resource_app/scenario.zig`
- `build.zig`
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`

## Verification

zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model -Dtest-mode=run && zig build test-resource-core -Dtest-mode=run && zig build test-resource-app-logic -Dtest-mode=run && zig build install-resource-editor && zig build resource-editor-auto && zig build resource-editor-smoke

## Observability Impact

Direction and position steps print the angle, the exported vPos and the measured shot difference.
