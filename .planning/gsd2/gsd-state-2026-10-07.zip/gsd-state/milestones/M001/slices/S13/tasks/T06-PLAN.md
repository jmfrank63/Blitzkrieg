---
estimated_steps: 3
estimated_files: 8
skills_used: []
---

# T06: Road/River terrain preview, wireframe and river playback in the bridge

Why: B-19.2/B-20.2. Highest-risk part: MFC's road/river preview is not IVisObjBuilder. LoadRoadMap/LoadRiverMap (3dRoadFrm.cpp/3dRiverFrm.cpp) read maps\road3d.xml / river3d.xml into a map info, CreateTerrain(), Load, IScene::SetTerrain; UpdateRoadView/UpdateRiverView take the terrain editor's STerrainInfo, FillRPGStats into roads3[0] and [1] (river: rivers[0]) and call UpdateRoad/UpdateRiver. Today BeginPreview refuses kinds not in kPreviewKinds (resource_bridge.cpp ~4127) and refuses when pSession->bMapOpen (~4475).
Do: (1) Confirm first, in a test, what the engine reads from Data/Maps/road3d.xml (the file holds a vector_roads list with two entries) and river3d.xml (Rivers with one item): read with NMapFile::Read as session.cpp OpenMapIntoSession does, and assert the STerrainInfo road/river arrays are non-empty before indexing; if road3d.xml's two roads land in a differently named array than roads3, follow the engine and record it. (2) Add a terrain-preview branch in resource_bridge.cpp beside kPreviewKinds for kinds 14/15: Begin loads the map terrain into the resource session without BkEditorOpenMap (CreateTerrain/Load/SetTerrain, camera anchor at (16*fWorldCellSize,16*fWorldCellSize), terrain shown, as ShowFrameWindows does); Show runs the real exporter (T05) into the staging folder, reads the VSODescription back through SVectorStripeObjectDesc operator& (the preview tests the export, D-16), writes it into the terrain editor's road/river entries (ITerrain::GetEditor, see bridge.cpp OpenMapTerrain) and calls UpdateRoad/UpdateRiver; Stop sets the scene terrain to 0 / clears the scene and resets wireframe. Kind 13 answers BK_EDITOR_REFUSED 'tileset has no scene preview; the thumbnail list is its preview (CTileSetFrame hides its GameWnd)'. (3) Wireframe: add BkResPreviewWireframe(session,on) in resource_bridge.h/.cpp applying the shared per-frame wireframe (BkEditorSetWireframe / ApplyWireframeForFrame, session.cpp ~3274) for the resource session; reset on Stop and on kind switch. (4) River playback: BkResPreviewPlayback must accept the terrain kinds (today it refuses when pPreviewObj == nullptr); PreviewBeforeDraw advances the game timer every frame as MFC GFXDraw did, Run/Stop being the UI label. Road has no Run in MFC: Playback for 14 answers REFUSED naming that. (5) Tests in resource_bridge_test.cpp (GPU, run from the shell, not the gsd_exec sandbox): bare terrain shot vs road shot and vs river shot differ by a measured pixel count; wireframe on vs off differ; two river shots at advanced timer differ; til Begin refused with the message; Stop then Begin of a sprite kind still works (no leaked terrain); captures under zig-out/local-test/resource_editor/t06/preview-scene/. (6) Mirror BkResPreviewWireframe in Sources/editor/resource_core/bridge.zig, fake_bridge.zig (store the flag; refuse for kinds other than 14/15) and Sources/editor/resource_app/c_bridge.zig with a core test. Keep CRLF.
Done when: verify exits 0.

## Inputs

- `Sources/src/editor/3dRoadFrm.cpp`
- `Sources/src/editor/3dRiverFrm.cpp`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/session.cpp`
- `Sources/src/EditorBridge/bridge.h`
- `Data/Maps/road3d.xml`
- `Data/Maps/river3d.xml`
- `tools/zig/map_file_test.cpp`
- `Sources/src/ResourceModel/items/road3d/road3d_export.cpp`
- `Sources/src/ResourceModel/items/river3d/river3d_export.cpp`

## Expected Output

- `Sources/src/EditorBridge/resource_bridge.h`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `Sources/editor/resource_core/bridge.zig`
- `Sources/editor/resource_core/fake_bridge.zig`
- `Sources/editor/resource_app/c_bridge.zig`

## Verification

zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-core -Dtest-mode=run && zig build test-resource-app-logic -Dtest-mode=run && zig build test-editor-bridge -Dtest-mode=run && zig build test-editor-core -Dtest-mode=run

## Observability Impact

Preview refusals for til and road playback carry specific messages; measured shot pixel counts printed by the bridge test.
