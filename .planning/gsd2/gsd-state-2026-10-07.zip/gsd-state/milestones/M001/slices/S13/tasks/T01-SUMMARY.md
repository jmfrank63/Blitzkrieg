---
id: T01
parent: S13
milestone: M001
key_files:
  - Sources/src/EditorBridge/resource_bridge.cpp
  - Sources/src/EditorBridge/resource_bridge.h
  - Sources/src/EditorBridge/resource_bridge_test.cpp
  - Sources/editor/resource_app/docks.zig
  - Sources/editor/resource_app/docks_logic.zig
  - Sources/editor/resource_app/scenario.zig
  - build.zig
  - .planning/phases/06-resource-editor-portable-port/06-PARITY.md
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-05T22:36:55.421Z
blocker_discovered: false
---

# T01: Added BkResGetParticleInfo and a Get particle info menu item with MFC's four-pane status bar for .pcp projects, with bridge, core, app-logic and auto coverage.

**Added BkResGetParticleInfo and a Get particle info menu item with MFC's four-pane status bar for .pcp projects, with bridge, core, app-logic and auto coverage.**

## What Happened

Resumed with the bridge, Zig mirrors, app button, status bar and scenario verb already on disk. BkResGetParticleInfo refuses with a named reason (no project, not a .pcp, preview export or build failure, no particle source, source without info). Otherwise it runs the real pcp exporter, builds the effect and reads IParticleSourceWithInfo::GetInfo of the last source. The bridge test first failed because it edited the complex source's Density node, which a simple-source export ignores. I changed it to pick the first Density node, the simple source's. The auto schedule's do=particle_info was first at frame 511, right after preview_run, and rebuilt the preview object so the two animation shots no longer differed. I moved it to frame 505, before the run. Removed a temporary debug print. Updated 06-PARITY.md B-06.3 to done with the evidence.

## Verification

All six commands in the plan's Verify line were run and exit 0. The bridge test shows fixture Max particles 5, Size 0.01687, Average size 0.0130261, Average count 4.48826. With density x4, Max particles is 20. A .wpn project is refused naming .pcp. The auto run prints the four values at frame 505. Full sweep left to the maintainer.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 75000ms |
| 2 | `zig build test-resource-core -Dtest-mode=run` | 0 | pass | 20000ms |
| 3 | `zig build test-resource-app-logic -Dtest-mode=run` | 0 | pass | 20000ms |
| 4 | `zig build install-resource-editor` | 0 | pass | 30000ms |
| 5 | `zig build resource-editor-auto` | 0 | pass | 60000ms |
| 6 | `zig build resource-editor-smoke` | 0 | pass | 30000ms |

## Deviations

None.

## Known Issues

None.

## Files Created/Modified

- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge.h`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `Sources/editor/resource_app/docks.zig`
- `Sources/editor/resource_app/docks_logic.zig`
- `Sources/editor/resource_app/scenario.zig`
- `build.zig`
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`
