---
estimated_steps: 4
estimated_files: 1
skills_used: []
---

# T11: BK_EDITOR_AUTO til/3rd/3rv blocks with measured shots, PARITY rows, spec, tier run

Why: the demo needs tileset edits, road/river preview, wireframe and river playback proved in an auto scenario with measured shots; PARITY and spec record evidence. Last task of the slice (D027, D028).
State (hard steer D029, 2026-10-06T01:55): the implementation is already committed in c8e7eef38 (til/3rd/3rv auto blocks with measured shots: road solid 93.8% drawn vs wireframe 30.7%, river animated and stopped; PARITY B-18..B-20 filled, B-06.4 closed; spec and sweep/CI wiring updated) plus affe58ffd (the S13 headers and crosset fixture the earlier S13 task commits left out). Do not re-implement it.
Do: run in the foreground only zig build install-resource-editor, then resource-editor-auto-til, resource-editor-auto-3rd and resource-editor-auto-3rv (each a few minutes). Do NOT run tools/zig/run-resource-sweep.sh, the aggregate resource-editor-auto or any other long multi-tier run, and do not start or wait on a background monitor: the maintainer runs the full sweep and is running it on 4284d3c4d in a separate worktree. Run GUI tiers from the shell, not the gsd_exec sandbox (no video device there). Write T11-SUMMARY citing exactly those three runs (exit codes and measured shares from their output) plus 'full sweep left to the maintainer'; never claim macOS/Windows. Check git status shows nothing the task touched as modified or untracked, then call gsd_task_complete.
Done when: the three auto tiers exit 0 in this task's own foreground runs and the summary cites them.

## Inputs

- `build.zig`
- `Sources/editor/resource_app/scenario.zig`
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`

## Expected Output

- `.gsd/milestones/M001/slices/S13/tasks/T11-SUMMARY.md`

## Verification

zig build install-resource-editor && zig build resource-editor-auto-til && zig build resource-editor-auto-3rd && zig build resource-editor-auto-3rv

## Observability Impact

None; the summary cites the three foreground auto-tier runs.
