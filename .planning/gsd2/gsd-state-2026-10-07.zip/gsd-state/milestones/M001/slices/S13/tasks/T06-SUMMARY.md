---
id: T06
parent: S13
milestone: M001
key_files: []
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-06T00:16:06.091Z
blocker_discovered: false
---

# T06: Road (.3rd) and River (.3rv) previews draw on the maps\road3d and maps\river3d terrain through the resource bridge, with BkResPreviewWireframe, a river that plays and measured shots; the tileset preview is refused with the reason.

**Road (.3rd) and River (.3rv) previews draw on the maps\road3d and maps\river3d terrain through the resource bridge, with BkResPreviewWireframe, a river that plays and measured shots; the tileset preview is refused with the reason.**

## What Happened

The recovery briefing listed T05's tool calls, so T06 started from the plan. BkResPreviewBegin for kinds 14 and 15 now reads maps\road3d / maps\river3d through NMapFile::ReadNewest (the engine's storage, as MFC's LoadRoadMap did), loads them into a fresh CreateTerrain(), sets it as the scene terrain, forces SCENE_SHOW_TERRAIN on and anchors the camera at (16*fWorldCellSize, 16*fWorldCellSize), without BkEditorOpenMap. BkResPreviewShow runs the real exporter (T05) into the staging folder, reads the VSODescription back through SVectorStripeObjectDesc::operator&, writes it into roads3[0] and [1] (rivers[0]) of the terrain editor's STerrainInfo keeping the map's nID and points (a river keeps the map's type), and calls UpdateRoad / UpdateRiver. Stop sets the scene terrain to null, clears the scene and turns the wire frame off. Kind 13 answers BK_EDITOR_REFUSED naming that the thumbnail list is the tileset's preview (CTileSetFrame hides its GameWnd). BkResPreviewWireframe (new, in resource_bridge.h/.cpp) sets the session's wire-frame layer bit that ApplyWireframeForFrame already reads every frame; it is refused unless a terrain preview has begun. BkResPreviewPlayback accepts the terrain kinds: the river runs on the per-frame game timer (PreviewBeforeDraw), the road is REFUSED with "a 3D road has no Run in MFC". The engine reads road3d.xml's two roads into terrain.roads3 and river3d.xml's river into terrain.rivers (asserted in the test; the "vector_roads" list is the same data). BkResPreviewWireframe is mirrored in resource_core/bridge.zig, fake_bridge.zig (stores the flag, refuses for kinds other than 14/15, clears on Stop and Begin), resource_app/c_bridge.zig, with a core test. The bridge test (S13Terrain::Run) prints measured pixel counts against thresholds; captures are under zig-out/local-test/resource_editor/t02/t06/preview-scene/ (the t02 folder is the test's scratch root). A viewed contact sheet confirmed the bare terrain, the exported road drawn as a grey cross, the wire-frame mesh and the river band.

## Verification

Ran the five Verify commands in the foreground: test-resource-bridge, test-resource-core, test-resource-app-logic, test-editor-bridge, test-editor-core, all with -Dtest-mode=run and all exit 0. The bridge test ran on this machine's GPU. The full resource sweep is left to the maintainer.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 70000ms |
| 2 | `zig build test-resource-core -Dtest-mode=run` | 0 | pass | 1000ms |
| 3 | `zig build test-resource-app-logic -Dtest-mode=run` | 0 | pass | 2000ms |
| 4 | `zig build test-editor-bridge -Dtest-mode=run` | 0 | pass | 552000ms |
| 5 | `zig build test-editor-core -Dtest-mode=run` | 0 | pass | 1000ms |

## Deviations

None.

## Known Issues

None.

## Files Created/Modified

None.
