---
id: T02
parent: S13
milestone: M001
key_files:
  - Sources/src/ResourceModel/items/particle/particle_export.cpp
  - Sources/src/ResourceModel/items/particle/particle_export.h
  - Sources/src/EditorBridge/resource_bridge.cpp
  - Sources/src/EditorBridge/resource_bridge.h
  - Sources/src/EditorBridge/resource_bridge_test.cpp
  - Sources/editor/resource_core/bridge.zig
  - Sources/editor/resource_core/fake_bridge.zig
  - Sources/editor/resource_core/root.zig
  - Sources/editor/resource_app/c_bridge.zig
  - Sources/editor/resource_app/docks_logic.zig
  - Sources/editor/resource_app/docks.zig
  - Sources/editor/resource_app/scenario.zig
  - build.zig
  - .planning/phases/06-resource-editor-portable-port/06-PARITY.md
key_decisions:
  - The engine's SParticleSourceData and SSmokinParticleSourceData readers abort on the other kind's file, so tests read the ComplexParticleSource attribute first and then use the matching struct.
  - Scenario tokens are limited to 64 characters, so the export expectation is split into export_complex and export_simple verbs.
duration: 
verification_result: passed
completed_at: 2026-10-05T22:57:11.522Z
blocker_discovered: false
---

# T02: Particle simple/complex source toggle (BkResParticleSourceMode / BkResParticleSetSourceMode), undoable, using one IsComplexSource derivation shared with the exporter, with a toolbar checkbox and an auto scenario.

**Particle simple/complex source toggle (BkResParticleSourceMode / BkResParticleSetSourceMode), undoable, using one IsComplexSource derivation shared with the exporter, with a toolbar checkbox and an auto scenario.**

## What Happened

Added IsComplexSource(root) to the particle model and made ExportParticle call it, so the UI mode and the exported flag share one derivation. Added the bridge calls BkResParticleSourceMode and BkResParticleSetSourceMode (complex needs a non-empty name, simple clears it; each switch is one undo step), mirrored in resource_core (bridge, fake_bridge, root) and in the app's c_bridge. The app has a pcp checkbox toolbar button with pure expand/collapse logic in docks_logic.zig, and scenario.zig has do=source_mode plus expect=source_mode and expect=export_complex / export_simple. The pcp block of resource-editor-auto toggles, exports, undoes and redoes. During resumed verification the bridge test crashed because the engine's operator& aborts when a simple file is read as the complex struct (and the reverse). The test now reads the ComplexParticleSource attribute from the XML text to pick the matching struct, then confirms with the engine's read. The auto tokens also exceeded the 64-character argument limit, so the expectation was split into two verbs that take only the path. 06-PARITY B-06.4 was updated earlier in the task.

## Verification

Re-ran the plan's verify chain step by step in the foreground. The bridge test prints mode and exported flag for opened, complex and simple as 0/0, 1/1, 0/0. The auto run prints the same pairs for the undo, redo and simple steps and ends with auto PASS (718 actions). Smoke was run before the scenario.zig token rename and was not re-run after it; resource-editor-auto rebuilt and passed with the renamed verbs. Full resource sweep is left to the maintainer.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass (after test fix) | 60000ms |
| 2 | `zig build test-resource-model -Dtest-mode=run` | 0 | pass | 20700ms |
| 3 | `zig build test-resource-core -Dtest-mode=run` | 0 | pass | 600ms |
| 4 | `zig build test-resource-app-logic -Dtest-mode=run` | 0 | pass | 600ms |
| 5 | `zig build install-resource-editor` | 0 | pass | 60000ms |
| 6 | `zig build resource-editor-auto` | 0 | pass (718 actions) | 120000ms |
| 7 | `zig build resource-editor-smoke` | 0 | pass (run before scenario.zig verb rename) | 60000ms |

## Deviations

The plan said to read the exported flag back through the engine's operator& alone. It is read from the XML attribute to choose the struct, then confirmed through operator&.

## Known Issues

None.

## Files Created/Modified

- `Sources/src/ResourceModel/items/particle/particle_export.cpp`
- `Sources/src/ResourceModel/items/particle/particle_export.h`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge.h`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `Sources/editor/resource_core/bridge.zig`
- `Sources/editor/resource_core/fake_bridge.zig`
- `Sources/editor/resource_core/root.zig`
- `Sources/editor/resource_app/c_bridge.zig`
- `Sources/editor/resource_app/docks_logic.zig`
- `Sources/editor/resource_app/docks.zig`
- `Sources/editor/resource_app/scenario.zig`
- `build.zig`
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`
