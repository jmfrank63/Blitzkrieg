# S13: S13 — UAT

**Milestone:** M001
**Written:** 2026-10-06T02:06:09.355Z

# S13 UAT

**UAT Type:** automated tiers plus optional hand try on Linux.

## Preconditions
- Linux x64 with a graphical session (XDG_RUNTIME_DIR and WAYLAND_DISPLAY set); `zig build install-resource-editor` done.

## Steps
1. Run `zig build test-resource-bridge -Dtest-mode=run`, then test-resource-model, -comparator, -core, -app-logic. Expected: all pass.
2. Run `zig build resource-editor-auto-til`, `-3rd`, `-3rv`. Expected: `auto PASS`; road solid draws far more of the frame than wireframe; river frames differ while playing and are equal after Stop.
3. Run `zig build resource-editor-smoke` and `resource-editor-host-check`. Expected: pass.
4. Hand try: open a .pcp, choose Get particle info (four values shown), toggle simple/complex and undo; open a .eff and turn the Direction dock; in the Function window add, drag and delete a key, then undo and redo.
5. Open .3rd and .3rv: preview shows the road or river, wireframe toggles. Open .til: terrain and crosset thumbnail lists, double-click adds a tile.

## Edge cases
- Tileset preview and .til import from game data are refused with a message, as in the plan.
- Crosset edit mode: see PARITY.

## Not Proven By This UAT
- macOS and Windows behaviour (CI only), the full sweep (maintainer), GOG goldens on win-home, game-reads-it for these kinds.
