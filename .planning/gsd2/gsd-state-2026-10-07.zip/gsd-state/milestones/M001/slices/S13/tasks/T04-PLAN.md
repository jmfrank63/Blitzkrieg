---
estimated_steps: 3
estimated_files: 5
skills_used: []
---

# T04: Auto path drives the Function window widget with real pointer events

Why: hard steer D027 item (4). Today resource-editor-auto's do=keyframe: verbs call keyframe_logic directly; the displayed curve widget in the Function window (docks.zig) is never driven by input, so hit testing, drag and the widget-to-bridge write are unproved. PARITY A-15 and B-06.5 must cite this.
Do: (1) scenario.zig: verbs that inject synthetic SDL/ImGui pointer and key events at widget coordinates computed from the widget's own layout (expose the graph rect and key-to-pixel mapping from keyframe_logic/docks so the scenario does not hard-code pixels): e.g. do=curve_click:<t>,<v> (add a key by clicking on empty graph space as the widget does), do=curve_drag:<index>,<t>,<v> (press on a key's displayed handle, move over several frames, release), do=curve_delete:<index> (select the key by click, then the delete key or the widget's delete action, as MFC's KeyFrame.cpp editor does). Events go through the host's normal event path (the same queue real input uses), one frame per step, so ImGui sees down/move/up. (2) After each gesture read the stored keys back from the bridge and assert count and values (tolerance from the widget's pixel resolution, stated in the predicate), then undo and redo and assert the keys again. (3) Add the sequence to the pcp block of resource-editor-auto in build.zig (Function window open via Ctrl+F or the View menu, a curve selected): add, drag, delete, each with undo/redo checks, plus a capture of the widget measured by code (key handle pixels present at the expected place). (4) Fix whatever the real input path exposes. (5) Update 06-PARITY.md A-15 and B-06.5 evidence with the new frames ('pointer-driven: add/drag/delete through the displayed widget'). Keep CRLF. Run GUI tiers from the shell (no video device in the gsd_exec sandbox).
Done when: verify exits 0 and A-15/B-06.5 cite the pointer-driven frames.

## Inputs

- `Sources/editor/resource_app/scenario.zig`
- `Sources/editor/resource_app/docks.zig`
- `Sources/editor/resource_app/keyframe_logic.zig`
- `Sources/src/editor/KeyFrame.cpp`
- `Sources/src/editor/KeyFrameDock.cpp`
- `build.zig`

## Expected Output

- `Sources/editor/resource_app/scenario.zig`
- `build.zig`
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`

## Verification

zig build test-resource-app-logic -Dtest-mode=run && zig build install-resource-editor && zig build resource-editor-auto && zig build resource-editor-smoke && zig build resource-editor-host-check

## Observability Impact

Each pointer gesture prints the keys read back from the bridge, before and after undo/redo.
