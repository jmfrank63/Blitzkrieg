---
estimated_steps: 3
estimated_files: 14
skills_used: []
---

# T05: 3D Road and 3D River exporters and importers with shipped round trip

Why: B-19.3/B-19.4/B-20.3/B-20.4, and the road/river preview (T06) feeds the export through the engine reader (D-16). FindExporter("3rd"/"3rv") is null today (Sources/src/ResourceModel/exporter.cpp lists wpn..eff) and BkResImportFromGame refuses kinds 14/15 (resource_bridge.cpp bPorted ~5833).
Do: (1) Add Sources/src/ResourceModel/items/road3d/road3d_export.{h,cpp} and items/river3d/river3d_export.{h,cpp} with ExportRoad3D/ExportRiver3D and Road3DStatsToTree/River3DStatsToTree, ported line for line from Sources/src/editor/3dRoadFrm.cpp and 3dRiverFrm.cpp (FillRPGStats, SaveRPGStats/ExportFrameData writing VSODescription, GetRPGStats). Road: desc.eType = TYPE_ROAD then overwritten by GetRoadType(); AIClasses inverted (~); borders only if the second layer-props item ("Border layer") exists: bottomBorders = 2 copies with RelWidth = border width and bottom.fRelWidth = 1 - border; minimap colours; soil params; import adds the border-layer child when bottomBorders is non-empty. River: bottom layer props and the Layers list (nNumCells from bottom width, animated, disturbance, stream speed, texture step, opacity, texture). Use the engine's SVectorStripeObjectDesc (Sources/src/Formats/fmtVSO.h) operator& through NStatsExport::WriteStats and stats_export.h helpers, as particle_export.cpp/effect_export.cpp do; never hand-write XML. Read model slots from Sources/src/ResourceModel/items/{road3d,river3d}/*.{h,cpp}; do not renumber ETIT_* types. Register {"3rd",&ExportRoad3D} and {"3rv",&ExportRiver3D} in exporter.cpp, declare in stats_export.h, add both .cpp files to build.zig's ResourceModel source list next to particle_export.cpp/effect_export.cpp. (2) In resource_bridge.cpp add kinds 14/15 to bPorted and the import switch. Contract change: for these kinds the path is the runtime <name>.xml file itself (not a folder holding 1.xml); document that in resource_bridge.h's BkResImportFromGame comment. (3) Tests in Sources/src/EditorBridge/resource_bridge_test.cpp: fixtures tools/zig/fixtures/resource_editor/3rd/project.3rd and 3rv/project.3rv export; second forced export byte-identical; read back through operator& and compare to the tree. If the default fixtures exercise too little, extend tools/zig/resource_editor_fixtures.zig (step make-resource-fixtures; EXTENSIONS.md is generated, do not hand-edit) or edit the tree at test time to add a border layer and an animated river layer. Shipped scan: copy every Data/Terrain/sets/*/Roads3D/*.xml and Rivers/*.xml read-only to zig-out/local-test (resolve case-insensitively, DataFile helper), import each, export, compare field-equal through the comparator (extend comparator.{h,cpp} for SVectorStripeObjectDesc if missing; unknown fields fail; check its float policy for RelWidth 1-border rounding and record any tolerance), print 'VSO checked=N files=N unimportable=U'; a listed unimportable file that imports fails the test. Update the batch/import-refusal tests that expect 3rd/3rv unported. 'GOLDEN 3rd pending' and 'GOLDEN 3rv pending' lines; update 3rd/golden/README.md and 3rv/golden/README.md with the win-home step (tools/zig/win-home/export-goldens.ps1 -Extensions 3rd,3rv). Keep new files CRLF.
Done when: the verify tiers exit 0 and the summary records the real VSO counts.

## Inputs

- `Sources/src/editor/3dRoadFrm.cpp`
- `Sources/src/editor/3dRiverFrm.cpp`
- `Sources/src/editor/3dRoadTreeItem.cpp`
- `Sources/src/editor/3dRiverTreeItem.cpp`
- `Sources/src/Formats/fmtVSO.h`
- `Sources/src/ResourceModel/items/road3d/road3d.h`
- `Sources/src/ResourceModel/items/road3d/road3d.cpp`
- `Sources/src/ResourceModel/items/river3d/river3d.h`
- `Sources/src/ResourceModel/items/river3d/river3d.cpp`
- `Sources/src/ResourceModel/items/particle/particle_export.cpp`
- `Sources/src/ResourceModel/exporter.cpp`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `tools/zig/fixtures/resource_editor/3rd/project.3rd`
- `tools/zig/fixtures/resource_editor/3rv/project.3rv`
- `Data/Terrain/sets/1/Roads3D/road_pavement.xml`
- `Data/Terrain/sets/1/Rivers/water.xml`

## Expected Output

- `Sources/src/ResourceModel/items/road3d/road3d_export.h`
- `Sources/src/ResourceModel/items/road3d/road3d_export.cpp`
- `Sources/src/ResourceModel/items/river3d/river3d_export.h`
- `Sources/src/ResourceModel/items/river3d/river3d_export.cpp`
- `Sources/src/ResourceModel/items/stats_export.h`
- `Sources/src/ResourceModel/exporter.cpp`
- `Sources/src/EditorBridge/resource_bridge.h`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `build.zig`
- `tools/zig/fixtures/resource_editor/3rd/golden/README.md`
- `tools/zig/fixtures/resource_editor/3rv/golden/README.md`

## Verification

zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model -Dtest-mode=run && zig build test-resource-model-comparator -Dtest-mode=run && zig build test-resource-core -Dtest-mode=run

## Observability Impact

Shipped scan prints VSO checked/files/unimportable with offender paths; GOLDEN 3rd/3rv pending lines.
