---
id: T09
parent: S13
milestone: M001
key_files:
  - Sources/editor/resource_app/terrain_logic.zig
  - Sources/editor/resource_app/docks.zig
  - Sources/editor/resource_app/docks_logic.zig
  - Sources/editor/resource_app/panels_logic.zig
  - Sources/editor/resource_core/sub_editor_tools.zig
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-06T01:05:02.016Z
blocker_discovered: false
---

# T09: Terrain (.til) thumbnail lists with crosset mode from tree selection, double-click add and Import terrains/crossets, plus Wireframe toggle for 3rd/3rv and a road that shows without playing.

**Terrain (.til) thumbnail lists with crosset mode from tree selection, double-click add and Import terrains/crossets, plus Wireframe toggle for 3rd/3rv and a road that shows without playing.**

## What Happened

Added Sources/editor/resource_app/terrain_logic.zig (wired into test-resource-app-logic through panels_logic.zig): modeFor derives terrains vs crossets from the selected tree item as TileTreeItem.cpp's SwitchToEditCrossetsMode does; listFolder points the all-tiles list at the project's terrains or crossets folder; addTarget resolves the item a double-click adds to; addTile calls BkResTileSetAddTile and records an insert_node step so it undoes; importFile calls BkResTileSetImport. docks.zig: for a .til the Thumbnails window opens itself once, shows the mode's folder and a second list of the active item's tiles (names), double-click adds the tile, and the Preview menu has Import terrains... / Import crossets... (file dialog). A Wireframe check sits in the View and Preview menus, enabled for a begun 3rd/3rv preview, reset when the scene changes. docks_logic PreviewSync.run no longer starts playback for a road (a still scene); the river plays and Stop works. The til preview refusal is shown once (PreviewSync asks once per kind). Added tileset/crosset item_type constants to sub_editor_tools.zig. The ID_EDIT_CROSSETS button is not added (no MFC handler; recorded in T10).

## Verification

Ran the Verify chain in the foreground: app-logic tests (152 pass), test-resource-core, install-resource-editor, resource-editor-smoke, resource-editor-host-check, all exit 0. Also ran ResourceEditor --hidden on copies of the til, 3rd and 3rv fixtures: all three PASS (30 frames). Full sweep left to the maintainer. The ImGui windows were not driven by pointer here, so the new menus and lists are covered by the pure-logic tests and the hidden-run smoke only.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-app-logic -Dtest-mode=run` | 0 | pass | 3000ms |
| 2 | `zig build test-resource-core -Dtest-mode=run` | 0 | pass | 2000ms |
| 3 | `zig build install-resource-editor` | 0 | pass | 60000ms |
| 4 | `zig build resource-editor-smoke` | 0 | pass | 5600ms |
| 5 | `zig build resource-editor-host-check` | 0 | pass | 5700ms |

## Deviations

Import terrains/crossets replaces the whole tree, which no single history command can undo, so importFile clears the undo history, reloads, and marks the project unsaved instead of recording one undo step. The selected-item list shows tile names, not pictures. One list widget serves both modes, so it rescans when the mode flips instead of loading each folder once. The Wireframe and import controls are menu items (View/Preview) because the app has no toolbar.

## Known Issues

None known beyond the deviations above.

## Files Created/Modified

- `Sources/editor/resource_app/terrain_logic.zig`
- `Sources/editor/resource_app/docks.zig`
- `Sources/editor/resource_app/docks_logic.zig`
- `Sources/editor/resource_app/panels_logic.zig`
- `Sources/editor/resource_core/sub_editor_tools.zig`
