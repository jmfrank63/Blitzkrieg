---
id: T05
parent: S13
milestone: M001
key_files:
  - Sources/src/ResourceModel/items/road3d/road3d_export.cpp
  - Sources/src/ResourceModel/items/river3d/river3d_export.cpp
  - Sources/src/EditorBridge/resource_bridge.cpp
  - Sources/src/EditorBridge/resource_bridge_test.cpp
  - Sources/src/ResourceModel/comparator.cpp
  - build.zig
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-05T23:58:07.687Z
blocker_discovered: false
---

# T05: 3D Road (.3rd) and 3D River (.3rv) exporters and importers through the engine's SVectorStripeObjectDesc, with a shipped round trip over 40 road and river files (VSO checked=40 files=40 unimportable=0).

**3D Road (.3rd) and 3D River (.3rv) exporters and importers through the engine's SVectorStripeObjectDesc, with a shipped round trip over 40 road and river files (VSO checked=40 files=40 unimportable=0).**

## What Happened

Added ExportRoad3D/ExportRiver3D and Road3DStatsToTree/River3DStatsToTree (items/road3d and items/river3d *_export.{h,cpp}), ported from C3DRoadFrame/C3DRiverFrame FillRPGStats and GetRPGStats, writing the VSODescription chunk through the engine's operator& via NStatsExport::WriteStats. Registered both in exporter.cpp, declared in stats_export.h, added to build.zig. BkResImportFromGame now accepts kinds 14/15; the path is the runtime <name>.xml itself (documented in resource_bridge.h). Import refuses a file with no VSODescription (naming the file) and a file whose type is plainly the other kind's; a river with TYPE_UNKNOUN (what MFC's river export writes) imports. Found and fixed a port gotcha: SetItemName sets the default name too, so CreateDefaultChilds erased an imported road's 'Border layer' on reload; the border item now keeps the layer's default name 'Central layer' with display name 'Border layer'. Tests (S13Vso in resource_bridge_test.cpp): both fixtures export, engine reads them back, a second forced export is byte-identical, import->export is field-equal, refusals name the reason, shipped scan over Data/Terrain/sets/*/Roads3D and Rivers prints 'VSO checked=40 files=40 unimportable=0 fields=1570 differences=0 excused=93' and proves Data is untouched; road type/priority/cells are read back directly. The 93 excused differences are MFC's own round-trip losses, listed with reasons in comparator.cpp kRoundTripLosses (river export never sets Type/Priority, writes constant Disturbance/StreamSpeed/RelWidth, layer NumCells = bottom width; road AIClasses rebuilt from four flags; SoilParams absent in older files). Batch export test now expects .3rd/.3rv to export. GOLDEN 3rd/3rv pending lines printed; golden READMEs updated.

## Verification

test-resource-bridge, test-resource-model, test-resource-model-comparator and test-resource-core all exit 0 (fresh runs this session). Full sweep left to the maintainer.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 300000ms |
| 2 | `zig build test-resource-model -Dtest-mode=run` | 0 | pass | 20670ms |
| 3 | `zig build test-resource-model-comparator -Dtest-mode=run` | 0 | pass | 19730ms |
| 4 | `zig build test-resource-core -Dtest-mode=run` | 0 | pass | 640ms |

## Deviations

None.

## Known Issues

MFC's 'Has borders?' toggle (adds/removes the Border layer item on edit) is not ported by this task; import and export handle the border layer. GOLDEN 3rd/3rv remain pending until made on win-home.

## Files Created/Modified

- `Sources/src/ResourceModel/items/road3d/road3d_export.cpp`
- `Sources/src/ResourceModel/items/river3d/river3d_export.cpp`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `Sources/src/ResourceModel/comparator.cpp`
- `build.zig`
