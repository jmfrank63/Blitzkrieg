# S11 Research: Bridge sub-editor (.bdg)

Depth: targeted. The technology is known and S09/S10 (Object, Fence, Building) set the exact pattern. S11 is the same recipe applied to `CBridgeFrame`. The new work is the Bridge-specific export (3 damage states x begin/center/end spans, segments, packs) and the span-marks tool.

## Summary

S11 has to add the following for kind 10 (`bdg`). Status today is in brackets.

- **Model tree** [DONE in S03]: `Sources/src/ResourceModel/items/bridge/bridge.{h,cpp}` has every MFC class from `BridgeTreeItem.h`: Root, CommonProps, Defences/DefenceProps, StageProps, Begin/Center/End Spans, Parts/PartProps, FirePoints/FirePointProps, DirExplosions/DirExplosionProps, Smokes/SmokeProps. The root is registered as `Bridge_Composer_Project` in `resource_bridge.cpp:111`. Parts items already hold `lockedTiles` and `unLockedTiles` (`bridge.h:103-105`).
- **Fixture** [partly there]: `tools/zig/fixtures/resource_editor/bdg/` has `project.bdg`, a single `art-16x16.tga` and `golden/README.md`. The golden folder is pending win-home. The fixture almost certainly needs the S10 treatment: generated art for every sprite and shadow (`<n>.tga` plus `<n>s.tga`) that the project references. Check what `project.bdg` references first. `tools/zig/resource_editor_fixtures.zig` has a `bld` generator to copy (~30 lines added in S10 T03). It has no bdg generator yet.
- **Bridge channel 10** `CHANNEL_BRIDGE_SPAN_MARKS` [DONE in the C++ bridge]: `resource_bridge.cpp:253, 826, 1066, 1158, 2712` read and write the frame own_data `Begin`/`End`/`Front`/`Back`. It is a points2 list of exactly 3 points, `(Begin, End, (Front, Back))`, root only, HOME_FRAME. `resource_core/bridge.zig:291` already has `.bridge_span_marks` as points2. The Zig tools and app do not use it yet.
- **Exporter / importer** [MISSING]: `kBuildingKind = 9` is wired at `resource_bridge.cpp:4933`, in `bPorted` at 5711 and in the load switch at 5813. Kind 10 is not. The `bridge` enum value exists in `resource_core/bridge.zig:55`.
- **Zig tools and app** [MISSING]: `grid_logic.zig` registers only `.build`, obt and fnc (`building_tools` at line 367). `point_tools.zig` header says it is kind-agnostic "so the bridge editor (S11) reuses them for its fire and smoke". No `.bridge` registration or toolbar exists. Nothing yet in `scenario.zig` or `build.zig` for bdg (the build.zig auto scenario block is at about 8652 for bld).
- **PARITY**: B-12.1 to B-12.6 are all `todo` (`06-PARITY.md:219-228`).

## MFC behaviour to port (`Sources/src/editor/BridgeFrm.cpp`, 2592 lines, plus BridgeFire.cpp 462, BridgeSmoke.cpp 469, BridgeTreeItem.cpp 687)

- **`ExportFrameData` (652-1037)**
  - Builds `SBridgeRPGStats` (`Sources/src/Main/RPGStats.h:1300`). Direction is HORIZONTAL or VERTICAL. `fMaxHP` and `fRepairCost` come from CommonProps.
  - AI classes: `AI_CLASS_HUMAN`, `_WHEEL`, `_HALFTRACK` and `_TRACK` come from the four passability flags.
  - Loops `nActiveDamage` 0..2 (three damage stages), then `i` 0..2 (begin, center, end spans, with `vBeginPos`/`vCenterPosition`/end as the parent position `vPapa`).
  - Per stage it creates a sprite pack and a shadow pack, named `"%d"` (1, 2, 3).
  - Calls `SaveSegmentInformation` (2416) for passability (CArray2D<BYTE>), origin, `vRelPos`, `szModel` and `nFrameIndex`.
  - `AddSpriteAndShadow` (1286) loads the part's `<name>.tga` and `<name>s.tga`. It refuses a size mismatch between sprite and shadow, and with a missing file shows an error and skips. Port this as a refusal, as S10 did for "missing-picture".
  - `ComputeSpriteNewZeroPos` gives the pack centre.
  - Outputs: stats XML (`<n>.xml`, root desc), per-stage `_c.dds`, `_h.dds`, `_l.dds` and `.san`, and `icon.tga`.
  - Shipped layout seen in `Data/Bridges/woodenlittle/01`: `1.xml`, `1_c.dds`, `1_h.dds`, `1_l.dds`, `1.san`, `2_*`, `3_*` and `icon.tga`.
- **`FillRPGStats` (1038)**
  - Defences: six DefenceProps items (Left, Right, Top, Bottom, Front, Back) are mapped by name to the RPG_* index. Each writes `nArmorMin`, `nArmorMax` and `fSilhouette`.
  - It also fills fire points, smokes and directed explosions, the same `SSlot` / effect structures as the building. Reuse the S10 point code: BuildingStatsToTree and FillRPGStats share helpers in `building_export.cpp`.
- **`GetRPGStats` (1149) / `LoadRPGStats` (553)**: this is the importer path (the tree built from stats). The `LoadFrameOwnData` / `SaveFrameOwnData` (515-552) chunks hold Begin, End, Front and Back.
- **Tools**
  - Grid and passability: `OnDrawGrid`, `OnDrawPass`, `OnChangeTranseparence`, `OnSetZeroButton`, `SetZeroCoordinate`. Locked tiles are per Parts item (`lockedTiles`, HOME_TILE_LIST at `resource_bridge.cpp:805`), the same shape as the fence.
  - Point modes (`SetActiveMode` 2069): `OnSetFirePoint`, `OnSetSmokePoint`, `OnMovePoint`, `OnSetHorizontalShoot`, `OnSetShootAngle`, `OnGeneratePoints`. These match building's `fire`, `smoke`, `move_point`, `horizontal`, `angle`.
  - Span marks: in `OnLButtonDown` (1736) Begin, End, Front and Back are placed or moved via mouse. `SetBridgeType( bHorizontal )` (180) rotates the layout. `CreateKrest` (225) is the cross marker.
  - `GFXDraw` (258-427) shows the overlay: locked tiles, span marks, points.
- `Sources/src/editor/BridgeFire.cpp` and `BridgeSmoke.cpp` are the fire/smoke point item classes and probably already ported with the tree. Verify before duplicating.

## Natural seams (suggested tasks; mirror S10 T01-T06)

1. **Model and fixture art.** Confirm the bdg tree round trip passes today (`test-resource-model`). Add a bdg generator in `tools/zig/resource_editor_fixtures.zig` plus the generated TGAs in `tools/zig/fixtures/resource_editor/bdg/`. Check what `project.bdg` references and how many stages, spans and parts it has. The fixture may need extending to have all 3 stages x 3 span types, one part each. Update `golden/README.md` if the art changes.
2. **C++ exporter + importer**, the highest risk and the first proof. Add `items/bridge/bridge_export.{h,cpp}` with `ExportBridge`, `BridgeStatsToTree`, `WriteBridgeFrameData`, modelled on `items/building/building_export.cpp` (767 lines). Wire kind 10 into `resource_bridge.cpp` in three places (`bPorted`, load switch, own_data write), add to `build.zig` source lists (S10 touched one line) and add the preview kind. Tests in `resource_bridge_test.cpp`: export, determinism, missing-picture refusal, sprite/shadow size mismatch, import round trip.
3. **Shipped bridge round trip.** Import every `Data/Bridges/*/*` (about 10 folders: asphaltbridge, asphaltbridge_special, railwaybridge_little, woodenbig_heavy, woodenlittle and their `w_` variants) and compare field-equal against the original stats through the engine's reader. Watch for the D021 negative-tile guard that S10 added to building (a part with tiles left of or above (0,0)). Check whether it applies to bridge segments.
4. **Zig: registration of the `.bridge` grid editor in `grid_logic.zig`.** Tools: move, draw_grid, draw_transparency, set_zero, fire, smoke, move_point, horizontal, angle, plus a new `span_marks` tool (Begin, End, Front, Back, using `.bridge_span_marks` through `point_tools`/`grid_tools`). Each tool is undoable with before/after geometry. Add tests in `grid_logic.zig` and `sub_editor_tools.zig` (the building Rig pattern, `Rig.building` at line 764, gives a `Rig.bridge` template). The passability list is HOME_TILE_LIST on the active Parts item, not a frame grid. Check how fence's `fence_transparences` / tile-list code in `grid_tools.zig` handles it. Note the bridge has `SetBridgeType( bHorizontal )`, so the span marks and tile layout depend on the Direction property.
5. **App wiring and overlays.** Add the toolbar in `panels.zig`, the overlay for span marks, points and locked tiles, and the preview wiring.
6. **Auto scenario and docs.** `BK_EDITOR_AUTO` bdg block in `scenario.zig` and `build.zig` (copy fixture to `{dir}/bdg/`, place span marks, fire and smoke point, undo, export, measured shots as in bld). Update PARITY B-12.1-B-12.6 and the spec channel table. Add `bdg` to `run-resource-sweep.sh` and `export-goldens.ps1 -Extensions` as S10 did, with golden pending win-home. Verify the PARITY entry B-12.3 `Begin/End/Front/Back` is evidenced by an undoable shot.

Seams 2 and 4 can run in parallel after 1: C++ and Zig are independent until 5 because the fake bridge covers the Zig tests.

## Risks and watch-outs

- **Export is the biggest unknown.** `ExportFrameData` is about 400 lines of pack, segment and index logic (`GetFreeBridgeIndex`, `RemoveBridgeIndex`, `nPackSegmentIndex`) tied to MFC sprite loading (`pProps->pSprite`, `ComputeSpriteNewZeroPos`). Find how `building_export.cpp` and the fence export replaced the sprite loader (via `ResourceModel/compose.h` and `image_export`) and reuse it. Do not re-derive.
- **Segment, span and state indexing is easy to get wrong.** Test each span count against shipped bridges, not only the fixture.
- **Goldens.** MFC goldens for bdg are pending win-home (like S09/S10). Record "GOLDEN bdg pending" and do not claim parity. No GOG golden is listed for S11 in the roadmap.
- **Span marks channel contract.** It needs exactly 3 points. A stale (Front, Back) must round trip because they are written as floats via `MfcFloat`. The z component and export name stay as read (`resource_bridge.cpp:1158`).
- **Spec table:** S09 and S10 each updated the spec channel table. Do the same.
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md` and `06-PARITY.md` must be updated when rows change.
- Per `AGENTS.md`: keep CRLF in new files, run tiers in the foreground (each under 10 minutes), do not run the full sweep (left to the maintainer), do not claim macOS or Windows results, and commit with `feat(resource-editor): ...` style. Never commit GOG files.

## Verification (runnable commands, `&&` joined, per the AGENTS rule)

- Per-task: `zig build test-resource-model -Dtest-mode=run`, `zig build test-resource-model-comparator -Dtest-mode=run`, `zig build test-resource-bridge -Dtest-mode=run`, `zig build test-resource-core -Dtest-mode=run`, `zig build test-resource-app-logic -Dtest-mode=run`, `zig build test-editor-core -Dtest-mode=run`.
- Slice close: `zig build install-resource-editor && zig build resource-editor-auto && zig build resource-editor-smoke && zig build resource-editor-host-check && zig build map-editor-smoke`. The GUI tiers fail under the gsd_exec sandbox ("No available video device"), so run them from the shell and not in the sandbox (S05 note).

## Sources / skills

No new libraries. No skill search needed. The relevant local material is the S10 plan (`.gsd/milestones/M001/slices/S10/S10-PLAN.md`) as the task template, the S10 commits `20454f003` (exporter) and `0cd85b8fb`/`ff8655237` (Zig tools and auto) as the code template, and MEM005, which says to re-derive extensions from the frame sources.
