---
id: T05
parent: S11
milestone: M001
key_files:
  - Sources/editor/resource_app/scenario.zig
  - build.zig
  - Sources/editor/resource_core/point_tools.zig
  - .planning/phases/06-resource-editor-portable-port/06-PARITY.md
  - docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md
key_decisions:
  - Undo of the first span-mark edit restores the frame's default marks, because the bridge channel refuses empty writes
  - Auto-scenario marks and tiles are chosen inside the visible part of the grid view; fire is measured while active, smoke by differ
duration: 
verification_result: passed
completed_at: 2026-10-05T20:17:39.943Z
blocker_discovered: false
---

# T05: resource-editor-auto gains a measured bdg block (span marks, locked tiles, fire/smoke points, undo/redo, export), a span_mark verb, and a fix so the first span-mark edit undoes; PARITY B-12 and the spec are updated.

**resource-editor-auto gains a measured bdg block (span marks, locked tiles, fire/smoke points, undo/redo, export), a span_mark verb, and a fix so the first span-mark edit undoes; PARITY B-12 and the spec are updated.**

## What Happened

Reviewed the interrupted scenario.zig (span_mark do/expect verbs) and build.zig (bdg block) work and continued it. The first auto run showed the cyan crosses vanishing: the grid view only shows grid x from about -620 to 0 and the Grid tools window covers the top, so tiles like 28/28 and the moved marks were off-screen. I moved the scenario to tiles near 10/10 for locked tiles and fire/smoke points, and to tiles 17/17, 20/17, 18/19, 18/15 for the marks so that Begin/End sit on the red line right of the tools window. The fire point is measured in its own shot (bdg_fire) while active, because inactive points are drawn at 120/255 alpha; the smoke point is checked by a differ against bdg_fire, since its c0c0c0 colour equals the grid lines. The run exposed a real bug: undoing the first span-mark edit failed with 'bridge span marks are Begin, End and (Front, Back): three points', because with nothing stored the command's before value was an empty list and the channel refuses empty writes. setSpanMark in point_tools.zig now makes before the frame defaults when nothing is stored; the matching test now expects the defaults after undo (and its leak is fixed). Thresholds were tightened to measured values (red 263 base, 629 with two locked tiles; cyan 179 base, 377 with marks moved; fire 51, 0 after undo) and export checks for data/bridges/bdg/1.xml and 1_c.dds were added. 06-PARITY.md B-12.1..B-12.6 now carry evidence (golden pending win-home; Draw pass and transparency dropdown not ported, per the T04 decision), and the spec channel table records the bridge homes and the undo-to-defaults rule.

## Verification

All 11 verify commands were run in the foreground from the shell and exited 0. resource-editor-auto prints the measured colour counts against thresholds for bdg_base, bdg_tiles, bdg_marks, bdg_fire, bdg_undone. Not claimed: macOS and Windows results, the golden (pending win-home) and the full resource sweep (left to the maintainer).

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build install-resource-editor` | 0 | pass | 4000ms |
| 2 | `zig build resource-editor-auto` | 0 | pass | 295000ms |
| 3 | `zig build resource-editor-smoke` | 0 | pass | 6000ms |
| 4 | `zig build resource-editor-host-check` | 0 | pass | 6000ms |
| 5 | `zig build test-resource-app-logic -Dtest-mode=run` | 0 | pass | 2000ms |
| 6 | `zig build test-resource-core -Dtest-mode=run` | 0 | pass | 1000ms |
| 7 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 48000ms |
| 8 | `zig build test-resource-model -Dtest-mode=run` | 0 | pass | 21000ms |
| 9 | `zig build test-resource-model-comparator -Dtest-mode=run` | 0 | pass | 20000ms |
| 10 | `zig build test-editor-core -Dtest-mode=run` | 0 | pass | 1000ms |
| 11 | `zig build map-editor-smoke` | 0 | pass | 13000ms |

## Deviations

The plan says T07 (D023, the 12 europe/summer buildings) must be complete before T05 finishes. T07 is still open in the slice plan, so the test-resource-bridge run here still uses the building allow-list. The T05 deliverables themselves are complete.

## Known Issues

T07 is still pending, so the 12 allow-listed europe/summer buildings still do not import; test-resource-bridge should be re-run after T07. Golden for bdg is pending win-home. Full resource sweep is left to the maintainer. No macOS or Windows result was seen.

## Files Created/Modified

- `Sources/editor/resource_app/scenario.zig`
- `build.zig`
- `Sources/editor/resource_core/point_tools.zig`
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`
