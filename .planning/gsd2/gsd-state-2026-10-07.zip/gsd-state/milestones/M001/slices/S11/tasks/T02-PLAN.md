---
estimated_steps: 3
estimated_files: 5
skills_used: []
---

# T02: Every shipped Data/Bridges folder (21) now round-trips field-equal through import and stats-only export; strict BRIDGES and NEGTILES scans added.

Why: the slice demo needs an import round trip on shipped data, and segment/span/state indexing is easy to get wrong, so every shipped bridge is the test, not only the fixture.
Do: in resource_bridge_test.cpp, copy every Data/Bridges/*/* folder (asphaltbridge, asphaltbridge_special, railwaybridge_little, woodenbig_heavy, woodenlittle and the w_ variants, each with numbered subfolders) read-only to zig-out/local-test, import each to a tree, export stats-only and compare field-equal through the comparator/engine reader. Print 'BRIDGES checked=N' and assert N equals the folder count found. Resolve Data paths case-insensitively (DataFile helper). Scan bridge part passability for tiles left of or above (0,0) as S10 did for buildings (D021) and print 'NEGTILES bridges checked=N negative=M' with offender paths; if M>0, handle the origin as S10 did and add a round-trip test on such a bridge, else record N in the spec. Confirm tools/zig/win-home/export-goldens.ps1 already lists bdg and document the bdg golden step in bdg/golden/README.md.
Done when: every shipped bridge round-trips with 0 field differences and nothing is written into Data/.

## Inputs

- `Sources/src/ResourceModel/items/bridge/bridge_export.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `tools/zig/win-home/export-goldens.ps1`
- `Data/Bridges/woodenlittle/01/1.xml`

## Expected Output

- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `tools/zig/fixtures/resource_editor/bdg/golden/README.md`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`

## Verification

zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model-comparator -Dtest-mode=run

## Observability Impact

BRIDGES and NEGTILES lines with offender paths; comparator names the differing field.
