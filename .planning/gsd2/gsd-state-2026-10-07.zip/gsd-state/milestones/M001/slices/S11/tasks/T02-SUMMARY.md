---
id: T02
parent: S11
milestone: M001
key_files:
  - Sources/src/EditorBridge/resource_bridge_test.cpp
  - Sources/src/EditorBridge/resource_bridge.cpp
  - Sources/src/ResourceModel/items/bridge/bridge_export.cpp
  - Sources/src/ResourceModel/items/bridge/bridge_export.h
  - docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-05T18:59:55.673Z
blocker_discovered: false
---

# T02: Every shipped Data/Bridges folder (21) now round-trips field-equal through import and stats-only export; strict BRIDGES and NEGTILES scans added.

**Every shipped Data/Bridges folder (21) now round-trips field-equal through import and stats-only export; strict BRIDGES and NEGTILES scans added.**

## What Happened

Added S11Bridge::Shipped and NegativeTiles to resource_bridge_test.cpp. Shipped imports each of the 21 Data/Bridges folders, exports stats only and compares against the shipped 1.xml through the comparator, then checks that nothing was written into Data. NegativeTiles reads every part's passability (226 parts) strictly (D022): checked must equal folders found and any other failure fails. The first run showed 1356 differences, all in Segments/*/Origin: a stats file keeps a grid origin but not the span marks it came from, so the importer's default marks gave different origins. Fix: BridgeStatsToTree/WriteBridgeFrameData now recover the Begin, Center and End marks from the first slab origin of each kind (MarkOfOrigin), WriteBridgeFrameData takes a GridProjection, own_data gets a Center mark that the exporter reads, and the test allows 1e-3 on Origin fields (float cancellation of ~700-size positions). bdg golden README already documents the golden step and export-goldens.ps1 already lists bdg. Recorded NEGTILES bridges checked=21 negative=0 in the spec.

## Verification

test-resource-bridge, test-resource-model-comparator and test-resource-model all pass. BRIDGES checked=21 folders=21 failed=0 fields=19083 differences=0; NEGTILES bridges checked=21 negative=0 failed=0 parts=226; GOLDEN bdg pending: golden missing (win-home). Full sweep left to the maintainer.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 120000ms |
| 2 | `zig build test-resource-model-comparator -Dtest-mode=run` | 0 | pass | 30000ms |
| 3 | `zig build test-resource-model -Dtest-mode=run` | 0 | pass | 30000ms |

## Deviations

Importer now recovers span marks and writes an own_data Center element (not in the MFC project format); Origin comparison uses a 1e-3 tolerance.

## Known Issues

bdg golden still pending win-home. The own_data Center element has not been checked against the MFC loader.

## Files Created/Modified

- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/ResourceModel/items/bridge/bridge_export.cpp`
- `Sources/src/ResourceModel/items/bridge/bridge_export.h`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`
