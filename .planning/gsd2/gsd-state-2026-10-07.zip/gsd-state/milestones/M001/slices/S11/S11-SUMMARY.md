---
id: S11
parent: M001
milestone: M001
provides:
  - (none)
requires:
  []
affects:
  []
key_files: []
key_decisions: []
patterns_established:
  - (none)
observability_surfaces:
  - none
drill_down_paths:
  []
duration: ""
verification_result: passed
completed_at: 2026-10-05T20:31:21.559Z
blocker_discovered: false
---

# S11: S11

**Bridge (.bdg) sub-editor: ported exporter/importer, undoable span marks, fire/smoke/dir-explosion points and part passability, .bridge grid editor in the app, measured auto scenario.**

## What Happened

T01 ported the Bridge exporter and importer (kind 10) with fixture art; T02 round-tripped all 21 shipped Data/Bridges folders field-equal with strict BRIDGES and NEGTILES scans; T03 homed the zero, fire, smoke and directed-explosion channels on the bridge root and added undoable span-mark, point and generate commands in resource_core; T04 registered the .bridge grid editor, toolbar and overlay in the app; T05 added the BK_EDITOR_AUTO bdg block with measured shots, plus the PARITY B-12 rows and the spec; T06 unified the negative-tile scan across objects, buildings and bridges; T07 made the 12 europe/summer buildings the scan had skipped import. The MFC golden for bdg stays pending on win-home and is not claimed.

## Verification

Run fresh on Linux in this unit, all exit 0: test-resource-bridge, test-resource-model, test-resource-model-comparator, test-resource-core, test-resource-app-logic, test-editor-core, install-resource-editor, resource-editor-host-check, resource-editor-smoke, resource-editor-auto (PASS, 585 actions, bdg block included), map-editor-smoke. I did not re-read the BRIDGES/NEGTILES count lines from the bridge test log, because the grep in this unit returned no output. The full resource sweep is left to the maintainer. No macOS or Windows result was seen.

## Requirements Advanced

None.

## Requirements Validated

None.

## New Requirements Surfaced

None.

## Requirements Invalidated or Re-scoped

None.

## Operational Readiness

None.

## Deviations

None.

## Known Limitations

None.

## Follow-ups

None.

## Files Created/Modified

None.
