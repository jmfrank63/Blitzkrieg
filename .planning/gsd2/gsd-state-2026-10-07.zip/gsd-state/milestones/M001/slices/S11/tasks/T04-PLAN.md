---
estimated_steps: 3
estimated_files: 3
skills_used: []
---

# T04: The app registers the .bridge grid editor: Draw grid paints the active span part's locked tiles, plus Set zero, a new Span marks tool (Begin/End/Front/Back), fire/smoke/directed-explosion points with move/horizontal/angle and Generate points. The overlay draws the red bridge line, labelled cyan span-mark crosses, the points with angle and cone handles, and the locked tiles in red.

Why: users edit bridges in the app. MFC CBridgeFrame toolbar: draw grid, passability, transparency dropdown, set zero, fire/smoke point, move point, horizontal, angle, generate points (SetActiveMode 2069), and span marks via OnLButtonDown (1736) with the cross marker (CreateKrest 225) drawn in GFXDraw (258-427).
Do: in Sources/editor/resource_app/grid_logic.zig add bridge_tools and registrationFor(.bridge) (next to building_tools at ~367) including a new span_marks tool, targetNode for the bridge root and the active Parts item for passability; app-logic tests for registration, target node and tool dispatch. In panels.zig add the bridge toolbar and overlay (span marks as crosses with labels, points with angle/cone handles reused from bld, locked tiles red). Wire bdg preview in main.zig as bld is wired.
Done when: verify exits 0 and opening the bdg fixture in resource-editor-smoke does not regress.

## Inputs

- `Sources/editor/resource_app/grid_logic.zig`
- `Sources/editor/resource_app/panels.zig`
- `Sources/editor/resource_app/main.zig`
- `Sources/editor/resource_core/point_tools.zig`
- `Sources/src/editor/BridgeFrm.cpp`

## Expected Output

- `Sources/editor/resource_app/grid_logic.zig`
- `Sources/editor/resource_app/panels.zig`
- `Sources/editor/resource_app/main.zig`

## Verification

zig build test-resource-app-logic -Dtest-mode=run && zig build test-resource-core -Dtest-mode=run && zig build install-resource-editor && zig build resource-editor-smoke
