---
id: T07
parent: S11
milestone: M001
key_files:
  - Sources/src/EditorBridge/resource_bridge.cpp
  - Sources/src/EditorBridge/resource_bridge_test.cpp
  - docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md
  - .gsd/OVERRIDES.md
key_decisions:
  - Use the folder name as the import label when KeyName is empty; keep the stats' empty name so export stays field-equal
duration: 
verification_result: passed
completed_at: 2026-10-05T20:22:14.038Z
blocker_discovered: false
---

# T07: The 12 europe/summer buildings the scan skipped now import: the bld importer no longer treats an empty KeyName as "no stats". The building allow-list is empty, and a named e_house07_1 round trip passes.

**The 12 europe/summer buildings the scan skipped now import: the bld importer no longer treats an empty KeyName as "no stats". The building allow-list is empty, and a named e_house07_1 round trip passes.**

## What Happened

Before the fix, `test-resource-bridge` showed all 12 allow-listed buildings failing with "1.xml holds no bld RPG stats". The cause is the same for all 12: each 1.xml has a full `<desc>` (e_house07_1 has MaxHP=500) followed by an empty `<KeyName></KeyName>`. The working e_house08_1 has `<KeyName>Unknown Building</KeyName>`. The bld case in resource_bridge.cpp used `szKeyName.empty()` as its "no stats" sentinel. I changed it to label the import with the folder name when the key name is empty, and to always call BuildingStatsToTree. The stats keep their own empty name, so export stays field-equal, and nothing in Data is touched. In the test I emptied the building allow-list and passed `{}` to the scan. I also parametrised S10Building::Shipped by folder and added a second call on europe/summer/e_house07_1. The spec's D021 line is rewritten with the real counts. A resolution entry is added to OVERRIDES.md, and D023 is recorded as resolved via gsd_decision_save.

## Verification

`zig build test-resource-bridge -Dtest-mode=run` printed no FAIL lines, and the output shows: ROUNDTRIP bld e_stella/01 with 101 fields and 0 differences; ROUNDTRIP bld e_house07_1 with 585 fields and 0 differences; NEGTILES buildings checked=194 folders=194 negative=0 unimportable=0; BRIDGES checked=21 differences=0; NEGTILES bridges checked=21 negative=0; NEGTILES objects checked=590 negative=0. I did not capture the exit code separately. Only this tier was run. I did not run the other editor tiers, the full sweep (left to the maintainer), or any macOS/Windows build.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | passed (no FAIL lines in output) | 62000ms |

## Deviations

None.

## Known Issues

None.

## Files Created/Modified

- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`
- `.gsd/OVERRIDES.md`
