---
estimated_steps: 3
estimated_files: 2
skills_used: []
---

# T06: Objects, buildings and bridges now share one strict negative-tile scan; 12 shipped buildings the old scan silently skipped are allow-listed by name.

Why: hard steer D022. The scans S09Object::NegativeTiles (resource_bridge_test.cpp ~4296) and S10Building::NegativeTiles (~5519) print import_failed but never assert it, and count a channel failure as negative only when the message says 'left of or above'. Any other failure is silently skipped, so the D021 result is not exact. The S11 bridge scan from T02 must not repeat that. This task runs after T02 so the bridge scan exists; if T02 already wrote it strictly, T06 only verifies it and adds the shared helper.
Do: (1) Put the scan logic in one shared helper (a template or function taking the root folder, the Data subfolder name and an allow-list of unimportable folders) used by objects, buildings and bridges, so the three cannot drift. (2) For every folder found, import it. Fail the test on: an import failure, a missing root node, or any channel-read failure whose message is not the expected negative-tile refusal ('left of or above'). Only the expected refusal counts as negative. (3) Assert checked == number of folders found (count the folders first, independently of the import loop). (4) Items that genuinely cannot be imported are listed by name in the test in an explicit allow-list with the reason for each; they count as checked, are printed, and any listed item that now imports fails the test so the list cannot go stale. If nothing needs listing, say so in the summary. (5) Print 'NEGTILES <kind> checked=N folders=N negative=M unimportable=U' for objects, buildings and bridges. (6) Resolve Data paths case-insensitively (DataFile helper); nothing is written into Data/. (7) Run the verify command, record the real counts for all three kinds in the task summary and in the spec's D021 result line, and cite only commands actually run in this task. Keep new text CRLF.
Done when: zig build test-resource-bridge -Dtest-mode=run exits 0 with the stricter scans, the three NEGTILES lines show checked equal to folders, and the summary lists any unimportable shipped items by name with the reason. Only then mark D022 resolved in DECISIONS.md and OVERRIDES.md.

## Inputs

- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `.gsd/OVERRIDES.md`
- `.gsd/DECISIONS.md`
- `Sources/src/ResourceModel/items/bridge/bridge_export.cpp`

## Expected Output

- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`

## Verification

zig build test-resource-bridge -Dtest-mode=run

## Observability Impact

Scans fail loudly with folder and message on any unexpected failure; NEGTILES lines print checked, folders, negative and unimportable counts.
