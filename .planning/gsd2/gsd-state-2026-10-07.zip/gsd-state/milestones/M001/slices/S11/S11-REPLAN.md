# S11 Replan

**Milestone:** M001
**Slice:** S11
**Blocker Task:** T06
**Created:** 2026-10-05T19:22:28.983Z

## Blocker Description

Hard steer 2026-10-05T19:20 (D023): T06 allow-listed 12 shipped europe/summer buildings (e_ctownhouse01_1 ... e_townrailwaystation_4) as 'the shipped 1.xml holds no bld RPG stats (history only)'. That reason is false: e.g. Data/Buildings/europe/summer/e_house07_1/1.xml has a full <desc MaxHP="500" ...> after its <History> block, and e_house08_1 has the same History-then-desc layout and imports fine. These are real shipped buildings the Resource Editor must import (D-04/D-07).

## What Changed

Corrected decision IDs: the hard steer is D023 (DB-assigned); the T06 resolution of D022 is D024. T07 (fix the building importer for the 12 allow-listed europe/summer buildings, shrink the allow-list, named round-trip test) runs before T05 finishes; T05 must not complete until T07 is complete.
