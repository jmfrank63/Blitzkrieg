---
estimated_steps: 3
estimated_files: 8
skills_used: []
---

# T01: Ported the Bridge exporter and importer (kind 10) with 54-picture fixture art and bridge export/import tests

Why: B-12.5 and B-12.6; kind 10 answers 'not ported yet' today (resource_bridge.cpp: kBuildingKind=9 at ~4933, bPorted ~5711, load switch ~5813). This is the highest-risk piece and the first proof.
Do: (1) Read tools/zig/fixtures/resource_editor/bdg/project.bdg: it has Begin/Center/End spans x3 stages (Whole/Damaged/Destroyed), 'Span parts' and 3 'Picture' values. Extend the fixture only as needed so every stage has a begin, center and end span with a part (Slab/Back girder/Front girder) referencing generated art; add a bdg generator in tools/zig/resource_editor_fixtures.zig copied from the bld generator (S10 T03) emitting <n>.tga and <n>s.tga of equal size; update bdg/golden/README.md. (2) Add Sources/src/ResourceModel/items/bridge/bridge_export.{h,cpp} with ExportBridge, FillBridgeRPGStats and BridgeStatsToTree, ported from BridgeFrm.cpp ExportFrameData (652-1037), FillRPGStats (1038), SaveSegmentInformation (2416), AddSpriteAndShadow (1286), GetRPGStats/LoadRPGStats (1149/553). Reuse building_export.cpp's pack, compose, image_export and point (SSlot/effect) helpers; do not re-derive the sprite loader. Direction HORIZONTAL/VERTICAL from 'Bridge type', AI classes from the four passability flags, defences mapped by name to RPG_* indices. Missing picture and sprite/shadow size mismatch are refusals naming the file. (3) Wire kind 10 (kBridgeKind) into resource_bridge.cpp bPorted, the load/import switch and the preview kind; add bridge_export.cpp to build.zig's ResourceModel source list next to building_export.cpp (~4134). (4) Tests in Sources/src/EditorBridge/resource_bridge_test.cpp: fixture export writes 1..3 {.xml,_c.dds,_h.dds,_l.dds,.san} + icon.tga, second forced export byte-identical, import->export->import field-equal, missing-picture and size-mismatch refusals, 'GOLDEN bdg pending' line. Keep new files CRLF.
Done when: the verify tiers exit 0 and the bdg export/import tests pass.

## Inputs

- `Sources/src/editor/BridgeFrm.cpp`
- `Sources/src/editor/BridgeTreeItem.cpp`
- `Sources/src/ResourceModel/items/bridge/bridge.h`
- `Sources/src/ResourceModel/items/bridge/bridge.cpp`
- `Sources/src/ResourceModel/items/building/building_export.cpp`
- `Sources/src/ResourceModel/items/building/building_export.h`
- `Sources/src/Main/RPGStats.h`
- `tools/zig/fixtures/resource_editor/bdg/project.bdg`
- `Data/Bridges/woodenlittle/01/1.xml`

## Expected Output

- `Sources/src/ResourceModel/items/bridge/bridge_export.h`
- `Sources/src/ResourceModel/items/bridge/bridge_export.cpp`
- `tools/zig/resource_editor_fixtures.zig`
- `tools/zig/fixtures/resource_editor/bdg/project.bdg`
- `tools/zig/fixtures/resource_editor/bdg/golden/README.md`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `build.zig`

## Verification

zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model -Dtest-mode=run && zig build test-resource-model-comparator -Dtest-mode=run && zig build test-resource-core -Dtest-mode=run

## Observability Impact

Export refusals name the missing or mismatched file; GOLDEN bdg pending line.
