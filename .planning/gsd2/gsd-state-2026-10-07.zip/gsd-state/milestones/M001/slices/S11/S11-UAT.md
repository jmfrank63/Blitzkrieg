# S11: S11 — UAT

**Milestone:** M001
**Written:** 2026-10-05T20:31:21.560Z

# S11 UAT

**UAT Type:** automated tiers on Linux x64, plus an optional hand check.

## Preconditions
- `zig build install-resource-editor` has been run.

## Steps
1. Run `zig build test-resource-bridge -Dtest-mode=run`. Expected: exit 0, the bdg fixture exports, and every shipped Data/Bridges folder round-trips field-equal.
2. Run `zig build test-resource-core -Dtest-mode=run`. Expected: span-mark, point and passability commands pass their before, after, undo and redo assertions.
3. Run `zig build resource-editor-auto`. Expected: "auto PASS" and the bdg block's measured shots pass their thresholds.
4. Open the bdg fixture in ResourceEditor, place a span mark and a fire point, then undo. Expected: the overlay changes and then reverts.

## Edge cases
- A missing picture or a sprite/shadow size mismatch is refused with the file named.

## Not Proven By This UAT
- MFC golden equality (pending win-home).
- macOS and Windows results (CI only).
- The full resource sweep (left to the maintainer).
