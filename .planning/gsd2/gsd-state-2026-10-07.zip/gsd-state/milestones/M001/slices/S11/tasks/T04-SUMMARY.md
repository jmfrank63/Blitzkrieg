---
id: T04
parent: S11
milestone: M001
key_files:
  - Sources/editor/resource_app/grid_logic.zig
  - Sources/editor/resource_app/panels.zig
  - Sources/editor/resource_app/main.zig
  - Sources/editor/resource_app/docks_check.zig
  - Sources/editor/resource_app/scenario.zig
  - Sources/editor/resource_core/point_tools.zig
  - Sources/editor/resource_core/sub_editor_tools.zig
  - Sources/editor/resource_core/fake_bridge.zig
key_decisions:
  - Span marks are stored in world units: setSpanMark takes a Frame, as MFC's GetPos3 does. The app passes the default editor camera's gridToWorld. MFC's zeroShift sprite offset is not applied: the crosses are drawn centred on the stored point.
  - The bridge toolbar leaves out Draw pass (unlocked tiles), the transparency combo, Move and shoot points: the C++ bridge homes only the locked tiles on a bridge part, and a bridge has no sprite_pos and no shoot points. Registration.transparency became optional.
  - Span-mark crosses are cyan (0xff00ffff): MFC's krest texture is not in the shipped data. The bridge line is red, as in SetBridgeType.
  - Front/Back are measured from the active part's group: Begin mark, End mark, or the fixed centre cross vCenterKrest (596.657, 742.038).
duration: 
verification_result: passed
completed_at: 2026-10-05T19:17:54.065Z
blocker_discovered: false
---

# T04: The app registers the .bridge grid editor: Draw grid paints the active span part's locked tiles, plus Set zero, a new Span marks tool (Begin/End/Front/Back), fire/smoke/directed-explosion points with move/horizontal/angle and Generate points. The overlay draws the red bridge line, labelled cyan span-mark crosses, the points with angle and cone handles, and the locked tiles in red.

**The app registers the .bridge grid editor: Draw grid paints the active span part's locked tiles, plus Set zero, a new Span marks tool (Begin/End/Front/Back), fire/smoke/directed-explosion points with move/horizontal/angle and Generate points. The overlay draws the red bridge line, labelled cyan span-mark crosses, the points with angle and cone handles, and the locked tiles in red.**

## What Happened

grid_logic.zig: added Tool.span_marks, bridge_tools and registrationFor(.bridge) (passability = locked_tiles, transparency = null; Registration.transparency is now optional). targetNode(.bridge) returns the bridge root. New helpers: activePart (the selected Parts item, the parent of a selected part-props item, else the first part), SpanGroup/spanGroupOf (begin, centre or end spans decide the papa cross), bridgeTypeOf (the common props' 'Bridge type', as GetDirection reads it), spanLine, readSpanMarks (stored or the frame's defaults), spanPapa and spanOffset. In GridEditor: init picks the kind's first tool and first point family, so a bridge never starts in Move or shoot. New fields part/span_mark/bridge_type/span_group, plus gridNode() and setPart(), which cancels a stroke in progress. Draw grid paints gridNode(). documentTarget uses bridgeTarget for bridges, canGenerate covers bridges, and releasing Span marks commits point_tools.setSpanMark. Added six app-logic tests: registration; target node, active part, group and bridge type; part-scoped locked-tile painting with a part switch and undo; fire/smoke placing with tree children, angle drag, fixed explosions and generate from the part's tiles; span marks for both bridge types, Front from the Begin mark, Back from the centre cross, one step each, a repeat records nothing, undo and redo. panels.zig: grid toolbar rows generalised, Generate and Delete point are gated on .fire, and a bridge strip shows the active part, its group and the bridge type, with Begin/End/Front/Back radios under Span marks. The clear buttons and tile layers use gridNode and the optional transparency channel. drawSpanMarks draws the red line and labelled crosses, and drawBuildingPoints now runs for bridges. Supporting changes: point_tools.setSpanMark gains a Frame parameter, so Begin/End/Front/Back are stored in world units (MFC's GetPos3), not grid pixels. The T03 tests pass the identity frame and are unchanged otherwise. default_span_mark is made pub and centre_span_mark (vCenterKrest) added. item_type gains the bridge common props, begin/center/end spans and part props. fake_bridge seeds 'Bridge type' on bridge common props. scenario.zig cellValue copes with the optional channel and uses gridNode. main.zig/docks_check.zig: the bdg preview was already in kPreviewKinds and the sync is per kind, so 'as bld is wired' came down to moving the host check's 'unported import' probe off .bdg (its importer came with T01/T02, which broke that probe) onto .pcp, with main.zig's PASS line updated.

## Verification

All four verify commands, run in the foreground, exited 0, alone and as the full && chain (10.7 s). App-logic: 126/126 pass. resource-core: 79/79 pass. resource-editor-smoke: smoke and smoke-edit PASS. I also ran resource-editor-host-check, which exits 0 with 'docks PASS (... .pcp import refused ...)'. I opened a copy of the bdg fixture under zig-out/local-test with ResourceEditor --hidden: 'hidden run PASS (30 frames, bdg)', exit 0, so the bridge grid frame draws without errors. The settings path was redirected under zig-out/local-test, but I gave it a directory where it expects a file, so whether settings were saved there was not checked. CRLF checked on every touched file.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-app-logic -Dtest-mode=run` | 0 | pass | 620ms |
| 2 | `zig build test-resource-core -Dtest-mode=run` | 0 | pass | 1408ms |
| 3 | `zig build install-resource-editor` | 0 | pass | 7436ms |
| 4 | `zig build resource-editor-smoke` | 0 | pass | 5510ms |
| 5 | `full verify chain joined by &&` | 0 | pass | 10660ms |
| 6 | `zig build resource-editor-host-check` | 0 | pass | 5644ms |
| 7 | `ResourceEditor --hidden <copy of bdg/project.bdg>` | 0 | pass | 10000ms |

## Deviations

No transparency dropdown and no Draw pass: the bridge has no geometry home for a bridge part's transeparences or unLockedTiles. main.zig needed no preview wiring, since bdg is already in kPreviewKinds. Its change, with docks_check.zig, moves the host check's 'unported import' probe to .pcp, because the bridge importer is now ported. Files touched outside the expected outputs, all small: point_tools.zig (Frame parameter, pub defaults), sub_editor_tools.zig (item types), fake_bridge.zig (Bridge type prop seed), scenario.zig (optional channel, gridNode), docks_check.zig.

## Known Issues

resource-editor-smoke only opens .unt fixtures, so the bdg open was proved by a separate hidden run, not by the smoke step. T05 adds the measured bdg auto block. Bridge Generate points reads the first span part's locked tiles, as T03's bridgeTarget defines, not the active part's.

## Files Created/Modified

- `Sources/editor/resource_app/grid_logic.zig`
- `Sources/editor/resource_app/panels.zig`
- `Sources/editor/resource_app/main.zig`
- `Sources/editor/resource_app/docks_check.zig`
- `Sources/editor/resource_app/scenario.zig`
- `Sources/editor/resource_core/point_tools.zig`
- `Sources/editor/resource_core/sub_editor_tools.zig`
- `Sources/editor/resource_core/fake_bridge.zig`
