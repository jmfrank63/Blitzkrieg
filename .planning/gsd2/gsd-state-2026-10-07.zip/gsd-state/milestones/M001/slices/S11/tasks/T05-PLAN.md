---
estimated_steps: 3
estimated_files: 4
skills_used: []
---

# T05: BK_EDITOR_AUTO bdg block with measured shots, PARITY B-12 rows, spec, tier run

Why: the demo needs a preview shot measured by code and an auto scenario; parity and spec must record the evidence. This is the slice's last task; T07 (D023, the 12 europe/summer buildings) must be complete before T05 finishes, so its test-resource-bridge run includes the fixed building importer.
Do: add a span_mark verb (and any bridge-specific verbs) to Sources/editor/resource_app/scenario.zig; add a bdg block in build.zig's resource-editor-auto scenario next to the bld block (~8659): copy the fixture and generated art to {dir}/bdg/, open, draw a frame, place a span mark, a fire point and a smoke point, brush passability, shoot and measure span-mark colour, locked red and point colour against thresholds, undo and measure the baseline again, export and check 1.xml and 1_c.dds. Fix any bugs it exposes. Update .planning/phases/06-resource-editor-portable-port/06-PARITY.md B-12.1..B-12.6 with evidence (golden pending win-home) and the spec channel table with the bridge homes. Run the GUI tiers from the shell, not the gsd_exec sandbox (no video device there). Full sweep left to the maintainer; do not claim macOS/Windows. Uncommitted work on scenario.zig and build.zig from an interrupted earlier session is already on disk: review and continue it, do not restart.
Done when: all verify tiers exit 0.

## Inputs

- `Sources/editor/resource_app/scenario.zig`
- `build.zig`
- `Sources/editor/resource_app/grid_logic.zig`
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`

## Expected Output

- `Sources/editor/resource_app/scenario.zig`
- `build.zig`
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`

## Verification

zig build install-resource-editor && zig build resource-editor-auto && zig build resource-editor-smoke && zig build resource-editor-host-check && zig build test-resource-app-logic -Dtest-mode=run && zig build test-resource-core -Dtest-mode=run && zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model -Dtest-mode=run && zig build test-resource-model-comparator -Dtest-mode=run && zig build test-editor-core -Dtest-mode=run && zig build map-editor-smoke

## Observability Impact

Auto log prints measured colour counts and thresholds for the bdg shots.
