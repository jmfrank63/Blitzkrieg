---
id: T06
parent: S11
milestone: M001
key_files:
  - Sources/src/EditorBridge/resource_bridge_test.cpp
  - docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md
  - .gsd/DECISIONS.md
  - .gsd/OVERRIDES.md
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-05T19:13:20.649Z
blocker_discovered: false
---

# T06: Objects, buildings and bridges now share one strict negative-tile scan; 12 shipped buildings the old scan silently skipped are allow-listed by name.

**Objects, buildings and bridges now share one strict negative-tile scan; 12 shipped buildings the old scan silently skipped are allow-listed by name.**

## What Happened

Added S09Object::ScanNegativeTiles and ReadRootGrids in resource_bridge_test.cpp. The scan counts folders first, imports each one, and fails on an import failure, a missing root node, or any read failure that is not the 'left of or above' refusal. It asserts checked == folders, that nothing was written into Data, and that a listed allow-list item still fails to import. It prints 'NEGTILES <kind> checked=N folders=N negative=M unimportable=U'. Objects, buildings and the T02 bridge scan (which also keeps its parts>0 check) all call it. The first run with the strict scan failed on buildings: 12 europe/summer folders have a 1.xml with no bld RPG stats, and the old scan had silently skipped them. They are now in an explicit allow-list with that reason. The spec's D021 result line is updated. D023 in DECISIONS.md supersedes D022, and OVERRIDES.md has a resolution entry. Real counts: objects checked=590 folders=590 negative=0 unimportable=0; buildings checked=194 folders=194 negative=0 unimportable=12; bridges checked=21 folders=21 negative=0 unimportable=0. Unimportable buildings (europe/summer): e_ctownhouse01_1, 01_2, 01_4, 02_1, 02_4, 03_2, 03_4, e_house07_1, e_house09_1, e_townhouse04_3, 04_4, e_townrailwaystation_4.

## Verification

zig build test-resource-bridge -Dtest-mode=run exited 0 after the allow-list was added. It exited 1 on the first strict run, which exposed the 12 skipped buildings. The three NEGTILES lines show checked equal to folders. resource_bridge_test.cpp stayed CRLF (6632 of 6632 lines). Nothing was written into Data.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 54161ms |

## Deviations

None.

## Known Issues

The 12 allow-listed buildings are not proved free of negative tiles, because their grids cannot be read.

## Files Created/Modified

- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`
- `.gsd/DECISIONS.md`
- `.gsd/OVERRIDES.md`
