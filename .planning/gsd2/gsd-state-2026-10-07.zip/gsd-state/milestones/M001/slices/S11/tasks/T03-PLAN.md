---
estimated_steps: 3
estimated_files: 8
skills_used: []
---

# T03: Bridge root homes zero, fire, smoke and directed-explosion channels in the C++ bridge, and resource_core gains undoable span-mark, bridge point-target and generate commands with before/after/undo/redo tests.

Why: B-12.2..B-12.4. Channel 10 bridge_span_marks exists in C++ (resource_bridge.cpp ~1068/1160/2711) and resource_core/bridge.zig:291 but no tool uses it; fire/smoke/dir-explosion/zero channels are homed only for object and building roots (HomeOf ~line 785-830), and bridge part passability is HOME_TILE_LIST on CBridgePartsItem (~1214).
Do: (1) In resource_bridge.cpp home channels 3 (zero), 6 (fire), 7 (smoke), 8 (dir explosion) on the bridge root as CBridgeFrame keeps them, and confirm channel 1 locked_tiles on bridge parts; get/set/save/reopen round-trip tests in resource_bridge_test.cpp including span marks with stale Front/Back. Mirror any new channel home in fake_bridge.zig. (2) In Sources/editor/resource_core add a span-marks command (point_tools.zig or grid_tools.zig, whichever fits) that moves one of Begin, End, Front, Back as one undo step through .bridge_span_marks, honouring 'Bridge type' horizontal/vertical (SetBridgeType, BridgeFrm.cpp:180). Reuse point_tools for fire/smoke/dir-explosion/move/horizontal/angle/delete/generate and grid_tools tile-list brush and set zero for parts. (3) Tests in sub_editor_tools.zig with a Rig.bridge (template Rig.building in grid_logic.zig ~765 / sub_editor_tools) asserting geometry before, after, undo and redo for each tool listed in the success criteria.
Done when: the verify tiers exit 0 with the new tests.

## Inputs

- `Sources/src/editor/BridgeFrm.cpp`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/editor/resource_core/point_tools.zig`
- `Sources/editor/resource_core/grid_tools.zig`
- `Sources/editor/resource_core/sub_editor_tools.zig`
- `Sources/editor/resource_core/fake_bridge.zig`

## Expected Output

- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `Sources/editor/resource_core/fake_bridge.zig`
- `Sources/editor/resource_core/point_tools.zig`
- `Sources/editor/resource_core/grid_tools.zig`
- `Sources/editor/resource_core/sub_editor_tools.zig`

## Verification

zig build test-resource-core -Dtest-mode=run && zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-app-logic -Dtest-mode=run && zig build test-editor-core -Dtest-mode=run

## Observability Impact

Bad span-mark writes return bad_argument with the bridge message 'three points'.
