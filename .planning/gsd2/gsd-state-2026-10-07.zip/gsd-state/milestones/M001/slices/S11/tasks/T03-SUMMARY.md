---
id: T03
parent: S11
milestone: M001
key_files:
  - Sources/src/EditorBridge/resource_bridge.cpp
  - Sources/src/EditorBridge/resource_bridge_test.cpp
  - Sources/editor/resource_core/point_tools.zig
  - Sources/editor/resource_core/sub_editor_tools.zig
  - Sources/editor/resource_core/fake_bridge.zig
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-05T19:08:16.561Z
blocker_discovered: false
---

# T03: Bridge root homes zero, fire, smoke and directed-explosion channels in the C++ bridge, and resource_core gains undoable span-mark, bridge point-target and generate commands with before/after/undo/redo tests.

**Bridge root homes zero, fire, smoke and directed-explosion channels in the C++ bridge, and resource_core gains undoable span-mark, bridge point-target and generate commands with before/after/undo/redo tests.**

## What Happened

C++ (resource_bridge.cpp): the bridge root now homes channels 3, 6, 7 and 8 as frame data, with fire, smoke and directed-explosion points kept in the bridge's RPG chunk (StatsChunkName, FrameChunk "RPG"). SyncAimedChildren covers the bridge's point containers, and a bridge smoke point drops FireEffect. Locked tiles on span parts and span marks (channel 10) were already homed. BridgeFrameChannels in resource_bridge_test.cpp round-trips each through set, get, save and reopen, with span marks carrying a stale Front/Back. Zig (resource_core): item_type gains the bridge classes. point_tools gains bridgeTarget (fire, smoke, fixed five directed explosions; no shoot points, as in CBridgeFrame), with Target.footprint_node/footprint_channel so the generate commands walk a span part's locked tiles. It also gains BridgeType, SpanMark, spanLineY (SetBridgeType and GetPointOnLine geometry) and setSpanMark, which moves one of Begin, End, Front or Back as one undo step through .bridge_span_marks. Begin/End take the line's y for the bridge type. Front/Back store the offset from the papa across the line. Other marks stay as they were. A repeat gives null, and a list that is not 3 points gives BadArgument. fake_bridge.zig mirrors the bridge point-children sync and seeds Direction-only bridge point props. Tests, in point_tools.zig beside the existing Rig and building tests and driven by a new Rig.initBridge: place/copy/delete fire and smoke, drags of move/horizontal/direction, directed explosion direction edit, generate smoke and dir-explosion from locked tiles, each span mark for both bridge types with stale Front/Back kept, defaults, repeat and refusal, part passability brush and set zero.

## Verification

All four verify tiers were run in the foreground and exited 0 after the changes. CRLF was checked on every touched Zig file.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-core -Dtest-mode=run` | 0 | pass | 60000ms |
| 2 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 120000ms |
| 3 | `zig build test-resource-app-logic -Dtest-mode=run` | 0 | pass | 60000ms |
| 4 | `zig build test-editor-core -Dtest-mode=run` | 0 | pass | 60000ms |

## Deviations

Bridge tool tests live in point_tools.zig (where Rig and the building tests are) rather than sub_editor_tools.zig. Bridge directed explosions are fixed-children (five), like a building's, so place and delete are refused. Bridge generate commands read the first span part's locked_tiles via the new Target footprint fields.

## Known Issues

None. The app-side registration of .bridge tools in grid_logic is a later task.

## Files Created/Modified

- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `Sources/editor/resource_core/point_tools.zig`
- `Sources/editor/resource_core/sub_editor_tools.zig`
- `Sources/editor/resource_core/fake_bridge.zig`
