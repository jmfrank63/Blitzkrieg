---
estimated_steps: 3
estimated_files: 4
skills_used: []
---

# T07: D023: make the 12 allow-listed europe/summer buildings import, shrink the allow-list, named round-trip test

Why: hard steer D023 (overturns the building allow-list recorded in D024, the T06 resolution of D022). T06 allow-listed 12 shipped buildings in Data/Buildings/europe/summer (e_ctownhouse01_1 ... e_townrailwaystation_4, the full list is the allow-list in S09Object::ScanNegativeTiles' building call in Sources/src/EditorBridge/resource_bridge_test.cpp) with the reason 'the shipped 1.xml holds no bld RPG stats (history only)'. That reason is false: e_house07_1/1.xml has a full <desc MaxHP="500" ...> after its <History> block, and e_house08_1 has the same History-then-desc layout and imports fine. They are real shipped buildings the Resource Editor must import (D-04/D-07). Must be complete before T05, the slice's last task, finishes.
Do: (1) For each of the 12, find the actual cause: import it alone, capture the importer's error, and diff its 1.xml (and any sibling files the importer reads: _c/_h/_l.dds, .san, icon) against a working building of the same layout (e_house08_1) field by field: which element, attribute, value range, missing/extra file or path case the importer (building_export.cpp BuildingStatsToTree / the bld load path in resource_bridge.cpp) trips on. Do not assume one cause for all 12. Record the per-building cause in the task summary. (2) Fix the building importer (and the engine-reader side only if the engine itself reads the file differently) so each of the 12 imports to a tree and exports stats-only field-equal through the comparator, like the other buildings. Fixes go in the importer, never in shipped Data/. (3) Shrink the allow-list to only items with a verified, specific reason (the exact element or file and why the game itself cannot use it); if none remain, the building allow-list is empty and the scan says unimportable=0. A listed item that imports still fails the test. (4) Add a named round-trip test on at least one of the 12 (e.g. S10Building::ShippedEHouse07RoundTrip on europe/summer/e_house07_1, copied read-only to zig-out/local-test): import, export stats-only, compare field-equal with 0 differences. (5) Ensure the shipped building round trip and the NEGTILES buildings line now count the 12 as checked imports; update the 'NEGTILES buildings ... unimportable=U' value and the spec's D021 result line with the real counts. (6) Resolve Data paths case-insensitively (DataFile helper); nothing is written into Data/. Keep new text CRLF. Cite only commands actually run in this task.
Done when: zig build test-resource-bridge -Dtest-mode=run exits 0, the named round-trip test passes on at least one of the 12, the building allow-list holds only items with a verified specific reason, and the summary lists the real cause per building and the real counts. Then record D023 as resolved (a gsd_decision_save resolution entry, not a hand edit of DECISIONS.md) and add a resolution entry in OVERRIDES.md.

## Inputs

- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `Sources/src/ResourceModel/items/building/building_export.cpp`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Data/Buildings/europe/summer/e_house07_1/1.xml`
- `Data/Buildings/europe/summer/e_house08_1/1.xml`
- `.gsd/DECISIONS.md`
- `.gsd/OVERRIDES.md`

## Expected Output

- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `Sources/src/ResourceModel/items/building/building_export.cpp`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`

## Verification

zig build test-resource-bridge -Dtest-mode=run
