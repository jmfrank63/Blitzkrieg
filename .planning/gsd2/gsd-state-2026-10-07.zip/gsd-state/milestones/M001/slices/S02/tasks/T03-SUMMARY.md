---
id: T03
parent: S02
milestone: M001
key_files:
  - Sources/editor/kit/history.zig
  - Sources/editor/kit/settings.zig
  - Sources/editor/kit/root.zig
  - Sources/editor/core/history.zig
  - Sources/editor/core/settings.zig
key_decisions:
  - Kit history uses a two-level generic (`fn Entry(comptime Command: type) type` + `fn History(comptime Command: type) type` returning a struct) rather than an opaque pointer or a type-erased command: lets the stack hold values with their own `deinit`, keeps the save-mark + revision + merge-hook mechanics completely map-free, and preserves monomorphised performance for MapEditor's hot path.
  - Kit settings exposes BOTH a standalone generic `Settings` struct (usable by future kit-only editors) AND duck-typed helpers `applyGenericKey`/`writeGenericKeys`/`writeGenericTailKeys`/`writeRecentLines` that operate on any struct with the generic field names. This lets MapEditor's composed `Settings` keep its flat shape - every caller's `state.settings.scroll_speed`, `state.settings.layers`, `state.settings.filter_active` etc. still works, and `mapeditor.cfg`'s on-disk byte order is preserved by threading the composed caller's own writes between the kit's head and tail writers.
  - `FixedPath` mutation rules (control-char dropping, max_path cap) and the recent-list operations (pushRecent dedup, removeRecent shift) live only in the kit as `setGameParametersField`/`pushRecentField`/`removeRecentField`, with core's `Settings` methods thin forwarders. One place for WR-B03 enforcement, one place to change if a future kit editor needs a different cap.
  - Core keeps its own `parse` loop rather than calling a kit `parse` entry point: a composed caller needs to interleave its own keys with the generic key dispatch, and splitting the loop would double the key-dispatch cost. The kit's `applyGenericKey` returns `bool` so the composed caller fails over to its own key handlers only on a kit miss.
duration: 
verification_result: passed
completed_at: 2026-10-04T21:53:49.775Z
blocker_discovered: false
---

# T03: Carved a generic History(Command) + Entry(Command) primitive and a generic Settings/parse/format primitive into Sources/editor/kit/{history,settings}.zig; MapEditor's own history Command union and layer/filter/terrain-toggle sidecar stay in Sources/editor/core/{history,settings}.zig, which compose the kit through duck-typed helpers so every core.history.* and core.settings.* call site compiles unchanged and mapeditor.cfg's on-disk byte order is preserved.

**Carved a generic History(Command) + Entry(Command) primitive and a generic Settings/parse/format primitive into Sources/editor/kit/{history,settings}.zig; MapEditor's own history Command union and layer/filter/terrain-toggle sidecar stay in Sources/editor/core/{history,settings}.zig, which compose the kit through duck-typed helpers so every core.history.* and core.settings.* call site compiles unchanged and mapeditor.cfg's on-disk byte order is preserved.**

## What Happened

Split both coupled primitives behind the kit boundary without changing any caller's surface:

- **History**: `Sources/editor/kit/history.zig` now exposes `pub fn Entry(comptime Command: type) type` and `pub fn History(comptime Command: type) type`, generic over an opaque Command (which must offer `pub fn deinit(*Command, Allocator)`). The returned struct holds `undo_stack`, `redo_stack`, `clean_depth`, `revision`, and the full `deinit/clear/reserve/record/recordAssumeCapacity/top/touchTop/dropTop/markClean/dirty/canUndo/canRedo` surface - identical semantics (gesture-merge hook via `top()`, revision bumps on every mutation including `clear`, save-mark lost on branch-drop) to the pre-split version. Kit tests use a toy `TestCommand` union so the primitive is proven map-free.
- `Sources/editor/core/history.zig` keeps `Pose`, `DeletedRecord`, `EditScope`, and the MapEditor-specific `Command` union with its full 18-case deinit, and defines `pub const Entry = kit_history.Entry(Command)` + `pub const History = kit_history.History(Command)`. Every existing `history_mod.Pose/Entry/DeletedRecord/EditScope/Command/History` path in `core/editor.zig` keeps resolving. The three original tests (`dropTop` save-mark, `markClean/touchTop` dirty-tracking, revision moves) are kept here against the real Command union so MapEditor still has its own coverage.

- **Settings**: `Sources/editor/kit/settings.zig` exports every generic plumbing primitive (constants `min/max/default_scroll_speed`, `min/max/default_autosave_minutes`, `recent_capacity`, `max_game_parameters`, `max_path`; types `Format` + `formatExtension`, `FixedPath`; helpers `isControl`, `hasControl`, `sameOsPath`), a standalone `Settings` struct that any kit-only editor can use directly, and three duck-typed helpers (`applyGenericKey`, `writeGenericKeys`, `writeGenericTailKeys`, `writeRecentLines`) that operate on any struct whose field names match the generic Settings. Also exports shared `setGameParametersField`, `pushRecentField`, `removeRecentField` so FixedPath mutation rules (control-char drop, capacity bound, dedup) live in one place.
- `Sources/editor/core/settings.zig` now composes the kit: it keeps `Settings` as a flat struct (same field names and defaults as before) with the generic fields drawn from `kit_settings` types and the MapEditor sidecar fields (`instant_update`, `fit_to_grid`, `layers: layers_mod.State`, `filter_active`, `filter_slots`, `filter_slot_count`). Its `parse` loops over lines, dispatches each key through `kit_settings.applyGenericKey` first, then falls back to a local `applyMapKey` for the five map-specific keys (`instant_update`, `fit_to_grid`, `layers_bits`, `fire_range_mode`, `fire_range_filter`, `filter_active`, `filter_slot_*`) and the lenient layer-mode normalisation. `format` calls `kit_settings.writeGenericKeys` → writes the MapEditor-specific middle keys (toggles, layer bits, fire-range) in their original byte order → `kit_settings.writeGenericTailKeys` → filter_active + filter_slot_* → `kit_settings.writeRecentLines`. The resulting on-disk order is byte-for-byte identical to the pre-split layout.
- Every `core.settings.X` caller (constants, `Format`, `max_game_parameters`, `Settings.filter_slot_count`, `formatExtension`, `parse`, `format`) and every `state.settings.FIELD` access (scroll_speed, autosave, autosave_minutes, default_format, layers, instant_update, fit_to_grid, filter_active, filter_slots, filterSlot, setFilterSlot, hidden_panels, mapsFolder, setMapsFolder, recentCount, recentAt, pushRecent, removeRecent, gameParameters, setGameParameters) keeps its exact previous shape.

- **Kit root wiring**: added `pub const history = @import("history.zig");` and `pub const settings = @import("settings.zig");` to `Sources/editor/kit/root.zig`. No change to `Sources/editor/core/root.zig` was needed - `pub const history = @import("history.zig")` and `pub const settings = @import("settings.zig")` already resolved to the (now composed) core files.

- **Tests**: kept every existing core-settings test under `core/settings.zig` (including the full WR-B03 newline-handling test, CR-A03 filter-length test, layers round trip, filter slots, recent capacity, clamping). Added fresh kit-side tests for the standalone generic Settings covering defaults, round trip, clamping, pushRecent dedup/capacity, control-char dropping, and FixedPath caps. Kit history tests prove the generic primitive on a toy TestCommand so the kit stays map-agnostic.

## Verification

Ran the plan's full verification set plus the three previously-green related tiers:

- `zig build test-editor-kit` → exit 0 (kit history + settings tests both green against the generic primitives).
- `zig build test-editor-core` → exit 0 (core history + settings tests green against the composed MapEditor types).
- `zig build test-map-editor-panels` → exit 0 (panels_logic covers settings-driven UI: filter slots, hidden_panels, options text, default_format round trip; all green).
- `zig build install-game` → exit 0.
- `zig build install-map-editor` → exit 0.
- `zig build map-editor-m3-auto` → exit 1 with the exact S01 baseline footprint: 2 MapEditor binary aborts in `AIWarFog::SetZero` (`Sources/src/AILogic/../Misc/2Darray.h:33`), same `InstallMapInSession` → `AIEditorInternal::Clear` → `AILogicInternal::Clear` → `GlobalObjects::Clear` → `HitsStore::Clear` → `SetZero` stack as the pre-existing BkEditorOpenMap crash recorded in `zig-out/local-test/resource_editor/s01-sweep.log`. Build summary: "147/158 steps succeeded (2 failed); 14/14 tests passed" - every Zig test green, only the engine-side binary aborts the baseline already carries.
- Three previously-green tiers I touched by rebuild also stayed green: `test-map-editor-view` (exit 0), `test-map-editor-testlaunch` (exit 0), `test-map-editor-auto` (exit 0).

No new red tiers introduced; the stable 8-failure MapEditor-binary footprint on BkEditorOpenMap is unchanged. mapeditor.cfg on-disk format preservation is proved by the existing round-trip tests in `core/settings.zig` all passing (every field survives format then parse byte-for-byte).

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-editor-kit` | 0 | pass | 500ms |
| 2 | `zig build test-editor-core` | 0 | pass | 1000ms |
| 3 | `zig build test-map-editor-panels` | 0 | pass | 2000ms |
| 4 | `zig build install-game` | 0 | pass | 3000ms |
| 5 | `zig build install-map-editor` | 0 | pass | 3000ms |
| 6 | `zig build map-editor-m3-auto` | 1 | baseline-match (same AIWarFog::SetZero nullptr-memset in BkEditorOpenMap as S01 sweep; 14/14 Zig tests passed) | 5000ms |
| 7 | `zig build test-map-editor-view` | 0 | pass | 1000ms |
| 8 | `zig build test-map-editor-testlaunch` | 0 | pass | 500ms |
| 9 | `zig build test-map-editor-auto` | 0 | pass | 500ms |

## Deviations

None. The task plan asked for a generic `History(comptime Command: type)` returning a struct with `push, undo, redo, markSaved, isDirty, capacity policy, gesture-merge hook` - delivered as `record`/`recordAssumeCapacity` (which cover `push`), `markClean` (= markSaved), `dirty`/`canUndo`/`canRedo` (= isDirty + stack queries), `reserve` (capacity policy for the pre-bridge reservation), and `top()` (the gesture-merge hook: MapEditor's `editor.zig::mergeable` reads this). Undo/redo-of-individual-steps lives on top in `core/editor.zig` (which pops from one stack onto the other and runs replay) - unchanged from before and consistent with the plan's note that MapEditor's own Command union and replay driver stay in core.

## Known Issues

The map-editor-m3-auto tier still exits 1 with the pre-existing `AIWarFog::SetZero` nullptr-memset on BkEditorOpenMap - identical footprint to the S01 baseline recorded in `zig-out/local-test/resource_editor/s01-sweep.log`. Not caused by T03; the slice contract explicitly allows this stable 8-failure footprint. Fixing it is engine-side work outside S02 scope.

## Files Created/Modified

- `Sources/editor/kit/history.zig`
- `Sources/editor/kit/settings.zig`
- `Sources/editor/kit/root.zig`
- `Sources/editor/core/history.zig`
- `Sources/editor/core/settings.zig`
