---
estimated_steps: 3
estimated_files: 2
skills_used: []
---

# T06: Run the full S02 Linux sweep (test-editor-kit + 13 MapEditor tiers) and record a diff vs. the S01 baseline

Why: S02 is only green when every MapEditor tier runs with the same red/green profile as S01's sweep PLUS the new `test-editor-kit` tier passes. A regression that is "a new red" vs. S01 is a slice failure; a stable red carried over from S01 (the 8 BkEditorOpenMap-dependent tiers blocked by the pre-existing AIWarFog::SetZero nullptr-memset trap) is not.

Do: Create and run a sweep script `tools/zig/run-s02-sweep.sh` (CRLF) that invokes, in order, `zig build install-game install-map-editor` then `zig build test-editor-kit test-editor-core test-map-editor-view test-map-editor-panels test-map-editor-testlaunch test-map-editor-auto test-map-editor-engine test-editor-bridge map-editor-host-check map-editor-smoke map-editor-auto map-editor-auto-m2 map-editor-m3-auto map-editor-game-reads-it-m3` with `BK_DEBUG_LOG=1` set, writing one line per tier to `zig-out/local-test/resource_editor/s02-sweep.log` with the pattern `TIER=<name> EXIT=<code> ELAPSED_MS=<n> VERDICT=<PASS|FAIL|PREEXISTING>`. The script must mark the 8 BkEditorOpenMap tiers (`test-map-editor-engine`, `test-editor-bridge`, `map-editor-host-check`, `map-editor-smoke`, `map-editor-auto`, `map-editor-auto-m2`, `map-editor-m3-auto`, `map-editor-game-reads-it-m3`) as `PREEXISTING` when their failure stack matches the AIWarFog::SetZero signature recorded in S01's sweep log, and otherwise `FAIL`. Append a final `S02 VERDICT=<PASS|FAIL>` line that is `PASS` only when: `test-editor-kit` is `PASS`, the 5 non-BkEditorOpenMap tiers are `PASS`, and no tier is `FAIL` (PREEXISTING is tolerated).

Done when: `zig-out/local-test/resource_editor/s02-sweep.log` exists, is at least 15 lines long, ends with a `S02 VERDICT=PASS` line, and `grep -c 'EXIT=0' zig-out/local-test/resource_editor/s02-sweep.log` is at least 6 (the 5 non-BkEditorOpenMap tiers + test-editor-kit, all exit 0).

## Inputs

- `zig-out/local-test/resource_editor/s01-sweep.log`
- `Sources/editor/kit/root.zig`
- `Sources/editor/kit/README.md`

## Expected Output

- `tools/zig/run-s02-sweep.sh`
- `zig-out/local-test/resource_editor/s02-sweep.log`

## Verification

bash tools/zig/run-s02-sweep.sh && test -s zig-out/local-test/resource_editor/s02-sweep.log && grep -q 'S02 VERDICT=PASS' zig-out/local-test/resource_editor/s02-sweep.log

## Observability Impact

The sweep log at `zig-out/local-test/resource_editor/s02-sweep.log` is the inspection surface for S02 verification: tier name, exit code, elapsed ms, verdict (PASS/FAIL/PREEXISTING) per line; a `S02 VERDICT` summary line at the end. Future agents inspecting S02's health open this file. BK_DEBUG_LOG=1 is set during the sweep so DebugTrace output surfaces in release-build tier logs when anything regresses.
