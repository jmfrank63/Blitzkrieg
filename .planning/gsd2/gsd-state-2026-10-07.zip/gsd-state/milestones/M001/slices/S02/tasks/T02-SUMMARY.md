---
id: T02
parent: S02
milestone: M001
key_files:
  - Sources/editor/kit/files.zig
  - Sources/editor/kit/shipped.zig
  - Sources/editor/kit/script_file.zig
  - Sources/editor/kit/autosave.zig
  - Sources/editor/kit/root.zig
  - Sources/editor/core/root.zig
  - Sources/editor/core/editor.zig
  - Sources/editor/core/fake_bridge.zig
key_decisions:
  - Generalised the kit's autosave.recoveryName to take `extension: []const u8` so the kit stays map-agnostic; MapEditor keeps its 2-arg call shape via a thin forwarding shim in `core/root.zig` rather than a per-caller edit. This localises the only behavioural touchpoint to one function in the core re-export layer.
  - Kept `core.autosave` as a wrapper struct (not a direct `kit_mod.autosave` re-export) so the local `recoveryName` shim can co-exist with the kit's generalised one. Other kit members (`default_interval_minutes`, `Autosave`, `Target`, `target`) are re-exported one by one — explicit and auditable.
  - Dependency direction is `editor_core -> editor_kit` only; the kit must never import `editor_core`. Enforced by convention and the kit's root.zig doc comment.
duration: 
verification_result: passed
completed_at: 2026-10-04T21:44:38.089Z
blocker_discovered: false
---

# T02: Moved the four leaf primitives (files, shipped, script_file, autosave) into Sources/editor/kit/ and re-exported them from editor_core so every MapEditor caller keeps its core.files/core.shipped/core.script_file/core.autosave surface unchanged.

**Moved the four leaf primitives (files, shipped, script_file, autosave) into Sources/editor/kit/ and re-exported them from editor_core so every MapEditor caller keeps its core.files/core.shipped/core.script_file/core.autosave surface unchanged.**

## What Happened

T02 relocated the four map-domain-free leaf modules out of `Sources/editor/core/` into the kit scaffolded in T01. The files `files.zig`, `shipped.zig`, `script_file.zig`, and `autosave.zig` were moved with `git mv` (no edits to the first three — their relative `@import` paths were already same-directory-only, so they compile unchanged under `Sources/editor/kit/`). `Sources/editor/kit/root.zig` grew four `pub const` re-exports (`files`, `shipped`, `script_file`, `autosave`), replacing its empty-scaffold body from T01. `Sources/editor/core/root.zig` was rewritten to pull from `editor_kit`: it now imports `editor_kit` once as `kit_mod`, exposes it as `pub const kit`, and re-exports `files`, `shipped`, `script_file` directly through it. The autosave surface needed a thin shim because the kit's `recoveryName` was generalised: its `const extension = ".bzm"` was promoted to a required `extension: []const u8` parameter so the kit stays map-agnostic (other editors on the kit will thread their own project extension). To keep MapEditor's existing `core.autosave.recoveryName(buffer, doc_path)` call shape stable (the only caller is `panels.zig`), `Sources/editor/core/root.zig` wraps the kit's autosave module in a local `pub const autosave = struct { ... }` that re-exports `default_interval_minutes`, `Autosave`, `Target`, and `target` one by one, and provides a thin `recoveryName(buffer, doc_path)` that forwards to `kit_mod.autosave.recoveryName(buffer, doc_path, ".bzm")`. Autosave's unit tests in `Sources/editor/kit/autosave.zig` were updated to pass `.bzm` explicitly, and a new test confirms a caller-chosen extension (e.g. `.wpn`, `.obt`) is honoured, pinning the kit's generic contract for future editors. `editor.zig` and `fake_bridge.zig` only picked up incidental edits to match the new re-export shape — no behavioural change. CRLF preserved. Dependency direction stays `editor_core -> editor_kit`.

## Verification

Ran the T02 verification command `zig build test-editor-kit test-editor-core install-game install-map-editor` on this Linux x64 machine. The build completed in 2.87s wall time and exited 0 — all shader cross-compiles ran, both unit-test tiers passed, and both install targets produced binaries. No MapEditor caller required edits because the `core.files`/`core.shipped`/`core.script_file`/`core.autosave` surface is preserved via re-exports, and the generalised `recoveryName` is kept MapEditor-shaped by the thin shim in `core/root.zig`. The slice-level 13-tier sweep is deferred to the final S02 task (T06); intermediate tasks only need the kit + core + install combo green per the task plan's Done-when clause.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-editor-kit test-editor-core install-game install-map-editor` | 0 | pass | 2868ms |

## Deviations

None.

## Known Issues

None.

## Files Created/Modified

- `Sources/editor/kit/files.zig`
- `Sources/editor/kit/shipped.zig`
- `Sources/editor/kit/script_file.zig`
- `Sources/editor/kit/autosave.zig`
- `Sources/editor/kit/root.zig`
- `Sources/editor/core/root.zig`
- `Sources/editor/core/editor.zig`
- `Sources/editor/core/fake_bridge.zig`
