---
id: T06
parent: S02
milestone: M001
key_files:
  - tools/zig/run-s02-sweep.sh
  - zig-out/local-test/resource_editor/s02-sweep.log
key_decisions:
  - Signature-matched PREEXISTING classification: a BkEditorOpenMap-dependent tier is only PREEXISTING when its captured stderr matches one of {AIWarFog::SetZero, BkEditorOpenMap, OpenMapIntoSession}. Any other failure mode on those tiers is FAIL. This keeps the regression gate tight — a new crash in the same tier would not be masked as 'the known one'.
  - Script truncates the log on each run (`: > ${LOG}`) rather than appending across invocations. This keeps the log a single-sweep snapshot — the inspection surface future agents open is always the latest run, not a growing history. S01's log is the baseline reference; S02's log is the current state.
  - Aggregate verdict is PASS iff test-editor-kit is PASS, the 5 non-BkEditorOpenMap tiers are PASS, and no tier is FAIL. PREEXISTING is tolerated by design (owned by S04/S13), so the gate is 'no new reds introduced by the kit carve-out', not 'all 14 tiers green'.
duration: 
verification_result: passed
completed_at: 2026-10-04T22:22:30.081Z
blocker_discovered: false
---

# T06: Added tools/zig/run-s02-sweep.sh and captured zig-out/local-test/resource_editor/s02-sweep.log recording test-editor-kit + 13 MapEditor tiers against the S01 baseline, with S02 VERDICT=PASS and no new reds beyond the 8 preexisting BkEditorOpenMap/AIWarFog traps owned by S04/S13.

**Added tools/zig/run-s02-sweep.sh and captured zig-out/local-test/resource_editor/s02-sweep.log recording test-editor-kit + 13 MapEditor tiers against the S01 baseline, with S02 VERDICT=PASS and no new reds beyond the 8 preexisting BkEditorOpenMap/AIWarFog traps owned by S04/S13.**

## What Happened

Created tools/zig/run-s02-sweep.sh (CRLF, executable) as the S02 regression-sweep driver: BK_DEBUG_LOG=1 is exported, each tier runs through zig build with stdout dropped and stderr captured to a tmp file, elapsed_ms is sampled from `date +%s%3N`, and each line is appended to zig-out/local-test/resource_editor/s02-sweep.log with the required `TIER=<name> EXIT=<code> ELAPSED_MS=<n> VERDICT=<PASS|FAIL|PREEXISTING>` shape. The 8 BkEditorOpenMap-dependent tiers (test-map-editor-engine, test-editor-bridge, map-editor-host-check, map-editor-smoke, map-editor-auto, map-editor-auto-m2, map-editor-m3-auto, map-editor-game-reads-it-m3) are classified PREEXISTING only when their captured stderr matches the AIWarFog::SetZero / BkEditorOpenMap / OpenMapIntoSession signature from the S01 baseline; any other failure (or a new tier failing) is FAIL. The script computes a final `S02 VERDICT=<PASS|FAIL>` line that passes only when test-editor-kit is PASS, the 5 non-BkEditorOpenMap tiers are PASS, and no tier is FAIL. Running the sweep produced a 16-line log: install-game+install-map-editor + 14 tiers + aggregate verdict. test-editor-kit, test-editor-core, test-map-editor-view, test-map-editor-panels, test-map-editor-testlaunch, test-map-editor-auto all exit 0 (7 EXIT=0 rows counting the base install). The 8 BkEditorOpenMap tiers all exit 1 and classify as PREEXISTING — the same 8-tier footprint and signature S01 recorded with the `# PRE-EXISTING: AIWarFog::SetZero nullptr-memset` annotation, so no new reds are attributable to the kit carve-out. The script writes `S02 VERDICT=PASS` as the final line, satisfying the slice contract. Note on resume: the previous session's log capture was truncated at line 11 (map-editor-smoke) due to an interruption; the script's `: > "${LOG}"` prefix truncates the log on each run, so the fresh invocation produced the complete 16-line record from scratch.

## Verification

Ran `bash tools/zig/run-s02-sweep.sh` to completion (stdout: `S02 VERDICT=PASS`). Confirmed the log via `wc -l` (16 lines, ≥15 required) and `grep -c 'EXIT=0'` (7, ≥6 required). Confirmed the final line is `S02 VERDICT=PASS`. Cross-checked the 8 PREEXISTING tiers against the S01 baseline — identical tier set, identical AIWarFog::SetZero / BkEditorOpenMap signature, so S02 introduces no new reds.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `bash tools/zig/run-s02-sweep.sh` | 0 | pass | 45000ms |
| 2 | `test -s zig-out/local-test/resource_editor/s02-sweep.log && grep -q 'S02 VERDICT=PASS' zig-out/local-test/resource_editor/s02-sweep.log` | 0 | pass | 10ms |
| 3 | `wc -l zig-out/local-test/resource_editor/s02-sweep.log` | 0 | pass | 5ms |
| 4 | `grep -c 'EXIT=0' zig-out/local-test/resource_editor/s02-sweep.log` | 0 | pass | 5ms |

## Deviations

None.

## Known Issues

None.

## Files Created/Modified

- `tools/zig/run-s02-sweep.sh`
- `zig-out/local-test/resource_editor/s02-sweep.log`
