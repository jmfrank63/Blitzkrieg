---
estimated_steps: 3
estimated_files: 6
skills_used: []
---

# T03: Carve a generic save-mark+stack primitive and a generic settings primitive out of history.zig and settings.zig

Why: R001 names history/undo and settings as kit material, but today's `history.zig` imports `bridge.ObjectRecord`/`SoundRecord`/`records` and defines a map-specific Command union; today's `settings.zig` imports `layers` and holds 50+ layer references alongside generic fields (scroll speed, autosave on/off, maps folder, recent-files list, format enum). The split keeps the map-specific union/sections where they belong and lifts only the reusable primitive into the kit.

Do: Carve the stack+save-mark mechanics out of `Sources/editor/core/history.zig` into a new `Sources/editor/kit/history.zig` that is generic over an opaque command type (e.g. `pub fn History(comptime Command: type) type` returning a struct with `push`, `undo`, `redo`, `markSaved`, `isDirty`, capacity policy, and the gesture-merge hook). Keep MapEditor's own Command union, DeletedRecord, Pose, and EditScope in `Sources/editor/core/history.zig` — it now imports `editor_kit`'s generic `History(MapCommand)`. Carve `Sources/editor/kit/settings.zig` with the generic fields (scroll_speed, autosave_minutes, autosave on/off, default_folder, recent_capacity + list, format enum, max_game_parameters, FixedPath, parse/write for `key=value`); keep MapEditor-specific layer visibility, scroll/swipe quirks, and anything that imports `layers_mod` in `Sources/editor/core/settings.zig`, which composes the kit's `Settings` struct + a MapEditor sidecar. Preserve the existing `core.settings.X` call-site API through a re-export shim in `Sources/editor/core/root.zig` so callers in `app/*.zig` do not change. Settings `parse` must stay lenient per the spec note (T-03-07-01). Preserve `mapeditor.cfg`'s on-disk format byte-for-byte so the smoke run reads existing cfg files unchanged. CRLF preserved.

Done when: `zig build test-editor-kit test-editor-core install-game install-map-editor` exits 0 and all 13 MapEditor tiers run with the same red/green profile as S01's sweep (specifically `test-map-editor-panels`, which exercises settings-driven UI, and `map-editor-m3-auto`, which exercises history save-mark + autosave).

## Inputs

- `Sources/editor/core/history.zig`
- `Sources/editor/core/settings.zig`
- `Sources/editor/core/bridge.zig`
- `Sources/editor/core/records.zig`
- `Sources/editor/core/layers.zig`
- `Sources/editor/kit/root.zig`

## Expected Output

- `Sources/editor/kit/history.zig`
- `Sources/editor/kit/settings.zig`
- `Sources/editor/kit/root.zig`
- `Sources/editor/core/history.zig`
- `Sources/editor/core/settings.zig`
- `Sources/editor/core/root.zig`

## Verification

zig build test-editor-kit test-editor-core test-map-editor-panels install-game install-map-editor map-editor-m3-auto
