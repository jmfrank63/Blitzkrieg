---
estimated_steps: 3
estimated_files: 2
skills_used: []
---

# T01: Scaffold Sources/editor/kit/ and wire the editor_kit module into build.zig alongside editor_core

Why: Every other task in this slice moves code into `Sources/editor/kit/`; the module needs to exist first with a build-step that compiles the empty root and runs an empty test tier green on Linux. Without this, every move is also a build.zig edit.

Do: Create `Sources/editor/kit/root.zig` (CRLF, `pub` re-exports slot for each kit submodule — initially empty), add an `editor_kit` module in `build.zig` next to the existing `editor_core_module` (around build.zig:2788), import it everywhere `editor_core_module` is already imported in build.zig's addEditor/MapEditor functions by adding `.{ .name = "editor_kit", .module = editor_kit_module }` to the imports arrays; add a new `test-editor-kit` build step that runs the kit's `refAllDecls` test with `test_mode == .run` the same way `test-editor-core` does; `editor_core_module` must gain `.imports = &.{.{ .name = "editor_kit", .module = editor_kit_module }}` so later tasks can re-point internal imports; the kit must not import `editor_core`. Keep CRLF line endings. Do not move any files in this task — only prove the scaffold compiles.

Done when: `zig build test-editor-kit` exits 0, `zig build install-game install-map-editor` exits 0 (unchanged behaviour), and `zig build test-editor-core` exits 0. The empty kit must be importable from `Sources/editor/core/root.zig` without failing.

## Inputs

- `Sources/editor/core/root.zig`
- `build.zig`

## Expected Output

- `Sources/editor/kit/root.zig`
- `build.zig`

## Verification

zig build test-editor-kit test-editor-core install-game install-map-editor
