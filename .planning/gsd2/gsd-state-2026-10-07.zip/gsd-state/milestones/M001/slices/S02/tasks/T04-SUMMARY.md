---
id: T04
parent: S02
milestone: M001
key_files:
  - Sources/editor/kit/host.zig
  - Sources/editor/kit/crt.zig
  - Sources/editor/kit/testlaunch.zig
  - Sources/editor/kit/auto_schedule.zig
  - Sources/editor/kit/pictures_cache.zig
  - Sources/editor/kit/imgui/imgui.zig
  - Sources/editor/kit/imgui/imgui_backend.cpp
  - Sources/editor/kit/imgui/imgui_backend.h
  - Sources/editor/kit/root.zig
  - Sources/editor/app/auto.zig
  - Sources/editor/app/pictures.zig
  - build.zig
key_decisions:
  - auto.zig split keeps the kit map-free with an opaque `dispatch(action) !void` callback: the kit's auto_schedule.zig owns the BK_EDITOR_AUTO grammar, parser, synthetic-event step driver, and TGA compare; MapEditor's app/auto.zig becomes a thin adapter that resolves `tool=label` / `do=<named_cmd>` into the kit's action enum and plugs in MapEditor's own commands. This lets ResourceEditor (and any future editor) reuse the whole BK_EDITOR_AUTO engine without inheriting MapEditor's command vocabulary.
  - pictures.zig split carves the SDL_GPU texture entries + decode queue + per-frame budget pump + clear/deinit into kit/pictures_cache.zig, generic over a `fn (name: []const u8, out: *Decoded) !void` decoder callback. MapEditor's app/pictures.zig owns the BkEditorObjectPicture / BkEditorTilePicture bindings and the two cache instances; the kit stays decoder-agnostic. Same pattern used for history/settings in T03 — kit holds the mechanism, app plugs in the domain-specific closure.
  - imgui backend moved under Sources/editor/kit/imgui/ rather than kept at Sources/editor/imgui/. build.zig's existing editor_imgui module just updates its path — no new module needed. Keeps the kit self-contained so a future editor can import editor_kit alone and get the ImGui+SDL_GPU backend for free.
duration: 
verification_result: mixed
completed_at: 2026-10-04T22:10:02.474Z
blocker_discovered: false
---

# T04: Moved the app-level editor plumbing (host, crt, imgui wrapper + backend, BK_EDITOR_AUTO schedule driver, SDL_GPU pictures cache, testlaunch) out of Sources/editor/app/ and into Sources/editor/kit/, leaving MapEditor's app layer as thin adapters that plug its own commands/dispatch/decoders into the generic kit primitives.

**Moved the app-level editor plumbing (host, crt, imgui wrapper + backend, BK_EDITOR_AUTO schedule driver, SDL_GPU pictures cache, testlaunch) out of Sources/editor/app/ and into Sources/editor/kit/, leaving MapEditor's app layer as thin adapters that plug its own commands/dispatch/decoders into the generic kit primitives.**

## What Happened

T04 carved the final six "kit" members named in R001 out of the MapEditor app and into Sources/editor/kit/, finishing the S02 goal of a reusable, engine-bridge-free editor plumbing library.

Moves (all content preserved, CRLF intact):
- Sources/editor/app/host.zig  -> Sources/editor/kit/host.zig  (SDL+SDL_GPU window host, failure reporting, ImGui frame bracket). The only edit was switching one same-dir @import("imgui.zig") to the kit module.
- Sources/editor/app/crt.zig   -> Sources/editor/kit/crt.zig   (Windows console-ownership probe + survival chord).
- Sources/editor/app/testlaunch.zig -> Sources/editor/kit/testlaunch.zig (hidden/headless window + render-N-frames harness, Linux stack-size + SDL_WINDOW_HIDDEN|NOT_FOCUSABLE pitfalls baked in).
- Sources/editor/imgui/imgui.zig + imgui_backend.{cpp,h} -> Sources/editor/kit/imgui/* (Dear ImGui SDL_GPU backend). build.zig's editor_imgui module now points at the new path.

Carvings (split kit-generic core from MapEditor-specific adapter):
- auto.zig: pure BK_EDITOR_AUTO grammar/parser + synthetic-event schedule driver + TGA compare moved into Sources/editor/kit/auto_schedule.zig. The driver takes an opaque `dispatch(action) !void` callback, so it's map-free. Sources/editor/app/auto.zig shrank to a 1.4 KB thin adapter that plugs MapEditor's `tool=label` / `do=<named_cmd>` dispatch and `BkEditor*` commands into the kit's step loop.
- pictures.zig: SDL_GPU texture entries + decode queue + per-frame budget pump + clear/deinit carved into Sources/editor/kit/pictures_cache.zig, generic over a `fn (name: []const u8, out: *Decoded) !void` decoder callback. Sources/editor/app/pictures.zig shrank to a thin adapter that owns the two cache instances and threads MapEditor's BkEditorObjectPicture / BkEditorTilePicture decoders through the generic cache.

build.zig: addMapEditor / mapEditorModule and the view/panels_logic/testlaunch/auto standalone test modules now pick up editor_kit alongside editor_core. editor_imgui path updated to Sources/editor/kit/imgui/.

Observability unchanged: host.failureReason(), autosave due/target log lines, files.lastError(), BkEditorLastMessage via host, and BK_EDITOR_AUTO's step log through the moved schedule driver all preserve their existing surfaces.

## Verification

Ran the slice-level sweep on Linux x64 Ubuntu 24.04. Captured per-tier exit codes to zig-out/local-test/resource_editor/s02-sweep.log and compared the engine-tier failure footprint against S01's baseline (zig-out/local-test/resource_editor/s01-sweep.log).

All MapEditor tiers that do not depend on BkEditorOpenMap pass: test-editor-kit, test-editor-core, test-map-editor-view, test-map-editor-panels, test-map-editor-testlaunch, test-map-editor-auto. install-game + install-map-editor exit 0.

All 8 engine-tier failures abort on the same AIWarFog::SetZero (Misc/2Darray.h:33) nullptr-memset stack as S01's baseline (test-map-editor-engine, test-editor-bridge, map-editor-host-check, map-editor-smoke, map-editor-auto, map-editor-auto-m2, map-editor-m3-auto, map-editor-game-reads-it-m3). This is the pre-existing BkEditorOpenMap trap owned by S04/S13 per the preview-scene runbook and T05 summary; T04 did not touch Sources/src/AILogic/*, Sources/src/EditorBridge/*, or any shared engine-runtime code. Same stable 8-failure footprint as S01 — no new tier regressions attributable to the kit moves.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build install-game install-map-editor` | 0 | pass | 3000ms |
| 2 | `zig build test-editor-kit` | 0 | pass | 0ms |
| 3 | `zig build test-editor-core` | 0 | pass | 1000ms |
| 4 | `zig build test-map-editor-view` | 0 | pass | 0ms |
| 5 | `zig build test-map-editor-panels` | 0 | pass | 3000ms |
| 6 | `zig build test-map-editor-testlaunch` | 0 | pass | 1000ms |
| 7 | `zig build test-map-editor-auto` | 0 | pass | 0ms |
| 8 | `zig build test-map-editor-engine` | 1 | pre-existing-fail (S01 baseline: AIWarFog::SetZero nullptr-memset via BkEditorOpenMap) | 8000ms |
| 9 | `zig build test-editor-bridge` | 1 | pre-existing-fail (same signature) | 4000ms |
| 10 | `zig build map-editor-host-check` | 1 | pre-existing-fail (same signature) | 4000ms |
| 11 | `zig build map-editor-smoke` | 1 | pre-existing-fail (same signature) | 4000ms |
| 12 | `zig build map-editor-auto` | 1 | pre-existing-fail (same signature) | 4000ms |
| 13 | `zig build map-editor-auto-m2` | 1 | pre-existing-fail (same signature) | 4000ms |
| 14 | `zig build map-editor-m3-auto` | 1 | pre-existing-fail (same signature) | 4000ms |
| 15 | `zig build map-editor-game-reads-it-m3` | 1 | pre-existing-fail (same signature) | 5000ms |

## Deviations

None. The task plan's prescribed moves + carvings landed as specified. The sweep log also records the heavier map-editor-auto-m2, map-editor-m3-auto, and map-editor-game-reads-it-m3 tiers for parity with S01's baseline, even though the task plan only required map-editor-auto — the extras confirm the same 8-failure footprint and are useful for the S02 slice summary.

## Known Issues

The pre-existing AIWarFog::SetZero nullptr-memset trap via BkEditorOpenMap continues to redden the 8 engine-tier builds. Not a T04 or S02 issue: it is owned by S04/S13 per the preview-scene runbook and T05 summary.

## Files Created/Modified

- `Sources/editor/kit/host.zig`
- `Sources/editor/kit/crt.zig`
- `Sources/editor/kit/testlaunch.zig`
- `Sources/editor/kit/auto_schedule.zig`
- `Sources/editor/kit/pictures_cache.zig`
- `Sources/editor/kit/imgui/imgui.zig`
- `Sources/editor/kit/imgui/imgui_backend.cpp`
- `Sources/editor/kit/imgui/imgui_backend.h`
- `Sources/editor/kit/root.zig`
- `Sources/editor/app/auto.zig`
- `Sources/editor/app/pictures.zig`
- `build.zig`
