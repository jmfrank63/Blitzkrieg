---
estimated_steps: 3
estimated_files: 6
skills_used: []
---

# T02: Move the leaf primitives (files, shipped, script_file, autosave) into the kit with no map-specific coupling

Why: These four files have no map-domain imports (files/shipped/script_file reach only `std`/`builtin`/each other; autosave reaches only `std`). They are the safest first move and prove the kit's public API shape before anything coupled is touched.

Do: `git mv Sources/editor/core/{files,shipped,script_file,autosave}.zig Sources/editor/kit/`. Internally rewire their relative `@import` paths — unchanged (same directory). In `Sources/editor/kit/root.zig` add `pub const files = @import("files.zig");` etc. In `Sources/editor/core/root.zig` replace the four local imports with re-exports from `editor_kit`: `pub const files = @import("editor_kit").files;`, same for `shipped`, `script_file`, `autosave` — this preserves the `core.files`/`core.shipped` API every caller in `Sources/editor/app/*.zig` and `Sources/editor/core/*.zig` already uses, so no caller edits are required. One `autosave.zig` edit: parameterise the hardcoded `.bzm` default in `recoveryName`'s `const extension = ".bzm";` to take an extension argument (`fn recoveryName(buffer: []u8, path: []const u8, extension: []const u8)`) — add a thin shim `recoveryNameBzm` in `Sources/editor/core/root.zig` (or at MapEditor's caller) that threads `.bzm` through, so MapEditor callers keep the same shape. Update autosave's unit tests to pass `.bzm` explicitly. CRLF preserved. No behaviour change expected in any MapEditor tier.

Done when: `zig build test-editor-kit test-editor-core install-game install-map-editor` exits 0 and all 13 MapEditor tiers (same list as the slice success criteria) run with the same red/green profile as S01's sweep.

## Inputs

- `Sources/editor/core/files.zig`
- `Sources/editor/core/shipped.zig`
- `Sources/editor/core/script_file.zig`
- `Sources/editor/core/autosave.zig`
- `Sources/editor/core/root.zig`
- `Sources/editor/kit/root.zig`

## Expected Output

- `Sources/editor/kit/files.zig`
- `Sources/editor/kit/shipped.zig`
- `Sources/editor/kit/script_file.zig`
- `Sources/editor/kit/autosave.zig`
- `Sources/editor/kit/root.zig`
- `Sources/editor/core/root.zig`

## Verification

zig build test-editor-kit test-editor-core install-game install-map-editor map-editor-smoke map-editor-auto
