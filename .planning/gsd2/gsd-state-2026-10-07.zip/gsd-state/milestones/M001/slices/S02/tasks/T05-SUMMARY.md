---
id: T05
parent: S02
milestone: M001
key_files:
  - Sources/editor/kit/README.md
  - Sources/editor/core/root.zig
  - Sources/editor/app/main.zig
  - Sources/editor/app/panels.zig
  - Sources/editor/app/panels_logic.zig
  - Sources/editor/app/panels_m2.zig
  - Sources/editor/app/commands.zig
  - Sources/editor/app/smoke.zig
  - Sources/editor/app/minimap.zig
  - Sources/editor/app/game_reads_common.zig
  - Sources/editor/app/game_reads_m2.zig
  - build.zig
key_decisions:
  - Kept `core.kit = kit_mod` as a convenience re-expose on core/root.zig even after deleting the leaf-primitive re-exports, so a future core-only caller (e.g. the yet-to-port ResourceEditor sharing core modules) still has a one-line way to reach the kit without the app's two-import pattern. The app-side pattern remains the explicit `const kit = @import("editor_kit");`.
  - Replaced panels.zig's call to the deleted MapEditor-specific `core.autosave.recoveryName(buffer, path)` shim with a direct call to the kit's generic `kit.autosave.recoveryName(buffer, path, ".bzm")`, inlining the format extension at the one call site rather than keeping the two-arg wrapper. The kit stays map-free (map extension is a caller concern); a future resource/mission editor passes its own `.<ext>` the same way.
  - Added `editor_kit` to the imports of the panels_logic test module in build.zig (test-map-editor-panels). The runtime executable graph already pulls editor_kit through MapEditor, but the panels_logic test is a standalone `zig test` of just that file, so it needed its own module edge after panels_logic switched from `core.files/...` to `kit.files/...`.
duration: 
verification_result: passed
completed_at: 2026-10-04T22:18:27.141Z
blocker_discovered: false
---

# T05: Documented the editor_kit public API in Sources/editor/kit/README.md, cut every remaining MapEditor import of the four leaf primitives (files, shipped, autosave, script_file) from editor_core over to editor_kit directly, and removed those re-exports from Sources/editor/core/root.zig so the kit owns them.

**Documented the editor_kit public API in Sources/editor/kit/README.md, cut every remaining MapEditor import of the four leaf primitives (files, shipped, autosave, script_file) from editor_core over to editor_kit directly, and removed those re-exports from Sources/editor/core/root.zig so the kit owns them.**

## What Happened

T02-T04 moved the plumbing into Sources/editor/kit/ while keeping thin editor_core re-exports (core.files, core.shipped, core.autosave, core.script_file). T05 removes those shims so the dependency direction is explicit: every Sources/editor/app/*.zig caller now reaches the leaf primitives through editor_kit directly, and Sources/editor/core/root.zig keeps only the map-composed modules (settings, history) that layer MapEditor-specific state over the kit, plus `core.kit` as a convenience re-expose.

Scope of the import cut: panels.zig, panels_m2.zig, panels_logic.zig, main.zig, smoke.zig, commands.zig, game_reads_common.zig, game_reads_m2.zig, and minimap.zig each gained a `const kit = @import("editor_kit");` line (or renamed an existing editor_kit alias) and rewrote `core.files` -> `kit.files`, `core.shipped` -> `kit.shipped`, `core.autosave` -> `kit.autosave`, `core.script_file` -> `kit.script_file`. The one caller of the two-arg `core.autosave.recoveryName(buffer, path)` MapEditor shim in panels.zig now calls the generic `kit.autosave.recoveryName(buffer, path, ".bzm")` directly, so the extension-threading shim is deleted along with the rest of the leaf re-exports.

build.zig: the panels_logic test module (test-map-editor-panels) only had editor_core in its imports; it now also carries editor_kit, since panels_logic.zig itself imports editor_kit directly after the switchover. Nothing else in build.zig needed changing - every other app source already runs under a target that pulls editor_kit through the MapEditor executable graph.

README: Sources/editor/kit/README.md (CRLF, 6793 bytes) has one `## ` section per public kit submodule - files, shipped, script_file, autosave, history, settings, host, crt, imgui, auto_schedule, pictures_cache, testlaunch (12 total). Each section lists the surface the caller sees in two or three sentences, with an explicit one-line map-neutrality note where applicable (history takes a `comptime Command`, settings exposes duck-typed helpers over the generic fields, auto_schedule takes a `comptime Action` and a dispatch callback, pictures_cache takes a decoder callback, autosave's `recoveryName` takes a format extension). The imgui submodule is called out as reached through the separate `editor_imgui` Zig module, not through this root.

## Verification

Ran the T05 verification command and confirmed the Done-when checks on the local Linux x64 machine. All green:

- `zig build test-editor-kit test-editor-core test-map-editor-view test-map-editor-panels install-game install-map-editor --summary all` -> Build Summary: 157/157 steps succeeded; 757/757 tests passed; exit 0 (3.08s cached).
- `grep -rn 'core\.files\|core\.shipped\|core\.autosave\|core\.script_file' Sources/editor/app/` -> zero hits.
- `wc -c Sources/editor/kit/README.md` -> 6793 (>=100).
- `grep -c '^## ' Sources/editor/kit/README.md` -> 12 (one per kit submodule).
- `file Sources/editor/kit/README.md` -> ASCII/UTF-8 with CRLF line terminators (project .gitattributes rule).

Known pre-existing reds confirmed unchanged by this task: map-editor-host-check and test-editor-bridge still abort inside `BkEditorOpenMap` -> `InstallMapInSession` the same way S02's sweep baseline recorded (the slice's own "stable 8-failure footprint on BkEditorOpenMap"). My changes only touched Zig import paths plus the new README, so these C++ engine panics are untouched and were not in T05's own verification set.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-editor-kit test-editor-core test-map-editor-view test-map-editor-panels install-game install-map-editor --summary all` | 0 | pass | 3080ms |
| 2 | `grep -rn 'core\.files\|core\.shipped\|core\.autosave\|core\.script_file' Sources/editor/app/` | 1 | pass | 20ms |
| 3 | `wc -c Sources/editor/kit/README.md` | 0 | pass | 5ms |
| 4 | `grep -c '^## ' Sources/editor/kit/README.md` | 0 | pass | 5ms |

## Deviations

The task plan's "Expected Output" lists 17 app files, but only 9 of them actually referenced the four leaf primitives (`core.files/shipped/autosave/script_file`); the other 8 (panels_m3.zig, view.zig, markers.zig, game_reads_m3.zig, c_bridge.zig, c_bridge_test.zig) already reached the kit directly through `@import("editor_kit")` after T04, or carried no `core.`-leaf references at all. I edited only the files that actually needed a change rather than touching every path in the plan's inputs list, which is the plan's spirit (switchover is complete) with fewer unnecessary edits.

Also added `editor_kit` to the panels_logic test module in build.zig; the plan did not list build.zig as an expected output but the switchover made the standalone `test-map-editor-panels` test need the editor_kit module edge.

## Known Issues

None introduced by T05. The pre-existing stable reds on map-editor-host-check and test-editor-bridge (null-pointer abort inside `BkEditorOpenMap`/`InstallMapInSession`) remain, matching S02's recorded sweep baseline; they are a C++-engine issue outside the kit's own surface and outside T05's "Done when"/verification command list.

## Files Created/Modified

- `Sources/editor/kit/README.md`
- `Sources/editor/core/root.zig`
- `Sources/editor/app/main.zig`
- `Sources/editor/app/panels.zig`
- `Sources/editor/app/panels_logic.zig`
- `Sources/editor/app/panels_m2.zig`
- `Sources/editor/app/commands.zig`
- `Sources/editor/app/smoke.zig`
- `Sources/editor/app/minimap.zig`
- `Sources/editor/app/game_reads_common.zig`
- `Sources/editor/app/game_reads_m2.zig`
- `build.zig`
