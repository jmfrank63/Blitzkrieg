---
estimated_steps: 3
estimated_files: 17
skills_used: []
---

# T05: Document the kit public API in Sources/editor/kit/README.md and cut remaining MapEditor imports to the kit namespace

Why: S03..S15 depend on reading the kit's public API without re-reading implementation. The README is the kit's contract. This task also finishes the switchover: any `app/*.zig` that still reaches into `editor_core` for things that are now in the kit (`core.files`, `core.shipped`, `core.autosave`, `core.history`, `core.settings`, and the formerly in-app `host`/`crt`/`auto`/`pictures`/`testlaunch`/`imgui`) is rewritten to `editor_kit` directly so the dependency direction is explicit.

Do: Write `Sources/editor/kit/README.md` (CRLF): one section per public submodule (files, shipped, script_file, autosave, history, settings, host, crt, imgui, auto_schedule, pictures_cache, testlaunch), each listing the surface the caller sees (types, free functions, invariants from the module header comments) in two or three lines, with a one-line note on map-editor-neutrality ("takes a `comptime Command`"/"takes a decoder callback"/"takes a format extension" where applicable). In `Sources/editor/core/root.zig`, remove the leaf-primitive re-exports added by T02/T03 and keep only the map-specific symbols; search `Sources/editor/app/*.zig` for every `core.files`/`core.shipped`/`core.autosave`/`core.history`/`core.settings` and `app`-level `@import("host.zig")`/`@import("crt.zig")`/`@import("testlaunch.zig")`/`@import("auto.zig")`/`@import("pictures.zig")` and update them to `editor_kit`'s namespace or to the new app-side thin adapters. Keep MapEditor behaviour unchanged. CRLF preserved.

Done when: `zig build install-game install-map-editor` exits 0; `grep -rn 'core\.files\|core\.shipped\|core\.autosave' Sources/editor/app/` reports zero hits (all app callers reach the kit directly); `Sources/editor/kit/README.md` exists and is >=100 bytes with one `## ` section per kit submodule; `test-editor-kit` + `test-editor-core` + `test-map-editor-panels` + `test-map-editor-view` all exit 0.

## Inputs

- `Sources/editor/kit/root.zig`
- `Sources/editor/core/root.zig`
- `Sources/editor/app/main.zig`
- `Sources/editor/app/panels.zig`
- `Sources/editor/app/panels_logic.zig`
- `Sources/editor/app/panels_m2.zig`
- `Sources/editor/app/panels_m3.zig`
- `Sources/editor/app/commands.zig`
- `Sources/editor/app/smoke.zig`
- `Sources/editor/app/view.zig`
- `Sources/editor/app/markers.zig`
- `Sources/editor/app/minimap.zig`
- `Sources/editor/app/game_reads_common.zig`
- `Sources/editor/app/game_reads_m2.zig`
- `Sources/editor/app/game_reads_m3.zig`
- `Sources/editor/app/c_bridge.zig`
- `Sources/editor/app/c_bridge_test.zig`

## Expected Output

- `Sources/editor/kit/README.md`
- `Sources/editor/core/root.zig`
- `Sources/editor/app/main.zig`
- `Sources/editor/app/panels.zig`
- `Sources/editor/app/panels_logic.zig`
- `Sources/editor/app/panels_m2.zig`
- `Sources/editor/app/panels_m3.zig`
- `Sources/editor/app/commands.zig`
- `Sources/editor/app/smoke.zig`
- `Sources/editor/app/view.zig`
- `Sources/editor/app/markers.zig`
- `Sources/editor/app/minimap.zig`
- `Sources/editor/app/game_reads_common.zig`
- `Sources/editor/app/game_reads_m2.zig`
- `Sources/editor/app/game_reads_m3.zig`
- `Sources/editor/app/c_bridge.zig`
- `Sources/editor/app/c_bridge_test.zig`

## Verification

zig build test-editor-kit test-editor-core test-map-editor-view test-map-editor-panels install-game install-map-editor
