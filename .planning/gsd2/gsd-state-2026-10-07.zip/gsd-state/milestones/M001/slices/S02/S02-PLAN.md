# S02: Editor kit extraction; MapEditor on the kit, all tiers green on Linux and CI

**Goal:** Carve `Sources/editor/kit/` out of the Map Editor as a reusable, engine-bridge-free editor plumbing library (files + shipped + script_file + autosave + history-stack primitive + settings primitive + host + crt + imgui wrapper + BK_EDITOR_AUTO schedule driver + pictures-cache + testlaunch), cut MapEditor onto it with no behaviour change, and prove green with every MapEditor tier passing on this Linux machine; macOS + Windows parity is CI-verified on push, never claimed from the Linux session.
**Demo:** `Sources/editor/kit/` exists and compiles independently. MapEditor is cut over to import from the kit. On this Linux machine: every MapEditor tier (`test-editor-core`, `test-map-editor-view`, `test-map-editor-panels`, `test-map-editor-testlaunch`, `test-map-editor-auto`, `test-map-editor-engine`, `test-editor-bridge`, `map-editor-host-check`, `map-editor-smoke`, `map-editor-auto`, `map-editor-auto-m2`, `map-editor-m3-auto`, `map-editor-game-reads-it-m3`) is green. CI shows the same green on macOS + Windows after push.

## Must-Haves

- (1) `Sources/editor/kit/` exists with its own `root.zig`, builds as an independent Zig module (`editor_kit`), has its own `test-editor-kit` build step that runs green on Linux. (2) `Sources/editor/core/` compiles after `files`, `shipped`, `script_file`, `autosave`, the generic save-mark stack, and the generic settings primitive are moved into the kit and re-imported from there — map-specific `history` Command union and `settings` map/layer sections remain in the core (or a new app-side module), map-domain modules (bridge/records/editor/tools_*/filters/layers/rmg/composers) stay unchanged in core. (3) `Sources/editor/app/` imports host/crt/imgui/pictures-cache/auto-schedule/testlaunch from the kit; the MapEditor-specific action dispatch, panels, view, markers, minimap, smoke, game-reads, main stay in app. (4) MapEditor binary (`install-map-editor`) builds and installs on Linux x64 via `zig build install-game install-map-editor`. (5) All 13 MapEditor tiers run green on Linux: `test-editor-core`, `test-map-editor-view`, `test-map-editor-panels`, `test-map-editor-testlaunch`, `test-map-editor-auto`, `test-map-editor-engine`, `test-editor-bridge`, `map-editor-host-check`, `map-editor-smoke`, `map-editor-auto`, `map-editor-auto-m2`, `map-editor-m3-auto`, `map-editor-game-reads-it-m3`. The 8 pre-existing BkEditorOpenMap-dependent failures from S01's sweep remain owned by S04/S13 and are not re-introduced from a new source. (6) `Sources/editor/kit/README.md` documents the kit's public API surface so S03..S15 can import from it without reading implementation. (7) A Linux sweep log at `zig-out/local-test/resource_editor/s02-sweep.log` records tier-by-tier verdicts for all 13 MapEditor tiers plus `test-editor-kit`.

## Proof Level

- This slice proves: integration — real builds and real tier runs on Linux; no mocks of the host; MapEditor behaviour unchanged is the oracle. macOS + Windows cross-platform.yml is the final cross-arch gate but is CI-only (not claimed from this session).

## Integration Closure

Upstream surfaces consumed: `Sources/editor/core/*.zig` (today's layout), `Sources/editor/app/*.zig` (today's layout), `build.zig` module/step definitions for `editor_core`, `editor_imgui`, `install-map-editor`, and all map-editor tier steps. New wiring introduced in this slice: `Sources/editor/kit/root.zig` + per-module files, new `editor_kit` module in `build.zig`, new `test-editor-kit` step, `editor_core_module` and the MapEditor app module both pick up an `.imports` entry for `editor_kit`, every moved file's internal `@import("files.zig")`/etc. rewired to `editor_kit`'s API. What remains before the milestone is truly usable end-to-end: S03's ResourceModel still has to be built on top of the kit (the kit must be the common lower half), S04's resource bridge still has to be designed, S05's ResourceEditor app has to be scaffolded on the kit; S02 only proves the kit shape works for the MapEditor.

## Verification

- Sweep log at `zig-out/local-test/resource_editor/s02-sweep.log` prints one line per tier with its exit code, the test-editor-kit timing, and a diff vs. the S01 sweep baseline (same stable 8-failure footprint on BkEditorOpenMap, no new reds). BK_DEBUG_LOG=1 is set when running tiers that take `DebugTrace` output. Kit-side failure modes are visible through the same mechanism MapEditor already uses: `host.failureReason()`, autosave `due`/`target` log lines, `files.lastError()`. No new runtime signals are introduced; the slice preserves the existing surfaces.

## Tasks

- [x] **T01: Scaffold Sources/editor/kit/ and wire the editor_kit module into build.zig alongside editor_core** `est:45m`
  Why: Every other task in this slice moves code into `Sources/editor/kit/`; the module needs to exist first with a build-step that compiles the empty root and runs an empty test tier green on Linux. Without this, every move is also a build.zig edit.
  - Files: `Sources/editor/kit/root.zig`, `build.zig`
  - Verify: zig build test-editor-kit test-editor-core install-game install-map-editor

- [x] **T02: Move the leaf primitives (files, shipped, script_file, autosave) into the kit with no map-specific coupling** `est:1h30m`
  Why: These four files have no map-domain imports (files/shipped/script_file reach only `std`/`builtin`/each other; autosave reaches only `std`). They are the safest first move and prove the kit's public API shape before anything coupled is touched.
  - Files: `Sources/editor/kit/files.zig`, `Sources/editor/kit/shipped.zig`, `Sources/editor/kit/script_file.zig`, `Sources/editor/kit/autosave.zig`, `Sources/editor/kit/root.zig`, `Sources/editor/core/root.zig`
  - Verify: zig build test-editor-kit test-editor-core install-game install-map-editor map-editor-smoke map-editor-auto

- [x] **T03: Carve a generic save-mark+stack primitive and a generic settings primitive out of history.zig and settings.zig** `est:3h`
  Why: R001 names history/undo and settings as kit material, but today's `history.zig` imports `bridge.ObjectRecord`/`SoundRecord`/`records` and defines a map-specific Command union; today's `settings.zig` imports `layers` and holds 50+ layer references alongside generic fields (scroll speed, autosave on/off, maps folder, recent-files list, format enum). The split keeps the map-specific union/sections where they belong and lifts only the reusable primitive into the kit.
  - Files: `Sources/editor/kit/history.zig`, `Sources/editor/kit/settings.zig`, `Sources/editor/kit/root.zig`, `Sources/editor/core/history.zig`, `Sources/editor/core/settings.zig`, `Sources/editor/core/root.zig`
  - Verify: zig build test-editor-kit test-editor-core test-map-editor-panels install-game install-map-editor map-editor-m3-auto

- [x] **T04: Move the app-level kit pieces (host, crt, imgui wrapper, auto-schedule, pictures-cache, testlaunch) into the kit** `est:4h`
  Why: R001 names host, Windows CRT and console, ImGui backend, BK_EDITOR_AUTO parser/driver/TGA compare, picture cache, and testlaunch as kit material. The MapEditor app keeps its scenario dispatch (`tool=`, `do=<named_cmd>`), its panels, markers, view, minimap, smoke, game-reads, and main.
  - Files: `Sources/editor/kit/host.zig`, `Sources/editor/kit/crt.zig`, `Sources/editor/kit/testlaunch.zig`, `Sources/editor/kit/auto_schedule.zig`, `Sources/editor/kit/pictures_cache.zig`, `Sources/editor/kit/imgui/imgui.zig`, `Sources/editor/kit/imgui/imgui_backend.cpp`, `Sources/editor/kit/imgui/imgui_backend.h`, `Sources/editor/kit/root.zig`, `Sources/editor/app/auto.zig`, `Sources/editor/app/pictures.zig`, `build.zig`
  - Verify: zig build install-game install-map-editor test-editor-kit test-editor-core test-map-editor-view test-map-editor-panels test-map-editor-testlaunch test-map-editor-auto map-editor-host-check map-editor-smoke map-editor-auto

- [x] **T05: Document the kit public API in Sources/editor/kit/README.md and cut remaining MapEditor imports to the kit namespace** `est:2h`
  Why: S03..S15 depend on reading the kit's public API without re-reading implementation. The README is the kit's contract. This task also finishes the switchover: any `app/*.zig` that still reaches into `editor_core` for things that are now in the kit (`core.files`, `core.shipped`, `core.autosave`, `core.history`, `core.settings`, and the formerly in-app `host`/`crt`/`auto`/`pictures`/`testlaunch`/`imgui`) is rewritten to `editor_kit` directly so the dependency direction is explicit.
  - Files: `Sources/editor/kit/README.md`, `Sources/editor/core/root.zig`, `Sources/editor/app/main.zig`, `Sources/editor/app/panels.zig`, `Sources/editor/app/panels_logic.zig`, `Sources/editor/app/panels_m2.zig`, `Sources/editor/app/panels_m3.zig`, `Sources/editor/app/commands.zig`, `Sources/editor/app/smoke.zig`, `Sources/editor/app/view.zig`, `Sources/editor/app/markers.zig`, `Sources/editor/app/minimap.zig`, `Sources/editor/app/game_reads_common.zig`, `Sources/editor/app/game_reads_m2.zig`, `Sources/editor/app/game_reads_m3.zig`, `Sources/editor/app/c_bridge.zig`, `Sources/editor/app/c_bridge_test.zig`
  - Verify: zig build test-editor-kit test-editor-core test-map-editor-view test-map-editor-panels install-game install-map-editor

- [x] **T06: Run the full S02 Linux sweep (test-editor-kit + 13 MapEditor tiers) and record a diff vs. the S01 baseline** `est:1h`
  Why: S02 is only green when every MapEditor tier runs with the same red/green profile as S01's sweep PLUS the new `test-editor-kit` tier passes. A regression that is "a new red" vs. S01 is a slice failure; a stable red carried over from S01 (the 8 BkEditorOpenMap-dependent tiers blocked by the pre-existing AIWarFog::SetZero nullptr-memset trap) is not.
  - Files: `tools/zig/run-s02-sweep.sh`, `zig-out/local-test/resource_editor/s02-sweep.log`
  - Verify: bash tools/zig/run-s02-sweep.sh && test -s zig-out/local-test/resource_editor/s02-sweep.log && grep -q 'S02 VERDICT=PASS' zig-out/local-test/resource_editor/s02-sweep.log

## Files Likely Touched

- Sources/editor/kit/root.zig
- build.zig
- Sources/editor/kit/files.zig
- Sources/editor/kit/shipped.zig
- Sources/editor/kit/script_file.zig
- Sources/editor/kit/autosave.zig
- Sources/editor/core/root.zig
- Sources/editor/kit/history.zig
- Sources/editor/kit/settings.zig
- Sources/editor/core/history.zig
- Sources/editor/core/settings.zig
- Sources/editor/kit/host.zig
- Sources/editor/kit/crt.zig
- Sources/editor/kit/testlaunch.zig
- Sources/editor/kit/auto_schedule.zig
- Sources/editor/kit/pictures_cache.zig
- Sources/editor/kit/imgui/imgui.zig
- Sources/editor/kit/imgui/imgui_backend.cpp
- Sources/editor/kit/imgui/imgui_backend.h
- Sources/editor/app/auto.zig
- Sources/editor/app/pictures.zig
- Sources/editor/kit/README.md
- Sources/editor/app/main.zig
- Sources/editor/app/panels.zig
- Sources/editor/app/panels_logic.zig
- Sources/editor/app/panels_m2.zig
- Sources/editor/app/panels_m3.zig
- Sources/editor/app/commands.zig
- Sources/editor/app/smoke.zig
- Sources/editor/app/view.zig
- Sources/editor/app/markers.zig
- Sources/editor/app/minimap.zig
- Sources/editor/app/game_reads_common.zig
- Sources/editor/app/game_reads_m2.zig
- Sources/editor/app/game_reads_m3.zig
- Sources/editor/app/c_bridge.zig
- Sources/editor/app/c_bridge_test.zig
- tools/zig/run-s02-sweep.sh
- zig-out/local-test/resource_editor/s02-sweep.log
