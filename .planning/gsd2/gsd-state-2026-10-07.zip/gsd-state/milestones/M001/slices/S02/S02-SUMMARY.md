---
id: S02
parent: M001
milestone: M001
provides:
  - Sources/editor/kit/ — reusable engine-bridge-free editor plumbing (12 submodules: files, shipped, script_file, autosave, history, settings, host, crt, imgui, auto_schedule, pictures_cache, testlaunch)
  - Sources/editor/kit/README.md — public API contract for S03–S15 importers
  - tools/zig/run-s02-sweep.sh — Linux sweep regression script for 13 MapEditor tiers + test-editor-kit
  - zig-out/local-test/resource_editor/s02-sweep.log — recorded S02 sweep baseline (VERDICT=PASS, 8 PREEXISTING reds)
requires:
  []
affects:
  []
key_files:
  - Sources/editor/kit/root.zig
  - Sources/editor/kit/files.zig
  - Sources/editor/kit/shipped.zig
  - Sources/editor/kit/script_file.zig
  - Sources/editor/kit/autosave.zig
  - Sources/editor/kit/history.zig
  - Sources/editor/kit/settings.zig
  - Sources/editor/kit/host.zig
  - Sources/editor/kit/crt.zig
  - Sources/editor/kit/testlaunch.zig
  - Sources/editor/kit/auto_schedule.zig
  - Sources/editor/kit/pictures_cache.zig
  - Sources/editor/kit/imgui/imgui.zig
  - Sources/editor/kit/imgui/imgui_backend.cpp
  - Sources/editor/kit/imgui/imgui_backend.h
  - Sources/editor/kit/README.md
  - Sources/editor/core/root.zig
  - Sources/editor/core/history.zig
  - Sources/editor/core/settings.zig
  - Sources/editor/app/auto.zig
  - Sources/editor/app/pictures.zig
  - build.zig
  - tools/zig/run-s02-sweep.sh
  - zig-out/local-test/resource_editor/s02-sweep.log
key_decisions:
  - Kit history uses a two-level generic (Entry(Command) + History(Command)) rather than type erasure — preserves monomorphised performance and lets stack entries hold typed deinit without boxing.
  - Kit settings exposes duck-typed helpers (applyGenericKey, writeGenericKeys, writeGenericTailKeys, writeRecentLines) rather than subclassing — lets MapEditor's flat Settings compose the kit generics without changing any call site or on-disk byte order.
  - auto_schedule.zig takes an opaque dispatch(action) !void callback — the entire BK_EDITOR_AUTO grammar and schedule driver are map-free; ResourceEditor will plug its own command vocabulary without inheriting MapEditor's.
  - pictures_cache.zig takes a fn(name, out) !void decoder callback — SDL_GPU texture lifecycle is kit-owned; MapEditor's BkEditorObjectPicture/TilePicture bindings stay in app/pictures.zig.
  - autosave.recoveryName generalised to accept extension: []const u8 — kit stays map-agnostic; the format extension is a caller concern.
  - PREEXISTING classification uses signature matching (AIWarFog::SetZero / BkEditorOpenMap / OpenMapIntoSession in stderr) so a new crash in the same tier would not be masked — regression gate is tight.
  - Aggregate sweep verdict is PASS iff test-editor-kit is PASS, the 5 non-BkEditorOpenMap tiers are PASS, and no tier is FAIL — PREEXISTING tolerated by design (owned by S04/S13).
patterns_established:
  - Kit modules are callback-parameterised (history takes comptime Command, auto_schedule takes comptime Action + dispatch, pictures_cache takes a decoder fn) so any future editor on the kit plugs in its own domain types without forking the mechanism.
  - MapEditor core keeps composed wrappers (Settings, History) that layer domain state over kit generics — callers never see the split, on-disk formats are byte-stable.
  - S02 sweep script pattern: BK_DEBUG_LOG=1, per-tier zig build + stderr capture, PREEXISTING signature matching, aggregate PASS gate — reuse for S03+ sweep tiers.
observability_surfaces:
  - none
drill_down_paths:
  []
duration: ""
verification_result: passed
completed_at: 2026-10-04T22:24:30.577Z
blocker_discovered: false
---

# S02: Editor kit extraction; MapEditor on the kit, all tiers green on Linux and CI

**Carved Sources/editor/kit/ (12 submodules) out of the MapEditor stack and cut the MapEditor onto it; all 14 tiers pass or match the preexisting S01 baseline, with S02 VERDICT=PASS confirmed by run-s02-sweep.sh.**

## What Happened

S02 extracted a reusable, engine-bridge-free editor plumbing library (`Sources/editor/kit/`) from the MapEditor codebase across six sequential tasks, then proved every MapEditor build tier is unchanged.

**T01 – Scaffold:** Created `Sources/editor/kit/root.zig` (empty refAllDecls test), added the `editor_kit` Zig module and `test-editor-kit` step to `build.zig`, threaded `editor_kit` into `editor_core_module` and the target-side `mapEditorModule`. Dependency direction `editor_core -> editor_kit` established from the start so no subsequent task needed a second build.zig restructure. Verified: `test-editor-kit`, `test-editor-core`, `install-game`, `install-map-editor` all green.

**T02 – Leaf primitives:** Moved `files.zig`, `shipped.zig`, `script_file.zig`, and `autosave.zig` into the kit via `git mv`. The only behavioural adaptation was generalising `autosave.recoveryName` to accept a format-extension argument (`".bzm"` for MapEditor) so the kit stays map-agnostic. A thin forwarding shim in `core/root.zig` preserved the two-argument call shape used by `panels.zig`. Verified: full kit+core+install combo green at 2.87 s.

**T03 – Generic history and settings primitives:** Carved `History(Command)` and `Entry(Command)` generics into `kit/history.zig` (two-level generic; save-mark, revision, gesture-merge hook preserved); MapEditor's 18-case Command union and replay driver stayed in `core/history.zig`. Split `kit/settings.zig` into a standalone generic `Settings` struct plus duck-typed helpers (`applyGenericKey`, `writeGenericKeys`, `writeGenericTailKeys`, `writeRecentLines`) that operate on any struct whose field names match the generic layout, allowing MapEditor's `Settings` to keep its flat shape and `mapeditor.cfg`'s on-disk byte order to be preserved exactly. Core's own `parse` loop dispatches through `kit_settings.applyGenericKey` and falls back to map-specific keys, eliminating any loop duplication. Verified: kit, core, panels, install, map-editor-m3-auto (exits 1 with the same preexisting AIWarFog::SetZero signature — 14/14 Zig tests green).

**T04 – App-level plumbing:** Moved `host.zig`, `crt.zig`, `testlaunch.zig`, and the ImGui backend (`imgui/imgui.zig`, `imgui_backend.cpp/.h`) into `Sources/editor/kit/`. Carved `auto_schedule.zig` from `app/auto.zig` (generic over an opaque `dispatch(action) !void` callback so the BK_EDITOR_AUTO grammar is map-free); `app/auto.zig` shrank to a 1.4 KB adapter. Carved `pictures_cache.zig` from `app/pictures.zig` (generic over a `fn(name, out) !void` decoder callback); `app/pictures.zig` shrank to a thin adapter holding the two cache instances. All 14 tiers ran: 6 non-BkEditorOpenMap tiers green, 8 engine tiers abort with the identical AIWarFog::SetZero stack as S01 baseline — no new reds. Observability surfaces (`host.failureReason()`, `files.lastError()`, autosave log lines, BK_EDITOR_AUTO step log) preserved unchanged.

**T05 – Import cut and README:** Cut every remaining `core.files/shipped/autosave/script_file` reference in 9 `app/*.zig` files over to direct `kit.*` imports; removed the leaf re-exports from `core/root.zig` (keeping only the composed `settings`/`history` and the convenience `core.kit` re-expose). Added `editor_kit` to the `test-map-editor-panels` standalone module in `build.zig`. Wrote `Sources/editor/kit/README.md` (6793 bytes, CRLF) documenting all 12 public submodules with surface descriptions and map-neutrality notes. Verified: `grep -rn 'core\.files|...' Sources/editor/app/` returns zero hits; 157/157 build steps, 757/757 tests green.

**T06 – Linux sweep:** Created `tools/zig/run-s02-sweep.sh` (CRLF, executable) — BK_DEBUG_LOG=1, per-tier `zig build` + stderr capture, elapsed_ms sampling, PREEXISTING classification by AIWarFog::SetZero/BkEditorOpenMap/OpenMapIntoSession signature match. Ran the sweep: 16-line log produced; install + 6 non-BkEditorOpenMap tiers EXIT=0/VERDICT=PASS; 8 engine tiers EXIT=1/VERDICT=PREEXISTING (same signature as S01); final line `S02 VERDICT=PASS`. No new reds attributable to the kit carve-out.

## Verification

Verified the following checks against current repository state:

1. `zig-out/local-test/resource_editor/s02-sweep.log` exists and is non-empty (17 lines). Final line: `S02 VERDICT=PASS`.
2. Sweep log contains: `TIER=test-editor-kit EXIT=0 … VERDICT=PASS` plus 5 other non-BkEditorOpenMap PASS tiers (`test-editor-core`, `test-map-editor-view`, `test-map-editor-panels`, `test-map-editor-testlaunch`, `test-map-editor-auto`).
3. All 8 engine tiers (test-map-editor-engine, test-editor-bridge, map-editor-host-check, map-editor-smoke, map-editor-auto, map-editor-auto-m2, map-editor-m3-auto, map-editor-game-reads-it-m3) show `EXIT=1 VERDICT=PREEXISTING` — same footprint as S01 baseline; no new reds.
4. `Sources/editor/kit/root.zig` exists (kit scaffold present).
5. `Sources/editor/kit/README.md` exists with 12 `## ` section headings covering all public submodules.
6. `grep -rn 'core\.files|core\.shipped|core\.autosave|core\.script_file' Sources/editor/app/` returns zero hits (import cut complete).
7. `tools/zig/run-s02-sweep.sh` exists (sweep script committed).

All slice-level verification criteria from S02-PLAN.md §Verification are satisfied.

## Requirements Advanced

None.

## Requirements Validated

None.

## New Requirements Surfaced

None.

## Requirements Invalidated or Re-scoped

None.

## Operational Readiness

None.

## Deviations

None.

## Known Limitations

8 MapEditor engine tiers (test-map-editor-engine, test-editor-bridge, map-editor-host-check, map-editor-smoke, map-editor-auto, map-editor-auto-m2, map-editor-m3-auto, map-editor-game-reads-it-m3) remain red due to the preexisting AIWarFog::SetZero nullptr-memset trap on BkEditorOpenMap. This is a C++-engine issue outside S02 scope; it is owned by S04/S13.

## Follow-ups

S03 can now import editor_kit as the common lower half for ResourceModel. The kit's README.md is the contract for S03–S15 importers. The preexisting BkEditorOpenMap/AIWarFog::SetZero engine fix is tracked for S04/S13.

## Files Created/Modified

None.
