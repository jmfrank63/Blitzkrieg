# S02: Editor kit extraction; MapEditor on the kit, all tiers green on Linux and CI — UAT

**Milestone:** M001
**Written:** 2026-10-04T22:24:30.578Z

# S02 UAT

## UAT Type
Integration UAT — proves the extracted `editor_kit` module compiles independently, the MapEditor cut-over is complete, and no MapEditor tier regresses vs. the S01 baseline.

## Preconditions
- Linux x64 machine with Zig 0.16, SDL2/SDL_GPU, and the full Blitzkrieg repo checked out on `feat/resource-editor`.
- `zig-out/local-test/resource_editor/s01-sweep.log` exists as the baseline reference (produced by S01's sweep task).
- No uncommitted changes to `Sources/editor/kit/`, `Sources/editor/core/`, `Sources/editor/app/`, or `build.zig`.

## Steps and Expected Outcomes

1. **Build and install the MapEditor binary.**
   ```
   zig build install-game install-map-editor
   ```
   Expected: exit 0. `zig-out/game/linux/x86_64/release/MapEditor` is present.

2. **Run the editor-kit unit tests.**
   ```
   zig build test-editor-kit
   ```
   Expected: exit 0. All kit submodule tests green (files, shipped, script_file, autosave, history generics, settings generics).

3. **Run the editor-core unit tests.**
   ```
   zig build test-editor-core
   ```
   Expected: exit 0. All MapEditor-specific tests (Command union, composed settings/history, settings round-trip, WR-B03 newline handling) green.

4. **Run the non-BkEditorOpenMap MapEditor tiers.**
   ```
   zig build test-map-editor-view test-map-editor-panels test-map-editor-testlaunch test-map-editor-auto
   ```
   Expected: all exit 0.

5. **Run the full S02 sweep script.**
   ```
   bash tools/zig/run-s02-sweep.sh
   ```
   Expected: stdout ends with `S02 VERDICT=PASS`; `zig-out/local-test/resource_editor/s02-sweep.log` has 16+ lines; 6+ EXIT=0 rows; 8 PREEXISTING rows matching the AIWarFog::SetZero/BkEditorOpenMap signature; no FAIL rows.

6. **Confirm no `core.leaf` references remain in app/.**
   ```
   grep -rn 'core\.files\|core\.shipped\|core\.autosave\|core\.script_file' Sources/editor/app/
   ```
   Expected: zero matches.

7. **Confirm README has 12 section headings.**
   ```
   grep -c '^## ' Sources/editor/kit/README.md
   ```
   Expected: 12.

## Edge Cases
- If `zig build test-editor-kit` fails, the kit root.zig or a submodule has a compile error — investigate `Sources/editor/kit/`.
- If any of the 6 non-BkEditorOpenMap tiers exits non-zero, that is a regression introduced by S02 and blocks completion.
- If a BkEditorOpenMap tier exits non-zero with a **new** stderr signature (not AIWarFog::SetZero / BkEditorOpenMap / OpenMapIntoSession), it is also a regression — the sweep script classifies it as FAIL rather than PREEXISTING.

## Not Proven By This UAT
- macOS arm64 and Windows MSVC cross-platform correctness — verified by CI `.github/workflows/cross-platform.yml` after push; not claimable from this Linux session.
- The BkEditorOpenMap / AIWarFog::SetZero engine bug fix — owned by S04/S13.
- ResourceEditor app functionality — not built until S05.
- Import of `editor_kit` from the yet-to-be-built `ResourceModel` (S03) or `resource_core` (S04).
