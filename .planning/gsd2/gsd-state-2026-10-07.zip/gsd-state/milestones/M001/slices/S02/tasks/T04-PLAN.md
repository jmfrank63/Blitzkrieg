---
estimated_steps: 3
estimated_files: 12
skills_used: []
---

# T04: Move the app-level kit pieces (host, crt, imgui wrapper, auto-schedule, pictures-cache, testlaunch) into the kit

Why: R001 names host, Windows CRT and console, ImGui backend, BK_EDITOR_AUTO parser/driver/TGA compare, picture cache, and testlaunch as kit material. The MapEditor app keeps its scenario dispatch (`tool=`, `do=<named_cmd>`), its panels, markers, view, minimap, smoke, game-reads, and main.

Do: `git mv Sources/editor/app/host.zig Sources/editor/kit/host.zig`; `git mv Sources/editor/app/crt.zig Sources/editor/kit/crt.zig`; `git mv Sources/editor/app/testlaunch.zig Sources/editor/kit/testlaunch.zig`; move the imgui wrapper (`Sources/editor/imgui/imgui.zig` + the backend `.cpp`/`.h`) under `Sources/editor/kit/imgui/` — the existing `editor_imgui` build-time module continues to point at the new path. For `auto.zig`: carve the pure parser + synthetic-event schedule driver + TGA compare into `Sources/editor/kit/auto_schedule.zig` (grammar, action enum, step driver signature over an opaque "dispatch(action)" callback); keep the MapEditor's `tool=label` dispatch and its `do=<named_cmd>` handlers in `Sources/editor/app/auto.zig`, now a thin adapter that imports the kit's schedule driver and plugs in MapEditor-specific actions. For `pictures.zig`: carve `Sources/editor/kit/pictures_cache.zig` holding the SDL_GPU texture entries + queue + per-frame budget pump + clear/deinit, generic over a `fn (name: []const u8, out: *Decoded) !void` decoder callback; keep MapEditor's `BkEditorObjectPicture`/`BkEditorTilePicture` bindings and its two cache instances in `Sources/editor/app/pictures.zig`, now a thin adapter. Rewire `build.zig`: `addMapEditor`/`mapEditorModule` imports pick up `editor_kit`, the view/panels_logic/testlaunch/auto standalone test modules (around build.zig:2803-2855) also pick up `editor_kit` where they already pick up `editor_core`. `editor_imgui` module path updated. CRLF preserved.

Done when: `zig build install-game install-map-editor` exits 0 on Linux, `test-map-editor-testlaunch`, `test-map-editor-auto`, `test-map-editor-view`, `test-map-editor-panels` all exit 0, and `map-editor-host-check` + `map-editor-smoke` + `map-editor-auto` + `map-editor-auto-m2` + `map-editor-m3-auto` all run with the same red/green profile as S01's sweep (specifically: the host-check and smoke must stay green — they exercise the moved host.zig and testlaunch.zig most directly).

## Inputs

- `Sources/editor/app/host.zig`
- `Sources/editor/app/crt.zig`
- `Sources/editor/app/testlaunch.zig`
- `Sources/editor/app/auto.zig`
- `Sources/editor/app/pictures.zig`
- `Sources/editor/imgui/imgui.zig`
- `Sources/editor/imgui/imgui_backend.cpp`
- `Sources/editor/imgui/imgui_backend.h`
- `Sources/editor/kit/root.zig`
- `build.zig`

## Expected Output

- `Sources/editor/kit/host.zig`
- `Sources/editor/kit/crt.zig`
- `Sources/editor/kit/testlaunch.zig`
- `Sources/editor/kit/auto_schedule.zig`
- `Sources/editor/kit/pictures_cache.zig`
- `Sources/editor/kit/imgui/imgui.zig`
- `Sources/editor/kit/imgui/imgui_backend.cpp`
- `Sources/editor/kit/imgui/imgui_backend.h`
- `Sources/editor/kit/root.zig`
- `Sources/editor/app/auto.zig`
- `Sources/editor/app/pictures.zig`
- `build.zig`

## Verification

zig build install-game install-map-editor test-editor-kit test-editor-core test-map-editor-view test-map-editor-panels test-map-editor-testlaunch test-map-editor-auto map-editor-host-check map-editor-smoke map-editor-auto

## Observability Impact

No new runtime signals. Preserves existing surfaces: `host.failureReason()`, autosave `due`/`target` log lines, `files.lastError()`, BkEditorLastMessage via host, and BK_EDITOR_AUTO's step log through the moved schedule driver.
