---
id: T01
parent: S02
milestone: M001
key_files:
  - Sources/editor/kit/root.zig
  - Sources/editor/core/root.zig
  - build.zig
key_decisions:
  - kit root.zig starts empty (only the refAllDecls test) rather than pre-declaring `pub const` slots for the yet-to-move submodules — Zig would fail to compile unresolved @imports, and every later S02 move task has to touch root.zig anyway to add its re-export.
  - editor_core imports editor_kit (not the other way) at both host and target: dependency direction `editor_core -> editor_kit` is set now so later moves don't need a second build.zig edit per submodule.
  - The target-side kit_module is threaded through `mapEditorModule`'s signature as an explicit parameter rather than captured from a closure — the two call sites (`main.zig` and `c_bridge_test.zig`) stay consistent and future tiers that call mapEditorModule will be forced to pass it.
  - Only addEditor/MapEditor call sites of editor_core got the editor_kit import added. The host panels_logic_module was left alone — the task plan scopes imports to `addEditor/MapEditor functions`, and no panels_logic code moves in T01.
duration: 
verification_result: passed
completed_at: 2026-10-04T21:39:26.000Z
blocker_discovered: false
---

# T01: Scaffolded Sources/editor/kit/ with an empty root.zig and wired editor_kit into build.zig alongside editor_core, giving green test-editor-kit + test-editor-core + install-game + install-map-editor on Linux x64.

**Scaffolded Sources/editor/kit/ with an empty root.zig and wired editor_kit into build.zig alongside editor_core, giving green test-editor-kit + test-editor-core + install-game + install-map-editor on Linux x64.**

## What Happened

T01 only had to prove the kit scaffold compiles — no code moves, no behaviour change — so later S02 tasks can land each submodule move as a one-file edit plus a `pub const` re-export in `Sources/editor/kit/root.zig`.

Created `Sources/editor/kit/root.zig` with CRLF line endings and a short "why" doc comment (reusable editor plumbing, no engine bridge, dependency direction `editor_core -> editor_kit`), containing only `test { @import("std").testing.refAllDecls(@This()); }` so the kit tier passes with no submodules yet.

In `build.zig`:
- Added `editor_kit_module` next to `editor_core_module` at the top of the host-only editor test block (near line 2788), built against `b.graph.host` + `.Debug` the same way `editor_core_module` is.
- Added a new `test-editor-kit` build step that mirrors `test-editor-core`: `addTest` → `addRunArtifact`, step name, `if (test_mode == .run) step.dependOn(&run.step)`, and attached to the aggregate `test` step.
- Added `.imports = &.{.{ .name = "editor_kit", .module = editor_kit_module }}` on `editor_core_module` so later tasks can re-point core submodules at the kit without a second build.zig edit, and so the kit is importable from `Sources/editor/core/root.zig`.
- Inside `addMapEditor` added a target-built `kit_module` sibling of `core_module`, imported it into `view_test_module` next to `editor_core`, and threaded it through `mapEditorModule`'s signature (new `kit_module: *std.Build.Module` parameter) + both call sites (`Sources/editor/app/main.zig` and `Sources/editor/app/c_bridge_test.zig`). The target `core_module` also gained `editor_kit` in its `.imports`, matching the host side.

In `Sources/editor/core/root.zig` added `pub const kit = @import("editor_kit");` right after the module doc comment, proving the kit is importable from core (the Done-when criterion). The core module's existing submodule imports are untouched; later tasks will replace individual `@import("foo.zig")` lines with `kit.foo` as code moves.

CRLF preserved on both new/edited files (verified via `file`).

The task plan's "no file moves in this task" was respected — this change is purely scaffold + wiring.

## Verification

Ran the task plan's three verification commands on this Linux x64 machine:
1. `zig build test-editor-kit` → exit 0 (new tier green with empty-but-importable kit).
2. `zig build test-editor-core` → exit 0 (core still green after gaining the `editor_kit` import).
3. `zig build install-game install-map-editor` → exit 0 (unchanged behaviour; MapEditor binary written to `zig-out/game/linux/x86_64/release/MapEditor`).

Also ran `zig build test-editor-kit test-editor-core` together (0.78s, exit 0) to confirm both tiers co-exist. The kit is importable from `Sources/editor/core/root.zig` via `pub const kit = @import("editor_kit");` — the import compiles cleanly through both the host-only core module and the target core_module inside addMapEditor.

Did not run macOS or Windows tiers — this machine is Linux and the AGENTS.md rule is to never claim CI-only results. CI's cross-platform workflow verifies those on push.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-editor-kit` | 0 | pass | 600ms |
| 2 | `zig build test-editor-core` | 0 | pass | 500ms |
| 3 | `zig build install-game install-map-editor` | 0 | pass | 4689ms |
| 4 | `zig build test-editor-kit test-editor-core` | 0 | pass | 783ms |

## Deviations

None. The task plan's three-step scaffold matched exactly what landed: create kit root.zig, add module + test step to build.zig, add editor_kit import to editor_core_module. The only addition the plan did not spell out literally was threading kit_module through mapEditorModule's signature; that was implied by "import it everywhere `editor_core_module` is already imported in build.zig's addEditor/MapEditor functions" and the only way to reach the two mapEditorModule call sites without duplicating the import list.

## Known Issues

None. The scaffold is empty by design; later S02 tasks will add submodule content. The `test-editor-kit` tier currently exercises only refAllDecls on an empty module (a trivial pass); it will become meaningful as submodules land.

## Files Created/Modified

- `Sources/editor/kit/root.zig`
- `Sources/editor/core/root.zig`
- `build.zig`
