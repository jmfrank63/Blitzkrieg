---
id: T04
parent: S03
milestone: M001
key_files:
  - Sources/src/ResourceModel/references.h
  - Sources/src/ResourceModel/references.cpp
  - Sources/src/ResourceModel/combos.h
  - Sources/src/ResourceModel/combos.cpp
  - Sources/src/ResourceModel/localization.h
  - Sources/src/ResourceModel/localization.cpp
  - tools/zig/resource_model_references_test.cpp
  - tools/zig/fixtures/resource_editor/references_root/
  - build.zig
key_decisions:
  - References stores every per-type list as a vector of plain std::string in the original file-case; matching is done against a lower-cased backslash-form copy. Reasoning: the MFC picker displayed the file's own spelling, and the project XML stored exactly what the picker chose; a case-folding store would silently change serialised bytes.
  - The MFC InitLists per-type if/else chain is replaced by a single data-driven SRule table (type, {dirs}, ext, stripDir) with three inline special cases (asks' one-level-deep rule, road textures' roads3d/ sub-dir, sounds/soldiers from the IObjectsDB). Reasoning: 13 of the 20 types share the same (parent-dir + extension) shape, so one iteration-of-files * iteration-of-rules keeps the port shorter than MFC and keeps the three idiosyncratic rules at eye-height instead of buried in a 150-line switch.
  - playerSides() exposes both a static fallback table and a readPlayerSides(partys.xml) parser rather than making the fallback the only path. Reasoning: MFC read partys.xml at run time via engine singletons; the test harness and S04 bridge both need a cheap stand-in for when no Data root is loaded, but S07's comparator still has to see the real partys.xml names when they are present, so both surfaces are kept side-by-side.
  - loadLocalization() returns raw bytes with no re-encoding and matches file names case-insensitively via a directory_iterator scan. Reasoning: the comparator plan treats localization bytes as opaque (the editor never introspected them beyond file existence), and Linux doesn't fold case, so a Stats.TXT fixture entry has to resolve to the stats.txt lookup to prove the Linux pitfall is handled.
duration: 
verification_result: passed
completed_at: 2026-10-04T23:46:14.440Z
blocker_discovered: false
---

# T04: Ported EReferenceType (20), AI-class + player-sides combos, and CLocalizationItem into Sources/src/ResourceModel/{references,combos,localization}, with tracked references_root fixture and test-resource-model-references green on Linux.

**Ported EReferenceType (20), AI-class + player-sides combos, and CLocalizationItem into Sources/src/ResourceModel/{references,combos,localization}, with tracked references_root fixture and test-resource-model-references green on Linux.**

## What Happened

T04 wires the three data-list surfaces every per-sub-editor picker in S05..S15 reads from. The port is MFC-free C++17 and lives entirely under Sources/src/ResourceModel/, so S04's EditorBridge can expose it without reaching back into Sources/src/editor/.

The EReferenceType enumeration from RefDlg.h:9 lands as `enum class EReferenceType : int` in references.h with the same 20 names and the same order (E_ANIMATIONS_REF=0 .. E_WATER_TEXTURE_REF=19). ReferenceTypeName() gives the symbolic name for the per-type log line.

InitLists' per-type IDataStorage scan is ported to References::rebuild(dataRoot) as a single recursive_directory_iterator pass with std::filesystem. The matching rule is data-driven: a vector of SRule {type, {dirs}, ext, stripDir} drives the common (parent-dir + extension) cases; the three MFC special-cases (asks' one-level-deep sounds\ack\<group>\<name>.xml, road textures' terrain\sets\<set>\roads3d\..._h.dds, and the IObjectsDB-sourced sounds/soldiers lists) stay inline. Each file's relative path is lower-cased with backslashes to match the MFC storage form for matching, but stored in its original case so a picker preserves the file's own spelling; de-duplication is linear-scan via std::find (lists stay tiny). E_ACTIONS_REF has no file-system list - it is the MultiSelDialog combo in MFC - so its vector stays empty by design (count=0 in the log, which is the signal a future agent needs that no file-system picker will populate it).

Combos: aiClasses() returns {"wheel","halftrack","track","human"} in the MFC AI_CLASS_* order (Reference.cpp LoadAIClassCombo). playerSides() is the static fallback {"USSR","German","GB","African_GB"}; readPlayerSides(partysXml) parses <PartyName> entries so a real Data/partys.xml drives the list exactly like FillVectorOfSides did. The fallback exists so S05/S06 picker code has a defaulted list when no Data root is at hand (test harness without a shipped partys.xml).

Localization: SLocalizationItem{name, desc, stats, hasName, hasDesc, hasStats}. loadLocalization() reads name.txt, desc.txt and the optional stats.txt case-insensitively via a directory_iterator scan (Linux does not fold case; the fixture names stats.txt as Stats.TXT so the CI matching path is exercised). Bytes are returned raw with no re-encoding, so the comparator can treat them opaque as planned.

Fixtures tree tools/zig/fixtures/resource_editor/references_root/ holds exactly 3 entries per type (a/b/c) under each MFC-era directory - effects/{sprites,particles,effects}/, weapons/, units/humans/, scenarios/{settings,scenariomissions,templatemissions,chapters}/, objects/terraobjects/{shell_hole,death_hole}/, maps/, music/, movies/, sounds/{,ack/grp/}, terrain/sets/s1/roads3d/, water/, effects/particles/*_h.dds - plus partys.xml and a locale/ with the three localization files. One _h.dds pair per set; the test asserts count=3 for every type except E_ACTIONS_REF (0).

The test tools/zig/resource_model_references_test.cpp constructs a References over the fixture, prints one `REF <name> count=<n>` line per EReferenceType to stderr, asserts the expected counts, probes the first entry of E_ANIMATIONS_REF ("a"), E_ASKS_REF ("sounds\\ack\\grp\\a") and the emptiness of E_ACTIONS_REF, checks missing-root robustness, verifies aiClasses()/playerSides()/readPlayerSides() and the locale read with the raw byte invariant for name.txt (binary "Name \xe9\r\n") and the case-insensitive stats.txt. The sweep is wired as `test-resource-model-references` on all five engine targets in build.zig (the function addResourceModelReferencesTest, called from the top-level config at build.zig:1382).

## Verification

Ran `zig build install-game test-resource-model-references` from the repo root with a 540s cap. Exit code 0. The references executable printed 20 `REF <name> count=<n>` lines (every type at the planned count: 3 for the 19 file-system-sourced types, 0 for E_ACTIONS_REF), `COMBO ai=4 sides=4`, and `resource-model-references OK`. install-game relinks with no regressions. The Linux fixture tree is 3-per-type by design so the counts are reproducible without eyeballing.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build install-game test-resource-model-references` | 0 | passed | 540000ms |

## Deviations

None.

## Known Issues

None.

## Files Created/Modified

- `Sources/src/ResourceModel/references.h`
- `Sources/src/ResourceModel/references.cpp`
- `Sources/src/ResourceModel/combos.h`
- `Sources/src/ResourceModel/combos.cpp`
- `Sources/src/ResourceModel/localization.h`
- `Sources/src/ResourceModel/localization.cpp`
- `tools/zig/resource_model_references_test.cpp`
- `tools/zig/fixtures/resource_editor/references_root/`
- `build.zig`
