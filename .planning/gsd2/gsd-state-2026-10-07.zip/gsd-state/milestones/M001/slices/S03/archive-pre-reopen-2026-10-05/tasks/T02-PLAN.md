---
estimated_steps: 3
estimated_files: 13
skills_used: []
---

# T02: Port every item class for the 11 stats-only sub-editors (Weapon, Mine, Trench, Squad, Sprite, Infantry, Mesh, Object, Fence, Building, Bridge)

Why: These 11 sub-editors share the pattern 'root item + property items + export-driven RPGStats' — no keyframe curves, no image frame, no GUI tree. Porting them together keeps a single mental model (CTreeItem subclass with CPropVector `values`, `InitDefaultValues`, `operator&(IDataTree&)`) and lets a single T02 reviewer check the whole stats-oriented port in one pass.

Do: For every EType in Sources/src/editor/TreeItem.h belonging to Weapon (E_WEAPON_*), Mine (E_MINE_*), Trench (E_TRENCH_*), Squad (E_SQUAD_*), Sprite (E_SPRITE_*), Infantry (E_UNIT_* — the EType family rooted at E_ANIMATION_ROOT_ITEM, which is the infantry editor), Mesh/Unit (E_MESH_*), Object (E_OBJECT_* excluding keyframes), Fence (E_FENCE_*), Building (E_BUILDING_*), and Bridge (E_BRIDGE_*): add a header/impl pair under Sources/src/ResourceModel/items/<kind>/ that mirrors the Sources/src/editor/<Kind>TreeItem.{h,cpp} subclass without the MFC base, without SECTreeCtrl, and without any UI inspector dependency. Props become std::vector<SProp>; defaultChilds becomes an initializer list of {ETreeItemType, defaultName}. Register them in Sources/src/ResourceModel/factory.cpp under per-kind blocks that match the exact REGISTER_CLASS order of Sources/src/editor/TreeItemFactory.cpp:35 so an audit against the MFC file is one `diff`. operator&(IDataTree&) becomes a pair of serialise(NResourceXml::Node&) / parse(const NResourceXml::Node&) methods on CTreeItem; the implementation walks props in-order so project-XML attribute order matches MFC byte-for-byte.

Done when: `grep -c REGISTER_CLASS Sources/src/ResourceModel/factory.cpp` matches the sum of registrations for these 11 kinds in Sources/src/editor/TreeItemFactory.cpp (count via a one-off script in the task); `zig build install-game` still links; and `tools/zig/resource_model_scaffold_test.cpp` is extended to loop over `wpn, mcp, trc, scp, spt, unt, msh, obt, fnc, bld, bdg` fixtures and assert rtout1==rtout2==fixture bytes with unknown-node preservation (plant a `<FutureBlob attr='v'><child/></FutureBlob>` under the root before serialise, confirm it survives).

## Inputs

- `Sources/src/editor/TreeItem.h`
- `Sources/src/editor/TreeItemFactory.cpp`
- `Sources/src/editor/WeaponTreeItem.cpp`
- `Sources/src/editor/WeaponTreeItem.h`
- `Sources/src/editor/MineTreeItem.cpp`
- `Sources/src/editor/MineTreeItem.h`
- `Sources/src/editor/TrenchTreeItem.cpp`
- `Sources/src/editor/TrenchTreeItem.h`
- `Sources/src/editor/SquadTreeItem.cpp`
- `Sources/src/editor/SquadTreeItem.h`
- `Sources/src/editor/SpriteTreeItem.cpp`
- `Sources/src/editor/SpriteTreeItem.h`
- `Sources/src/editor/AnimTreeItem.cpp`
- `Sources/src/editor/AnimTreeItem.h`
- `Sources/src/editor/MeshTreeItem.cpp`
- `Sources/src/editor/MeshTreeItem.h`
- `Sources/src/editor/ObjTreeItem.cpp`
- `Sources/src/editor/ObjTreeItem.h`
- `Sources/src/editor/FenceTreeItem.cpp`
- `Sources/src/editor/FenceTreeItem.h`
- `Sources/src/editor/BuildTreeItem.cpp`
- `Sources/src/editor/BuildTreeItem.h`
- `Sources/src/editor/BridgeTreeItem.cpp`
- `Sources/src/editor/BridgeTreeItem.h`
- `Sources/src/ResourceModel/factory.h`
- `Sources/src/ResourceModel/tree_item.h`
- `tools/zig/fixtures/resource_editor/wpn/project.wpn`
- `tools/zig/fixtures/resource_editor/mcp/project.mcp`
- `tools/zig/fixtures/resource_editor/trc/project.trc`
- `tools/zig/fixtures/resource_editor/scp/project.scp`
- `tools/zig/fixtures/resource_editor/spt/project.spt`
- `tools/zig/fixtures/resource_editor/unt/project.unt`
- `tools/zig/fixtures/resource_editor/msh/project.msh`
- `tools/zig/fixtures/resource_editor/obt/project.obt`
- `tools/zig/fixtures/resource_editor/fnc/project.fnc`
- `tools/zig/fixtures/resource_editor/bld/project.bld`
- `tools/zig/fixtures/resource_editor/bdg/project.bdg`

## Expected Output

- `Sources/src/ResourceModel/items/weapon/`
- `Sources/src/ResourceModel/items/mine/`
- `Sources/src/ResourceModel/items/trench/`
- `Sources/src/ResourceModel/items/squad/`
- `Sources/src/ResourceModel/items/sprite/`
- `Sources/src/ResourceModel/items/infantry/`
- `Sources/src/ResourceModel/items/mesh/`
- `Sources/src/ResourceModel/items/object/`
- `Sources/src/ResourceModel/items/fence/`
- `Sources/src/ResourceModel/items/building/`
- `Sources/src/ResourceModel/items/bridge/`
- `Sources/src/ResourceModel/factory.cpp`
- `tools/zig/resource_model_scaffold_test.cpp`

## Verification

zig build install-game resource-model-scaffold-test

## Observability Impact

The scaffold test's per-ext stderr line adds `childs=<n> props=<n>` so a future agent can tell at a glance whether a factory registration dropped a type (would show `childs=0`).
