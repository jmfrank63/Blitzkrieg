# S03: S03

**Goal:** Reopened by the 2026-10-05 hard steer (.gsd/OVERRIDES.md, .planning/gsd2/steer-2026-10-05-review.md). Make `Sources/src/ResourceModel` a faithful port of the MFC tree items, not a shell: every MFC tree item class in `Sources/src/editor/*TreeItem.{h,cpp}` has its full property table and its `operator&( IDataTree & )` serialisation ported (D-04, D-07), so every MFC project in `Data/Editor/TestProjects/` (21 folders) and every fixture under `tools/zig/fixtures/resource_editor/<ext>/` opens, saves and reopens with equal content, a project opened and saved without edits is byte-identical to the MFC file (MFC indentation and element order; any exception recorded in the spec with its reason), a node inserted through the model saves as valid MFC XML, and MFC can read what the port writes. The comparator compares exported game data through the engine's own readers (D-11), not project XML. The DXT tolerance is re-measured on shipped textures. One sweep script replaces run-s02/s03-sweep.sh. Previous S03 artifacts: `slices/S03/archive-pre-reopen-2026-10-05/`.
**Demo:** `test-resource-model` passes on the five engine targets (incl. Linux): every repo fixture project loads and saves idempotently; unknown-node preservation test passes; per-type stats comparator reads both port output and MFC golden through the engine's own readers (`GameDB::ReadRPGStats`, `GetAddStats`, `GetGameStats`, `ParticleSourceData`, `SmokinParticleSourceData`, `fmtEffect`, `fmtTerrain`, `fmtVSO`) and fails loudly on unknown fields.

## Must-Haves

- A generated inventory `tools/zig/fixtures/resource_editor/mfc-item-inventory.json` lists, for every MFC tree item class, its ClassTypeID, its property names/types/defaults in order, and the element names and order its `operator&( IDataTree & )` writes; it is produced by a script reading `Sources/src/editor`, not written by hand. `test-resource-model` asserts every port item class matches it (e.g. 48 weapon properties, 108 mesh-tree properties, exactly as MFC).
- Every project in `Data/Editor/TestProjects/*` and every fixture project: load → save → reload is content-equal (all 21 extensions, no exceptions); load → save without edits is byte-identical, or the spec (`docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`) lists the exact difference and why it cannot be avoided.
- Inserting a node of every insertable item type through the model, then save → reload, gives valid XML that MFC's `IDataTree` reader shape accepts (no `<>`); test covers each type.
- Comparator: reads exported data (stats via `GameDB::ReadRPGStats`/`GetAddStats`/`GetGameStats`, particle/effect/terrain/VSO readers) field by field with exact floats, accepts real MFC exports, fails loudly on unknown fields, and is proven on shipped `Data/` stats (self-equal passes, a one-ulp float change fails). MFC export goldens cannot be generated on this Linux machine: the slice summary says so, a win-home batch script and README are ready, and the golden comparison is NOT marked done.
- `dxt-tolerance.json` holds numbers measured on several shipped DXT1, DXT3 and DXT5 `_c.dds` from `Data/` (incl. alpha channels), recording the file list; the gate uses these numbers.
- One sweep script `tools/zig/run-resource-sweep.sh` (run-s02-sweep.sh and run-s03-sweep.sh deleted); it never classifies a Map Editor tier failure as pre-existing; it reports pointer-over-window smoke failures only as a FAIL with a hint, never a pass.
- Every task summary cites only commands really run in that task on this machine.

## Proof Level

- This slice proves: Contract + fidelity: equality is measured by code against MFC files (TestProjects, fixtures) and MFC source-derived inventory; no claim from eyeballing, from earlier tasks, or from other machines.

## Integration Closure

S04 (bridge) consumes the faithful items: its remaining tasks (lock file, per-node geometry, geometry families, export) depend on S03 being reopened and closed first. S06..S15 add only sub-editor tools, previews and exports on top of these items; they must not re-port property tables.

## Verification

- Round-trip failures print project path, first differing byte offset and a line-level diff excerpt; inventory mismatches print class, property index, expected vs actual name/type. Sweep log `zig-out/local-test/resource_editor/resource-sweep.log` has one PASS/FAIL line per tier and a final `VERDICT=`.

## Tasks

- [x] **T01: MFC tree item inventory generator + failing fidelity tests (incl. the `<>` insert bug)** `est:5h`
  Tests first. Write `tools/zig/mfc_item_inventory.py` (or a Zig tool, whichever fits tools/zig conventions) that parses every `Sources/src/editor/*TreeItem.{h,cpp}` (+ TreeItem.cpp base, TreeItemFactory.cpp, AnimTreeItem, KeyFrame items) and emits `tools/zig/fixtures/resource_editor/mfc-item-inventory.json`: per class its ClassTypeID (from the factory), property table (name, DT_* domain type, default, order — from the `defaultValues`/InitDefaultValues code), child-item list, and the element names and order written by its `operator&( IDataTree & )`. Spot-check the generator against the review's counts (weapon 48, mesh-tree 108) and fail if they differ. Then add to `test-resource-model`: (a) an inventory-conformance test over every port item class; (b) a round-trip test over every project in `Data/Editor/TestProjects/*` (copied to zig-out/local-test, never in place) and every fixture: load→save→reload content-equal and load→save byte-identical; (c) insert-each-type→save→reload valid-XML test. Commit the tests failing (expected-fail list recorded in the test so the tier still reports the gaps precisely); later tasks shrink that list to empty.
  - Files: `tools/zig/mfc_item_inventory.py`, `tools/zig/fixtures/resource_editor/mfc-item-inventory.json`, `tools/zig/resource_model_test.cpp`, `build.zig`
  - Verify: python3 tools/zig/mfc_item_inventory.py --check && zig build test-resource-model -Dtest-mode=run

- [x] **T02: Port property tables + IDataTree serialisation: Weapon, Mine, Trench, Squad, Sprite, Infantry (AnimTreeItem)** `est:8h`
  For each MFC tree item class of these six sub-editors, port the full property table (names, DT_* types, defaults, order, combos/reference types) and the `operator&( IDataTree & )` serialisation line by line into `Sources/src/ResourceModel/items/<kind>/`, MFC-free. Keep MFC element names, nesting and order. Remove these classes from T01's expected-fail list; the inventory, TestProjects round-trip (07_Weapon, 14_Mine, 12_Trench, 13_Squad, 03_Sprite, 02_InfantryAnimation) and insert tests must pass for them.
  - Files: `Sources/src/ResourceModel/items/weapon`, `Sources/src/ResourceModel/items/mine`, `Sources/src/ResourceModel/items/trench`, `Sources/src/ResourceModel/items/squad`, `Sources/src/ResourceModel/items/sprite`, `Sources/src/ResourceModel/items/infantry`, `tools/zig/resource_model_test.cpp`
  - Verify: zig build test-resource-model -Dtest-mode=run

- [x] **T03: Port property tables + IDataTree serialisation: Mesh, Object, Fence, Building, Bridge** `est:8h`
  Same as T02 for MeshTreeItem (108 properties incl. locators/platforms/guns), ObjTreeItem, FenceTreeItem, BuildTreeItem, BridgeTreeItem, including grid/passability/point data each item stores. Remove them from the expected-fail list; TestProjects 06_Mesh, 05_Object, 10_Fence, 08_Building, 15_Bridge and the fixtures round-trip.
  - Files: `Sources/src/ResourceModel/items/mesh`, `Sources/src/ResourceModel/items/object`, `Sources/src/ResourceModel/items/fence`, `Sources/src/ResourceModel/items/building`, `Sources/src/ResourceModel/items/bridge`, `tools/zig/resource_model_test.cpp`
  - Verify: zig build test-resource-model -Dtest-mode=run

- [x] **T04: Port property tables + IDataTree serialisation: Particle, Effect, Tileset/Crosset, 3D Road, 3D River, Mission, Chapter, Campaign, Medal, GUI** `est:8h`
  Same as T02 for ParticleTreeItem (+ keyframe items), EffTreeItem, TileTreeItem, 3dRoadTreeItem, 3dRiverTreeItem, MissionTreeItem, ChapterTreeItem, CampaignTreeItem, MedalTreeItem, GUITreeItem. Expected-fail list becomes empty; all 21 TestProjects folders and all fixtures round-trip content-equal.
  - Files: `Sources/src/ResourceModel/items`, `Sources/src/ResourceModel/key_frame_tree_item.cpp`, `tools/zig/resource_model_test.cpp`
  - Verify: zig build test-resource-model -Dtest-mode=run

- [x] **T05: MFC-identical writer: indentation, element order, byte-identical unedited save; record exceptions in the spec** `est:5h`
  Make `NResourceXml`/project save emit MFC's exact layout (indentation, attribute/element order, line endings, header, History list, expand flags, editor-only blocks) so an unedited open→save is byte-identical for every TestProjects project and fixture. Where byte identity is impossible (e.g. float formatting the MFC writer produced non-deterministically), add the case to the spec's D-07 section with the exact difference and reason, and make the test assert content equality for exactly those listed cases only. Re-check that a saved port project is readable by MFC's reader shape (same element names/ClassTypeID) — the MFC binary itself is a win-home check; list it in the S03 UAT as pending for win-home.
  - Files: `Sources/src/ResourceModel/xml.cpp`, `Sources/src/ResourceModel/project.cpp`, `tools/zig/resource_model_test.cpp`, `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`
  - Verify: zig build test-resource-model -Dtest-mode=run

- [x] **T06: Comparator over exported game data (D-11) + win-home golden generation kit** `est:6h`
  Rewrite `comparator.{h,cpp}` to compare exported data, not project XML: stats via the engine's own readers field by field with exact float equality; particle/smoking-particle/effect/terrain/VSO via their readers; `_h.dds` byte equality; DXT within the T07 gate; unknown fields fail loudly. Accept real MFC exports. Prove it on shipped `Data/` (copied to zig-out/local-test): every shipped stats file compares equal to itself; a one-ulp float change, a dropped field and an extra field each fail with a precise message. Fill golden folders' README with how goldens are made; add `tools/zig/win-home/export-goldens.ps1` (or .bat) that runs MFC `editor.exe` batch export over the fixtures into `tools/zig/fixtures/resource_editor/<ext>/golden/`. Goldens cannot be generated on this Linux machine: state that in the slice summary, keep the golden comparison test present but reporting `pending: golden missing` (not PASS), and do not mark the comparison done.
  - Files: `Sources/src/ResourceModel/comparator.h`, `Sources/src/ResourceModel/comparator.cpp`, `tools/zig/resource_model_test.cpp`, `tools/zig/win-home/export-goldens.ps1`, `tools/zig/fixtures/resource_editor/EXTENSIONS.md`
  - Verify: zig build test-resource-model -Dtest-mode=run

- [x] **T07: Re-measure DXT tolerance on shipped _c.dds textures (DXT1/3/5, with alpha) and gate on it** `est:3h`
  Replace the random-noise measurement: pick several shipped `_c.dds` from `Data/` per format (DXT1, DXT3, DXT5, including ones with real alpha), decode to RGBA, re-encode with `NDxt`, decode, measure max per-channel delta and p99 per format and for alpha separately. Write numbers and the exact file list into `dxt-tolerance.json` (with how they were measured), and make the comparator's DXT gate read them. Keep the measurement as a repeatable tool/test step.
  - Files: `tools/zig/fixtures/resource_editor/dxt-tolerance.json`, `tools/zig/dxt_tolerance.cpp`, `Sources/src/ResourceModel/comparator.cpp`, `build.zig`
  - Verify: zig build measure-dxt-tolerance && zig build test-resource-model -Dtest-mode=run

- [x] **T08: One sweep script, smoke pointer immunity, CI, S03 sweep** `est:3h`
  Replace `tools/zig/run-s02-sweep.sh` and `run-s03-sweep.sh` with one `tools/zig/run-resource-sweep.sh` (delete both): runs install-game, install-map-editor, test-resource-model, test-resource-core, test-resource-bridge, test-editor-core and every Map Editor tier listed in AGENTS.md; no PREEXISTING classification at all — any failure is FAIL. If map-editor-smoke/auto fail, record whether the pointer was over the hidden window. Make the smoke immune to the real pointer if cheap (ignore the global mouse position / SDL mouse motion from the OS while a script drives input); otherwise record the weakness in the S03 summary and the sweep's FAIL hint. Ensure CI runs test-resource-model on the five engine targets. Run the sweep; the S03 summary cites only this run.
  - Files: `tools/zig/run-resource-sweep.sh`, `tools/zig/run-s02-sweep.sh`, `tools/zig/run-s03-sweep.sh`, `Sources/editor/app`, `Sources/editor/kit/auto.zig`, `.github/workflows/cross-platform.yml`
  - Verify: bash tools/zig/run-resource-sweep.sh && grep -q 'VERDICT=PASS' zig-out/local-test/resource_editor/resource-sweep.log

## Files Likely Touched

- tools/zig/mfc_item_inventory.py
- tools/zig/fixtures/resource_editor/mfc-item-inventory.json
- tools/zig/resource_model_test.cpp
- build.zig
- Sources/src/ResourceModel/items/weapon
- Sources/src/ResourceModel/items/mine
- Sources/src/ResourceModel/items/trench
- Sources/src/ResourceModel/items/squad
- Sources/src/ResourceModel/items/sprite
- Sources/src/ResourceModel/items/infantry
- Sources/src/ResourceModel/items/mesh
- Sources/src/ResourceModel/items/object
- Sources/src/ResourceModel/items/fence
- Sources/src/ResourceModel/items/building
- Sources/src/ResourceModel/items/bridge
- Sources/src/ResourceModel/items
- Sources/src/ResourceModel/key_frame_tree_item.cpp
- Sources/src/ResourceModel/xml.cpp
- Sources/src/ResourceModel/project.cpp
- docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md
- Sources/src/ResourceModel/comparator.h
- Sources/src/ResourceModel/comparator.cpp
- tools/zig/win-home/export-goldens.ps1
- tools/zig/fixtures/resource_editor/EXTENSIONS.md
- tools/zig/fixtures/resource_editor/dxt-tolerance.json
- tools/zig/dxt_tolerance.cpp
- tools/zig/run-resource-sweep.sh
- tools/zig/run-s02-sweep.sh
- tools/zig/run-s03-sweep.sh
- Sources/editor/app
- Sources/editor/kit/auto.zig
- .github/workflows/cross-platform.yml
