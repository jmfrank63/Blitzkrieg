---
estimated_steps: 1
estimated_files: 4
skills_used: []
---

# T05: MFC-identical writer: indentation, element order, byte-identical unedited save; record exceptions in the spec

Make `NResourceXml`/project save emit MFC's exact layout (indentation, attribute/element order, line endings, header, History list, expand flags, editor-only blocks) so an unedited open→save is byte-identical for every TestProjects project and fixture. Where byte identity is impossible (e.g. float formatting the MFC writer produced non-deterministically), add the case to the spec's D-07 section with the exact difference and reason, and make the test assert content equality for exactly those listed cases only. Re-check that a saved port project is readable by MFC's reader shape (same element names/ClassTypeID) — the MFC binary itself is a win-home check; list it in the S03 UAT as pending for win-home.

## Inputs

- `Sources/src/ResourceModel/xml.cpp`
- `Data/Editor/TestProjects`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`

## Expected Output

- `Sources/src/ResourceModel/xml.cpp`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`

## Verification

zig build test-resource-model -Dtest-mode=run
