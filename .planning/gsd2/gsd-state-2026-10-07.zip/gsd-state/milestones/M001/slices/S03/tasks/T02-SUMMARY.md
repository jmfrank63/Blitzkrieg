---
id: T02
parent: S03
milestone: M001
key_files:
  - Sources/src/ResourceModel/items/weapon/weapon.cpp
  - Sources/src/ResourceModel/items/mine/mine.cpp
  - Sources/src/ResourceModel/items/trench/trench.cpp
  - Sources/src/ResourceModel/items/squad/squad.cpp
  - Sources/src/ResourceModel/items/sprite/sprite.cpp
  - Sources/src/ResourceModel/items/infantry/infantry.cpp
  - Sources/src/ResourceModel/mfc_value.cpp
  - Sources/src/ResourceModel/editor_env.cpp
  - Sources/src/ResourceModel/tree_item.cpp
  - Sources/src/ResourceModel/comparator.cpp
  - tools/zig/fixtures/resource_editor/resource-model-xfail.txt
key_decisions:
  - An unedited CVariant value keeps the MFC <value> element exactly as read, stale slots included, so re-saving writes the same element back
  - The pre-T06 project-XML comparator accepts the MFC framework field names for every kind (kMfcProjectFields) instead of listing them in each kind's table; T06 replaces the comparator
duration: 
verification_result: mixed
completed_at: 2026-10-05T04:21:13.553Z
blocker_discovered: false
---

# T02: Ported MFC property tables and IDataTree serialisation for Weapon, Mine, Trench, Squad, Sprite and Infantry (AnimTreeItem) into ResourceModel/items; their inventory, insert and TestProjects round-trip tests pass and the T02 block of the xfail list is empty

**Ported MFC property tables and IDataTree serialisation for Weapon, Mine, Trench, Squad, Sprite and Infantry (AnimTreeItem) into ResourceModel/items; their inventory, insert and TestProjects round-trip tests pass and the T02 block of the xfail list is empty**

## What Happened

The earlier attempt ported the code: the property tables (names, DT_* types, defaults, order, combos and references) and the operator&(IDataTree &) serialisation of every MFC tree item class in WeaponTreeItem, MineTreeItem, TrenchTreeItem, SquadTreeItem, SpriteTreeItem and AnimTreeItem, now in Sources/src/ResourceModel/items/{weapon,mine,trench,squad,sprite,infantry}. It also added shared MFC-free support code. mfc_value.{h,cpp} reads and writes MFC's CVariant <value> element (type, flag, float_value, int_value, string_value, int64low/high). Stale slots of an unedited value are kept, so a re-save writes them back unchanged. editor_env.{h,cpp} holds what MFC item defaults read from the running editor: browse filters, the data dir and the active project. localization_item.cpp was added. CTreeItem (tree_item.cpp) now writes the MFC framework fields default_name, display_name, values, expand and childs, with ClassTypeID on the item. The six repo fixtures (wpn/mcp/trc/scp/spt/unt) were regenerated in MFC project format, and the T02 block of resource-model-xfail.txt was emptied. That attempt ended without recording completion.

This attempt re-ran the verification. Fidelity was green: 348 PASS, 157 XFAIL, 0 FAIL, 0 XPASS, 0 stale. But test-resource-model-comparator aborted with "UNKNOWN FIELD @expand". The old project-XML comparator keeps a per-kind allowlist of field names, and the regenerated fixtures now carry MFC framework names it did not list. I added a shared kMfcProjectFields list to comparator.cpp: the names written by CTreeItem::operator&, the item/ClassTypeID element and the CVariant encoding. I also added the kind-specific names, each confirmed in the MFC sources: TrenchIndex (TrenchTreeItem.cpp:136), and units, ZeroPos, FormationDir, Pos and Dir plus the CVec3 components x/y/z (SquadTreeItem.cpp:509-520). With that, test-resource-model exits 0. T06 rewrites this comparator to compare exported game data (D-11), so this allowlist is a bridge until then.

## Verification

Ran `zig build test-resource-model -Dtest-mode=run`: exit 0. resource-model-fidelity reports 348 PASS, 157 XFAIL, 0 FAIL, 0 XPASS, 0 stale xfail ids. Every inventory and insert test for the C(Weapon|Mine|Trench|Squad|Sprite|Anim)* classes passes (50 PASS lines), and none of them is XFAIL or FAIL. These TestProjects pass round-trip-content, typed and edit: 07_Weapon, 14_Mine, 12_Trench, 13_Squad, 03_Sprite and 02_InfantryAnimation. The six fixtures also pass round-trip-bytes. The comparator sweep logs COMPARE_SUMMARY exts=21 goldens_present=0 goldens_missing=20 not_applicable=1, and the planted unknown-field child still aborts and prints UNKNOWN FIELD.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-model -Dtest-mode=run` | 1 | fail (before fix: comparator UNKNOWN FIELD @expand) | 756ms |
| 2 | `zig build test-resource-model -Dtest-mode=run` | 0 | pass | 1930ms |

## Deviations

comparator.cpp was not in the task's file list. Its field allowlists had to learn the MFC framework names and the Squad/Trench operator& names, or test-resource-model would abort on the regenerated fixtures.

## Known Issues

roundtrip-bytes for TestProjects/02_InfantryAnimation/WinSniper.unt stays XFAIL. That MFC file was written unindented with the legacy type= attribute, and making unedited saves byte-identical is T05. Content, typed and edit round trips pass for it. No MFC goldens exist yet; generating them is T06 on Windows.

## Files Created/Modified

- `Sources/src/ResourceModel/items/weapon/weapon.cpp`
- `Sources/src/ResourceModel/items/mine/mine.cpp`
- `Sources/src/ResourceModel/items/trench/trench.cpp`
- `Sources/src/ResourceModel/items/squad/squad.cpp`
- `Sources/src/ResourceModel/items/sprite/sprite.cpp`
- `Sources/src/ResourceModel/items/infantry/infantry.cpp`
- `Sources/src/ResourceModel/mfc_value.cpp`
- `Sources/src/ResourceModel/editor_env.cpp`
- `Sources/src/ResourceModel/tree_item.cpp`
- `Sources/src/ResourceModel/comparator.cpp`
- `tools/zig/fixtures/resource_editor/resource-model-xfail.txt`
