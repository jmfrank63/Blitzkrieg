---
estimated_steps: 1
estimated_files: 3
skills_used: []
---

# T04: Port property tables + IDataTree serialisation: Particle, Effect, Tileset/Crosset, 3D Road, 3D River, Mission, Chapter, Campaign, Medal, GUI

Same as T02 for ParticleTreeItem (+ keyframe items), EffTreeItem, TileTreeItem, 3dRoadTreeItem, 3dRiverTreeItem, MissionTreeItem, ChapterTreeItem, CampaignTreeItem, MedalTreeItem, GUITreeItem. Expected-fail list becomes empty; all 21 TestProjects folders and all fixtures round-trip content-equal.

## Inputs

- `Sources/src/editor/ParticleTreeItem.cpp`
- `Sources/src/editor/EffTreeItem.cpp`
- `Sources/src/editor/TileTreeItem.cpp`
- `Sources/src/editor/3dRoadTreeItem.cpp`
- `Sources/src/editor/3dRiverTreeItem.cpp`
- `Sources/src/editor/MissionTreeItem.cpp`
- `Sources/src/editor/ChapterTreeItem.cpp`
- `Sources/src/editor/CampaignTreeItem.cpp`
- `Sources/src/editor/MedalTreeItem.cpp`
- `Sources/src/editor/GUITreeItem.cpp`

## Expected Output

- `Sources/src/ResourceModel/items`

## Verification

zig build test-resource-model -Dtest-mode=run
