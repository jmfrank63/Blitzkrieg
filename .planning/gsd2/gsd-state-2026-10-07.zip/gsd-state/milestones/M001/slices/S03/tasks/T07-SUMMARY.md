---
id: T07
parent: S03
milestone: M001
key_files:
  - tools/zig/fixtures/resource_editor/dxt-tolerance.json
  - tools/zig/dxt_tolerance_test.cpp
  - Sources/src/ResourceModel/dxt_gate.h
  - Sources/src/ResourceModel/dxt_gate.cpp
  - Sources/src/ResourceModel/comparator.cpp
  - tools/zig/resource_model_comparator_test.cpp
  - build.zig
key_decisions:
  - The gate per format is the largest max and p99 over all listed files and over both measurements (NDxt re-encode, and legacy MFC encoder vs NDxt), with colour (RGB pooled) and alpha kept separate.
  - CompareDxt reports UNREADABLE, never EQUAL, when the pixels differ and no tolerance is loaded.
duration: 
verification_result: passed
completed_at: 2026-10-05T05:23:34.579Z
blocker_discovered: false
---

# T07: DXT tolerance is now measured on 20 shipped _c.dds files (6 DXT1, 6 DXT3, 8 DXT5, most with real alpha). The results are written to dxt-tolerance.json (schema 2, per-file results and a gate per format), and the D-11 comparator's CompareDxt checks port textures against those gates.

**DXT tolerance is now measured on 20 shipped _c.dds files (6 DXT1, 6 DXT3, 8 DXT5, most with real alpha). The results are written to dxt-tolerance.json (schema 2, per-file results and a gate per format), and the D-11 comparator's CompareDxt checks port textures against those gates.**

## What Happened

An interrupted earlier session had already built most of this. The tool is `tools/zig/dxt_tolerance_test.cpp`, run as `zig build measure-dxt-tolerance` (rewrites the JSON) or `zig build test-dxt-tolerance` (re-measures and requires the JSON unchanged). It decodes every mip of each listed shipped _c.dds with NDxt into ARGB8888 and takes two measurements. ndxt_reencode is NDxt encode then decode against that reference. legacy_vs_ndxt compares the MFC-era NLegacyDxt encoder with NDxt on the same reference. For each it records max and p99 of the absolute per-channel delta, with R, G and B pooled as colour and A measured separately. The JSON records the exact file list, size, mip count and alpha-pixel count per file, plus the method. Per format, the gate is the largest of each statistic over its files and both measurements: DXT1 colour 43/p99 33, alpha 0; DXT3 colour 54/p99 3, alpha 0; DXT5 colour 47/p99 2, alpha 18/p99 18. `Sources/src/ResourceModel/dxt_gate.{h,cpp}` holds DecodeDds, EncodeDds, the delta histograms and LoadDxtTolerance, which refuses a schema other than 2, a missing key, an empty gate or a missing file. comparator.cpp CompareDxt checks a port texture against the golden with these gates. If the pixels differ and no tolerance is loaded, the result is UNREADABLE, never EQUAL. In this session I confirmed that re-measuring produces a byte-identical JSON. I also fixed a misleading diagnostic in resource_model_comparator_test.cpp: szError was not cleared per texture, so PASS lines showed a stale "cannot open missing.json".

## Verification

Ran `zig build measure-dxt-tolerance` (exit 0): the regenerated JSON is byte-identical to the committed one, so the measurement is deterministic. Ran `zig build test-resource-model -Dtest-mode=run` (exit 0, 0 FAIL lines, VERDICT=PASS with goldens pending), which includes the DXT gate checks. Each listed DXT1/3/5 texture, re-encoded by NDxt, is EQUAL within its gate. A planted 16x16 region is DIFFERENT, with colour and alpha exceedances named. Differing pixels with no tolerance loaded are UNREADABLE, and a truncated file is UNREADABLE. Malformed tolerance JSON (wrong schema, missing alpha_p99, empty gate) and a missing file are refused. Ran `zig build test-dxt-tolerance -Dtest-mode=run` (exit 0): it reports the JSON matches the measurement of 20 shipped textures.

## Failure Modes
Dependencies are Data/ textures and the JSON on the filesystem. A missing or unreadable texture fails the measurement step and the decode check, naming the path. A truncated DDS gives UNREADABLE with the expected and actual byte counts. A missing or malformed tolerance JSON makes LoadDxtTolerance return false with the reason, and differing pixels then compare as UNREADABLE, never EQUAL.

## Load Profile
This is an offline measurement over 20 textures of at most 512x512, taking about 2 s. Memory is one decoded image plus fixed 256-bin histograms per file. At 10x the files, runtime grows linearly (about 20 s), with nothing shared to saturate.

## Negative Tests
tools/zig/resource_model_comparator_test.cpp DxtGate covers: the bad-tolerance cases (schema_version 1, missing alpha_p99, empty gate); a missing tolerance file; a planted 16x16 region exceeding the colour and alpha gates (DIFFERENT); differing pixels with no tolerance loaded (UNREADABLE); and a DDS cut short (UNREADABLE). test-dxt-tolerance fails if the committed JSON drifts from a fresh measurement.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build measure-dxt-tolerance (and cmp with the previous JSON)` | 0 | pass: byte-identical | 2000ms |
| 2 | `zig build test-resource-model -Dtest-mode=run` | 0 | pass (0 FAIL, goldens pending) | 20000ms |
| 3 | `zig build test-dxt-tolerance -Dtest-mode=run` | 0 | pass | 2000ms |

## Deviations

Most of the implementation already existed from an interrupted earlier session. This session re-verified it and fixed a stale error string in the PASS diagnostics of the comparator test.

## Known Issues

The real port-vs-MFC golden DXT comparisons stay pending until goldens are exported on Windows (win-home/export-goldens.ps1).

## Files Created/Modified

- `tools/zig/fixtures/resource_editor/dxt-tolerance.json`
- `tools/zig/dxt_tolerance_test.cpp`
- `Sources/src/ResourceModel/dxt_gate.h`
- `Sources/src/ResourceModel/dxt_gate.cpp`
- `Sources/src/ResourceModel/comparator.cpp`
- `tools/zig/resource_model_comparator_test.cpp`
- `build.zig`
