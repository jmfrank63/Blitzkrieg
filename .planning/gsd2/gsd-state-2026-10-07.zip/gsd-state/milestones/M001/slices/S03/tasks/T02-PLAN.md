---
estimated_steps: 1
estimated_files: 7
skills_used: []
---

# T02: Port property tables + IDataTree serialisation: Weapon, Mine, Trench, Squad, Sprite, Infantry (AnimTreeItem)

For each MFC tree item class of these six sub-editors, port the full property table (names, DT_* types, defaults, order, combos/reference types) and the `operator&( IDataTree & )` serialisation line by line into `Sources/src/ResourceModel/items/<kind>/`, MFC-free. Keep MFC element names, nesting and order. Remove these classes from T01's expected-fail list; the inventory, TestProjects round-trip (07_Weapon, 14_Mine, 12_Trench, 13_Squad, 03_Sprite, 02_InfantryAnimation) and insert tests must pass for them.

## Inputs

- `Sources/src/editor/WeaponTreeItem.cpp`
- `Sources/src/editor/MineTreeItem.cpp`
- `Sources/src/editor/TrenchTreeItem.cpp`
- `Sources/src/editor/SquadTreeItem.cpp`
- `Sources/src/editor/SpriteTreeItem.cpp`
- `Sources/src/editor/AnimTreeItem.cpp`
- `tools/zig/fixtures/resource_editor/mfc-item-inventory.json`

## Expected Output

- `Sources/src/ResourceModel/items/weapon`
- `Sources/src/ResourceModel/items/mine`
- `Sources/src/ResourceModel/items/trench`
- `Sources/src/ResourceModel/items/squad`
- `Sources/src/ResourceModel/items/sprite`
- `Sources/src/ResourceModel/items/infantry`

## Verification

zig build test-resource-model -Dtest-mode=run
