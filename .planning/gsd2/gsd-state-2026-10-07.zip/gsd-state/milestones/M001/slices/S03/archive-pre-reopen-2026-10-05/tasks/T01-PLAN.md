---
estimated_steps: 3
estimated_files: 17
skills_used: []
---

# T01: Scaffold Sources/src/ResourceModel/ framework: Variant, SProp, CTreeItem, factory, project XML load/save (promoted from spike)

Why: Every subsequent task — all 21 item-class ports, references, comparator — needs the same MFC-free base: a Variant that stores int/float/bool/string/vec3/color/combo-index/reference-string without CVariant's MFC string + windows types; an SProp (id, default name, display name, domain type, value, combo strings) that mirrors Sources/src/editor/TreeItem.h:11 but without CPropVector's std-namespace+windows coupling; a CTreeItem base (list of children, props, factory-registerable type id, static defaultChilds) that mirrors TreeItem.h:290 without SECTreeCtrl/HTREEITEM/MFC CPtr; a CTreeItemFactory that mirrors TreeItemFactory.cpp but on std::unordered_map rather than CBasicObjectFactory; and an idempotent, unknown-node-preserving project-XML reader/writer promoted from the S01 spike at Sources/src/ResourceModel/spike/xml_spike.{h,cpp} into Sources/src/ResourceModel/xml.{h,cpp}. The project doc wrapper owns the Document+root-tree pairing and a FutureBlob opaque node type that holds any element whose tag the factory does not know, so a future tag survives round-trips verbatim.

Do: Create Sources/src/ResourceModel/{variant.h, variant.cpp, prop.h, tree_item.h, tree_item.cpp, factory.h, factory.cpp, xml.h, xml.cpp, project.h, project.cpp, future_blob.h, future_blob.cpp, domen_id.h, root.h} as a self-contained C++17 library. Only standard C++ headers and other ResourceModel headers; no `windows.h`, no `afx*.h`, no `../Common/LegacyUiCompat.h`, no `../Misc/BasicObjectFactory.h`, no `IRefCount`, no `DECLARE_SERIALIZE`. Preserve the Russian-encoded `szDisplayName` strings as opaque std::string bytes; the comparator does not decode them. Promote xml_spike into xml.{h,cpp} verbatim (rename namespace `XmlSpike` -> `NResourceXml`); keep the spike file in-tree so S01's `test-resource-xml-roundtrip` build target (if later wired) is not disturbed. Factory registers only an empty EType->ctor map in this task; the per-sub-editor REGISTER_CLASS blocks move in T02/T03.

Done when: `grep -rE 'windows\.h|afx|MFC|CPtr|CString|IRefCount|BasicObjectFactory|DECLARE_SERIALIZE' Sources/src/ResourceModel/*.{h,cpp}` returns zero hits; the files compile standalone as a C++17 translation unit set (checked by a one-off `zig build install-game` that links `editor_bridge` with the new sources added to its source list but with no new API surface used yet); and a free-standing round-trip-shape smoke in `tools/zig/resource_model_scaffold_test.cpp` reads one fixture (`tools/zig/fixtures/resource_editor/wpn/project.wpn`), serialises it back, and asserts byte-identity.

## Inputs

- `Sources/src/editor/TreeItem.h`
- `Sources/src/editor/TreeItem.cpp`
- `Sources/src/editor/TreeItemFactory.cpp`
- `Sources/src/editor/TreeItemFactory.h`
- `Sources/src/editor/COI/Variant.h`
- `Sources/src/editor/COI/Variant.cpp`
- `Sources/src/ResourceModel/spike/xml_spike.h`
- `Sources/src/ResourceModel/spike/xml_spike.cpp`
- `tools/zig/fixtures/resource_editor/wpn/project.wpn`

## Expected Output

- `Sources/src/ResourceModel/variant.h`
- `Sources/src/ResourceModel/variant.cpp`
- `Sources/src/ResourceModel/prop.h`
- `Sources/src/ResourceModel/tree_item.h`
- `Sources/src/ResourceModel/tree_item.cpp`
- `Sources/src/ResourceModel/factory.h`
- `Sources/src/ResourceModel/factory.cpp`
- `Sources/src/ResourceModel/xml.h`
- `Sources/src/ResourceModel/xml.cpp`
- `Sources/src/ResourceModel/project.h`
- `Sources/src/ResourceModel/project.cpp`
- `Sources/src/ResourceModel/future_blob.h`
- `Sources/src/ResourceModel/future_blob.cpp`
- `Sources/src/ResourceModel/domen_id.h`
- `Sources/src/ResourceModel/root.h`
- `tools/zig/resource_model_scaffold_test.cpp`
- `build.zig`

## Verification

zig build install-game resource-model-scaffold-test

## Observability Impact

The scaffold test writes a one-line result to stderr: `SCAFFOLD wpn bytes=<n> rt_equal=<0|1>`; `BK_DEBUG_LOG=1` additionally dumps the parse tree depth and child counts so a future agent can see why a round-trip diverged without re-running under a debugger.
