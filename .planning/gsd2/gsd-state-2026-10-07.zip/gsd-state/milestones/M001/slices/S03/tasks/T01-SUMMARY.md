---
id: T01
parent: S03
milestone: M001
key_files:
  - tools/zig/mfc_item_inventory.py
  - tools/zig/fixtures/resource_editor/mfc-item-inventory.json
  - tools/zig/resource_model_test.cpp
  - tools/zig/fixtures/resource_editor/resource-model-xfail.txt
  - build.zig
key_decisions:
  - The item class attribute is ClassTypeID, as the current DTHelper.h writer emits; legacy type= is accepted on read, as MFC's reader does
  - Review counts 48/108 are props + default children; the spot check asserts that sum, and the props alone are 42/82
  - Runtime-computed combo strings are recorded as {runtime: expr}; the test compares their count and literal entries only
  - The expected-fail list is a tracked text file read by the test, not inline in the .cpp; XPASS and stale ids fail the run so the list only shrinks
  - The roundtrip-typed check requires MFC project shape (root with childs), so stub fixtures fail instead of passing vacuously
duration: 
verification_result: passed
completed_at: 2026-10-05T03:54:54.478Z
blocker_discovered: false
---

# T01: Generated MFC tree-item inventory (217 classes, 423 props) from Sources/src/editor, plus test-resource-model-fidelity (inventory conformance, round trip of 23 projects, insert of 196 item types) with 461 known gaps recorded in an xfail list

**Generated MFC tree-item inventory (217 classes, 423 props) from Sources/src/editor, plus test-resource-model-fidelity (inventory conformance, round trip of 23 projects, insert of 196 item types) with 461 known gaps recorded in an xfail list**

## What Happened

The interrupted session had left nothing on disk (clean tree), so T01 was done from scratch in this session.

Generator: tools/zig/mfc_item_inventory.py parses the ETreeItemType enum (TreeItem.h), REGISTER_CLASS (TreeItemFactory.cpp), every header the factory includes (incl. localization.h for CLocalizationItem) and their .cpp files. It executes every InitDefaultValues symbolically (props in push order with nId, DT_* name and number, default, combo strings; default children). It also handles constructs that are not plain assignments: runtime combo/browse strings (filters, editor dirs, LoadAIClassCombo, FillVectorOfSides) are recorded as {runtime: expr}; the if/else in CLocalizationItem; the frame-existence guard; casts like (int)0xff808080, stored as the signed int; and CKeyFrameTreeItem members and default frames. Any statement it does not model goes into `unparsed`, and --check fails on it. Per class it also emits MFC's <item> shape: the ClassTypeID and expand attributes plus scalar override fields as attributes; default_name, display_name, values, childs (unless bSerializeChilds=false) and non-scalar override fields as elements, with frame SaveMyData fields for Bridge and Fence. Fields are classified by member type. It also emits which item inserts which (`new` in item handlers), the sub-editor (extension, root tag, root class) for each class, and the 21 frames.

Spot check: the review's 48 (weapon) and 108 (mesh) are `grep -c szDefaultName` counts, which are props plus default children (42+6 and 82+26). The parser matches exactly, and --check asserts those numbers.

Finding: the current MFC writer (Sources/src/StreamIO/DTHelper.h AddInternal) writes ClassTypeID. Its reader also accepts the legacy type attribute, which WinSniper.unt uses; current.msh uses ClassTypeID. The inventory and tests use ClassTypeID and read both.

Test: tools/zig/resource_model_test.cpp, built as test-resource-model-fidelity and added to the test-resource-model aggregate. The model's source list is now one shared resource_model_sources constant in build.zig. Check families:
- inventory:<Class> (217): factory Create(ClassTypeID); props compared on name, domain type, nId, default and literal combo strings; default children; and serialise() compared with MFC's <item> shape, including one values/item per prop.
- roundtrip-bytes / -content / -typed / -edit (23 projects: the two real MFC projects in Data/Editor/TestProjects plus 21 fixtures, all copied to zig-out/local-test/resource_model/fidelity first). The typed check fails files not in MFC project shape, so stub fixtures cannot pass vacuously. The edit check changes the first typed item's display name and requires it in the saved bytes and after reload.
- insert:<Class> (196 non-root types): the item is inserted under its MFC parent where one exists, saved, and must parse, appear as <item ClassTypeID=...> under childs, and reload typed. Failures show the bytes around the parse error, e.g. the `</>` from the empty-name bug.

Failure messages give class, property index, and expected vs actual name/type; for round trips, the path, first differing byte, line, and an excerpt.

Known gaps go in tools/zig/fixtures/resource_editor/resource-model-xfail.txt (461 ids, grouped T02/T03/T04 by sub-editor and T05 for roundtrip-bytes). A listed failure is XFAIL. XPASS, an unlisted failure, or a stale id fails the run. Log: zig-out/local-test/resource_model/fidelity.log.

## Verification

All of these commands were run in this task on this Linux machine:
- python3 tools/zig/mfc_item_inventory.py --check: exit 0 (217 classes, 423 props, weapon 48, mesh 108).
- zig build test-resource-model -Dtest-mode=run: exit 0; the fidelity tier reported 44 PASS, 461 XFAIL, 0 FAIL, 0 XPASS, 0 stale.
- Negative checks of the xfail mechanism: appending a bogus id gave exit 1 with a stale-id FAIL; removing roundtrip-bytes:TestProjects/06_Mesh/current.msh from the list gave exit 1 with an unlisted FAIL. The list was restored and compared byte-equal with cmp.
- Because build.zig changed: zig build install-game install-map-editor exit 0, zig build test-editor-core exit 0, zig build resource-model-scaffold-test -Dtest-mode=run exit 0.
- Slice-level: the sweep log and VERDICT belong to T08 and were not run here. The round-trip and inventory diagnostics the slice requires are in place.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `python3 tools/zig/mfc_item_inventory.py --check && zig build test-resource-model -Dtest-mode=run` | 0 | pass (44 PASS, 461 XFAIL, 0 FAIL) | 1081ms |
| 2 | `zig build test-resource-model-fidelity -Dtest-mode=run (bogus xfail id appended)` | 1 | pass (expected failure: stale id detected) | 3000ms |
| 3 | `zig build test-resource-model-fidelity -Dtest-mode=run (one xfail id removed)` | 1 | pass (expected failure: unlisted FAIL detected) | 3000ms |
| 4 | `zig build install-game install-map-editor` | 0 | pass | 60000ms |
| 5 | `zig build test-editor-core` | 0 | pass | 5000ms |
| 6 | `zig build resource-model-scaffold-test -Dtest-mode=run` | 0 | pass | 5000ms |

## Deviations

The expected-fail list lives in tools/zig/fixtures/resource_editor/resource-model-xfail.txt (461 ids) rather than inline in resource_model_test.cpp, to keep the test readable and let T02-T05 delete lines. The checks run as a new step, test-resource-model-fidelity, which the test-resource-model aggregate depends on. Data/Editor/TestProjects holds only two real MFC projects (02_InfantryAnimation/WinSniper.unt, 06_Mesh/current.msh); the other 19 folders are README references.

## Known Issues

The 21 fixtures tools/zig/fixtures/resource_editor/<ext>/project.<ext> are hand-written <fixture> stubs, not MFC projects (no childs/item tree). Their roundtrip-typed and roundtrip-edit checks are XFAIL until T02-T04 replace them with MFC-shaped projects. WinSniper.unt uses the legacy type= attribute and writes only the root's childs, while current.msh writes the root item's full operator& (default_name, values, childs) then own_data and RPG. T05 must handle both writer generations or record the byte difference in the spec. The port factory does not register CLocalizationItem (E_LOCALIZATION_ITEM). GUI items have no InitDefaultValues props in MFC (0 props, 8 default children).

## Files Created/Modified

- `tools/zig/mfc_item_inventory.py`
- `tools/zig/fixtures/resource_editor/mfc-item-inventory.json`
- `tools/zig/resource_model_test.cpp`
- `tools/zig/fixtures/resource_editor/resource-model-xfail.txt`
- `build.zig`
