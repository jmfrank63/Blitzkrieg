# S03: ResourceModel C++ library: framework, every item class, project XML, references, per-type stats comparator

**Goal:** Stand up `Sources/src/ResourceModel/` as a portable, MFC-free C++ library that owns the resource editor's data model (variant + SProp + CTreeItem + factory), every item class of every one of the 21 sub-editors, idempotent unknown-node-preserving project XML load/save for all 21 extensions, the reference and localisation lists, and a per-stats-type comparator that reads both the port's output and the MFC golden through the engine's own readers — then wire `test-resource-model` on the five engine targets so the slice's claim ("every repo fixture project loads and saves idempotently; unknown nodes survive; stats comparator reads both sides through the engine and fails loudly on unknown fields") is executable, not assertion-free.
**Demo:** `test-resource-model` passes on the five engine targets (incl. Linux): every repo fixture project loads and saves idempotently; unknown-node preservation test passes; per-type stats comparator reads both port output and MFC golden through the engine's own readers (`GameDB::ReadRPGStats`, `GetAddStats`, `GetGameStats`, `ParticleSourceData`, `SmokinParticleSourceData`, `fmtEffect`, `fmtTerrain`, `fmtVSO`) and fails loudly on unknown fields.

## Must-Haves

- (1) `zig build test-resource-model` runs the ResourceModel harness on Linux x64 and exits 0; the harness, for all 21 extensions in `tools/zig/fixtures/resource_editor/<ext>/project.<ext>`, round-trips bytes rtout1==rtout2==fixture bytes (idempotence) and preserves a planted FutureBlob unknown node. (2) For each sub-editor kind with a repo golden under `tools/zig/fixtures/resource_editor/<ext>/golden/`, the harness exports stats-only, then reads both the port output and the golden through the engine's own typed reader (`ReadRPGStats<T>` / `GetAddStats` / `GetGameStats` / `ParticleSourceData` / `SmokinParticleSourceData` / `fmtEffect` / `fmtTerrain` / `fmtVSO`) and reports field-by-field equality; mismatches on unknown fields abort with the field name. If a kind has no committed golden yet (win-home oracle not yet run), the comparator is exercised against port=port (idempotence) and the test records `GOLDEN_MISSING` without failing. (3) The 20 `EReferenceType` lists, the AI-class combo, the player-sides combo, and the localisation items load through portable (MFC-free) code and are enumerable from the harness. (4) `test-resource-model` is wired into `build.zig` for all five engine targets (linux x64, win x64 MSVC, mac arm64, mac x64) via the `addEngineHostedTool` pattern used by `test-rmg-composer-roundtrip`; `.github/workflows/cross-platform.yml` runs it on macOS and Windows. (5) `test-resources-all` meta-step is extended to include `test-resource-model` so the full-sweep gate pulls it in. (6) `tools/zig/run-s03-sweep.sh` records the full S03 Linux sweep (new tiers + S02 regression tiers) at `zig-out/local-test/resource_editor/s03-sweep.log` with per-tier EXIT/ELAPSED_MS/VERDICT lines and a final `S03 VERDICT=PASS` line; preexisting S01 BkEditorOpenMap failures stay classified PREEXISTING.

## Proof Level

- This slice proves: contract — ResourceModel is a data-only library on this slice; the preview/bridge/app layers (S04/S05) are what prove integration. Real-runtime engine linkage is required (`addEngineHostedTool`) because the comparator calls `ReadRPGStats<T>` which pulls in the engine's typed reader chain, matching the Random Missions and RMG Composer tiers' precedent.

## Integration Closure

Upstream consumed: `tools/zig/fixtures/resource_editor/<ext>/project.<ext>` (S01), `tools/zig/fixtures/resource_editor/<ext>/golden/` (S01 when win-home runs the oracle), `Sources/src/ResourceModel/spike/xml_spike.{h,cpp}` (S01, promoted into prod shape), `Sources/editor/kit/` (S02, read-only — the kit is not linked into ResourceModel; the C++ library stays bridge-free). New wiring: `Sources/src/ResourceModel/*.{h,cpp}` compiled into `editor_bridge` (the shared bridge library whose Zig wrapper S04 will add `BkRes*` entry points to) and a free-standing `resource_model_test` tool built by `addEngineHostedTool`. Remaining before end-to-end: S04 wires `BkRes*` ABI + Zig `resource_core`; S05 lands the app shell; S06..S15 add the per-sub-editor export content.

## Verification

- The ResourceModel harness writes a structured log (one JSON line per extension) under `zig-out/local-test/resource_model/round-trip.log` containing `{ext, bytes_in, bytes_out, rt_equal, unknown_preserved, golden_present, stats_fields_compared, stats_mismatch_count, first_mismatch}`. The comparator aborts with `UNKNOWN FIELD <field> under <path>` printed to stderr before exiting non-zero; `BK_DEBUG_LOG=1` promotes per-field compare lines. The sweep script captures stderr per tier so a future agent can grep for `UNKNOWN FIELD` or `BkEditorOpenMap` without re-running.

## Tasks

- [x] **T01: Scaffold Sources/src/ResourceModel/ framework: Variant, SProp, CTreeItem, factory, project XML load/save (promoted from spike)** `est:3h`
  Why: Every subsequent task — all 21 item-class ports, references, comparator — needs the same MFC-free base: a Variant that stores int/float/bool/string/vec3/color/combo-index/reference-string without CVariant's MFC string + windows types; an SProp (id, default name, display name, domain type, value, combo strings) that mirrors Sources/src/editor/TreeItem.h:11 but without CPropVector's std-namespace+windows coupling; a CTreeItem base (list of children, props, factory-registerable type id, static defaultChilds) that mirrors TreeItem.h:290 without SECTreeCtrl/HTREEITEM/MFC CPtr; a CTreeItemFactory that mirrors TreeItemFactory.cpp but on std::unordered_map rather than CBasicObjectFactory; and an idempotent, unknown-node-preserving project-XML reader/writer promoted from the S01 spike at Sources/src/ResourceModel/spike/xml_spike.{h,cpp} into Sources/src/ResourceModel/xml.{h,cpp}. The project doc wrapper owns the Document+root-tree pairing and a FutureBlob opaque node type that holds any element whose tag the factory does not know, so a future tag survives round-trips verbatim.
  - Files: `Sources/src/ResourceModel/variant.h`, `Sources/src/ResourceModel/variant.cpp`, `Sources/src/ResourceModel/prop.h`, `Sources/src/ResourceModel/tree_item.h`, `Sources/src/ResourceModel/tree_item.cpp`, `Sources/src/ResourceModel/factory.h`, `Sources/src/ResourceModel/factory.cpp`, `Sources/src/ResourceModel/xml.h`, `Sources/src/ResourceModel/xml.cpp`, `Sources/src/ResourceModel/project.h`, `Sources/src/ResourceModel/project.cpp`, `Sources/src/ResourceModel/future_blob.h`, `Sources/src/ResourceModel/future_blob.cpp`, `Sources/src/ResourceModel/domen_id.h`, `Sources/src/ResourceModel/root.h`, `tools/zig/resource_model_scaffold_test.cpp`, `build.zig`
  - Verify: zig build install-game resource-model-scaffold-test

- [x] **T02: Port every item class for the 11 stats-only sub-editors (Weapon, Mine, Trench, Squad, Sprite, Infantry, Mesh, Object, Fence, Building, Bridge)** `est:6h`
  Why: These 11 sub-editors share the pattern 'root item + property items + export-driven RPGStats' — no keyframe curves, no image frame, no GUI tree. Porting them together keeps a single mental model (CTreeItem subclass with CPropVector `values`, `InitDefaultValues`, `operator&(IDataTree&)`) and lets a single T02 reviewer check the whole stats-oriented port in one pass.
  - Files: `Sources/src/ResourceModel/items/weapon/`, `Sources/src/ResourceModel/items/mine/`, `Sources/src/ResourceModel/items/trench/`, `Sources/src/ResourceModel/items/squad/`, `Sources/src/ResourceModel/items/sprite/`, `Sources/src/ResourceModel/items/infantry/`, `Sources/src/ResourceModel/items/mesh/`, `Sources/src/ResourceModel/items/object/`, `Sources/src/ResourceModel/items/fence/`, `Sources/src/ResourceModel/items/building/`, `Sources/src/ResourceModel/items/bridge/`, `Sources/src/ResourceModel/factory.cpp`, `tools/zig/resource_model_scaffold_test.cpp`
  - Verify: zig build install-game resource-model-scaffold-test

- [x] **T03: Port every item class for the 10 keyframe/graph/image/UI sub-editors (Particle, Effect, Tileset, 3dRoad, 3dRiver, Mission, Chapter, Campaign, Medal, GUI)** `est:6h`
  Why: These 10 sub-editors deviate from the T02 stats-only pattern — Particle and Effect own CKeyFrameTreeItem (Sources/src/editor/TreeItem.h:378) with framesList/minX/maxX/stepX fields that need the same portable treatment; Tileset/3dRoad/3dRiver own grid/layer trees; Mission/Chapter/Campaign/Medal own the CImageFrame-aligned trees; GUI owns the switched-off UI tree. Grouping them together lets one task carry the keyframe generalisation.
  - Files: `Sources/src/ResourceModel/key_frame_tree_item.h`, `Sources/src/ResourceModel/key_frame_tree_item.cpp`, `Sources/src/ResourceModel/items/particle/`, `Sources/src/ResourceModel/items/effect/`, `Sources/src/ResourceModel/items/tileset/`, `Sources/src/ResourceModel/items/road3d/`, `Sources/src/ResourceModel/items/river3d/`, `Sources/src/ResourceModel/items/mission/`, `Sources/src/ResourceModel/items/chapter/`, `Sources/src/ResourceModel/items/campaign/`, `Sources/src/ResourceModel/items/medal/`, `Sources/src/ResourceModel/items/gui/`, `Sources/src/ResourceModel/factory.cpp`, `tools/zig/resource_model_scaffold_test.cpp`
  - Verify: zig build install-game resource-model-scaffold-test

- [x] **T04: Reference, localisation and combo lists: 20 EReferenceType enumerators + AI-class + player-sides + localisation items (A-30/A-33/A-34), ported MFC-free** `est:3h`
  Why: Parity rows A-30 (reference pickers for all 20 EReferenceType), A-33 (AI class combo, player sides combo), and A-34 (localisation items name/desc/stats .txt) all live in ResourceModel per the Parity map (06-PARITY.md), because the data lists must exist before S05's picker UI and S06..S15's per-sub-editor picker usages can read them. Keeping them in this slice means S04's bridge can expose them without reaching back into the MFC source tree.
  - Files: `Sources/src/ResourceModel/references.h`, `Sources/src/ResourceModel/references.cpp`, `Sources/src/ResourceModel/combos.h`, `Sources/src/ResourceModel/combos.cpp`, `Sources/src/ResourceModel/localization.h`, `Sources/src/ResourceModel/localization.cpp`, `tools/zig/resource_model_references_test.cpp`, `tools/zig/fixtures/resource_editor/references_root/`, `build.zig`
  - Verify: zig build install-game test-resource-model-references

- [x] **T05: Per-stats-type comparator: read both port output and MFC golden through the engine's own typed readers, fail loudly on unknown fields** `est:5h`
  Why: The slice contract says 'the per-type stats comparator reads both port output and MFC golden through the engine's own readers' — `ReadRPGStats<T>` (Sources/src/Main/GameDB.cpp:278), `GetAddStats` / `GetGameStats` (GameDB.cpp:403/439), `ParticleSourceData` / `SmokinParticleSourceData` (from Formats), `fmtEffect` (Sources/src/Formats/fmtEffect.cpp), `fmtTerrain` (fmtTerrain.cpp), `fmtVSO` (fmtVSO.cpp). Reading through the engine, not through a hand-rolled parser, is what proves the port's bytes mean the same thing the game would mean. 'Fail loudly on unknown fields' means any attribute present in the port XML but not consumed by the engine reader (or vice versa) aborts the comparator with the attribute name.
  - Files: `Sources/src/ResourceModel/comparator.h`, `Sources/src/ResourceModel/comparator.cpp`, `tools/zig/resource_model_comparator_test.cpp`, `tools/zig/fixtures/resource_editor/wpn/golden-synthetic-unknown.xml`, `build.zig`
  - Verify: zig build install-game test-resource-model-comparator

- [x] **T06: Wire `test-resource-model` on five engine targets, extend `test-resources-all`, record the S03 Linux sweep** `est:2h`
  Why: The slice-level claim is that `test-resource-model` is green on five engine targets. The individual tool steps T01/T04/T05 added (`resource-model-scaffold-test`, `test-resource-model-references`, `test-resource-model-comparator`) must be aggregated under one `test-resource-model` meta-step so the roadmap's success-criteria sentence maps to a single invocation; the aggregate must be wired into `test-resources-all` so S16's full-sweep gate pulls it in; the sweep script and recorded log are the slice's auditable finish line.
  - Files: `build.zig`, `.github/workflows/cross-platform.yml`, `tools/zig/run-s03-sweep.sh`, `zig-out/local-test/resource_editor/s03-sweep.log`
  - Verify: bash tools/zig/run-s03-sweep.sh

## Files Likely Touched

- Sources/src/ResourceModel/variant.h
- Sources/src/ResourceModel/variant.cpp
- Sources/src/ResourceModel/prop.h
- Sources/src/ResourceModel/tree_item.h
- Sources/src/ResourceModel/tree_item.cpp
- Sources/src/ResourceModel/factory.h
- Sources/src/ResourceModel/factory.cpp
- Sources/src/ResourceModel/xml.h
- Sources/src/ResourceModel/xml.cpp
- Sources/src/ResourceModel/project.h
- Sources/src/ResourceModel/project.cpp
- Sources/src/ResourceModel/future_blob.h
- Sources/src/ResourceModel/future_blob.cpp
- Sources/src/ResourceModel/domen_id.h
- Sources/src/ResourceModel/root.h
- tools/zig/resource_model_scaffold_test.cpp
- build.zig
- Sources/src/ResourceModel/items/weapon/
- Sources/src/ResourceModel/items/mine/
- Sources/src/ResourceModel/items/trench/
- Sources/src/ResourceModel/items/squad/
- Sources/src/ResourceModel/items/sprite/
- Sources/src/ResourceModel/items/infantry/
- Sources/src/ResourceModel/items/mesh/
- Sources/src/ResourceModel/items/object/
- Sources/src/ResourceModel/items/fence/
- Sources/src/ResourceModel/items/building/
- Sources/src/ResourceModel/items/bridge/
- Sources/src/ResourceModel/key_frame_tree_item.h
- Sources/src/ResourceModel/key_frame_tree_item.cpp
- Sources/src/ResourceModel/items/particle/
- Sources/src/ResourceModel/items/effect/
- Sources/src/ResourceModel/items/tileset/
- Sources/src/ResourceModel/items/road3d/
- Sources/src/ResourceModel/items/river3d/
- Sources/src/ResourceModel/items/mission/
- Sources/src/ResourceModel/items/chapter/
- Sources/src/ResourceModel/items/campaign/
- Sources/src/ResourceModel/items/medal/
- Sources/src/ResourceModel/items/gui/
- Sources/src/ResourceModel/references.h
- Sources/src/ResourceModel/references.cpp
- Sources/src/ResourceModel/combos.h
- Sources/src/ResourceModel/combos.cpp
- Sources/src/ResourceModel/localization.h
- Sources/src/ResourceModel/localization.cpp
- tools/zig/resource_model_references_test.cpp
- tools/zig/fixtures/resource_editor/references_root/
- Sources/src/ResourceModel/comparator.h
- Sources/src/ResourceModel/comparator.cpp
- tools/zig/resource_model_comparator_test.cpp
- tools/zig/fixtures/resource_editor/wpn/golden-synthetic-unknown.xml
- .github/workflows/cross-platform.yml
- tools/zig/run-s03-sweep.sh
- zig-out/local-test/resource_editor/s03-sweep.log
