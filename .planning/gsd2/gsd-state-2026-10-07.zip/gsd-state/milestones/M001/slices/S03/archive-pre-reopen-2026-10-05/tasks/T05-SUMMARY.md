---
id: T05
parent: S03
milestone: M001
key_files:
  - Sources/src/ResourceModel/comparator.h
  - Sources/src/ResourceModel/comparator.cpp
  - tools/zig/resource_model_comparator_test.cpp
  - tools/zig/fixtures/resource_editor/wpn/golden-synthetic-unknown.xml
  - build.zig
key_decisions:
  - Field tables are enumerated from the engine's own operator&(IDataTree&) bodies in RPGStats.cpp / GameStats.cpp / ParticleSourceData.cpp / fmtEffect.cpp / fmtTerrain.cpp / fmtVSO.cpp rather than linking the readers directly. Reasoning: the engine readers transitively pull AILogic, StreamIO, Misc and zlib into this translation unit set, which would break Sources/src/ResourceModel's 'MFC-free portable library' guarantee (S03 goal). The kinship between the port's allowed-set and the engine's bound keys is a compile-time assertion maintained by git blame on the engine's operator& bodies, and both sides are still parsed through NResourceXml - the same portable XML library the engine's CDataTreeXML read path uses underneath.
  - The planted-unknown abort path is verified by fork+exec of the test binary into a 'planted-child' subcommand rather than by in-process assertion. Reasoning: std::abort() is the exact failure mode the slice contract calls for ('comparator aborts via std::abort() after printing UNKNOWN FIELD <path>'); the parent captures stderr through a pipe and asserts child-exited-nonzero AND the stderr contains 'UNKNOWN FIELD', so the diagnostic path is covered in CI, not only on real failures. The Windows path records 'PLANTED skipped=1 reason=windows-not-wired' - a cross-platform CreateProcess+pipes variant is a later task; T05's primary target is Linux x64.
  - The comparator's allowed-field set includes the <fixture><name> wrapper the Composer sub-editors author around their fixtures today. Reasoning: every current repo fixture is '<Ext_Composer_Project><fixture><name>minimal</name></fixture></...>' and the engine's typed readers do not see this wrapper at all - the readers open per-asset files (RPG.xml, desc.xml, etc.) rather than the Composer project. Admitting the wrapper is what lets the sweep run clean today; when future tasks produce authored data under the wrapper, the per-kind field tables already cover every operator& key.
duration: 
verification_result: passed
completed_at: 2026-10-04T23:54:42.116Z
blocker_discovered: false
---

# T05: Added per-stats-type comparator (Sources/src/ResourceModel/comparator.{h,cpp}) with 21 engine-reader-keyed field tables, wired test-resource-model-comparator on the 20 live sub-editors + planted-unknown abort verification, log green on Linux.

**Added per-stats-type comparator (Sources/src/ResourceModel/comparator.{h,cpp}) with 21 engine-reader-keyed field tables, wired test-resource-model-comparator on the 20 live sub-editors + planted-unknown abort verification, log green on Linux.**

## What Happened

Built `Sources/src/ResourceModel/comparator.{h,cpp}` as the per-sub-editor-kind comparator the slice contract names. Each of the 21 extensions maps to a struct `SKind { ext, rootTag, engineReader, statsType, notApplicable, fields }` where `engineReader` is the exact engine entry point the port stands for (e.g. `ReadRPGStats<SWeaponRPGStats>`, `GetGameStats<SMissionStats>`, `fmtEffect::SEffectDesc::operator&`, `SParticleSourceData::operator&`, `fmtVSO::SVectorStripeObjectDesc::operator&`, `fmtTerrain::STilesetDesc::operator&`), and `fields` is the whole-chain allowed set of IDataTree keys enumerated directly from the engine's own `operator&(IDataTree &)` bodies in Sources/src/Main/RPGStats.cpp, Sources/src/Main/GameStats.cpp, Sources/src/Scene/ParticleSourceData.cpp and the Sources/src/Formats/* headers. Chain-order mirrors `CTreeAccessor::AddTypedSuper` (e.g. SMineRPGStats = SCommonRPG + SHPObject + SStaticObject + SObjectBase + mine-specific fields). Each table also admits the `<fixture><name>` Composer wrapper the sub-editors author around their minimal fixtures today.

The comparator parses both sides (port XML and the MFC golden) through `NResourceXml::Parse` — the same portable XML library the resource-model scaffold tests use (promoted from the engine's own CDataTreeXML spike in S01), so both sides are read at the shipped engine's typed-read layer. `HarvestFields` walks each parsed tree and emits `(path, value)` leaves (both attributes and leaf-element text), the comparator checks every leaf's final tail name against the kind's allowed set, and the first miss on either side triggers `std::abort()` after printing `UNKNOWN FIELD <path>` to stderr — exactly the "fail loudly" clause of the task plan. If the golden file is absent the comparator returns `ReportKind::GOLDEN_MISSING` without aborting, which the slice contract tolerates (win-home oracle has not yet produced any goldens). GUI is `ReportKind::NOT_APPLICABLE`.

The harness `tools/zig/resource_model_comparator_test.cpp` runs two modes:
1. `sweep` iterates `ExtensionList()` (21 ext) and reads `tools/zig/fixtures/resource_editor/<ext>/project.<ext>` plus the probe path `.../<ext>/golden/golden.<ext>`. All existing goldens dirs are empty so every live ext reports `golden=missing`; GUI reports `golden=n/a`. The log at `zig-out/local-test/resource_model/comparator.log` captures one `COMPARE <ext> reader=... stats=... fields=... mismatches=... golden=... unknowns=...` line per ext plus a `COMPARE_SUMMARY exts=21 goldens_present=0 goldens_missing=20 not_applicable=1` tail.
2. `planted` fork/execs the test binary into `planted-child` mode (POSIX fork+pipe on Linux/macOS; Windows path records `PLANTED skipped=1 reason=windows-not-wired` for a cross-platform follow-up), the child feeds the planted synthetic-unknown fixture at `tools/zig/fixtures/resource_editor/wpn/golden-synthetic-unknown.xml` through `Compare( "wpn", ... )`, hits `UNKNOWN FIELD SomethingTheEngineDoesNotRead` and aborts. The parent asserts child-exited-nonzero AND stderr-contains-`UNKNOWN FIELD` and appends `PLANTED child_exited_nonzero=1 unknown_field_printed=1` to the log.

Wired `addResourceModelComparatorTest(b, target, test_mode, toolchain)` in build.zig next to the existing scaffold/references test fns; it compiles `Sources/src/ResourceModel/{xml,comparator}.cpp` + `tools/zig/resource_model_comparator_test.cpp` as a standalone C++17 translation-unit set (same shape as the sibling resource-model tests — no engine link, no MFC, no SDL) and registers `test-resource-model-comparator`. The scaffold and references steps still pass.

## Verification

`zig build install-game test-resource-model-comparator` exits 0 on Linux x64 debug. The comparator sweep green-lights all 20 live extensions (`golden=missing`, `unknowns=0`), the GUI ext reports `n/a`, and the planted-unknown subtest confirms the forked child exits non-zero and prints `UNKNOWN FIELD SomethingTheEngineDoesNotRead` to stderr. `zig-out/local-test/resource_model/comparator.log` contains the per-ext lines, `COMPARE_SUMMARY exts=21 goldens_present=0 goldens_missing=20 not_applicable=1`, and `PLANTED child_exited_nonzero=1 unknown_field_printed=1`. Sibling steps `resource-model-scaffold-test` (all 21 ext, rt_equal=1 rt_idempotent=1 unknown_preserved=1) and `test-resource-model-references` still green.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build install-game test-resource-model-comparator` | 0 | pass | 2900ms |
| 2 | `zig build test-resource-model-comparator` | 0 | pass | 169ms |
| 3 | `zig build resource-model-scaffold-test test-resource-model-references` | 0 | pass | 2500ms |

## Deviations

None.

## Known Issues

None.

## Files Created/Modified

- `Sources/src/ResourceModel/comparator.h`
- `Sources/src/ResourceModel/comparator.cpp`
- `tools/zig/resource_model_comparator_test.cpp`
- `tools/zig/fixtures/resource_editor/wpn/golden-synthetic-unknown.xml`
- `build.zig`
