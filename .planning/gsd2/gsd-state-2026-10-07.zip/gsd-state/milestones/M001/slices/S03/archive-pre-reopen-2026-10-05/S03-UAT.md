# S03: S03 — UAT

**Milestone:** M001
**Written:** 2026-10-05T00:28:22.944Z

# S03 UAT

## UAT Type
Automated regression — `test-resource-model` tier + 16-tier MapEditor regression, run locally on Linux x64 and replicated in CI (macOS arm64, macOS x64, Windows MSVC, Linux x64).

## Preconditions
- Linux x64 build machine, Zig 0.16 toolchain
- `zig build install-game install-map-editor` succeeds from a clean checkout
- `Data/` present with shipped game assets (for BkEditorOpenMap tiers)
- `tools/zig/run-s03-sweep.sh` is executable

## Numbered Steps

1. Run `zig build test-resource-model`.
   **Expected:** exit 0; all three sub-steps (resource-model-scaffold-test, test-resource-model-references, test-resource-model-comparator) pass; no UNKNOWN FIELD output.

2. Run `zig build test-resources-all`.
   **Expected:** exit 0; depends on test-resource-model; aggregate reports success.

3. Run `tools/zig/run-s03-sweep.sh` and inspect `zig-out/local-test/resource_editor/s03-sweep.log`.
   **Expected:** 17 TIER lines all `VERDICT=PASS`; final line `S03 VERDICT=PASS`.

4. Manually load a fixture XML (e.g. `tools/zig/fixtures/resource_editor/wpn/`) through the scaffold test binary with `--roundtrip`.
   **Expected:** output bytes identical to input; no FutureBlob children survive a second round-trip.

5. In `test-resource-model-comparator`, substitute a fixture with a planted unknown field (field name not in the comparator's allowed set for that kind).
   **Expected:** binary exits non-zero; stderr contains `UNKNOWN FIELD <path>`.

6. Verify MapEditor regression tiers remain green after ResourceModel changes:
   Run `zig build map-editor-auto-m2 map-editor-m3-auto map-editor-game-reads-it-m3`.
   **Expected:** exit 0 on all three.

## Edge Cases
- A fixture with a `<FutureBlob>` node (unknown element): preserved through load/save unchanged; comparator does NOT abort on it (FutureBlob is not a stats field).
- A fixture with no MFC golden file: comparator returns `GOLDEN_MISSING`, does not abort.
- GUI sub-editor (`.gui`): comparator returns `NOT_APPLICABLE`; no abort, no field walk.
- Windows MSVC: the planted-unknown abort path records `PLANTED skipped=1 reason=windows-not-wired` (fork+exec variant not yet implemented); the rest of the comparator tests pass.

## Not Proven By This UAT
- macOS arm64 / Windows MSVC execution of `test-resource-model` locally (CI green is the proxy).
- MFC golden parity (no win-home goldens produced yet; covered by later slices with `resource-editor-game-reads-it`).
- S04 bridge ABI against ResourceModel (out of scope for S03).
- `test-resource-xml-roundtrip` and `test-dxt-tolerance` aggregate inclusion (deferred until S01 registers those build steps).
