# S03: ResourceModel: faithful MFC tree items, D-11 comparator, DXT gate, one sweep — UAT

**Milestone:** M001
**Written:** 2026-10-05T06:03:13.056Z

## UAT: S03 ResourceModel

### Linux (done, maintainer run at 27d03a607)
- [x] `bash tools/zig/run-resource-sweep.sh` gives VERDICT=PASS with every tier PASS (zig-out/local-test/resource_editor/resource-sweep.log).

### win-home (pending)
- [ ] Run `tools/zig/win-home/export-goldens.ps1` to fill `tools/zig/fixtures/resource_editor/<ext>/golden/` from MFC editor.exe exports. Then run `zig build test-resource-model -Dtest-mode=run`: comparator.log must show the golden comparisons as PASS, not "pending: golden missing".
- [ ] Open a port-saved project (a fixture re-saved through the model) in MFC editor.exe. It must load without error, with equal properties.

### CI (pending push)
- [ ] cross-platform.yml: test-resource-model passes on x86_64-linux-gnu, x86_64-windows-msvc, aarch64-macos, aarch64-linux-gnu and x86_64-macos.
