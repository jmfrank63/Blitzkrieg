---
id: T06
parent: S03
milestone: M001
key_files:
  - Sources/src/ResourceModel/comparator.cpp
  - Sources/src/ResourceModel/comparator.h
  - tools/zig/resource_model_comparator_test.cpp
  - tools/zig/win-home/export-goldens.ps1
  - tools/zig/fixtures/resource_editor/wpn/golden/README.md
  - docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md
key_decisions:
  - Unread nodes in shipped Data that come from older export layouts go in a reviewed kStaleFields table, each with its reason. They are counted and reported, not silently ignored, and a stale node on one side only is a difference.
  - Items of a container the reader entered but never indexed, and repeated names the struct itself asks for again, are not unknown fields, because the engine's own reader accounts for them.
  - Data-only hosts register a minimal IParticleManager so SSmokinParticleSourceData can be read. The only value it feeds is nUpdateStep, which is never serialised.
  - A wrong-kind read whose base node exists fails as UNKNOWN_FIELD, not UNREADABLE, because the engine reads it without complaint.
duration: 
verification_result: passed
completed_at: 2026-10-05T05:11:39.557Z
blocker_discovered: false
---

# T06: The D-11 comparator reads exported game data through the engine's own readers. All 1,776 shipped stats files across 19 kinds compare equal to themselves. Planted changes fail precisely: a one-ulp float, a dropped field, an unknown field, a stale field on one side only, an _h.dds byte, and DXT header/pixel changes. win-home/export-goldens.ps1 and the golden READMEs exist. All 20 golden comparisons report "pending: golden missing" because MFC goldens cannot be made on Linux.

**The D-11 comparator reads exported game data through the engine's own readers. All 1,776 shipped stats files across 19 kinds compare equal to themselves. Planted changes fail precisely: a one-ulp float, a dropped field, an unknown field, a stale field on one side only, an _h.dds byte, and DXT header/pixel changes. win-home/export-goldens.ps1 and the golden READMEs exist. All 20 golden comparisons report "pending: golden missing" because MFC goldens cannot be made on Linux.**

## What Happened

On resume, the earlier session had already rewritten comparator.{h,cpp} and resource_model_comparator_test.cpp. The test still aborted on the Linux debug build, though, and the win-home kit was missing.

Fixes, one hypothesis at a time:
1. Crash: SSmokinParticleSourceData::operator& calls InitIntegrals, which needs the IParticleManager singleton. The fix registers a comparator-owned manager in StartEngineReaders when none is registered. That manager only feeds nUpdateStep, a runtime cache that is never serialised, so it does not affect the comparison.
2. Effects: these open with document element <effect> (as CVisObjBuilder opens them). SExportKindInfo gains pszBase, which CreateDataTreeSaver and the root check now use.
3. Campaigns: these are Scenarios/Campaigns/<side>/<side>.xml, not 1.xml, and the test now lists them that way.
4. CVisitTree learned two engine behaviours:
   - A container the reader enters but never indexes was skipped by the reader: CTreeAccessor::Do2DArray skips an empty 2D array, and MFC writes it as <item size_x="0" size_y="0"/>.
   - A name asked for again under the same parent is noted as name#n: SBuildingRPGStats writes AmbientSound twice.
5. kStaleFields is a reviewed table of nodes that older exporters wrote and no current reader reads, each with its reason:
   - object EffectExplosion/EffectDeath, and effect sound, written as structs;
   - particle Position and GenerateSpinRand;
   - inline unit Acks;
   - BGImage/Script in one 2002 mission.
   Stale nodes are counted per kind in the log, and a stale node on one side only is a DIFFERENT.
6. Wrong-kind check: a weapon read as a medal is UNKNOWN_FIELD, because the engine reads it silently and ignores every field. A weapon read as an effect is UNREADABLE. A planted check for a stale node on one side only was added.

Golden kit: tools/zig/win-home/export-goldens.ps1 drives editor.exe batch mode (`*.ext src dest -f`). It works on a scratch copy of the fixture so the editor never writes into the repo. It then clears golden/ except README.md and .gitkeep, copies the export in, and prints PASS/FAIL per extension and a VERDICT. Every <ext>/golden/README.md explains how goldens are made.

The spec section "What the game reads it unchanged means" now records the comparator's rules.

## Verification

`zig build test-resource-model -Dtest-mode=run` exited 0 (Linux debug). comparator.log reports `VERDICT=PASS (goldens pending)`:
- 19 kinds PASS "shipped ... equal to themselves" (1,776 files, 0 failures).
- Planted checks PASS: one-ulp float, dropped field, unknown field on port and on golden, wrong kind (medal and effect), stale node on one side only, _h.dds byte, and DXT header/mip/pixel (pixels report PENDING_DXT_GATE).
- GOLDEN_SUMMARY extensions=20 pass=0 pending=20.

Static checks on export-goldens.ps1:
- The pwsh parser reports 0 errors.
- Run with a missing editor path, it throws the expected error.

Not run: the script itself. It needs MFC editor.exe on Windows.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-model -Dtest-mode=run` | 0 | pass | 19700ms |
| 2 | `pwsh ParseFile tools/zig/win-home/export-goldens.ps1` | 0 | pass | 1500ms |

## Deviations

The comparator and test had already been written by an earlier interrupted session; this session fixed them until they passed instead of writing them from scratch. Beyond the plan, a stale-field table and a planted stale-field check were added, and the spec's D-11 section was updated.

## Known Issues

Goldens cannot be generated on this Linux machine, so all 20 golden comparisons report "pending: golden missing", and the golden comparison is NOT done. Someone has to run tools/zig/win-home/export-goldens.ps1 on win-home and commit the result. Even with goldens present, the port has no exporter yet to compare them with; the test reports that as pending too. The DXT pixel tolerance gate stays with T07.

## Files Created/Modified

- `Sources/src/ResourceModel/comparator.cpp`
- `Sources/src/ResourceModel/comparator.h`
- `tools/zig/resource_model_comparator_test.cpp`
- `tools/zig/win-home/export-goldens.ps1`
- `tools/zig/fixtures/resource_editor/wpn/golden/README.md`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`
