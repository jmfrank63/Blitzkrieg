---
id: T01
parent: S03
milestone: M001
key_files:
  - Sources/src/ResourceModel/variant.h
  - Sources/src/ResourceModel/variant.cpp
  - Sources/src/ResourceModel/prop.h
  - Sources/src/ResourceModel/domen_id.h
  - Sources/src/ResourceModel/tree_item.h
  - Sources/src/ResourceModel/tree_item.cpp
  - Sources/src/ResourceModel/factory.h
  - Sources/src/ResourceModel/factory.cpp
  - Sources/src/ResourceModel/xml.h
  - Sources/src/ResourceModel/xml.cpp
  - Sources/src/ResourceModel/future_blob.h
  - Sources/src/ResourceModel/future_blob.cpp
  - Sources/src/ResourceModel/project.h
  - Sources/src/ResourceModel/project.cpp
  - Sources/src/ResourceModel/root.h
  - tools/zig/resource_model_scaffold_test.cpp
  - build.zig
key_decisions:
  - CVariant uses std::variant<monostate, int, float, bool, string, Vec3, Color, ComboIndex, Ref>; the EKind enum values are the variant alternative indices in declaration order so GetKind() just returns index(). Reasoning: lossless storage of the authored type, no DWORD-flag cache, trivial equality for round-trip tests.
  - CTreeItem owns children as std::vector<std::unique_ptr<CTreeItem>> rather than std::list<CPtr<...>>; the MFC list order mattered for serialisation but did not need O(1) splicing. Vector + unique_ptr makes the move semantics explicit and lets a sub-editor swap a FutureBlob child for a typed one in place.
  - CTreeItemFactory is a Meyers singleton keyed by int. T02 adds the REGISTER_CLASS equivalents as file-scope objects in each per-sub-editor translation unit; the factory is deliberately empty today so the scaffold test can prove the FutureBlob fallback path lands.
  - xml.h/.cpp are a verbatim promotion of the S01 spike (namespace rename XmlSpike -> NResourceXml) rather than a rewrite. The spike files stay in place so S01's test target keeps working, and the library can reuse the proven round-trip semantics without re-earning them.
  - Scaffold Save() returns the stored Document bytes verbatim rather than rebuilding from the Root tree. T02's first typed root class must change Save() to rebuild Document.root from the typed subtree and fall back to the stored node only for FutureBlob children, otherwise T02 authored edits will not reach the on-disk bytes - this is captured in a comment at the top of project.cpp and in MEM009.
duration: 
verification_result: passed
completed_at: 2026-10-04T22:40:24.484Z
blocker_discovered: false
---

# T01: Scaffolded Sources/src/ResourceModel/ as an MFC-free C++17 library (variant/prop/tree-item/factory/xml/project/future-blob) and wired resource-model-scaffold-test on the wpn fixture.

**Scaffolded Sources/src/ResourceModel/ as an MFC-free C++17 library (variant/prop/tree-item/factory/xml/project/future-blob) and wired resource-model-scaffold-test on the wpn fixture.**

## What Happened


Created Sources/src/ResourceModel/ as a self-contained C++17 translation-unit set replacing the MFC CTreeItem/SProp/CVariant/CTreeItemObjectFactory baseline that T02-T07 will populate.

- variant.h/.cpp: NResourceModel::CVariant on std::variant<monostate,int,float,bool,string,Vec3,Color,ComboIndex,Ref>; EKind indices follow the variant alternatives verbatim so GetKind() == index(). Replaces CVariant's EVarialeType + flag-gated optimisation caches with explicit alternatives; no DWORD, no mutable string cache.
- prop.h: NResourceModel::SProp mirrors Sources/src/editor/TreeItem.h:10 field-for-field (nId, szDefaultName, szDisplayName, nDomenType, value, szStrings) minus the CVariant/CVectorOfStrings coupling.
- domen_id.h: Header-only mirror of the DT_* enum from CtrlObjectInspector.h:25 so widget routing survives the port without pulling in the inspector header.
- tree_item.h/.cpp: CTreeItem base with vector<unique_ptr<CTreeItem>> children, CPropVector values, defaultChilds list, defaultValues vector. Drops SECTreeCtrl*, HTREEITEM, pItemParent, CPtr<>, IRefCount, DECLARE_SERIALIZE, OBJECT_NORMAL_METHODS - everything the Qt port can re-introduce at its own layer.
- factory.h/.cpp: CTreeItemFactory on std::unordered_map<int, std::function<unique_ptr<CTreeItem>()>>; Meyers singleton; Create() returns nullptr for unregistered types so the project loader can fall back to FutureBlob. Empty at this task per plan ("the per-sub-editor REGISTER_CLASS blocks move in T02/T03").
- xml.h/.cpp: Promoted verbatim from Sources/src/ResourceModel/spike/xml_spike.{h,cpp} with namespace rename XmlSpike -> NResourceXml. Spike files kept in place so S01's test target is not disturbed.
- future_blob.h/.cpp: FutureBlob is a CTreeItem subclass that stores an opaque NResourceXml::Node; nItemType=0 (E_UNKNOWN_ITEM). This is the "any element whose tag the factory does not know" wrapper the plan calls for.
- project.h/.cpp: Project is {Document, unique_ptr<Root>}. Load() parses the XML and wraps document.root in a FutureBlob (since the factory is empty today). Save() currently returns NResourceXml::Serialise(document) verbatim; the comment at the top of project.cpp flags that once T02 registers typed root classes Save must rebuild Document.root from the typed subtree, otherwise authored edits will not reach the bytes.
- root.h: Thin alias (Root = CTreeItem) so later tasks can specialise per sub-editor without a header churn.
- tools/zig/resource_model_scaffold_test.cpp: Reads tools/zig/fixtures/resource_editor/wpn/project.wpn (overrideable via argv[1]), Load+Save, asserts byte-identity, prints "SCAFFOLD <ext> bytes=<n> rt_equal=<0|1>" to stderr. BK_DEBUG_LOG=1 adds "SCAFFOLD <ext> depth=<n> elements=<n> root=<name>" plus a first-mismatch byte offset on failure. Also fails hard if project.root is not a FutureBlob (early-warning for T02 breaking the loader contract).
- build.zig: addResourceModelScaffoldTest wires the "resource-model-scaffold-test" step. Standalone C++17 translation-unit set, platform-conditional stdc++/c++ link, no engine libs, no SDL. Called from the main configure path next to addRuntimeHeadersTest.

Grep audit: grep -rE 'windows\.h|afx|MFC|CPtr|CString|IRefCount|BasicObjectFactory|DECLARE_SERIALIZE' Sources/src/ResourceModel/*.{h,cpp} returns matches only inside comments explaining what the port replaces; comment-stripped grep returns zero hits.


## Verification


1. "zig build install-game resource-model-scaffold-test" (the plan's Verification): built install-game cleanly (Game binary at zig-out/game/linux/x86_64/release/Game, 28,192,632 bytes, unchanged timestamp) and the scaffold test ran: "SCAFFOLD wpn bytes=127 rt_equal=1". Exit code 0.
2. "BK_DEBUG_LOG=1 zig build resource-model-scaffold-test": additionally emits "SCAFFOLD wpn depth=2 elements=3 root=Weapon_Composer_Project" so the observability-impact promise ("dumps parse tree depth and child counts") is observable.
3. MFC-ban grep: grep -rE 'windows\.h|afx|MFC|CPtr|CString|IRefCount|BasicObjectFactory|DECLARE_SERIALIZE' on comment-stripped Sources/src/ResourceModel/*.{h,cpp} returns zero hits (the raw grep hits are all in comments documenting what the port replaces).

Round-trip is byte-identical: 127 bytes in, 127 bytes out, memcmp passes.


## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build resource-model-scaffold-test` | 0 | pass | 5000ms |
| 2 | `zig build install-game resource-model-scaffold-test` | 0 | pass | 60000ms |
| 3 | `BK_DEBUG_LOG=1 zig build resource-model-scaffold-test` | 0 | pass | 2000ms |
| 4 | `grep -rE 'windows\.h|afx|MFC|CPtr|CString|IRefCount|BasicObjectFactory|DECLARE_SERIALIZE' Sources/src/ResourceModel/*.{h,cpp} (comment-stripped)` | 1 | pass | 100ms |

## Deviations

None. The task plan's "Done when" (grep audit returning zero, install-game + resource-model-scaffold-test succeeding, byte-identical round-trip) is met exactly.

## Known Issues

None. The scaffold is empty by design and T02 is where the first typed root class lands. The Save() fallback behaviour (comment in project.cpp) is a deliberate scaffold shortcut, not a defect.

## Files Created/Modified

- `Sources/src/ResourceModel/variant.h`
- `Sources/src/ResourceModel/variant.cpp`
- `Sources/src/ResourceModel/prop.h`
- `Sources/src/ResourceModel/domen_id.h`
- `Sources/src/ResourceModel/tree_item.h`
- `Sources/src/ResourceModel/tree_item.cpp`
- `Sources/src/ResourceModel/factory.h`
- `Sources/src/ResourceModel/factory.cpp`
- `Sources/src/ResourceModel/xml.h`
- `Sources/src/ResourceModel/xml.cpp`
- `Sources/src/ResourceModel/future_blob.h`
- `Sources/src/ResourceModel/future_blob.cpp`
- `Sources/src/ResourceModel/project.h`
- `Sources/src/ResourceModel/project.cpp`
- `Sources/src/ResourceModel/root.h`
- `tools/zig/resource_model_scaffold_test.cpp`
- `build.zig`
