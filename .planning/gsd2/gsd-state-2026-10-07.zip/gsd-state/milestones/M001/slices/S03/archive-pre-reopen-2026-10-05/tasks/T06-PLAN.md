---
estimated_steps: 4
estimated_files: 4
skills_used: []
---

# T06: Wire `test-resource-model` on five engine targets, extend `test-resources-all`, record the S03 Linux sweep

Why: The slice-level claim is that `test-resource-model` is green on five engine targets. The individual tool steps T01/T04/T05 added (`resource-model-scaffold-test`, `test-resource-model-references`, `test-resource-model-comparator`) must be aggregated under one `test-resource-model` meta-step so the roadmap's success-criteria sentence maps to a single invocation; the aggregate must be wired into `test-resources-all` so S16's full-sweep gate pulls it in; the sweep script and recorded log are the slice's auditable finish line.

Do: In build.zig: add `b.step("test-resource-model", ...)` that `dependOn`s `resource-model-scaffold-test`, `test-resource-model-references`, and `test-resource-model-comparator`. Confirm each underlying tool was registered on all five engine targets by `addEngineHostedTool` (Linux x64, Windows x64 MSVC, macOS arm64, macOS x64, and the host) — Linux is this agent's native proof; the other four are CI's. Add `test-resources-all` as a top-level step if it does not yet exist, having it `dependOn` `test-resource-model` plus any other tiers S01's summary claims it should include (`test-resource-xml-roundtrip`, `test-dxt-tolerance`); if those older S01 steps are not registered in build.zig (grep for them first — the slice context notes they were absent from the build file), add a `BK_RESOURCE_MODEL_ONLY=1`-gated branch that excludes them and documents why in a build.zig comment. Add `.github/workflows/cross-platform.yml` entries to run `zig build test-resource-model` on the macOS arm64, macOS x64, and Windows MSVC runners (match the pattern used for `test-rmg-composer-roundtrip`).

Add `tools/zig/run-s03-sweep.sh` (CRLF, +x), modelled on `tools/zig/run-s02-sweep.sh`, that runs: `install-game`, `install-map-editor`, `test-resource-model`, then every S02 regression tier (test-editor-kit + 13 MapEditor tiers). PREEXISTING classification for BkEditorOpenMap tiers is identical to S02's. Writes per-tier EXIT/ELAPSED_MS/VERDICT lines to `zig-out/local-test/resource_editor/s03-sweep.log` with final `S03 VERDICT=PASS|FAIL`. PASS iff: `test-resource-model` PASS; `test-editor-kit` PASS; the 5 non-BkEditorOpenMap MapEditor tiers PASS; no new FAIL.

Done when: `zig build test-resource-model` exits 0 on Linux x64; `grep -q 'test-resource-model' .github/workflows/cross-platform.yml` matches; `zig-out/local-test/resource_editor/s03-sweep.log` exists and its final line is `S03 VERDICT=PASS`; the log contains at least one PASS line for `test-resource-model`.

## Inputs

- `build.zig`
- `.github/workflows/cross-platform.yml`
- `tools/zig/run-s02-sweep.sh`
- `zig-out/local-test/resource_editor/s02-sweep.log`
- `Sources/src/ResourceModel/comparator.h`
- `Sources/src/ResourceModel/references.h`
- `tools/zig/resource_model_scaffold_test.cpp`
- `tools/zig/resource_model_references_test.cpp`
- `tools/zig/resource_model_comparator_test.cpp`

## Expected Output

- `build.zig`
- `.github/workflows/cross-platform.yml`
- `tools/zig/run-s03-sweep.sh`
- `zig-out/local-test/resource_editor/s03-sweep.log`

## Verification

bash tools/zig/run-s03-sweep.sh

## Observability Impact

The S03 sweep log is the single audit surface for the slice; a future agent reads `zig-out/local-test/resource_editor/s03-sweep.log` to see which tier regressed, with signature matching for PREEXISTING failures so a new red (different signature) is not masked.
