---
id: S03
parent: M001
milestone: M001
provides:
  - Faithful MFC tree items (property tables + IDataTree serialisation) for S04 and S06..S15
  - D-11 comparator over exported data
  - DXT gate
  - run-resource-sweep.sh
requires:
  []
affects:
  []
key_files:
  - tools/zig/mfc_item_inventory.py
  - tools/zig/fixtures/resource_editor/mfc-item-inventory.json
  - tools/zig/resource_model_test.cpp
  - Sources/src/ResourceModel/items
  - Sources/src/ResourceModel/xml.cpp
  - Sources/src/ResourceModel/comparator.cpp
  - Sources/src/ResourceModel/dxt_gate.cpp
  - tools/zig/fixtures/resource_editor/dxt-tolerance.json
  - tools/zig/win-home/export-goldens.ps1
  - tools/zig/run-resource-sweep.sh
key_decisions:
  - D006-D009 (review steer)
  - D010: long runs are run in the foreground or cited from the maintainer's run, never left in the background
patterns_established:
  - (none)
observability_surfaces:
  - none
drill_down_paths:
  []
duration: ""
verification_result: passed
completed_at: 2026-10-05T06:03:13.056Z
blocker_discovered: false
---

# S03: ResourceModel: faithful MFC tree items, D-11 comparator, DXT gate, one sweep

**ResourceModel is now a faithful port of the MFC tree items: property tables and IDataTree serialisation are checked against a generated inventory of 217 classes, and all 23 projects round-trip byte-identically. The D-11 comparator reads exported game data through the engine's readers; the MFC goldens are pending on win-home. The DXT gate is measured on 20 shipped textures, and one sweep passes all 18 Linux tiers.**

## What Happened

S03 was reopened by the 2026-10-05 review steer (D006-D009).
- T01: tools/zig/mfc_item_inventory.py generates mfc-item-inventory.json from Sources/src/editor: 217 classes and 423 properties (weapon 48 and mesh 108, counting properties plus default children). test-resource-model-fidelity checks the port against it, and also checks round trips of 23 projects and inserts of 196 item types. Known gaps went into a tracked xfail list that could only shrink.
- T02-T04: these ported every family's property tables and operator&(IDataTree&): Weapon, Mine, Trench, Squad, Sprite and Infantry; Mesh, Object, Fence, Building and Bridge; and Particle (with the Key_frames base), Effect, TileSet/Crosset, 3D Road and River, Mission, Chapter, Campaign, Medal and GUI. Each step emptied its block of the xfail list.
- T05: the writer now emits MSXML's compact MFC layout. Both MFC TestProjects re-save byte-identically, and the xfail list is empty. The spec's D-07 records the cases that are only content-proved.
- T06: the comparator was rewritten to compare exported data through the engine readers. All 1,776 shipped stats files (19 kinds) compare equal to themselves, and planted changes fail precisely. win-home/export-goldens.ps1 and the golden READMEs exist.
- T07: the DXT tolerance was measured on 20 shipped _c.dds files (DXT1/3/5, with alpha) into dxt-tolerance.json, and CompareDxt gates on it.
- T08: one sweep script, smoke immunity to the OS pointer, and test-resource-model in CI on five targets. The maintainer committed T05-T08 in 27d03a607 and ran the full sweep there.

## Verification

This verification cites only the maintainer's run of `bash tools/zig/run-resource-sweep.sh` at commit 27d03a607: zig-out/local-test/resource_editor/resource-sweep.log, 18 tiers all RESULT=PASS, VERDICT=PASS, about 27 min. Those tiers are the install, test-resource-model (fidelity, comparator and DXT gate inside), test-resource-core, test-resource-bridge, test-editor-kit and all 13 Map Editor tiers of AGENTS.md. The working tree has not changed from 27d03a607 under tools, Sources, build.zig or .github (git diff --stat is empty). Not verified: MFC golden comparisons are pending, because goldens cannot be generated on Linux. MFC editor.exe reading a port-written project is a win-home check. CI on macOS, Windows and Linux arm64 has not been seen, because the branch is not pushed.

## Requirements Advanced

None.

## Requirements Validated

None.

## New Requirements Surfaced

None.

## Requirements Invalidated or Re-scoped

None.

## Operational Readiness

None.

## Deviations

T08's sweep was run by the maintainer at 27d03a607 rather than inside an agent session (override 2026-10-05T06:01, D010).

## Known Limitations

The MFC export goldens cannot be generated on Linux. All 20 golden comparisons report pending, and the D-11 golden comparison is NOT done. Whether MFC can read port output is not yet proved on win-home. The byte-identity cases listed in spec D-07 (escaping, mixed text, pre-int64 values) are content-proved only.

## Follow-ups

Run the win-home golden export and the MFC read-back. Watch CI after the maintainer pushes. S04 (lock file locked_<user>, per-node geometry) can now proceed on the faithful items.

## Files Created/Modified

None.
