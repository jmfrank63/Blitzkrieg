---
estimated_steps: 1
estimated_files: 4
skills_used: []
---

# T01: MFC tree item inventory generator + failing fidelity tests (incl. the `<>` insert bug)

Tests first. Write `tools/zig/mfc_item_inventory.py` (or a Zig tool, whichever fits tools/zig conventions) that parses every `Sources/src/editor/*TreeItem.{h,cpp}` (+ TreeItem.cpp base, TreeItemFactory.cpp, AnimTreeItem, KeyFrame items) and emits `tools/zig/fixtures/resource_editor/mfc-item-inventory.json`: per class its ClassTypeID (from the factory), property table (name, DT_* domain type, default, order — from the `defaultValues`/InitDefaultValues code), child-item list, and the element names and order written by its `operator&( IDataTree & )`. Spot-check the generator against the review's counts (weapon 48, mesh-tree 108) and fail if they differ. Then add to `test-resource-model`: (a) an inventory-conformance test over every port item class; (b) a round-trip test over every project in `Data/Editor/TestProjects/*` (copied to zig-out/local-test, never in place) and every fixture: load→save→reload content-equal and load→save byte-identical; (c) insert-each-type→save→reload valid-XML test. Commit the tests failing (expected-fail list recorded in the test so the tier still reports the gaps precisely); later tasks shrink that list to empty.

## Inputs

- `Sources/src/editor`
- `Sources/src/ResourceModel`
- `Data/Editor/TestProjects`
- `tools/zig/fixtures/resource_editor`
- `.gsd/OVERRIDES.md`

## Expected Output

- `tools/zig/mfc_item_inventory.py`
- `tools/zig/fixtures/resource_editor/mfc-item-inventory.json`
- `tools/zig/resource_model_test.cpp`

## Verification

python3 tools/zig/mfc_item_inventory.py --check && zig build test-resource-model -Dtest-mode=run

## Observability Impact

Test output lists each failing class/project with the first difference; the expected-fail list is the visible to-do for T02-T05.
