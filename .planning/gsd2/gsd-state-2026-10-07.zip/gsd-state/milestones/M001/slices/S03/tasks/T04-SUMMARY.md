---
id: T04
parent: S03
milestone: M001
key_files:
  - Sources/src/ResourceModel/key_frame_tree_item.h
  - Sources/src/ResourceModel/key_frame_tree_item.cpp
  - Sources/src/ResourceModel/items/particle/particle.cpp
  - Sources/src/ResourceModel/items/effect/effect.cpp
  - Sources/src/ResourceModel/items/tileset/tileset.cpp
  - Sources/src/ResourceModel/items/road3d/road3d.cpp
  - Sources/src/ResourceModel/items/river3d/river3d.cpp
  - Sources/src/ResourceModel/items/mission/mission.cpp
  - Sources/src/ResourceModel/items/chapter/chapter.cpp
  - Sources/src/ResourceModel/items/campaign/campaign.cpp
  - Sources/src/ResourceModel/items/medal/medal.cpp
  - Sources/src/ResourceModel/items/gui/gui.h
  - Sources/src/ResourceModel/editor_env.h
  - Sources/src/ResourceModel/combos.cpp
  - tools/zig/mfc_item_inventory.py
  - tools/zig/resource_model_test.cpp
  - tools/zig/fixtures/resource_editor/resource-model-xfail.txt
  - build.zig
key_decisions:
  - MFC's frame lookups become editor_env seams: HasEditorFrame() returns true (MFC creates every frame at start-up) and GetFrameProjectFileName() returns the active project, since the port opens one project at a time
  - FillVectorOfSides reads partys.xml from a new GetGameDataDir() seam (MFC's IDataStorage root), falling back to the static playerSides() table
  - The inventory generator resolves bSerializeChilds through the base chain (nearest assigning class wins), fixing the 15 GUI template classes
duration: 
verification_result: passed
completed_at: 2026-10-05T04:45:46.326Z
blocker_discovered: false
---

# T04: Ported MFC property tables and IDataTree serialisation for Particle (with MFC-shaped Key_frames keyframe base), Effect, TileSet/Crosset (TileIndex/CrossIndex), 3D Road, 3D River, Mission, Chapter, Campaign, Medal and GUI; regenerated their 10 fixtures; T04 xfail block is empty (503 PASS, 0 FAIL)

**Ported MFC property tables and IDataTree serialisation for Particle (with MFC-shaped Key_frames keyframe base), Effect, TileSet/Crosset (TileIndex/CrossIndex), 3D Road, 3D River, Mission, Chapter, Campaign, Medal and GUI; regenerated their 10 fixtures; T04 xfail block is empty (503 PASS, 0 FAIL)**

## What Happened

I reused T03's throwaway code generator (copied to /tmp/t04: gen.py, extract.py, fixgen.cpp). It translates each MFC *TreeItem.h class (constructor flags, type) and each InitDefaultValues body line for line into Sources/src/ResourceModel/items/<kind>/. I extended it for T04:
- `g_frameManager.GetFrame(E_*_FRAME)->GetProjectFileName()` becomes the new editor_env seam `GetFrameProjectFileName()`, the active project's file.
- The "no frame" guards become `HasEditorFrame()`, which returns true: MFC creates every frame at start-up, so those guards never fire.
- `pair<float,float>` becomes `std::pair`.
- `_ITEMS` enum names are now matched.
- Classes and bodies inside `/* */` are skipped (Chapter's music items are commented out in MFC).
- An intermediate base whose E_ value the factory never registers is tolerated.

Hand-written parts:
- **Keyframe base:** key_frame_tree_item.{h,cpp} is rewritten to MFC's CKeyFrameTreeItem::operator&. framesList is a `std::list<std::pair<float,float>>` written as `<Key_frames><item first= second=/></Key_frames>`. This replaces the invented `<frames>` element.
- **TileSet:** CTileSetTilePropsItem and CCrossetTilePropsItem write their TileIndex/CrossIndex attributes.
- **GUI:** CTemplatesTreeItem (directory, window type) and CTemplatePropsTreeItem (window type, XML file) keep `bSerializeChilds = false`. The UI_* window types are mirrored from UI/UI.h.
- **Player sides:** FillVectorOfSides is ported into combos. It reads `GetGameDataDir() + "partys.xml"` (new editor_env seam) and falls back to playerSides().

Two problems in the reference itself were fixed:
1. **GUI child serialisation.** mfc_item_inventory.py read bSerializeChilds only from a class's own constructor. It now walks the base chain, so the 15 GUI template classes correctly write no childs, matching MFC. The inventory was regenerated; `--check` is clean.
2. **Player-side strings.** The fidelity test counted a runtime FillVectorOfSides() entry as one string. It now expands it to the party names of the tracked Data/partys.xml (8 parties), which is what MFC reads, and calls SetGameDataDir("Data/") at start.

The ten stub fixtures (pcp, eff, til, 3rd, 3rv, mip, chc, cgc, mdc, gui) were regenerated through the model, the way MFC builds a new project. Each is the default tree plus items MFC's insert handlers create (effect animation and function particle; terrain, tile and crosset tile with indices; river layer; mission objective and music; chapter mission and place; campaign chapter and template), and pcp has an extra key frame. EXTENSIONS.md was refreshed by `zig build make-resource-fixtures`. The T04 block of resource-model-xfail.txt is emptied. build.zig adds editor_env.cpp to the references test, because combos.cpp now needs it.

## Verification

`zig build test-resource-model -Dtest-mode=run` exits 0. resource-model-fidelity reports 503 PASS, 2 XFAIL, 0 FAIL, 0 XPASS, 0 stale ids. The 2 XFAIL are the T05 roundtrip-bytes checks for WinSniper.unt and current.msh, which fail on MFC's compact layout. All T04 inventory, insert and fixture round-trip checks (bytes, content, typed, edit) pass. The comparator logs COMPARE_SUMMARY exts=21, and the planted UNKNOWN FIELD still aborts. `python3 tools/zig/mfc_item_inventory.py --check` passes. `zig build make-resource-fixtures` passes. test-resources-all, test-resource-bridge and test-resource-core all pass (exit 0).

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-model -Dtest-mode=run` | 0 | pass (fidelity 503 PASS, 2 XFAIL T05, 0 FAIL, 0 XPASS) | 3000ms |
| 2 | `python3 tools/zig/mfc_item_inventory.py --check` | 0 | pass | 1000ms |
| 3 | `zig build make-resource-fixtures` | 0 | pass | 2000ms |
| 4 | `zig build test-resources-all -Dtest-mode=run` | 0 | pass | 2000ms |
| 5 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 11000ms |
| 6 | `zig build test-resource-core -Dtest-mode=run` | 0 | pass | 500ms |

## Deviations

The task touched more than the planned items directory. tools/zig/mfc_item_inventory.py had a bug: it ignored inherited bSerializeChilds. The fidelity test needed to expand the FillVectorOfSides runtime strings. build.zig needed editor_env.cpp in the references test. editor_env and combos gained seams. Ten fixtures and EXTENSIONS.md were regenerated.

## Known Issues

TestProjects 01_GUI, 04_Effect, 09_TileSet, 11_Particle and 16-21 contain only a README, so these kinds are proved only on the repo fixtures, which the port generated itself. No MFC goldens exist yet (T06). roundtrip-bytes of the two real MFC projects remains T05's.

## Files Created/Modified

- `Sources/src/ResourceModel/key_frame_tree_item.h`
- `Sources/src/ResourceModel/key_frame_tree_item.cpp`
- `Sources/src/ResourceModel/items/particle/particle.cpp`
- `Sources/src/ResourceModel/items/effect/effect.cpp`
- `Sources/src/ResourceModel/items/tileset/tileset.cpp`
- `Sources/src/ResourceModel/items/road3d/road3d.cpp`
- `Sources/src/ResourceModel/items/river3d/river3d.cpp`
- `Sources/src/ResourceModel/items/mission/mission.cpp`
- `Sources/src/ResourceModel/items/chapter/chapter.cpp`
- `Sources/src/ResourceModel/items/campaign/campaign.cpp`
- `Sources/src/ResourceModel/items/medal/medal.cpp`
- `Sources/src/ResourceModel/items/gui/gui.h`
- `Sources/src/ResourceModel/editor_env.h`
- `Sources/src/ResourceModel/combos.cpp`
- `tools/zig/mfc_item_inventory.py`
- `tools/zig/resource_model_test.cpp`
- `tools/zig/fixtures/resource_editor/resource-model-xfail.txt`
- `build.zig`
