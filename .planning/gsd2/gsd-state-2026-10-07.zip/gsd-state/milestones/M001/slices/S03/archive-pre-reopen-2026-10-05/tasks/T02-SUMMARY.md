---
id: T02
parent: S03
milestone: M001
key_files:
  - Sources/src/ResourceModel/items/stats_item.h
  - Sources/src/ResourceModel/items/stats_item.cpp
  - Sources/src/ResourceModel/items/tree_item_types.h
  - Sources/src/ResourceModel/items/weapon/weapon.h
  - Sources/src/ResourceModel/items/weapon/weapon.cpp
  - Sources/src/ResourceModel/items/mine/mine.h
  - Sources/src/ResourceModel/items/mine/mine.cpp
  - Sources/src/ResourceModel/items/trench/trench.h
  - Sources/src/ResourceModel/items/trench/trench.cpp
  - Sources/src/ResourceModel/items/squad/squad.h
  - Sources/src/ResourceModel/items/squad/squad.cpp
  - Sources/src/ResourceModel/items/sprite/sprite.h
  - Sources/src/ResourceModel/items/sprite/sprite.cpp
  - Sources/src/ResourceModel/items/infantry/infantry.h
  - Sources/src/ResourceModel/items/infantry/infantry.cpp
  - Sources/src/ResourceModel/items/mesh/mesh.h
  - Sources/src/ResourceModel/items/mesh/mesh.cpp
  - Sources/src/ResourceModel/items/object/object.h
  - Sources/src/ResourceModel/items/object/object.cpp
  - Sources/src/ResourceModel/items/fence/fence.h
  - Sources/src/ResourceModel/items/fence/fence.cpp
  - Sources/src/ResourceModel/items/building/building.h
  - Sources/src/ResourceModel/items/building/building.cpp
  - Sources/src/ResourceModel/items/bridge/bridge.h
  - Sources/src/ResourceModel/items/bridge/bridge.cpp
  - Sources/src/ResourceModel/factory.cpp
  - Sources/src/ResourceModel/project.cpp
  - tools/zig/resource_model_scaffold_test.cpp
  - build.zig
key_decisions:
  - CStatsItem is the single shared base for all 121 ported item classes; it holds nItemType and (for roots) the XML tag. Reasoning: 110 of the 121 kinds share the same shape (empty prop vector in T02, nItemType only), so a one-line CStatsItem subclass per kind beats 121 full header/impl pairs and keeps the diff-against-MFC audit shallow.
  - Root tag -> ETreeItemType map lives next to CStatsItem as a Meyers-singleton std::unordered_map populated by RegisterRootTag calls in factory.cpp PopulateFactory. Project::Load() touches CTreeItemFactory::Instance() first so the lambda-captured PopulateFactory runs before LookupRootTag reads the map; otherwise a caller that never created an item would see an empty tag map and fall back to FutureBlob at the root.
  - Save() takes two paths: unknown-root projects re-emit the stored Document bytes verbatim (the scaffold contract); typed-root projects rebuild Document.root with the typed xmlTag + stored root attributes + typed children (SProp-walk) + FutureBlob children (verbatim-node). Reasoning: the fixtures carry authored data under a `<fixture>` element the port's factory does not know; keeping that under a FutureBlob child of the typed root lets the authored bytes survive untouched while higher layers walk the typed root.
duration: 
verification_result: passed
completed_at: 2026-10-04T23:33:58.191Z
blocker_discovered: false
---

# T02: Ported every CTreeItem subclass for the 11 stats-only sub-editors (121 classes) into Sources/src/ResourceModel/items/, wired a tag->type map so Project::Load produces a typed root, and extended the scaffold test to sweep every stats-only fixture with a planted-FutureBlob unknown-node check.

**Ported every CTreeItem subclass for the 11 stats-only sub-editors (121 classes) into Sources/src/ResourceModel/items/, wired a tag->type map so Project::Load produces a typed root, and extended the scaffold test to sweep every stats-only fixture with a planted-FutureBlob unknown-node check.**

## What Happened


Added Sources/src/ResourceModel/items/<kind>/<kind>.{h,cpp} for weapon, mine, trench, squad, sprite, infantry, mesh, object, fence, building, bridge - 11 header/impl pairs plus a shared stats_item.{h,cpp} base and a tree_item_types.h mirror of the ETreeItemType constants from Sources/src/editor/TreeItem.h.

Each per-kind header declares its CTreeItem subclasses as one-line CStatsItem shells that set nItemType in their constructor and (for roots) capture the project-XML tag ("Weapon_Composer_Project" etc.). The MFC prop vectors stay empty: current fixtures are minimal `<X_Composer_Project><fixture><name>minimal</name></fixture></X_Composer_Project>` files, so the typed root has no SProp values to serialise and the fixture subtree lands in FutureBlob verbatim. Later tasks move InitDefaultValues bodies in.

Rewrote Sources/src/ResourceModel/factory.cpp as a single PopulateFactory() that calls REGISTER_CLASS( type, Class ) 121 times under per-kind blocks matching Sources/src/editor/TreeItemFactory.cpp line-for-line; root items get a RegisterRootTag("...Composer_Project", type) on the next line. Added LookupRootTag / RegisterRootTag in items/stats_item.{h,cpp} as a Meyers-singleton tag->type map.

Rewired Sources/src/ResourceModel/project.cpp: Load() now touches CTreeItemFactory::Instance() first (to force PopulateFactory to run before LookupRootTag reads the tag map), looks up the root tag, and if a typed root exists, adopts every parsed child under it as a FutureBlob. Save() rebuilds Document.root from the typed subtree + the FutureBlob children (keeping stored root attributes + child order) when the root is typed; it still falls back to the stored Document for unrecognised-root projects.

Rewrote tools/zig/resource_model_scaffold_test.cpp to sweep all 11 extensions when invoked with no args (default from CI), while still accepting a single-fixture path for debug loops. For each ext it checks three things: byte-identity on first Save (rt_equal), idempotence by Load->Save->Load->Save (rt_idempotent), and unknown-node preservation by planting `<FutureBlob attr="v"><child/></FutureBlob>` under the root before serialising and grepping the output for the planted bytes (unknown_preserved). Also emits childs=<n> props=<n> per the Observability Impact clause so a future agent spots a dropped factory registration at a glance.

Added the new TU files to the resource-model-scaffold-test step in build.zig next to the existing variant/tree_item/factory/future_blob/xml/project list.

Deleted Sources/src/ResourceModel/items/item_base.h - a prior-attempt leftover that referenced a non-existent etree_item_type.h and was unused.


## Verification


Three verification clauses from the task plan all pass:

1. "grep -c REGISTER_CLASS Sources/src/ResourceModel/factory.cpp matches the sum of registrations for these 11 kinds in Sources/src/editor/TreeItemFactory.cpp (count via a one-off script in the task)". A grep-friendly check: 121 REGISTER_CLASS( invocations in the port vs 121 matching lines in the MFC file across the 11 stats-only prefixes (E_WEAPON_, E_MINE_, E_TRENCH_, E_SQUAD_, E_SPRITE_/E_SPRITES_, E_ANIMATION_/E_UNIT_, E_MESH_, E_OBJECT_, E_FENCE_, E_BUILDING_, E_BRIDGE_). A plain `grep -c REGISTER_CLASS factory.cpp` returns 125 because it also counts the two define/undef lines and two comment lines; the audit script in this task restricts to the invocation form (^\s*REGISTER_CLASS\() and both counts come out at 121 exactly.

2. "zig build install-game still links": zig build install-game resource-model-scaffold-test exits 0 and the Linux Game binary at zig-out/game/linux/x86_64/release/Game (28,192,632 bytes) is rebuilt alongside the scaffold test.

3. "resource_model_scaffold_test.cpp is extended to loop over wpn, mcp, trc, scp, spt, unt, msh, obt, fnc, bld, bdg fixtures and assert rtout1==rtout2==fixture bytes with unknown-node preservation (plant a <FutureBlob attr='v'><child/></FutureBlob> under the root before serialise, confirm it survives)": the sweep ran against every tracked fixture under tools/zig/fixtures/resource_editor/. Each extension passed:

SCAFFOLD wpn bytes=127 rt_equal=1 rt_idempotent=1 unknown_preserved=1 childs=1 props=0
SCAFFOLD mcp bytes=123 rt_equal=1 rt_idempotent=1 unknown_preserved=1 childs=1 props=0
SCAFFOLD trc bytes=127 rt_equal=1 rt_idempotent=1 unknown_preserved=1 childs=1 props=0
SCAFFOLD scp bytes=125 rt_equal=1 rt_idempotent=1 unknown_preserved=1 childs=1 props=0
SCAFFOLD spt bytes=127 rt_equal=1 rt_idempotent=1 unknown_preserved=1 childs=1 props=0
SCAFFOLD unt bytes=123 rt_equal=1 rt_idempotent=1 unknown_preserved=1 childs=1 props=0
SCAFFOLD msh bytes=123 rt_equal=1 rt_idempotent=1 unknown_preserved=1 childs=1 props=0
SCAFFOLD obt bytes=127 rt_equal=1 rt_idempotent=1 unknown_preserved=1 childs=1 props=0
SCAFFOLD fnc bytes=125 rt_equal=1 rt_idempotent=1 unknown_preserved=1 childs=1 props=0
SCAFFOLD bld bytes=131 rt_equal=1 rt_idempotent=1 unknown_preserved=1 childs=1 props=0
SCAFFOLD bdg bytes=127 rt_equal=1 rt_idempotent=1 unknown_preserved=1 childs=1 props=0

BK_DEBUG_LOG=1 adds a second line per ext with "typed=1" (every parsed root hit the typed-root path, not FutureBlob) and element/depth counts.


## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `grep -c -E '^\s*REGISTER_CLASS\(' Sources/src/ResourceModel/factory.cpp` | 0 | pass (returns 121, equal to the MFC-side sum across the 11 stats-only kinds) | 50ms |
| 2 | `zig build install-game resource-model-scaffold-test` | 0 | pass (links; Game binary rebuilt; scaffold sweep rt_equal=1 rt_idempotent=1 unknown_preserved=1 for all 11 ext) | 120000ms |
| 3 | `BK_DEBUG_LOG=1 zig build resource-model-scaffold-test` | 0 | pass (typed=1 for every root, element/depth counts stable) | 2000ms |
| 4 | `python3 audit of port vs MFC REGISTER_CLASS counts per kind` | 0 | pass (121 == 121) | 200ms |

## Deviations

The task plan said "Register them in Sources/src/ResourceModel/factory.cpp under per-kind blocks that match the exact REGISTER_CLASS order of Sources/src/editor/TreeItemFactory.cpp:35". I kept factory.cpp as the single registration site exactly as the plan asked, but moved E_LOCALIZATION_ITEM (MFC line 38, inside the Infantry block) OUT of the Infantry block - it is the shared Localization item used by several non-stats sub-editors (mission, chapter), and the port parks it with the localization.cpp owner in a follow-up task rather than making the Infantry TU carry it. The Infantry block therefore registers 17 classes, matching the task plan's note at the top of infantry.cpp. Total count across 11 kinds remains 121 and equals the MFC per-kind sum when LOCALIZATION_ITEM is attributed to the shared block (see the one-off script in Verification).

Scaffold test behaviour was extended beyond the plan's single rt_equal check: the sweep also records rt_idempotent (Load->Save->Load->Save stability) which the slice's "idempotent load/save" goal clause asks for. This matches the slice-level Verification contract rather than only the task-level one, and costs nothing extra per fixture.

## Known Issues

The prop vectors on each of the 121 ported item classes are empty. The MFC source has 9 props on CWeaponCommonPropsItem, 16 on CWeaponDamagePropsItem, several on nearly every other class; those InitDefaultValues bodies are deferred to the follow-up data-fidelity task that will exercise them against non-minimal fixtures (actual authored projects). This is called out in the stats_item.h header comment and in each per-kind header. It does not threaten the T02 Done-When: the three fixture gates (rt_equal, rt_idempotent, unknown_preserved) pass with empty prop vectors because the minimal fixtures put authored data under a `<fixture>` subtree that the port treats as a FutureBlob child of the typed root.

## Files Created/Modified

- `Sources/src/ResourceModel/items/stats_item.h`
- `Sources/src/ResourceModel/items/stats_item.cpp`
- `Sources/src/ResourceModel/items/tree_item_types.h`
- `Sources/src/ResourceModel/items/weapon/weapon.h`
- `Sources/src/ResourceModel/items/weapon/weapon.cpp`
- `Sources/src/ResourceModel/items/mine/mine.h`
- `Sources/src/ResourceModel/items/mine/mine.cpp`
- `Sources/src/ResourceModel/items/trench/trench.h`
- `Sources/src/ResourceModel/items/trench/trench.cpp`
- `Sources/src/ResourceModel/items/squad/squad.h`
- `Sources/src/ResourceModel/items/squad/squad.cpp`
- `Sources/src/ResourceModel/items/sprite/sprite.h`
- `Sources/src/ResourceModel/items/sprite/sprite.cpp`
- `Sources/src/ResourceModel/items/infantry/infantry.h`
- `Sources/src/ResourceModel/items/infantry/infantry.cpp`
- `Sources/src/ResourceModel/items/mesh/mesh.h`
- `Sources/src/ResourceModel/items/mesh/mesh.cpp`
- `Sources/src/ResourceModel/items/object/object.h`
- `Sources/src/ResourceModel/items/object/object.cpp`
- `Sources/src/ResourceModel/items/fence/fence.h`
- `Sources/src/ResourceModel/items/fence/fence.cpp`
- `Sources/src/ResourceModel/items/building/building.h`
- `Sources/src/ResourceModel/items/building/building.cpp`
- `Sources/src/ResourceModel/items/bridge/bridge.h`
- `Sources/src/ResourceModel/items/bridge/bridge.cpp`
- `Sources/src/ResourceModel/factory.cpp`
- `Sources/src/ResourceModel/project.cpp`
- `tools/zig/resource_model_scaffold_test.cpp`
- `build.zig`
