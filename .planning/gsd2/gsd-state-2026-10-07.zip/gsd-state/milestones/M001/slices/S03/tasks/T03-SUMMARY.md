---
id: T03
parent: S03
milestone: M001
key_files:
  - Sources/src/ResourceModel/items/mesh/mesh.cpp
  - Sources/src/ResourceModel/items/object/object.cpp
  - Sources/src/ResourceModel/items/fence/fence.cpp
  - Sources/src/ResourceModel/items/building/building.cpp
  - Sources/src/ResourceModel/items/bridge/bridge.cpp
  - Sources/src/ResourceModel/items/ai_tiles.cpp
  - tools/zig/fixtures/resource_editor/resource-model-xfail.txt
  - tools/zig/resource_editor_fixtures.zig
key_decisions:
  - AI-tile and passability grids shared by Object, Fence, Building and Bridge live in one helper (items/ai_tiles) rather than being duplicated per item
  - roundtrip-bytes of TestProjects/06_Mesh stays XFAIL under T05, which owns MFC indentation and byte identity
duration: 
verification_result: passed
completed_at: 2026-10-05T04:31:44.544Z
blocker_discovered: false
---

# T03: Ported MFC property tables and IDataTree serialisation for Mesh (incl. locators/platforms/guns), Object, Fence, Building and Bridge (incl. passability/grid/point data) into ResourceModel/items; their inventory, insert and round-trip checks pass and the T03 block of the xfail list is empty

**Ported MFC property tables and IDataTree serialisation for Mesh (incl. locators/platforms/guns), Object, Fence, Building and Bridge (incl. passability/grid/point data) into ResourceModel/items; their inventory, insert and round-trip checks pass and the T03 block of the xfail list is empty**

## What Happened

The five MFC tree-item families (MeshTreeItem, ObjTreeItem, FenceTreeItem, BuildTreeItem, BridgeTreeItem) were ported into Sources/src/ResourceModel/items/{mesh,object,fence,building,bridge}, with their full property tables and operator&(IDataTree&) serialisation. Each item's grid, passability and point data is ported too. A shared items/ai_tiles.{h,cpp} helper holds the AI-tile and passability grids, and mfc_value.h, editor_env.h and localization_item.cpp hold shared support code. tree_item, variant, project and prop gained the hooks those items need. The repo fixtures msh/obt/fnc/bld/bdg/unt/scp/spt/trc/wpn/mcp were regenerated (resource_editor_fixtures.zig) so they carry the full MFC property sets. The comparator's per-kind field tables were extended for the new kinds. The T03 block of resource-model-xfail.txt is empty. This session resumed after an interruption, found the implementation complete in the working tree, and verified it.

## Verification

zig build test-resource-model -Dtest-mode=run: exit 0, fidelity 419 PASS, 86 XFAIL, 0 FAIL, 0 XPASS, 0 stale xfail ids. Over the five T03 families, 149 inventory and insert checks PASS. fixtures/{msh,obt,fnc,bld,bdg} PASS roundtrip-bytes, -content, -typed and -edit. TestProjects/06_Mesh/current.msh PASSes content, typed and edit. Its byte-identical save is still XFAIL; per the xfail header that check belongs to T05 (MFC indentation). TestProjects 05_Object, 08_Building, 10_Fence and 15_Bridge contain only a README, so the fixtures cover those types. The remaining XFAIL in this area, CEffectMeshPropsItem, is T04's Effect item. Also green: test-resources-all, test-resource-bridge and test-resource-core.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-model -Dtest-mode=run` | 0 | pass | 1100ms |
| 2 | `zig build test-resources-all -Dtest-mode=run` | 0 | pass | 1585ms |
| 3 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 12624ms |
| 4 | `zig build test-resource-core -Dtest-mode=run` | 0 | pass | 326ms |

## Deviations

TestProjects 05_Object, 08_Building, 10_Fence and 15_Bridge contain only README.md, so the round trip for those types is proved on the repo fixtures obt, bld, fnc and bdg.

## Known Issues

TestProjects/06_Mesh/current.msh does not yet save byte-identically: the port pretty-prints, while MFC writes compact XML. This is tracked as T05 in the xfail list.

## Files Created/Modified

- `Sources/src/ResourceModel/items/mesh/mesh.cpp`
- `Sources/src/ResourceModel/items/object/object.cpp`
- `Sources/src/ResourceModel/items/fence/fence.cpp`
- `Sources/src/ResourceModel/items/building/building.cpp`
- `Sources/src/ResourceModel/items/bridge/bridge.cpp`
- `Sources/src/ResourceModel/items/ai_tiles.cpp`
- `tools/zig/fixtures/resource_editor/resource-model-xfail.txt`
- `tools/zig/resource_editor_fixtures.zig`
