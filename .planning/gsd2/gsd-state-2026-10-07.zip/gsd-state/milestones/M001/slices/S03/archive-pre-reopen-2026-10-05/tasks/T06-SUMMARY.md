---
id: T06
parent: S03
milestone: M001
key_files:
  - build.zig
  - .github/workflows/cross-platform.yml
  - tools/zig/run-s03-sweep.sh
  - zig-out/local-test/resource_editor/s03-sweep.log
  - Sources/src/ResourceModel/items/item_base.h
key_decisions:
  - `test-resources-all` depends only on `test-resource-model` today, with a doc-comment at the step naming `test-resource-xml-roundtrip` and `test-dxt-tolerance` as deferred to S01's own `b.step` registration. Reasoning: those two steps are not registered yet (`grep -n 'test-resource-xml-roundtrip\|dxt-tolerance' build.zig` returns no hits), so a `top_level_steps.get(...) orelse @panic` on them would break the build; recording the exclusion in a comment next to the aggregate (rather than behind a `BK_RESOURCE_MODEL_ONLY=1` env branch) keeps the deferred work visible to any future agent reading build.zig without running anything.
  - The sweep script's PREEXISTING classification is kept identical to `run-s02-sweep.sh` even though the BkEditorOpenMap tiers all passed this run. Reasoning: a future red (a BkEditorOpenMap tier failing with a *different* signature) must not be silently masked by the PREEXISTING tag; the classifier only converts FAIL to PREEXISTING when the stderr contains one of the three documented signatures (`AIWarFog::SetZero` / `BkEditorOpenMap` / `OpenMapIntoSession`), so a new failure mode stays FAIL and poisons the S03 aggregate verdict.
  - Deleted `Sources/src/ResourceModel/items/item_base.h` as part of T06 rather than deferring. Reasoning: the file was an unused empty-shell (zero hits in `grep -rn 'item_base\.h' Sources/ tools/ build.zig`) and already appeared as a deletion in the inherited git status; keeping it would leave a stale include target that a later item-class port might include by mistake.
duration: 
verification_result: passed
completed_at: 2026-10-05T00:25:49.243Z
blocker_discovered: false
---

# T06: Wired `test-resource-model` and `test-resources-all` aggregate build steps, added CI workflow entries on Linux/Windows/macOS arm64+x64, and recorded a 17-tier S03 Linux sweep with `S03 VERDICT=PASS`.

**Wired `test-resource-model` and `test-resources-all` aggregate build steps, added CI workflow entries on Linux/Windows/macOS arm64+x64, and recorded a 17-tier S03 Linux sweep with `S03 VERDICT=PASS`.**

## What Happened

Aggregated the three underlying ResourceModel tools (resource-model-scaffold-test, test-resource-model-references, test-resource-model-comparator) under a single new `test-resource-model` step in build.zig via `addResourceModelAggregateStep`, so the slice-level success-criteria sentence maps to one invocation. Added a `test-resources-all` top-level step via `addResourcesAllAggregateStep` that depends on `test-resource-model` today; the S01-era `test-resource-xml-roundtrip` and `test-dxt-tolerance` steps are not yet b.step-registered in build.zig (grep returned no hits), so the aggregate's doc-comment names them explicitly as deferred to S01 landing those registrations rather than hiding them behind a `BK_RESOURCE_MODEL_ONLY=1` env branch — the exclusion lives next to the aggregate so a future agent reading build.zig sees it without having to run anything. Appended `Resource model tier` steps to `.github/workflows/cross-platform.yml` for the Linux x64, Windows MSVC, macOS arm64, and macOS x64 jobs, each matching that job's existing sysroot/toolchain pattern. Authored `tools/zig/run-s03-sweep.sh` (LF per `.gitattributes` eol=lf for *.sh, +x, modelled line-for-line on run-s02-sweep.sh) that runs install-game+install-map-editor, test-resource-model, then every S02 regression tier (test-editor-kit + 13 MapEditor tiers), with identical PREEXISTING-signature classification (AIWarFog::SetZero / BkEditorOpenMap / OpenMapIntoSession) so the two sweep logs are diffable, and the PASS requires: test-resource-model PASS, test-editor-kit PASS, the 5 non-BkEditorOpenMap MapEditor tiers PASS, no FAIL recorded. The resumed sweep ran to completion with 17 PASS lines and `S03 VERDICT=PASS` as the final log line — the BkEditorOpenMap tiers all passed (not PREEXISTING) because CArray2D::SetZero was fixed in 3e8afc8a7, so the classifier was never exercised, matching AGENTS.md's note that failures there are now real regressions. Also removed the empty-shell `Sources/src/ResourceModel/items/item_base.h` (zero references under Sources/, tools/, build.zig per grep) that was flagged in the inherited git status.

## Verification

Ran `bash tools/zig/run-s03-sweep.sh`. The sweep (resumed from the interruption; the pre-existing run was still live when this session started) wrote 17 TIER lines and a final `S03 VERDICT=PASS` to `zig-out/local-test/resource_editor/s03-sweep.log`. Every Done-when assertion verified: `zig build test-resource-model` exited 0 on Linux x64 (188 ms line in the log); `grep -q 'test-resource-model' .github/workflows/cross-platform.yml` matched (4 workflow entries present, one per cross-platform job); the sweep log exists and its final line is `S03 VERDICT=PASS`; the log contains the PASS line `TIER=test-resource-model EXIT=0 ELAPSED_MS=188 VERDICT=PASS`. The AGENTS.md note that `CArray2D::SetZero` is fixed is corroborated — every BkEditorOpenMap-dependent tier (test-editor-bridge, map-editor-{host-check,smoke,auto,auto-m2,m3-auto,game-reads-it-m3}) returned PASS, not PREEXISTING. Totals: install 2.9s, resource-model 0.19s, editor-kit 0.34s, editor-core 0.87s, map-editor-view 0.33s, panels 2.99s, testlaunch 0.22s, auto 0.23s, engine 21.6s, bridge 407s, host-check 14.3s, smoke 9.6s, map-editor-auto 25.4s, auto-m2 47.6s, m3-auto 145.1s, game-reads-it-m3 154.1s. The workflow entries follow the matching per-job pattern (bare Linux; `-Dtarget=... --release=fast "-Dmsvc-include=..."` Windows PowerShell quoting; `--sysroot "$MACOS_SYSROOT"` for both macOS targets).

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `bash tools/zig/run-s03-sweep.sh` | 0 | PASS | 1282155ms |
| 2 | `grep -q 'test-resource-model' .github/workflows/cross-platform.yml` | 0 | PASS | 5ms |
| 3 | `grep -c 'S03 VERDICT=PASS' zig-out/local-test/resource_editor/s03-sweep.log` | 0 | PASS | 5ms |
| 4 | `grep -n 'test-resource-model\|test-resources-all' build.zig` | 0 | PASS | 10ms |

## Deviations

None material. One housekeeping item outside the plan text: `Sources/src/ResourceModel/items/item_base.h` was deleted (zero references anywhere under Sources/ or tools/ or build.zig per grep) because it appeared as a dangling deletion in the inherited git status at session start.

## Known Issues

`test-resources-all` still omits `test-resource-xml-roundtrip` and `test-dxt-tolerance` — intentional, documented at the aggregate step; S01 owns the follow-up to register them as `b.step` entries and extend the dependency list.

## Files Created/Modified

- `build.zig`
- `.github/workflows/cross-platform.yml`
- `tools/zig/run-s03-sweep.sh`
- `zig-out/local-test/resource_editor/s03-sweep.log`
- `Sources/src/ResourceModel/items/item_base.h`
