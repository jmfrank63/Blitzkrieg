---
estimated_steps: 3
estimated_files: 14
skills_used: []
---

# T03: Port every item class for the 10 keyframe/graph/image/UI sub-editors (Particle, Effect, Tileset, 3dRoad, 3dRiver, Mission, Chapter, Campaign, Medal, GUI)

Why: These 10 sub-editors deviate from the T02 stats-only pattern — Particle and Effect own CKeyFrameTreeItem (Sources/src/editor/TreeItem.h:378) with framesList/minX/maxX/stepX fields that need the same portable treatment; Tileset/3dRoad/3dRiver own grid/layer trees; Mission/Chapter/Campaign/Medal own the CImageFrame-aligned trees; GUI owns the switched-off UI tree. Grouping them together lets one task carry the keyframe generalisation.

Do: Add a portable CKeyFrameTreeItem base in Sources/src/ResourceModel/key_frame_tree_item.{h,cpp} that owns the frames list + minX/maxX/stepX/minY/maxY/stepY/resizeMode fields and (de)serialises them under a `<frames>` child so the keyframe-editor-free fixtures round-trip. Add per-kind headers/impls under Sources/src/ResourceModel/items/<kind>/ for Particle (E_PARTICLE_* + CKeyFrameTreeItem usage), Effect (E_EFFECT_*), Tileset (E_TILESET_* + E_CROSSET_*), 3dRoad (E_3DROAD_*), 3dRiver (E_3DRIVER_*), Mission (E_MISSION_*), Chapter (E_CHAPTER_*), Campaign (E_CAMPAIGN_*), Medal (E_MEDAL_*), and GUI (E_GUI_* + E_TEMPLATE_*/E_STATIC_*/E_BUTTON_*/E_SLIDER_*/E_SCROLLBAR_*/E_STATUSBAR_*/E_LIST_*/E_DIALOG_*/E_UNKNOWNS_UI_*). Register them in Sources/src/ResourceModel/factory.cpp in the exact REGISTER_CLASS order of Sources/src/editor/TreeItemFactory.cpp. Same MFC-free rules as T01/T02.

Done when: `grep -c REGISTER_CLASS Sources/src/ResourceModel/factory.cpp` equals the full MFC total (sum of T02 + T03 counts); the scaffold test is extended with `pcp, eff, til, 3rd, 3rv, mip, chc, cgc, mdc, gui` fixtures and all 21 extensions pass rtout1==rtout2==fixture bytes with unknown-node preservation; `zig build install-game` still links.

## Inputs

- `Sources/src/editor/TreeItem.h`
- `Sources/src/editor/TreeItemFactory.cpp`
- `Sources/src/editor/ParticleTreeItem.cpp`
- `Sources/src/editor/ParticleTreeItem.h`
- `Sources/src/editor/EffTreeItem.cpp`
- `Sources/src/editor/EffTreeItem.h`
- `Sources/src/editor/TileTreeItem.cpp`
- `Sources/src/editor/TileTreeItem.h`
- `Sources/src/editor/3dRoadTreeItem.cpp`
- `Sources/src/editor/3dRoadTreeItem.h`
- `Sources/src/editor/3dRiverTreeItem.cpp`
- `Sources/src/editor/3dRiverTreeItem.h`
- `Sources/src/editor/MissionTreeItem.cpp`
- `Sources/src/editor/MissionTreeItem.h`
- `Sources/src/editor/ChapterTreeItem.cpp`
- `Sources/src/editor/ChapterTreeItem.h`
- `Sources/src/editor/CampaignTreeItem.cpp`
- `Sources/src/editor/CampaignTreeItem.h`
- `Sources/src/editor/MedalTreeItem.cpp`
- `Sources/src/editor/MedalTreeItem.h`
- `Sources/src/editor/GUITreeItem.cpp`
- `Sources/src/editor/GUITreeItem.h`
- `Sources/src/ResourceModel/factory.h`
- `Sources/src/ResourceModel/tree_item.h`
- `tools/zig/fixtures/resource_editor/pcp/project.pcp`
- `tools/zig/fixtures/resource_editor/eff/project.eff`
- `tools/zig/fixtures/resource_editor/til/project.til`
- `tools/zig/fixtures/resource_editor/3rd/project.3rd`
- `tools/zig/fixtures/resource_editor/3rv/project.3rv`
- `tools/zig/fixtures/resource_editor/mip/project.mip`
- `tools/zig/fixtures/resource_editor/chc/project.chc`
- `tools/zig/fixtures/resource_editor/cgc/project.cgc`
- `tools/zig/fixtures/resource_editor/mdc/project.mdc`
- `tools/zig/fixtures/resource_editor/gui/project.gui`

## Expected Output

- `Sources/src/ResourceModel/key_frame_tree_item.h`
- `Sources/src/ResourceModel/key_frame_tree_item.cpp`
- `Sources/src/ResourceModel/items/particle/`
- `Sources/src/ResourceModel/items/effect/`
- `Sources/src/ResourceModel/items/tileset/`
- `Sources/src/ResourceModel/items/road3d/`
- `Sources/src/ResourceModel/items/river3d/`
- `Sources/src/ResourceModel/items/mission/`
- `Sources/src/ResourceModel/items/chapter/`
- `Sources/src/ResourceModel/items/campaign/`
- `Sources/src/ResourceModel/items/medal/`
- `Sources/src/ResourceModel/items/gui/`
- `Sources/src/ResourceModel/factory.cpp`
- `tools/zig/resource_model_scaffold_test.cpp`

## Verification

zig build install-game resource-model-scaffold-test

## Observability Impact

The scaffold test's per-ext line now gains `kf_frames=<n>` for keyframe-bearing fixtures so a dropped keyframe serialiser surfaces without reparsing the file.
