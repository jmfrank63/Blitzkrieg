---
estimated_steps: 1
estimated_files: 6
skills_used: []
---

# T03: Port property tables + IDataTree serialisation: Mesh, Object, Fence, Building, Bridge

Same as T02 for MeshTreeItem (108 properties incl. locators/platforms/guns), ObjTreeItem, FenceTreeItem, BuildTreeItem, BridgeTreeItem, including grid/passability/point data each item stores. Remove them from the expected-fail list; TestProjects 06_Mesh, 05_Object, 10_Fence, 08_Building, 15_Bridge and the fixtures round-trip.

## Inputs

- `Sources/src/editor/MeshTreeItem.cpp`
- `Sources/src/editor/ObjTreeItem.cpp`
- `Sources/src/editor/FenceTreeItem.cpp`
- `Sources/src/editor/BuildTreeItem.cpp`
- `Sources/src/editor/BridgeTreeItem.cpp`
- `tools/zig/fixtures/resource_editor/mfc-item-inventory.json`

## Expected Output

- `Sources/src/ResourceModel/items/mesh`
- `Sources/src/ResourceModel/items/object`
- `Sources/src/ResourceModel/items/fence`
- `Sources/src/ResourceModel/items/building`
- `Sources/src/ResourceModel/items/bridge`

## Verification

zig build test-resource-model -Dtest-mode=run
