---
id: T05
parent: S03
milestone: M001
key_files:
  - Sources/src/ResourceModel/xml.cpp
  - Sources/src/ResourceModel/xml.h
  - Sources/src/ResourceModel/mfc_value.cpp
  - Sources/src/ResourceModel/project.cpp
  - tools/zig/resource_xml_roundtrip_test.cpp
  - tools/zig/fixtures/resource_editor/resource-model-xfail.txt
  - docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md
key_decisions:
  - The writer's default layout is MSXML's compact save. The port-authored fixtures keep a detected tab-indented layout so their diffs stay readable; both layouts re-save byte-identically and MSXML reads both.
  - An empty string chunk is an element with one empty Text child, written as <a></a>, as CDataTreeXML::StringData produces; <a/> means no children.
  - No byte-identity exception list is needed: the cases that are only content-equal (escaped characters, mixed text, values written before int64) occur in no tracked project, and the spec lists them under D-07.
duration: 
verification_result: passed
completed_at: 2026-10-05T04:52:10.645Z
blocker_discovered: false
---

# T05: NResourceXml now writes MSXML's compact MFC layout (declaration, CRLF, the tree on one line, CRLF; <a></a> for an empty string, <a/> for an empty container), so both MFC TestProjects re-save byte-identically; the spec records the layout and its unproved cases under D-07

**NResourceXml now writes MSXML's compact MFC layout (declaration, CRLF, the tree on one line, CRLF; <a></a> for an empty string, <a/> for an empty container), so both MFC TestProjects re-save byte-identically; the spec records the layout and its unproved cases under D-07**

## What Happened

The MFC project files were written by CDataTreeXML through IXMLDOMDocument::save with no indentation: `<?xml version="1.0"?>`, CRLF, the whole tree on one line, CRLF. StringData always appends a text node, so an empty string is `<a></a>`, while an empty container or an element with only attributes is `<a/>`. The port wrote a tab-indented layout instead, and StringElement left out the text node for an empty string.

Changes:
1. xml.h/xml.cpp:
   - Document has a Layout (Mfc by default, or Indented).
   - The parser marks a document Indented when it drops whitespace between elements.
   - The parser reads `<a></a>` as an element with one empty Text child, so it is written back that way.
   - Serialise writes Mfc through a new WriteCompact. Indented still goes through the old WriteNode.
2. project.cpp: Save carries the layout of the document it read.
3. mfc_value.cpp: StringElement always adds the text child, as StringData does.
4. Fixtures: six port-authored fixtures (mcp, scp, spt, trc, unt, wpn) were re-saved through the model. Their only change is the root's `<default_name></default_name>`/`<display_name></display_name>`. EXTENSIONS.md was refreshed by make-resource-fixtures. The fixtures stay tab-indented on purpose, so their diffs stay readable. Their layout is detected and kept, so they too re-save byte-identically. New projects and every MFC project are written in MFC layout.
5. resource-model-xfail.txt: the T05 block (the two roundtrip-bytes ids) is empty, so the xfail list now has no entries.
6. resource_xml_roundtrip_test.cpp:
   - MfcProjectSurvives now requires byte identity with the MFC file.
   - New edge cases: compact parse and re-save, `<a></a>` vs `<a/>`, a new document written in MFC layout, and an indented file keeping its layout.
7. Spec: a D-07 amendment records the layout and the cases that are equal in content but not byte-proved. No tracked file contains any of them, so roundtrip-bytes is asserted for all 23 projects with no exception list:
   - escaping of & < > " and control characters, which no MFC sample contains;
   - mixed-content text, which is stored trimmed;
   - values written before int64low/int64high existed;
   - MFC editor.exe reading a port-written project, pending on win-home in the S03 UAT.

Floats needed no change: MfcFloat already uses the MSVC three-digit exponent, and unedited values are kept as read.

## Verification

Results:
- zig build test-resource-model -Dtest-mode=run exits 0. resource-model-fidelity reports 505 PASS, 0 XFAIL, 0 FAIL, 0 XPASS, 0 stale ids. roundtrip-bytes passes for WinSniper.unt, current.msh and all 21 fixtures. The roundtrip-edit output of current.msh stays in compact MFC layout.
- The comparator logs COMPARE_SUMMARY exts=21.
- test-resource-xml-roundtrip passes: PASS mfc WinSniper.unt, PASS mfc current.msh (now byte-identical), PASS parser edge cases.
- test-resources-all, test-resource-bridge and test-resource-core all exit 0.

Not run: the slice-level sweep log (resource-sweep.log) belongs to the later sweep-script task.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-model -Dtest-mode=run` | 0 | pass | 15769ms |
| 2 | `zig build test-resources-all -Dtest-mode=run` | 0 | pass | 2119ms |
| 3 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 13998ms |
| 4 | `zig build test-resource-core -Dtest-mode=run` | 0 | pass | 358ms |
| 5 | `zig build test-resource-xml-roundtrip -Dtest-mode=run` | 0 | pass | 2000ms |
| 6 | `zig build make-resource-fixtures` | 0 | pass | 2000ms |

## Deviations

The plan named xml.cpp and the spec. The task also changed StringElement in mfc_value.cpp (empty-string text node), project.cpp (layout carried through Save), the XML round-trip test, six fixtures and EXTENSIONS.md.

## Known Issues

MSXML's escaping of & < > " and control characters is not byte-proved, because no MFC sample in the repo contains them. Opening a port-written project in the MFC editor.exe is pending on win-home (S03 UAT).

## Files Created/Modified

- `Sources/src/ResourceModel/xml.cpp`
- `Sources/src/ResourceModel/xml.h`
- `Sources/src/ResourceModel/mfc_value.cpp`
- `Sources/src/ResourceModel/project.cpp`
- `tools/zig/resource_xml_roundtrip_test.cpp`
- `tools/zig/fixtures/resource_editor/resource-model-xfail.txt`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`
