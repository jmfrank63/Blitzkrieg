---
estimated_steps: 1
estimated_files: 4
skills_used: []
---

# T07: Re-measure DXT tolerance on shipped _c.dds textures (DXT1/3/5, with alpha) and gate on it

Replace the random-noise measurement: pick several shipped `_c.dds` from `Data/` per format (DXT1, DXT3, DXT5, including ones with real alpha), decode to RGBA, re-encode with `NDxt`, decode, measure max per-channel delta and p99 per format and for alpha separately. Write numbers and the exact file list into `dxt-tolerance.json` (with how they were measured), and make the comparator's DXT gate read them. Keep the measurement as a repeatable tool/test step.

## Inputs

- `Data`
- `tools/zig/fixtures/resource_editor/dxt-tolerance.json`

## Expected Output

- `tools/zig/fixtures/resource_editor/dxt-tolerance.json`

## Verification

zig build measure-dxt-tolerance && zig build test-resource-model -Dtest-mode=run
