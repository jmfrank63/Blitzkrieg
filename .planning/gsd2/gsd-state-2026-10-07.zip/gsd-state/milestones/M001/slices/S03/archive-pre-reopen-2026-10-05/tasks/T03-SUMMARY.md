---
id: T03
parent: S03
milestone: M001
key_files:
  - Sources/src/ResourceModel/key_frame_tree_item.h
  - Sources/src/ResourceModel/key_frame_tree_item.cpp
  - Sources/src/ResourceModel/items/tree_item_types.h
  - Sources/src/ResourceModel/items/particle/particle.h
  - Sources/src/ResourceModel/items/particle/particle.cpp
  - Sources/src/ResourceModel/items/effect/effect.h
  - Sources/src/ResourceModel/items/effect/effect.cpp
  - Sources/src/ResourceModel/items/tileset/tileset.h
  - Sources/src/ResourceModel/items/tileset/tileset.cpp
  - Sources/src/ResourceModel/items/road3d/road3d.h
  - Sources/src/ResourceModel/items/road3d/road3d.cpp
  - Sources/src/ResourceModel/items/river3d/river3d.h
  - Sources/src/ResourceModel/items/river3d/river3d.cpp
  - Sources/src/ResourceModel/items/mission/mission.h
  - Sources/src/ResourceModel/items/mission/mission.cpp
  - Sources/src/ResourceModel/items/chapter/chapter.h
  - Sources/src/ResourceModel/items/chapter/chapter.cpp
  - Sources/src/ResourceModel/items/campaign/campaign.h
  - Sources/src/ResourceModel/items/campaign/campaign.cpp
  - Sources/src/ResourceModel/items/medal/medal.h
  - Sources/src/ResourceModel/items/medal/medal.cpp
  - Sources/src/ResourceModel/items/gui/gui.h
  - Sources/src/ResourceModel/items/gui/gui.cpp
  - Sources/src/ResourceModel/factory.cpp
  - tools/zig/resource_model_scaffold_test.cpp
  - build.zig
key_decisions:
  - CKeyFrameTreeItem derives from CStatsItem (not directly from CTreeItem) so it inherits the nItemType + xmlTag plumbing the stats-only pattern already provides; the 17 particle curve items pass through only the nType to the CKeyFrameTreeItem(int) constructor exactly the way CStatsItem(int) is used in T02. The eight non-keyframe particle items (CParticleCommonPropsItem, CParticleSourcePropItems, CParticlePropItems, CParticleComplexItem, CParticleComplexSourceItem) stay on the plain CStatsItem base to match MFC's class hierarchy. Reasoning: the MFC enum partitions particle items into keyframe-backed and non-keyframe-backed; keeping the same split in the port makes a later data-fidelity task that moves prop vectors in a trivial per-base-class exercise.
  - CKeyFrameTreeItem gets a parameterless default constructor keyed on ETIT_KEYFRAME_TREE_ITEM in addition to the (int) / (int, string) constructors used by subclasses. Reasoning: the MFC TreeItemFactory REGISTER_CLASSes CKeyFrameTreeItem *itself* (not just its derivatives, see TreeItemFactory.cpp:164), so the factory lambda `[] { return new CKeyFrameTreeItem(); }` needs a zero-arg constructor; without it, factory_populate.cpp fails to compile.
  - The keyframe serialiser emits a single `<frames>` child (with min_x/max_x/step_x/min_y/max_y/step_y/resize as attrs and `<f x y/>` sample children) rather than a flat sibling list under the item. Reasoning: this matches the MFC CKeyFrameTreeItem::operator& shape (one `Key_frames` named list) and keeps the port's keyframe output outside the SProp walk the base `CTreeItem::serialise` uses, so a mixed-SProp-plus-keyframe item in a later task does not need special-cased interleaving.
duration: 
verification_result: untested
completed_at: 2026-10-04T23:44:00.004Z
blocker_discovered: false
---

# T03: Ported every item class for the 10 keyframe/graph/image/UI sub-editors (95 classes incl. the shared CKeyFrameTreeItem base), registered them in factory.cpp line-for-line against MFC, and extended the scaffold sweep to all 21 project extensions with a kf_frames observability column.

**Ported every item class for the 10 keyframe/graph/image/UI sub-editors (95 classes incl. the shared CKeyFrameTreeItem base), registered them in factory.cpp line-for-line against MFC, and extended the scaffold sweep to all 21 project extensions with a kf_frames observability column.**

## What Happened


Added Sources/src/ResourceModel/key_frame_tree_item.{h,cpp} - a portable mirror of Sources/src/editor/TreeItem.h:378 that owns the framesList (vector<FrameSample>) plus the fMinValX/fMaxValX/fStepX/fMinValY/fMaxValY/fStepY/bResizeMode knobs and (de)serialises them under a single `<frames>` child element with `<f x="..." y="..."/>` samples. The base provides a default constructor keyed on ETIT_KEYFRAME_TREE_ITEM so the factory can create a plain CKeyFrameTreeItem directly (the MFC factory REGISTER_CLASSes CKeyFrameTreeItem itself, not just its derivatives).

Added ten per-kind header/impl pairs under Sources/src/ResourceModel/items/<kind>/ for the sub-editors T03 covers: particle (25 classes, 17 of which derive from CKeyFrameTreeItem), effect (11), tileset (14), road3d (3), river3d (4), mission (6), chapter (6), campaign (6), medal (4), gui (16). Each per-kind header follows the T02 one-line CStatsItem/CKeyFrameTreeItem shell pattern; the particle header is the only one mixing the two bases (CKeyFrameTreeItem for the 17 curve items and CStatsItem for the 8 non-curve items like CParticleCommonPropsItem, CParticleSourcePropItems, CParticlePropItems, CParticleComplexItem, CParticleComplexSourceItem). The GUI header omits CTemplateTreeItem and CTemplatePropsTreeItem because MFC never REGISTER_CLASSes them even though E_TEMPLATE_TREE_ITEM / E_TEMPLATE_PROPS_TREE_ITEM live in the enum.

Extended Sources/src/ResourceModel/items/tree_item_types.h with 96 new ETIT_* constants carrying the exact MFC enum offsets from Sources/src/editor/TreeItem.h (ETIT_EFFECT_* = BASE+31..41, ETIT_TILESET_* = BASE+101..109 and BASE+320..324, ETIT_KEYFRAME_TREE_ITEM = BASE+130, ETIT_PARTICLE_* = BASE+131..149 and BASE+340..343, ETIT_GUI_* = BASE+171..181 and BASE+192..198, ETIT_MISSION_* = BASE+230..235, ETIT_CHAPTER_* = BASE+240..247, ETIT_CAMPAIGN_* = BASE+250..255, ETIT_3DROAD_* = BASE+290..292, ETIT_3DRIVER_* = BASE+300..303, ETIT_MEDAL_* = BASE+310..313).

Extended Sources/src/ResourceModel/factory.cpp with 95 new REGISTER_CLASS entries across ten new per-kind blocks (Effect, TileSet, Particle+Keyframe, GUI, Mission, Chapter, Campaign, 3dRoad, 3dRiver, Medal). Each block mirrors Sources/src/editor/TreeItemFactory.cpp line-for-line and each root class gets a RegisterRootTag call ("Effect_Composer_Project", "TileSet_Composer_Project", "Particle_Composer_Project", "GUI_Composer_Project", "Mission_Composer_Project", "Chapter_Composer_Project", "Campaign_Composer_Project", "Road3D_Composer_Project", "River3D_Composer_Project", "Medal_Composer_Project"). Total port registrations: 216 (121 T02 + 95 T03). MFC total is 217; the one-entry delta is E_LOCALIZATION_ITEM which T02 deferred to the Localization owner task per the T02 deviation.

Extended tools/zig/resource_model_scaffold_test.cpp: added `pcp, eff, til, 3rd, 3rv, mip, chc, cgc, mdc, gui` to kAllExts so the sweep now covers all 21 project extensions; added a CountKeyframeFrames walk and a new `kf_frames=<n>` column on the per-ext line (the Observability Impact clause - a dropped keyframe serialiser in a later task will surface here before anyone reparses the file).

Added the eleven new TU files (key_frame_tree_item.cpp, particle.cpp, effect.cpp, tileset.cpp, road3d.cpp, river3d.cpp, mission.cpp, chapter.cpp, campaign.cpp, medal.cpp, gui.cpp) to the resource-model-scaffold-test addCSourceFiles list in build.zig next to the T02 TU set.


## Verification


Three verification clauses pass:

1. "grep -c REGISTER_CLASS Sources/src/ResourceModel/factory.cpp equals the full MFC total (sum of T02 + T03 counts)": port = 216 invocations (121 T02 + 95 T03), MFC = 217 (one more = E_LOCALIZATION_ITEM deferred to the Localization owner per T02 deviation). An awk-sliced count of just the T03 blocks returns 95, matching the MFC T03-prefix sum (Python regex check over the MFC file).

2. "the scaffold test is extended with pcp, eff, til, 3rd, 3rv, mip, chc, cgc, mdc, gui fixtures and all 21 extensions pass rtout1==rtout2==fixture bytes with unknown-node preservation": `zig build resource-model-scaffold-test` exits 0 and every ext reports rt_equal=1 rt_idempotent=1 unknown_preserved=1. BK_DEBUG_LOG=1 shows typed=1 for every T03 ext (Particle_Composer_Project, Effect_Composer_Project, TileSet_Composer_Project, Road3D_Composer_Project, River3D_Composer_Project, Mission_Composer_Project, Chapter_Composer_Project, Campaign_Composer_Project, Medal_Composer_Project, GUI_Composer_Project) - every parsed root hit the typed-root path, not FutureBlob.

3. "zig build install-game still links": `zig build install-game resource-model-scaffold-test` exits 0; the Linux Game binary at zig-out/game/linux/x86_64/release/Game (28,192,632 bytes) is rebuilt alongside the scaffold test.
</verification>
<parameter name="verificationEvidence">[
  {"command": "grep -cE '^\\s*REGISTER_CLASS\\(' Sources/src/ResourceModel/factory.cpp", "exitCode": 0, "verdict": "pass (returns 216 = T02's 121 + T03's 95; one less than MFC 217 for the deferred E_LOCALIZATION_ITEM)", "durationMs": 60},
  {"command": "zig build install-game resource-model-scaffold-test", "exitCode": 0, "verdict": "pass (install-game links; scaffold sweep rt_equal=1 rt_idempotent=1 unknown_preserved=1 for all 21 extensions incl. the 10 T03 kinds)", "durationMs": 240000},
  {"command": "BK_DEBUG_LOG=1 zig build resource-model-scaffold-test", "exitCode": 0, "verdict": "pass (typed=1 for every T03 ext; element/depth counts stable: depth=2 elements=3)", "durationMs": 3500},
  {"command": "python3 audit of port vs MFC REGISTER_CLASS counts for T03 kinds (Effect/TileSet/Particle/GUI/Mission/Chapter/Campaign/3DRoad/3DRiver/Medal)", "exitCode": 0, "verdict": "pass (95 == 95)", "durationMs": 150}
]

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| — | No verification commands discovered | — | — | — |

## Deviations

The CKeyFrameTreeItem base needed a parameterless default constructor on top of the (int) / (int, string) ones the stats-only port uses, because the MFC factory REGISTER_CLASSes the bare CKeyFrameTreeItem (not just its derivatives). Added it with a one-line body in key_frame_tree_item.cpp keyed on ETIT_KEYFRAME_TREE_ITEM. Not called out in the task plan but required for the factory to compile.

## Known Issues

The prop vectors on every T03 item class are empty, same as the T02 pattern. The MFC source carries authored prop vectors on CParticleCommonPropsItem, every CEffectCommonPropsItem subclass, the GUI common/dialog props, etc.; those InitDefaultValues bodies and the SProp-walk defaults stay deferred to the follow-up data-fidelity task that will exercise them against non-minimal fixtures. This is not a threat to the T03 Done-When clause: the three fixture gates (rt_equal, rt_idempotent, unknown_preserved) all pass with empty prop vectors because the minimal fixtures put authored data under a `<fixture>` subtree the port treats as a FutureBlob child of the typed root. The CKeyFrameTreeItem::serialise `<frames>` emission is similarly untested on the current fixtures (none plant keyframe data); a later task that adds a keyframe-bearing fixture will exercise that path.

## Files Created/Modified

- `Sources/src/ResourceModel/key_frame_tree_item.h`
- `Sources/src/ResourceModel/key_frame_tree_item.cpp`
- `Sources/src/ResourceModel/items/tree_item_types.h`
- `Sources/src/ResourceModel/items/particle/particle.h`
- `Sources/src/ResourceModel/items/particle/particle.cpp`
- `Sources/src/ResourceModel/items/effect/effect.h`
- `Sources/src/ResourceModel/items/effect/effect.cpp`
- `Sources/src/ResourceModel/items/tileset/tileset.h`
- `Sources/src/ResourceModel/items/tileset/tileset.cpp`
- `Sources/src/ResourceModel/items/road3d/road3d.h`
- `Sources/src/ResourceModel/items/road3d/road3d.cpp`
- `Sources/src/ResourceModel/items/river3d/river3d.h`
- `Sources/src/ResourceModel/items/river3d/river3d.cpp`
- `Sources/src/ResourceModel/items/mission/mission.h`
- `Sources/src/ResourceModel/items/mission/mission.cpp`
- `Sources/src/ResourceModel/items/chapter/chapter.h`
- `Sources/src/ResourceModel/items/chapter/chapter.cpp`
- `Sources/src/ResourceModel/items/campaign/campaign.h`
- `Sources/src/ResourceModel/items/campaign/campaign.cpp`
- `Sources/src/ResourceModel/items/medal/medal.h`
- `Sources/src/ResourceModel/items/medal/medal.cpp`
- `Sources/src/ResourceModel/items/gui/gui.h`
- `Sources/src/ResourceModel/items/gui/gui.cpp`
- `Sources/src/ResourceModel/factory.cpp`
- `tools/zig/resource_model_scaffold_test.cpp`
- `build.zig`
