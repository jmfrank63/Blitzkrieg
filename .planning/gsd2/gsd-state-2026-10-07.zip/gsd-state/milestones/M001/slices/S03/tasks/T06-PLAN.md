---
estimated_steps: 1
estimated_files: 5
skills_used: []
---

# T06: Comparator over exported game data (D-11) + win-home golden generation kit

Rewrite `comparator.{h,cpp}` to compare exported data, not project XML: stats via the engine's own readers field by field with exact float equality; particle/smoking-particle/effect/terrain/VSO via their readers; `_h.dds` byte equality; DXT within the T07 gate; unknown fields fail loudly. Accept real MFC exports. Prove it on shipped `Data/` (copied to zig-out/local-test): every shipped stats file compares equal to itself; a one-ulp float change, a dropped field and an extra field each fail with a precise message. Fill golden folders' README with how goldens are made; add `tools/zig/win-home/export-goldens.ps1` (or .bat) that runs MFC `editor.exe` batch export over the fixtures into `tools/zig/fixtures/resource_editor/<ext>/golden/`. Goldens cannot be generated on this Linux machine: state that in the slice summary, keep the golden comparison test present but reporting `pending: golden missing` (not PASS), and do not mark the comparison done.

## Inputs

- `.planning/phases/06-*/06-CONTEXT.md`
- `Sources/src/ResourceModel/comparator.cpp`
- `Data`

## Expected Output

- `Sources/src/ResourceModel/comparator.cpp`
- `tools/zig/win-home/export-goldens.ps1`

## Verification

zig build test-resource-model -Dtest-mode=run
