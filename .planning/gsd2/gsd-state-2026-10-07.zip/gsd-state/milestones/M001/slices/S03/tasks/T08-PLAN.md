---
estimated_steps: 1
estimated_files: 6
skills_used: []
---

# T08: One sweep script, smoke pointer immunity, CI, S03 sweep

Replace `tools/zig/run-s02-sweep.sh` and `run-s03-sweep.sh` with one `tools/zig/run-resource-sweep.sh` (delete both): runs install-game, install-map-editor, test-resource-model, test-resource-core, test-resource-bridge, test-editor-core and every Map Editor tier listed in AGENTS.md; no PREEXISTING classification at all — any failure is FAIL. If map-editor-smoke/auto fail, record whether the pointer was over the hidden window. Make the smoke immune to the real pointer if cheap (ignore the global mouse position / SDL mouse motion from the OS while a script drives input); otherwise record the weakness in the S03 summary and the sweep's FAIL hint. Ensure CI runs test-resource-model on the five engine targets. Run the sweep; the S03 summary cites only this run.

## Inputs

- `tools/zig/run-s02-sweep.sh`
- `tools/zig/run-s03-sweep.sh`
- `AGENTS.md`

## Expected Output

- `tools/zig/run-resource-sweep.sh`
- `zig-out/local-test/resource_editor/resource-sweep.log`

## Verification

grep -q 'VERDICT=PASS' zig-out/local-test/resource_editor/resource-sweep.log

Override 2026-10-05T06:01 (.gsd/OVERRIDES.md, D010): the maintainer ran the sweep at commit 27d03a607 (about 27 min). Do not start it again; read the log, check its tiers against the must-haves and cite that log and commit as the evidence.
