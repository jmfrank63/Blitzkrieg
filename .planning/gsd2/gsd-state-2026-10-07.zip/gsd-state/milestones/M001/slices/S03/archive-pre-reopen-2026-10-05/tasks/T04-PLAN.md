---
estimated_steps: 3
estimated_files: 9
skills_used: []
---

# T04: Reference, localisation and combo lists: 20 EReferenceType enumerators + AI-class + player-sides + localisation items (A-30/A-33/A-34), ported MFC-free

Why: Parity rows A-30 (reference pickers for all 20 EReferenceType), A-33 (AI class combo, player sides combo), and A-34 (localisation items name/desc/stats .txt) all live in ResourceModel per the Parity map (06-PARITY.md), because the data lists must exist before S05's picker UI and S06..S15's per-sub-editor picker usages can read them. Keeping them in this slice means S04's bridge can expose them without reaching back into the MFC source tree.

Do: Port the EReferenceType enumeration from Sources/src/editor/RefDlg.h:9 verbatim into Sources/src/ResourceModel/references.h as `enum class EReferenceType : int { ... }` with the identical 20 values and the identical order. Port the per-type `std::list<std::string>` lists from CReferenceDialog (RefDlg.h:71–92) as a `References` class with `enumerate(EReferenceType) const -> const std::vector<std::string>&`. Port `InitLists` behaviour from Sources/src/editor/RefDlg.cpp — it scans Data subdirectories for a per-type extension — into a portable `References::rebuild(const std::string& dataRoot)` that uses std::filesystem (C++17) with case-insensitive matching through a small helper mirroring the Linux DataFile pattern (tools/zig/editor_bridge_test.cpp). Port AI class combo from Sources/src/editor/Reference.cpp and player sides combo from Sources/src/editor/UnitSide.cpp into Sources/src/ResourceModel/combos.{h,cpp} exposing `aiClasses() -> const std::vector<std::string>&` and `playerSides() -> const std::vector<std::string>&`. Port localisation items (CLocalizationItem + Sources/src/editor/localization.{h,cpp}) into Sources/src/ResourceModel/localization.{h,cpp} with the three-file read (`name.txt`, `desc.txt`, optional `stats.txt`) under a locale directory, returning raw bytes (no re-encoding — the comparator treats them opaque).

Done when: a one-off test program `tools/zig/resource_model_references_test.cpp` with build step `test-resource-model-references` constructs a `References` over a tracked fixture `tools/zig/fixtures/resource_editor/references_root/` (new, created in this task with ~3 entries per type) and asserts every EReferenceType enumerates the expected count; it also calls `aiClasses().size() > 0` and `playerSides().size() > 0` from static-fixture tables under the same fixtures root. The references fixture directory tree is created in this task.

## Inputs

- `Sources/src/editor/RefDlg.h`
- `Sources/src/editor/RefDlg.cpp`
- `Sources/src/editor/Reference.cpp`
- `Sources/src/editor/UnitSide.cpp`
- `Sources/src/editor/localization.h`
- `Sources/src/editor/localization.cpp`
- `Sources/src/editor/AnimTreeItem.cpp`
- `tools/zig/editor_bridge_test.cpp`
- `Sources/src/ResourceModel/factory.h`

## Expected Output

- `Sources/src/ResourceModel/references.h`
- `Sources/src/ResourceModel/references.cpp`
- `Sources/src/ResourceModel/combos.h`
- `Sources/src/ResourceModel/combos.cpp`
- `Sources/src/ResourceModel/localization.h`
- `Sources/src/ResourceModel/localization.cpp`
- `tools/zig/resource_model_references_test.cpp`
- `tools/zig/fixtures/resource_editor/references_root/`
- `build.zig`

## Verification

zig build install-game test-resource-model-references

## Observability Impact

`test-resource-model-references` writes one stderr line per EReferenceType: `REF <name> count=<n>`; absent entries show `count=0` so a future agent sees the picker list is empty without opening the GUI.
