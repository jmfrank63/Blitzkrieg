---
id: T08
parent: S03
milestone: M001
key_files:
  - tools/zig/run-resource-sweep.sh
  - Sources/editor/app/smoke.zig
  - Sources/editor/app/main.zig
  - .github/workflows/cross-platform.yml
key_decisions:
  - Scripted runs drop OS mouse events (which != smoke_mouse_id) after observe, so the real pointer cannot disturb the smoke
  - Long runs are cited from the maintainer's log and commit, not restarted by the agent (D010)
duration: 
verification_result: passed
completed_at: 2026-10-05T06:02:52.418Z
blocker_discovered: false
---

# T08: One sweep script (tools/zig/run-resource-sweep.sh) replaces run-s02/s03-sweep.sh and has no pre-existing classification. Scripted smoke runs now drop OS mouse events. CI runs test-resource-model on the five engine targets. The maintainer's Linux sweep at 27d03a607 passed every one of its 18 tiers (VERDICT=PASS).

**One sweep script (tools/zig/run-resource-sweep.sh) replaces run-s02/s03-sweep.sh and has no pre-existing classification. Scripted smoke runs now drop OS mouse events. CI runs test-resource-model on the five engine targets. The maintainer's Linux sweep at 27d03a607 passed every one of its 18 tiers (VERDICT=PASS).**

## What Happened

The work itself (the sweep script, the pointer fix and the CI change) was finished in earlier attempts. It was committed by the maintainer in 27d03a607 together with the uncommitted T05-T07 changes. T08 got stuck three times because the sweep (about 27 min) outlives an agent session. Per the 2026-10-05T06:01 override, the maintainer ran `bash tools/zig/run-resource-sweep.sh` at 27d03a607, and this session did not start it again (D010). It read the log and checked the committed tree against each must-have:
- One script: `tools/zig/run-resource-sweep.sh` exists, and 27d03a607 deletes run-s02-sweep.sh and run-s03-sweep.sh (`ls tools/zig/run-*sweep*.sh` lists only the new one).
- No pre-existing class: `grep -c PREEXISTING` gives 0. Any non-zero exit is RESULT=FAIL, and the verdict is FAIL if any tier failed. Each tier is bounded by `timeout` (BK_SWEEP_TIER_TIMEOUT, default 3600 s), and its stderr is kept on failure.
- Tiers: install-game+install-map-editor; test-resource-model, -core and -bridge; test-editor-kit; and all 13 Map Editor tiers from AGENTS.md: test-editor-core, test-map-editor-view, -panels, -testlaunch, -auto, test-map-editor-engine, test-editor-bridge, map-editor-host-check, map-editor-smoke, map-editor-auto, map-editor-auto-m2, map-editor-m3-auto and map-editor-game-reads-it-m3.
- Pointer: a smoke or auto tier failure gets a `HINT=pointer:...` on its FAIL line, never a pass. The smoke is now immune to the real pointer. `Driver.isOsMouse` (Sources/editor/app/smoke.zig) spots mouse motion, button and wheel events whose `which` is not the script's `smoke_mouse_id`, and `run` in Sources/editor/app/main.zig drops them after `observe` while a driver runs. The hidden, non-focusable window keeps ImGui from reading the global mouse state.
- CI: .github/workflows/cross-platform.yml runs `zig build test-resource-model -Dtest-mode=run` for x86_64-linux-gnu, x86_64-windows-msvc, aarch64-macos, aarch64-linux-gnu and x86_64-macos. The branch has not been pushed, so no CI result has been seen.

## Verification

Evidence: the maintainer's run of `bash tools/zig/run-resource-sweep.sh` at commit 27d03a607. The log is zig-out/local-test/resource_editor/resource-sweep.log (written 2026-10-05 13:00; the commit is at 13:01). All 18 TIER lines are EXIT=0 RESULT=PASS, ending with VERDICT=PASS. Durations: install 4.1 s; test-resource-model 20.6 s; test-resource-core 0.4 s; test-resource-bridge 4.8 s; test-editor-kit 0.5 s; test-editor-core 1.2 s; test-map-editor-view 0.5 s; -panels 3.5 s; -testlaunch 0.3 s; -auto 0.3 s; test-map-editor-engine 28.8 s; test-editor-bridge 542.8 s; map-editor-host-check 19.2 s; map-editor-smoke 12.6 s; map-editor-auto 30.8 s; map-editor-auto-m2 56.4 s; map-editor-m3-auto 182.1 s; map-editor-game-reads-it-m3 187.3 s.

Run in this session: the log was read, and `grep -q 'VERDICT=PASS'` on it succeeded. `git diff 27d03a607 --stat -- tools Sources build.zig .github` is empty, so the working tree is still the swept code. `ls tools/zig/run-*sweep*.sh` lists only run-resource-sweep.sh, and `grep -c PREEXISTING tools/zig/run-resource-sweep.sh` gives 0. Grepping the CI workflow shows test-resource-model on five targets, and `git show 27d03a607` shows the isOsMouse change. This session did not run the sweep itself (override, D010).

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `bash tools/zig/run-resource-sweep.sh (run by the maintainer at 27d03a607, not by this session)` | 0 | pass: 18/18 tiers PASS, VERDICT=PASS | 1620000ms |
| 2 | `grep -q 'VERDICT=PASS' zig-out/local-test/resource_editor/resource-sweep.log` | 0 | pass | 10ms |
| 3 | `git diff 27d03a607 --stat -- tools Sources build.zig .github` | 0 | pass: empty, tree equals swept commit | 50ms |
| 4 | `grep -c PREEXISTING tools/zig/run-resource-sweep.sh` | 1 | pass: 0 matches | 10ms |

## Deviations

The sweep was run by the maintainer, not inside this task's session, as the 2026-10-05T06:01 override directs. The task cites that log and commit 27d03a607 instead of its own run (exception to D009, recorded in D010).

## Known Issues

CI on macOS, Windows and Linux arm64 has not been observed; the branch is not pushed.

## Files Created/Modified

- `tools/zig/run-resource-sweep.sh`
- `Sources/editor/app/smoke.zig`
- `Sources/editor/app/main.zig`
- `.github/workflows/cross-platform.yml`
