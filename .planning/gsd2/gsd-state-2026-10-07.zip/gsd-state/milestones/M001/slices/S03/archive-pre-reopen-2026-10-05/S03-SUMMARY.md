---
id: S03
parent: M001
milestone: M001
provides:
  - Sources/src/ResourceModel/ — portable MFC-free C++ library with variant, prop, tree-item, factory, XML, all 21 item classes, references, combos, localization, comparator
  - test-resource-model build step (aggregate of scaffold, references, comparator sub-steps)
  - test-resources-all build step (aggregate, today = test-resource-model)
  - CI workflow entries for test-resource-model on Linux x64, Windows MSVC, macOS arm64, macOS x64
  - Per-stats-type comparator with 21 SKind entries keyed to engine reader entry points; aborts on unknown fields
  - tools/zig/run-s03-sweep.sh + s03-sweep.log (17 PASS, S03 VERDICT=PASS)
requires:
  []
affects:
  []
key_files:
  - Sources/src/ResourceModel/variant.h
  - Sources/src/ResourceModel/variant.cpp
  - Sources/src/ResourceModel/prop.h
  - Sources/src/ResourceModel/tree_item.h
  - Sources/src/ResourceModel/tree_item.cpp
  - Sources/src/ResourceModel/factory.h
  - Sources/src/ResourceModel/factory.cpp
  - Sources/src/ResourceModel/xml.h
  - Sources/src/ResourceModel/xml.cpp
  - Sources/src/ResourceModel/future_blob.h
  - Sources/src/ResourceModel/future_blob.cpp
  - Sources/src/ResourceModel/project.h
  - Sources/src/ResourceModel/project.cpp
  - Sources/src/ResourceModel/key_frame_tree_item.h
  - Sources/src/ResourceModel/key_frame_tree_item.cpp
  - Sources/src/ResourceModel/references.h
  - Sources/src/ResourceModel/references.cpp
  - Sources/src/ResourceModel/combos.h
  - Sources/src/ResourceModel/comparator.h
  - Sources/src/ResourceModel/comparator.cpp
  - Sources/src/ResourceModel/items/stats_item.h
  - Sources/src/ResourceModel/items/tree_item_types.h
  - build.zig
  - .github/workflows/cross-platform.yml
  - tools/zig/run-s03-sweep.sh
key_decisions:
  - CVariant uses std::variant with EKind = variant alternative index, giving lossless type storage and trivial equality.
  - CTreeItemFactory is a Meyers singleton keyed by int; REGISTER_CLASS file-scope objects are distributed across per-sub-editor translation units.
  - Comparator field tables are derived from the engine's own operator&(IDataTree&) bodies, not by linking readers, to keep ResourceModel MFC-free and portable.
  - Planted-unknown abort path verified via fork+exec child subcommand capturing stderr (Windows wired deferred).
  - test-resources-all aggregate excludes test-resource-xml-roundtrip and test-dxt-tolerance with an inline comment because those build steps are not yet registered.
  - PREEXISTING-signature classification in run-s03-sweep.sh is identical to run-s02-sweep.sh so the two logs are diffable and new failure modes stay FAIL.
  - item_base.h deleted in T06 (zero references; stale shell that could cause a misimport in future item ports).
patterns_established:
  - (none)
observability_surfaces:
  - none
drill_down_paths:
  []
duration: ""
verification_result: passed
completed_at: 2026-10-05T00:28:22.943Z
blocker_discovered: false
---

# S03: S03

**Ported the full ResourceModel C++ library (variant, prop, tree-item, factory, XML, all 21 item classes, references, comparator) and wired test-resource-model + test-resources-all with CI; 17-tier Linux sweep passed.**

## What Happened

S03 built `Sources/src/ResourceModel/` as a portable, MFC-free C++ library that the resource editor's remaining slices depend on.

**T01** laid the scaffold: `CVariant` (std::variant over 9 types, EKind = variant index), `SProp`, `CTreeItem` (children as unique_ptr vector), `CTreeItemFactory` (Meyers singleton, keyed by int), `NResourceXml` (promoted from the S01 spike, verbatim rename), `FutureBlob` (unknown-node preservation), `CProject` (load/save round-trip), and a scaffold test that proved factory fallback to FutureBlob.

**T02** ported all 11 stats-only sub-editor CTreeItem subclasses (Weapon, Mine, Trench, Squad, Sprite, Infantry, Mesh, Object, Fence, Building, Bridge) into `Sources/src/ResourceModel/items/`, with `StatsItem` as the base, and `tree_item_types.h` as the central REGISTER_CLASS roster. Project::Save() was corrected to rebuild the XML tree from typed children rather than returning stored bytes verbatim.

**T03** ported the remaining 10 sub-editor item classes (Particle, Effect, TileSet, 3dRoad, 3dRiver, Mission, Chapter, Campaign, Medal, GUI) plus the shared `CKeyFrameTreeItem` base used by the keyframe/graph/image families. All 21 item classes were wired into the factory via REGISTER_CLASS file-scope objects.

**T04** ported `EReferenceType` (20 types), the AI-class and player-sides combos, and `CLocalizationItem` into `references.h/cpp`, `combos.h/cpp`, `localization.h/cpp`. A `references_root` fixture was tracked under `tools/zig/fixtures/resource_editor/` and a dedicated `test-resource-model-references` step was wired to prove case-insensitive path resolution on Linux.

**T05** added the per-stats-type comparator (`comparator.h/cpp`): 21 `SKind` structs each naming the engine entry point (`ReadRPGStats`, `GetGameStats`, `fmtEffect::operator&`, etc.) and the full allowed-field set harvested from the engine's own `operator&(IDataTree&)` bodies. The comparator parses both sides through `NResourceXml`, walks leaf `(path, value)` pairs, and `std::abort()`s with `UNKNOWN FIELD <path>` on any unknown key. The abort path was verified via fork+exec of a planted-child subcommand capturing stderr.

**T06** aggregated the three ResourceModel test steps under `test-resource-model` and `test-resources-all` in `build.zig`, appended CI workflow entries for Linux x64, Windows MSVC, macOS arm64, and macOS x64, authored `tools/zig/run-s03-sweep.sh` (modelled on run-s02-sweep.sh with identical PREEXISTING-signature classification), deleted the unused `item_base.h` shell, and ran the sweep to completion. The sweep recorded 17 PASS lines and `S03 VERDICT=PASS` in `zig-out/local-test/resource_editor/s03-sweep.log`.

## Verification

S03 Linux sweep (`tools/zig/run-s03-sweep.sh`) completed with S03 VERDICT=PASS. All 17 tiers passed:
- install-game+install-map-editor: PASS (2892 ms)
- test-resource-model: PASS (188 ms)
- test-editor-kit: PASS (340 ms)
- test-editor-core: PASS (868 ms)
- test-map-editor-view: PASS (329 ms)
- test-map-editor-panels: PASS (2990 ms)
- test-map-editor-testlaunch: PASS (222 ms)
- test-map-editor-auto: PASS (225 ms)
- test-map-editor-engine: PASS (21644 ms)
- test-editor-bridge: PASS (407095 ms)
- map-editor-host-check: PASS (14286 ms)
- map-editor-smoke: PASS (9605 ms)
- map-editor-auto: PASS (25405 ms)
- map-editor-auto-m2: PASS (47636 ms)
- map-editor-m3-auto: PASS (145101 ms)
- map-editor-game-reads-it-m3: PASS (154144 ms)

Log: zig-out/local-test/resource_editor/s03-sweep.log, final line: "S03 VERDICT=PASS"

Per-task verification: T01–T06 each carry verification_result: passed in their SUMMARY frontmatter.

## Requirements Advanced

None.

## Requirements Validated

None.

## New Requirements Surfaced

None.

## Requirements Invalidated or Re-scoped

None.

## Operational Readiness

None.

## Deviations

None.

## Known Limitations

Windows planted-unknown abort path in the comparator uses a stub 'PLANTED skipped=1 reason=windows-not-wired' record; the fork+exec CreateProcess+pipes variant is deferred. MFC goldens are absent (win-home oracle not yet run); comparator returns GOLDEN_MISSING without aborting. test-resources-all aggregate omits test-resource-xml-roundtrip and test-dxt-tolerance until S01 registers those steps.

## Follow-ups

["S04 consumes ResourceModel to build resource_bridge.h + BkRes ABI + Zig resource_core", "S01 must register test-resource-xml-roundtrip and test-dxt-tolerance build steps before test-resources-all can include them", "Windows comparator planted-unknown path (fork+exec variant) deferred to a later task"]

## Files Created/Modified

None.
