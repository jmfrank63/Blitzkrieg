---
estimated_steps: 13
estimated_files: 5
skills_used: []
---

# T05: Per-stats-type comparator: read both port output and MFC golden through the engine's own typed readers, fail loudly on unknown fields

Why: The slice contract says 'the per-type stats comparator reads both port output and MFC golden through the engine's own readers' — `ReadRPGStats<T>` (Sources/src/Main/GameDB.cpp:278), `GetAddStats` / `GetGameStats` (GameDB.cpp:403/439), `ParticleSourceData` / `SmokinParticleSourceData` (from Formats), `fmtEffect` (Sources/src/Formats/fmtEffect.cpp), `fmtTerrain` (fmtTerrain.cpp), `fmtVSO` (fmtVSO.cpp). Reading through the engine, not through a hand-rolled parser, is what proves the port's bytes mean the same thing the game would mean. 'Fail loudly on unknown fields' means any attribute present in the port XML but not consumed by the engine reader (or vice versa) aborts the comparator with the attribute name.

Do: Add Sources/src/ResourceModel/comparator.{h,cpp} with per-sub-editor-kind comparators:
  - `compareWeapon(const Project& port, const std::string& goldenPath)` reads both via `ReadRPGStats<SWeaponRPGStats>` and compares field-by-field via a hand-maintained field table enumerated from the struct declaration in Sources/src/Main/RPGStats.h (the authoritative RPGStats header; the Formats layer's fmtRPGStats.h is not shipped — confirmed by `ls Sources/src/Formats/`).
  - Same shape for Mine (SMineRPGStats), Squad (SSquadRPGStats), Trench (SEntrenchmentRPGStats), Infantry (SInfantryRPGStats), Mesh/Unit (SMechUnitRPGStats), Building (SBuildingRPGStats), Fence (SFenceRPGStats), Bridge (SBridgeRPGStats), Object (SObjectRPGStats), Sound (SSoundRPGStats — Mesh editor's export path).
  - For Particle: `compareParticle(port, goldenPath)` reads both via `SParticleSourceData` / `SSmokinParticleSourceData` from Sources/src/Main/ (grep for the struct declarations).
  - For Effect: via `fmtEffect`.
  - For Terrain/Tileset: via `fmtTerrain`.
  - For 3dRoad / 3dRiver / VSO-shaped formats: via `fmtVSO`.
  - For Mission/Chapter/Campaign/Medal: via `GetGameStats<SMissionStats|SChapterStats|SCampaignStats|SMedalStats>`.
  - For GUI: not applicable in this slice; comparator returns `NOT_APPLICABLE`.
  Each comparator returns `{ fields_compared, mismatches: [{field, port, golden}], unknown_fields: [path] }`. An `unknown_fields` non-empty entry triggers an abort via `std::abort()` after printing `UNKNOWN FIELD <path>` to stderr. If `goldenPath` is missing, the comparator returns `GOLDEN_MISSING` without aborting — the slice contract tolerates win-home oracle not yet having run.
  Wire a tool `tools/zig/resource_model_comparator_test.cpp` that drives the comparator on every repo-owned fixture via `addEngineHostedTool`, step name `test-resource-model-comparator`. The tool exports the port's stats-only output to a scratch directory under `zig-out/local-test/resource_model/export/<ext>/` and compares against `tools/zig/fixtures/resource_editor/<ext>/golden/`.

Done when: `zig build test-resource-model-comparator` exits 0 on Linux x64 against the current repo state (every ext without a golden reports `GOLDEN_MISSING`); the comparator's output log at `zig-out/local-test/resource_model/comparator.log` contains one line per (ext, stats_type) and prints `UNKNOWN FIELD` + abort on an injected mismatch (unit-tested via a planted-field fixture `tools/zig/fixtures/resource_editor/wpn/golden-synthetic-unknown.xml` added in this task).

## Inputs

- `Sources/src/Main/GameDB.cpp`
- `Sources/src/Main/GameDB.h`
- `Sources/src/Main/RPGStats.cpp`
- `Sources/src/Main/RPGStats.h`
- `Sources/src/Formats/fmtEffect.cpp`
- `Sources/src/Formats/fmtEffect.h`
- `Sources/src/Formats/fmtTerrain.cpp`
- `Sources/src/Formats/fmtTerrain.h`
- `Sources/src/Formats/fmtVSO.cpp`
- `Sources/src/Formats/fmtVSO.h`
- `Sources/src/ResourceModel/factory.h`
- `Sources/src/ResourceModel/project.h`
- `Sources/src/ResourceModel/tree_item.h`
- `tools/zig/fixtures/resource_editor/wpn/project.wpn`

## Expected Output

- `Sources/src/ResourceModel/comparator.h`
- `Sources/src/ResourceModel/comparator.cpp`
- `tools/zig/resource_model_comparator_test.cpp`
- `tools/zig/fixtures/resource_editor/wpn/golden-synthetic-unknown.xml`
- `build.zig`

## Verification

zig build install-game test-resource-model-comparator

## Observability Impact

`zig-out/local-test/resource_model/comparator.log` holds one line per (ext, stats_type) with `fields=<n> mismatches=<n> golden=present|missing`; the `UNKNOWN FIELD` abort path is covered by a planted fixture so the diagnostic is exercised in CI, not only on real failures.
