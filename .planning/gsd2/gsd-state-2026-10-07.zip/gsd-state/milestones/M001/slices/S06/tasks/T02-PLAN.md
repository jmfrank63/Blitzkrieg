---
estimated_steps: 12
estimated_files: 7
skills_used: []
---

# T02: Graphics export: TGA to DDS via NDxt, mine compose, trench and squad file copies

Why: mine, trench and squad export graphics (research finding 3), and no portable image pipeline exists.

Do: first spike the entry points in Sources/src/ResourceModel/dxt_gate.h (DecodeDds/EncodeDds/SDdsImage) and NDxt. Add a small portable image module, e.g. Sources/src/ResourceModel/image_export.{h,cpp}. It needs:
- a TGA reader (uncompressed and RLE 24/32-bit, as the fixtures use);
- ConvertAndSaveImage: TGA to DDS with the MFC format choice. Read CParentFrame::ConvertAndSaveImage / SaveCompressedTexture in Sources/src/editor for format, mips and the _h.dds rule;
- a port of ComposeSingleObject (Sources/src/editor/BuildCompose.cpp) for mine 1.tga + 1s.tga -> 1.
Wire them into the T01 exporters:
- mine: compose;
- trench: for 4 indices times each source item, copy the file by basename; for the first item only, convert 1/1w/1a;
- squad: copy the icon by basename, or use a backslash path as is.
Up-to-date skipping follows MFC's FindMinimalExportFileTime/FindMaximalSourceTime unless bForce, counted in nSkipped. bStatsOnly writes no graphics. Set SExportOutcome.szObjectName for mine and trench so preview (T05) can build them.

Tests: export each fixture into zig-out/local-test. Decode the produced DDS with NDxt and check it against the source TGA within the dxt-tolerance.json gate (LoadDxtTolerance). Copies must be byte-identical. bStatsOnly must produce no image files. Negative cases: a missing source TGA gives a false return with szError and nothing promoted; a truncated TGA is rejected; a non-power-of-two size is handled as MFC did.

Done when: the graphics checks pass in test-resource-bridge (or a model test) and nothing writes outside staging.

## Inputs

- `Sources/src/ResourceModel/dxt_gate.h`
- `Sources/src/ResourceModel/dxt_gate.cpp`
- `tools/zig/fixtures/resource_editor/dxt-tolerance.json`
- `Sources/src/editor/BuildCompose.cpp`
- `Sources/src/editor/MineFrm.cpp`
- `Sources/src/editor/TrenchFrm.cpp`
- `Sources/src/editor/SquadFrm.cpp`
- `Sources/src/ResourceModel/items/mine/mine_export.cpp`
- `Sources/src/ResourceModel/items/trench/trench_export.cpp`
- `Sources/src/ResourceModel/items/squad/squad_export.cpp`

## Expected Output

- `Sources/src/ResourceModel/image_export.h`
- `Sources/src/ResourceModel/image_export.cpp`
- `Sources/src/ResourceModel/items/mine/mine_export.cpp`
- `Sources/src/ResourceModel/items/trench/trench_export.cpp`
- `Sources/src/ResourceModel/items/squad/squad_export.cpp`
- `tools/zig/editor_bridge_test.cpp`
- `build.zig`

## Verification

zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model-comparator -Dtest-mode=run

## Observability Impact

Each image failure names the source path and the reason (missing, bad header, unsupported depth). Measured max/p99 deltas are printed beside the gate.
