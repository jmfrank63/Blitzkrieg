# S06: Weapon, Mine, Trench, Squad sub-editors

**Goal:** Weapon (.wpn), Mine (.mcp), Trench (.trc) and Squad (.scp) become real sub-editors. Each has a registered exporter that ports its MFC frame's SaveRPGStats/ExportFrameData: stats read back field-equal by the engine's own readers, plus mine compose, trench DDS and copies, and the squad icon. Each also has an import-then-export round trip of a shipped sample, an undoable command for every tool with set+get before/after tests, a measured preview shot where MFC draws something (D015), and a BK_EDITOR_AUTO scenario. Win-home goldens are wired and reported pending.
**Demo:** For each of 4 kinds: committed golden parity (stats field-equal via comparator, `_h.dds` byte-identical, DDS within tolerance), import-and-export round trip for a shipped sample, undo/redo tests for every tool, a measured preview shot, one `BK_EDITOR_AUTO` scenario. Squad: formation drag + zero point + direction arrow all undoable. Weapon: shoot, damage, sound, effect, flash, craters trees all editable.

## Must-Haves

- FindExporter returns a production exporter for wpn, mcp, trc and scp. BkResExport no longer refuses these kinds, and bStatsOnly skips graphics.
- For each fixture tools/zig/fixtures/resource_editor/{wpn,mcp,trc,scp}/project.*, the exported stats XML reads back through the comparator's engine readers with exact fields and no unknown fields. GOLDEN <ext> is still reported pending, not passed.
- Mine `1` (composed), trench `1/1w/1a` DDS: the image decoded by NDxt is within the dxt-tolerance.json gate of the source TGA. Trench copied sources and the squad icon are byte-identical copies.
- Import of one shipped runtime sample per kind from Data/ (copied under zig-out/local-test), then export, compares field-equal through the comparator.
- Every S06 tool has a do/undo/redo test with get-before and get-after state, in test-resource-core (fake bridge) and test-resource-bridge (real). Tools: squad formation drag (formation_positions), squad zero point, direction; weapon shoot/damage/sound/effect/flash/crater insert/delete/edit; trench source add/remove.
- Preview kinds for trc, scp and mcp capture a frame whose lit-pixel measure passes in test-resource-bridge. Weapon is marked "no behaviour in MFC" (D015).
- resource-editor-auto runs an S06 schedule covering each of the four kinds.
- 06-PARITY.md rows B-03.*, B-04.*, B-05.* and B-13.* are updated with evidence. Golden rows say "pending win-home".
- These tiers stay green on Linux: test-resource-model-comparator, test-resource-model-fidelity, test-resource-bridge, test-resource-core, test-resource-app-logic, resource-editor-host-check/-smoke/-auto, test-editor-core.

## Proof Level

- This slice proves: Integration on Linux x64: the real engine readers via the comparator, the real bridge and the real app under BK_EDITOR_AUTO. Golden parity against MFC is pending win-home. macOS and Windows are left to CI and not claimed.

## Integration Closure

Exporters registered in ResourceModel get picked up by BkResExport (staging, then all-or-nothing promotion). The app's Export, Run Blitzkrieg and Batch CLI then work for the four kinds without changes to the app shell. Tools go through resource_core ResourceCommand (geometry/insert_node/delete_node/set_prop/composite), so undo, save and autosave come with them. Preview kinds plug into kPreviewKinds and use the exporter's szObjectName.

## Verification

- The exporter fills SExportOutcome warnings and szError the way MFC's output pane did (missing source TGA, unresolved squad member, missing trench source). The comparator prints field paths on a mismatch. Auto-scenario failures print the frame and the action.

## Tasks

- [x] **T01: Stats exporters for wpn, mcp, trc, scp registered in ResourceModel** `est:3h`
  Why: no production exporter exists yet, so BkResExport refuses every real kind (research finding 1). This unblocks Export, Run Blitzkrieg, the auto scenarios and the import round trip.
  - Files: `Sources/src/ResourceModel/exporter.h`, `Sources/src/ResourceModel/exporter.cpp`, `Sources/src/ResourceModel/items/weapon/weapon_export.cpp`, `Sources/src/ResourceModel/items/mine/mine_export.cpp`, `Sources/src/ResourceModel/items/trench/trench_export.cpp`, `Sources/src/ResourceModel/items/squad/squad_export.cpp`, `Sources/src/EditorBridge/resource_bridge.cpp`, `tools/zig/resource_model_comparator_test.cpp`, `tools/zig/editor_bridge_test.cpp`, `build.zig`
  - Verify: zig build test-resource-model-comparator -Dtest-mode=run && zig build test-resource-model-fidelity -Dtest-mode=run && zig build test-resource-bridge -Dtest-mode=run

- [x] **T02: Graphics export: TGA to DDS via NDxt, mine compose, trench and squad file copies** `est:3h`
  Why: mine, trench and squad export graphics (research finding 3), and no portable image pipeline exists.
  - Files: `Sources/src/ResourceModel/image_export.h`, `Sources/src/ResourceModel/image_export.cpp`, `Sources/src/ResourceModel/items/mine/mine_export.cpp`, `Sources/src/ResourceModel/items/trench/trench_export.cpp`, `Sources/src/ResourceModel/items/squad/squad_export.cpp`, `tools/zig/editor_bridge_test.cpp`, `build.zig`
  - Verify: zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model-comparator -Dtest-mode=run

- [x] **T03: Import-and-export round trip of shipped wpn, mcp, trc, scp samples** `est:1.5h`
  Why: the slice demo requires the import of a shipped sample to round-trip (B-03.6, B-04.3, B-05.3, B-13.4).
  - Files: `tools/zig/editor_bridge_test.cpp`, `Sources/src/EditorBridge/resource_bridge.cpp`, `Sources/src/ResourceModel/comparator.cpp`
  - Verify: zig build test-resource-bridge -Dtest-mode=run

- [x] **T04: Undoable sub-editor tools in resource_core with fake-bridge and real-bridge tests** `est:3h`
  Why: every tool must be undoable, with set+get before and after state (slice demo; B-03.2..4, B-04.1, B-13.1).
  - Files: `Sources/editor/resource_core/sub_editor_tools.zig`, `Sources/editor/resource_core/root.zig`, `Sources/editor/resource_core/fake_bridge.zig`, `Sources/editor/resource_core/document.zig`, `tools/zig/editor_bridge_test.cpp`, `build.zig`
  - Verify: zig build test-resource-core -Dtest-mode=run && zig build test-resource-bridge -Dtest-mode=run

- [x] **T05: App wiring: squad formation overlay and toolbar, weapon/trench tree tools, preview kinds for trc/scp/mcp** `est:3h`
  Why: the tools need UI entries and the slice needs measured preview shots (D015).
  - Files: `Sources/editor/resource_app/panels.zig`, `Sources/editor/resource_app/panels_logic.zig`, `Sources/editor/resource_app/docks.zig`, `Sources/editor/resource_app/edit_logic.zig`, `Sources/editor/resource_app/squad_logic.zig`, `Sources/src/EditorBridge/resource_bridge.cpp`, `tools/zig/editor_bridge_test.cpp`, `build.zig`
  - Verify: zig build test-resource-app-logic -Dtest-mode=run && zig build test-resource-bridge -Dtest-mode=run && zig build install-resource-editor && zig build resource-editor-host-check && zig build resource-editor-smoke (GUI tiers from the real shell, not the gsd_exec sandbox)

- [x] **T06: BK_EDITOR_AUTO scenarios for the four kinds, parity rows, tier run** `est:2h`
  Why: the slice demo requires one BK_EDITOR_AUTO scenario per kind and parity evidence.
  - Files: `Sources/editor/resource_app/scenario.zig`, `build.zig`, `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`
  - Verify: zig build resource-editor-auto && zig build resource-editor-smoke && zig build test-resource-app-logic -Dtest-mode=run && zig build test-editor-core -Dtest-mode=run && zig build map-editor-smoke (real shell, one at a time)

## Files Likely Touched

- Sources/src/ResourceModel/exporter.h
- Sources/src/ResourceModel/exporter.cpp
- Sources/src/ResourceModel/items/weapon/weapon_export.cpp
- Sources/src/ResourceModel/items/mine/mine_export.cpp
- Sources/src/ResourceModel/items/trench/trench_export.cpp
- Sources/src/ResourceModel/items/squad/squad_export.cpp
- Sources/src/EditorBridge/resource_bridge.cpp
- tools/zig/resource_model_comparator_test.cpp
- tools/zig/editor_bridge_test.cpp
- build.zig
- Sources/src/ResourceModel/image_export.h
- Sources/src/ResourceModel/image_export.cpp
- Sources/src/ResourceModel/comparator.cpp
- Sources/editor/resource_core/sub_editor_tools.zig
- Sources/editor/resource_core/root.zig
- Sources/editor/resource_core/fake_bridge.zig
- Sources/editor/resource_core/document.zig
- Sources/editor/resource_app/panels.zig
- Sources/editor/resource_app/panels_logic.zig
- Sources/editor/resource_app/docks.zig
- Sources/editor/resource_app/edit_logic.zig
- Sources/editor/resource_app/squad_logic.zig
- Sources/editor/resource_app/scenario.zig
- .planning/phases/06-resource-editor-portable-port/06-PARITY.md
