---
estimated_steps: 3
estimated_files: 3
skills_used: []
---

# T03: Import-and-export round trip of shipped wpn, mcp, trc, scp samples

Why: the slice demo requires the import of a shipped sample to round-trip (B-03.6, B-04.3, B-05.3, B-13.4).

Do: in test-resource-bridge, pick one shipped runtime stats file per kind from Data/ (e.g. a weapons\*.xml, a mine, an entrenchment and a squad; find real names with a case-insensitive DataFile lookup) and copy it with any needed art under zig-out/local-test. Then BkResImportFromGame into a new project of that kind, save the project, BkResExport it (stats-only where the shipped art is not TGA source), and compare the exported stats with the shipped file through the comparator (field-equal, engine readers). For squad, the object lookup comes from the engine IObjectsDB over the copied data. Any field MFC itself could not round-trip goes to the comparator's documented exceptions table with a reason, never silently. Never write into Data/.

Done when: four round-trip cases pass and are listed by name in the tier output.

## Inputs

- `tools/zig/editor_bridge_test.cpp`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/ResourceModel/comparator.cpp`
- `Sources/src/ResourceModel/items/weapon/weapon_export.cpp`
- `Sources/src/ResourceModel/items/mine/mine_export.cpp`
- `Sources/src/ResourceModel/items/trench/trench_export.cpp`
- `Sources/src/ResourceModel/items/squad/squad_export.cpp`

## Expected Output

- `tools/zig/editor_bridge_test.cpp`

## Verification

zig build test-resource-bridge -Dtest-mode=run

## Observability Impact

Each round-trip case prints the shipped sample name and the first differing field path.
