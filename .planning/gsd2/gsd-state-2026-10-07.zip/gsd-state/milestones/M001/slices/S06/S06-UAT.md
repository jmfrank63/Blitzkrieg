# S06: S06 — UAT

**Milestone:** M001
**Written:** 2026-10-05T13:06:27.587Z

# S06 UAT

**UAT Type:** automated plus manual hand try on Linux

## Preconditions
- Build: `zig build install-resource-editor`.
- Redirect `XDG_DATA_HOME` so the user profile is not touched.

## Steps
1. Run `zig build resource-editor-auto`. Expected: exit 0, with the wpn, mcp, trc and scp scenario blocks all reporting exported.
2. Open a fresh mod, create a Squad and drag a slot. Expected: the slot moves, undo restores it and redo reapplies it.
3. Set the squad zero point and the direction arrow, then undo and redo each. Expected: both are undoable.
4. In a Weapon project, add a shoot type and a crater through the tree. Expected: both are editable and undoable.
5. Export a Mine, a Trench and a Squad. Expected: the graphics files are written next to the stats.

## Edge cases
- A bad scenario argument or an unknown action fails loudly with the frame and reason.

## Not Proven By This UAT
- Golden parity against MFC output (pending win-home).
- macOS and Windows behaviour.
- The full resource sweep.
