---
id: T04
parent: S06
milestone: M001
key_files:
  - Sources/editor/resource_core/sub_editor_tools.zig
  - Sources/editor/resource_core/root.zig
  - Sources/editor/resource_core/fake_bridge.zig
  - Sources/editor/resource_core/bridge.zig
  - Sources/editor/resource_app/c_bridge.zig
  - Sources/src/EditorBridge/resource_bridge.cpp
  - Sources/src/EditorBridge/resource_bridge.h
  - Sources/src/EditorBridge/resource_bridge_test.cpp
  - docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md
key_decisions:
  - Formation direction is the new point2 channel formation_direction (16): x = FormationDir in radians, y unused
  - The direction arrow is one composite step: the direction plus the slots turned about the centre
  - A formation drag writes the slots live and records one geometry step from press to release
  - The fake enforces geometry homes only after a test declares them
duration: 
verification_result: passed
completed_at: 2026-10-05T12:27:07.560Z
blocker_discovered: false
---

# T04: Undoable S06 sub-editor tools (squad drag/zero/direction, weapon tree, trench sources) in resource_core/sub_editor_tools.zig, tested on the fake and real bridges

**Undoable S06 sub-editor tools (squad drag/zero/direction, weapon tree, trench sources) in resource_core/sub_editor_tools.zig, tested on the fake and real bridges**

## What Happened

Added Sources/editor/resource_core/sub_editor_tools.zig (exported from root.zig). It builds commands from the mirror and the bridge, and the app (T05) only has to call it. It contains the ETIT class constants, finders (firstOfClass, childOfClass, placeOf, propIdByName), generic builders (setProp/setPropByName, insertChild/appendChild, deleteNode, setGeometry) and commit(), which reserves, applies and records the command, and on any error frees it and leaves the history unchanged.

Squad:
- FormationDrag (begin/moveSlot/finish/cancel) writes the slots live during a drag and gives back one geometry command from press to release.
- setZeroPoint.
- setFormationDirection builds a composite of formation_direction plus formation_positions turned about the zero point, matching MFC's CalculateNewPositions.

Weapon:
- weaponAddShootType/weaponDeleteShootType and weaponAddCrater/weaponDeleteCrater/weaponEditCrater.
- weaponEdit edits a WeaponPart (damage, sound, effect, flash_fire, flash_explosion, craters) by MFC prop name.

Trench: trenchAddSource and trenchRemoveSource.

Direction-arrow finding:
- ID_SHOW_DIRECTION_BUTTON only shows or hides the docker, so it is UI state.
- The arrow's angle is stored data: CSquadFormationPropsItem::fFormationDir (the FormationDir attribute). It is neither a prop nor a channel, so I added the geometry channel formation_direction = 16 (point2 family, x = radians, y unused). This touched resource_bridge.cpp/.h (HOME_SQUAD_DIR, BkResGet/SetFormationDirection), bridge.zig and c_bridge.zig. The spec geometry table records it.

Fake bridge changes:
- Optional geometry homes (addGeometryHome). The fake refuses undeclared pairs only once a test declares homes, so older tests are unaffected.
- save/open now serialise the geometry map.
- restoreNode honours the index.

Tests:
- 13 named tests in test-resource-core: one per tool plus a no-MFC-home negative test that checks the history stays unchanged. Each runs get-before, apply, get-after, undo == before, redo == after, save+reopen == after, and on a failure prints the tool, the step and both state dumps (channel, node, values).
- A matching S06Tools namespace in Sources/src/EditorBridge/resource_bridge_test.cpp (14 sequences on the scp/wpn/trc fixtures plus the no-home refusals). It also checks that the S03 reader sees the saved FormationDir.

## Verification

zig build test-resource-core -Dtest-mode=run: 43/43 pass, including the 13 new tool tests. zig build test-resource-bridge -Dtest-mode=run: exit 0, no FAIL lines, all s06-tool sequences pass ("resource-bridge: Project+Tree OK (21 fixtures)"). I also ran test-resource-app-logic (73/73) and install-resource-editor (builds, so c_bridge.zig compiles with the new channel). Full sweep left to the maintainer.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-core -Dtest-mode=run` | 0 | pass | 3000ms |
| 2 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 20000ms |
| 3 | `zig build test-resource-app-logic -Dtest-mode=run` | 0 | pass | 5000ms |
| 4 | `zig build install-resource-editor` | 0 | pass | 60000ms |

## Deviations

The real-bridge tests went into Sources/src/EditorBridge/resource_bridge_test.cpp, which is the file test-resource-bridge builds, not tools/zig/editor_bridge_test.cpp. The direction arrow was neither a prop nor a view toggle only, so a new C ABI channel (formation_direction) was added. Small edits to resource_bridge.cpp/.h, c_bridge.zig and the spec.

## Known Issues

For the parity row: ID_SHOW_DIRECTION_BUTTON is UI state and is not undoable. In drag mode the arrow sets a slot's own Dir (SUnit::fDir, which is exported); the bridge has no channel for that yet. MFC turns the slots about the drawn cross (ZeroPos plus a 15.4-pixel screen offset); setFormationDirection takes an optional centre so the app can pass it, and defaults to the stored zero point. Weapon effects and flash items are static in MFC (bStaticElements), so they only take property edits. CWeaponSoundPropsItem and CWeaponEffectPropsItem are never placed by WeaponFrm; sound and effect edits go to the Effects item's props.

## Files Created/Modified

- `Sources/editor/resource_core/sub_editor_tools.zig`
- `Sources/editor/resource_core/root.zig`
- `Sources/editor/resource_core/fake_bridge.zig`
- `Sources/editor/resource_core/bridge.zig`
- `Sources/editor/resource_app/c_bridge.zig`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge.h`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`
