---
id: T06
parent: S06
milestone: M001
key_files: []
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-05T13:04:37.548Z
blocker_discovered: false
---

# T06: resource-editor-auto gains tree, squad_drag, squad_zero, squad_dir actions and expect=slot/direction, plus one scenario block each for wpn, mcp, trc and scp; parity rows B-03/04/05/13 updated; all tiers green on Linux.

**resource-editor-auto gains tree, squad_drag, squad_zero, squad_dir actions and expect=slot/direction, plus one scenario block each for wpn, mcp, trc and scp; parity rows B-03/04/05/13 updated; all tiers green on Linux.**

## What Happened

scenario.zig got the S06 actions (do=tree:<add_shoot_type|add_crater|add_source>, do=squad_drag:<slot>/<dx>/<dy>, do=squad_zero:<x>/<y>, do=squad_dir:<rad>) and predicates (expect=slot:<n>=moved|home, expect=direction:<rad>), all routed through sub_editor_tools / squad_logic so they are the same undo steps as the UI; bad arguments and unknown actions still fail loudly with frame and reason. The build.zig schedule has frames 40-124: a fresh mod folder, then per kind open, tool, undo, redo, save, export (expect exported), with shot + shot_lit + differ for mcp, trc and scp. The weapon block has no shot (no MFC preview, D015). 06-PARITY.md rows B-03.1-6, B-04.1-3, B-05.1-3, B-13.1-4 now cite the tests and auto actions; golden parity is marked pending win-home (export-goldens.ps1 -Extensions wpn,mcp,trc,scp). Full resource sweep left to the maintainer. Nothing was run or claimed on macOS or Windows.

## Verification

resource-editor-auto PASS (110 actions over 125 frames); each tier below run in the foreground and exited 0.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build resource-editor-auto` | 0 | pass | 21000ms |
| 2 | `zig build resource-editor-smoke` | 0 | pass | 5000ms |
| 3 | `zig build test-resource-app-logic -Dtest-mode=run` | 0 | pass | 1000ms |
| 4 | `zig build test-editor-core -Dtest-mode=run` | 0 | pass | 1000ms |
| 5 | `zig build map-editor-smoke` | 0 | pass | 12000ms |
| 6 | `zig build test-resource-model-comparator -Dtest-mode=run` | 0 | pass (goldens pending) | 20000ms |
| 7 | `zig build test-resource-model-fidelity -Dtest-mode=run` | 0 | pass (505 PASS, 0 FAIL) | 1000ms |
| 8 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 26000ms |
| 9 | `zig build test-resource-core -Dtest-mode=run` | 0 | pass | 1000ms |
| 10 | `zig build install-resource-editor && zig build resource-editor-host-check` | 0 | pass | 9000ms |

## Deviations

None.

## Known Issues

None.

## Files Created/Modified

None.
