---
id: T02
parent: S06
milestone: M001
key_files:
  - Sources/src/ResourceModel/image_export.h
  - Sources/src/ResourceModel/image_export.cpp
  - Sources/src/ResourceModel/items/mine/mine_export.cpp
  - Sources/src/ResourceModel/items/trench/trench_export.cpp
  - Sources/src/ResourceModel/items/squad/squad_export.cpp
  - Sources/src/ResourceModel/exporter.h
  - Sources/src/EditorBridge/resource_bridge.cpp
  - Sources/src/EditorBridge/resource_bridge_test.cpp
  - tools/zig/resource_model_comparator_test.cpp
  - build.zig
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-05T12:39:55.431Z
blocker_discovered: false
---

# T02: Mine, trench and squad exporters now write their graphics: mine compose (_c/_l/_h.dds + .san for sprite and shadow), trench 1/1w/1a DDS and model copies, squad icon copy, all through the engine's image processor into staging.

**Mine, trench and squad exporters now write their graphics: mine compose (_c/_l/_h.dds + .san for sprite and shadow), trench 1/1w/1a DDS and model copies, squad icon copy, all through the engine's image processor into staging.**

## What Happened

New Sources/src/ResourceModel/image_export.{h,cpp} (built into the EditorBridge archive) ports ConvertAndSaveImage, SaveCompressedTexture/Shadow, ComposeSingleObject and MyCopyFile through the engine's IImageProcessor (TGA/PNG/BMP readers, gamma, NDxt Compress), so _h.dds is the raw ARGB8888 MFC wrote and DXT files differ only within the dxt-tolerance gate. Pictures are validated before anything is written. Mine export composes 1.tga + 1s.tga into 1/1s. Trench copies each segment model by basename and converts 1/1w/1a from the first source's folder (a failed picture is a warning, as MFC's output pane). Squad copies the icon beside the stats (backslash path used as is, else project-relative); failure is a warning. bStatsOnly writes no graphics. SExportContext gained szDataRoot (set by the bridge). szObjectName is set for mine and trench. MFC's up-to-date check never skipped for mine (base FindMaximalSourceTime), trench (it compares against a dest 1.tga that is never written) or squad (no override), so every export runs and nSkipped stays 0. Tests: the comparator test host now registers the Image module's IImageProcessor; added graphics checks (file presence, DXT5 decode vs source TGA against the gate max, stats-only writes no image, missing 1s.tga/1w.tga, truncated TGA, 20x12 non-power-of-two composes, model/icon byte-identical copies). Added tracked 16x16 fixture TGAs for mcp and trc, and the bridge test plants them for the shipped-trench case.

## Verification

zig build test-resource-model-comparator -Dtest-mode=run (VERDICT=PASS, goldens pending) and zig build test-resource-bridge -Dtest-mode=run (exit 0) both pass on Linux x64. macOS and Windows not run. Full sweep left to the maintainer.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-model-comparator -Dtest-mode=run` | 0 | pass | 60000ms |
| 2 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 120000ms |

## Deviations

The plan named editor_bridge_test.cpp; tests went into resource_model_comparator_test.cpp and resource_bridge_test.cpp, where the S06 export tests live. The DXT check holds only the gate's max (colour/alpha), not p99: the gate's p99 was measured on already-quantised textures, and a raw TGA exceeds it (measured colour max 12, p99 10). Missing trench pictures are warnings, not failures.

## Known Issues

Squad backslash-path icon copy is untested on Linux. MFC's History block and exact zero-point float bits unverified until win-home goldens exist.

## Files Created/Modified

- `Sources/src/ResourceModel/image_export.h`
- `Sources/src/ResourceModel/image_export.cpp`
- `Sources/src/ResourceModel/items/mine/mine_export.cpp`
- `Sources/src/ResourceModel/items/trench/trench_export.cpp`
- `Sources/src/ResourceModel/items/squad/squad_export.cpp`
- `Sources/src/ResourceModel/exporter.h`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `tools/zig/resource_model_comparator_test.cpp`
- `build.zig`
