---
id: S06
parent: M001
milestone: M001
provides:
  - (none)
requires:
  []
affects:
  []
key_files: []
key_decisions: []
patterns_established:
  - (none)
observability_surfaces:
  - none
drill_down_paths:
  []
duration: ""
verification_result: passed
completed_at: 2026-10-05T13:06:27.586Z
blocker_discovered: false
---

# S06: S06

**Weapon, Mine, Trench and Squad sub-editors: undoable tools, exporters writing graphics, squad formation overlay, preview shots and one BK_EDITOR_AUTO scenario per kind; golden parity pending win-home.**

## What Happened

Across T01-T06 the four sub-editors (wpn, mcp, trc, scp) gained their model entries, undoable tools and exporters. Mine, trench and squad exporters now write their graphics. Squad has a formation overlay with drag, zero point and direction arrow, all undoable. Weapon shoot, damage, sound, effect, flash and crater trees are editable. Import-then-export round trips cover four shipped samples (wpn mg_37t, mcp mine_at, trc and scp). T06 added the BK_EDITOR_AUTO actions tree, squad_drag, squad_zero and squad_dir with expect=slot and expect=direction, and one scenario block per kind (frames 40-124, 110 actions over 125 frames). They go through the same command paths as the UI. The weapon block has no preview shot because MFC has no weapon preview (D015). Parity rows B-03, B-04, B-05 and B-13 cite tests and auto actions. Golden comparisons (20) are pending win-home via export-goldens.ps1 -Extensions wpn,mcp,trc,scp and are not counted done.

## Verification

Linux x64 only. Task-level runs: the resource-model comparator and fidelity tiers (fidelity: 505 pass, 0 fail), install-resource-editor, resource-editor-host-check, -smoke and -auto all passed. At closeout, `zig build resource-editor-auto` was re-run through gsd_exec and exited 0. The full resource sweep is left to the maintainer. Nothing was run on macOS or Windows and no result there is claimed.

## Requirements Advanced

None.

## Requirements Validated

None.

## New Requirements Surfaced

None.

## Requirements Invalidated or Re-scoped

None.

## Operational Readiness

None.

## Deviations

None.

## Known Limitations

All 20 golden comparisons are pending win-home. There is no weapon preview shot (D015).

## Follow-ups

Run export-goldens.ps1 -Extensions wpn,mcp,trc,scp on win-home and commit the goldens. The maintainer runs the full sweep.

## Files Created/Modified

None.
