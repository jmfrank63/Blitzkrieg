---
estimated_steps: 8
estimated_files: 10
skills_used: []
---

# T01: Stats exporters for wpn, mcp, trc, scp registered in ResourceModel

Why: no production exporter exists yet, so BkResExport refuses every real kind (research finding 1). This unblocks Export, Run Blitzkrieg, the auto scenarios and the import round trip.

Do (TDD): first add failing checks to the model comparator/bridge tests that export each fixture project and read the result with the comparator's engine readers. Then port SaveRPGStats line for line:
- Weapon: Sources/src/editor/WeaponFrm.cpp:64-171. Fill SWeaponRPGStats from the common props, then one SShell per shoot-type child (trajectory, piercing, damage, area, speed, rate of fire, trace/track-break, craters list, track-damage bit 0, effect names, fire sound, two flash effects). Write tree.Add("RPG", &stats) through the engine's CTreeAccessor/IDataTree.
- Mine: Sources/src/editor/MineFrm.cpp:70-110, with szFlagModel="1", szWeapon and weight.
- Trench: Sources/src/editor/TrenchFrm.cpp:123.
- Squad: Sources/src/editor/SquadFrm.cpp:216. szIcon = GetSquadPicture() as MFC writes it. Members are resolved through a new optional object-lookup function pointer in SExportContext (D015); BkResExport fills it from the engine's IObjectsDB, and tests pass a fixture lookup.
Put the exporters under Sources/src/ResourceModel/items/<kind>/ (e.g. weapon_export.cpp) or beside the items, and register them at model init via RegisterExporter. Add the new .cpp files to resource_model_sources in build.zig. Leave graphics to T02, but honour bStatsOnly already. Output path: weapons\<name>.xml and the per-kind folders MFC used. Check the MFC frame's GetExportFileName equivalents. Remove the test-only mdc reliance only where the real kinds now cover the case; keep the mdc refusal test.

Done when: every fixture's exported stats compare field-equal and unknown-field-free with the comparator, BkResExport writes them through staging, the GOLDEN lines still say pending, and the listed tiers pass.

## Inputs

- `Sources/src/ResourceModel/exporter.h`
- `Sources/src/ResourceModel/comparator.cpp`
- `Sources/src/ResourceModel/items/weapon/weapon.h`
- `Sources/src/ResourceModel/items/mine/mine.h`
- `Sources/src/ResourceModel/items/trench/trench.h`
- `Sources/src/ResourceModel/items/squad/squad.h`
- `Sources/src/editor/WeaponFrm.cpp`
- `Sources/src/editor/MineFrm.cpp`
- `Sources/src/editor/TrenchFrm.cpp`
- `Sources/src/editor/SquadFrm.cpp`
- `tools/zig/fixtures/resource_editor/wpn/project.wpn`
- `tools/zig/fixtures/resource_editor/mcp/project.mcp`
- `tools/zig/fixtures/resource_editor/trc/project.trc`
- `tools/zig/fixtures/resource_editor/scp/project.scp`

## Expected Output

- `Sources/src/ResourceModel/items/weapon/weapon_export.cpp`
- `Sources/src/ResourceModel/items/mine/mine_export.cpp`
- `Sources/src/ResourceModel/items/trench/trench_export.cpp`
- `Sources/src/ResourceModel/items/squad/squad_export.cpp`
- `Sources/src/ResourceModel/exporter.h`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `build.zig`

## Verification

zig build test-resource-model-comparator -Dtest-mode=run && zig build test-resource-model-fidelity -Dtest-mode=run && zig build test-resource-bridge -Dtest-mode=run

## Observability Impact

SExportOutcome.szError names the missing prop, unresolved squad member or unwritable path. Warnings mirror MFC's output-pane messages.
