---
estimated_steps: 10
estimated_files: 6
skills_used: []
---

# T04: Undoable sub-editor tools in resource_core with fake-bridge and real-bridge tests

Why: every tool must be undoable, with set+get before and after state (slice demo; B-03.2..4, B-04.1, B-13.1).

Do (TDD, red-green per tool), in Sources/editor/resource_core:
- Squad formation drag: a geometry command on GeometryChannel.formation_positions. A whole drag collapses to one composite/geometry step.
- Squad zero point: GeometryChannel.zero_point on the formation node.
- Squad direction arrow: find in SquadFrm.cpp (ID_SHOW_DIRECTION_BUTTON and the formation props) where direction is stored. If it is a prop, it is a set_prop command; if it is a view toggle only, it is UI state and not undoable, and the parity row records that.
- Weapon: insert/delete/edit of shoot type, damage, sound, effect, flash and crater nodes via insert_node/delete_node/set_prop, using the ETIT_WEAPON_* class types from Sources/src/ResourceModel/items/weapon/weapon.h.
- Trench: add and remove a source.
Add small helper constructors (e.g. sub_editor_tools.zig) that build these commands from document state, so the app (T05) only calls them. Extend fake_bridge.zig where a channel is not served yet.
Tests: test-resource-core with the fake bridge, and the same sequences against the real bridge in test-resource-bridge on the fixture projects. Each test does get-before, apply, get-after, undo == before, redo == after, then save and reload == after. Negative: a geometry set on a node with no MFC home is BK_EDITOR_REFUSED and leaves the history unchanged.

Done when: both tiers pass with one named test per tool.

## Inputs

- `Sources/editor/resource_core/history.zig`
- `Sources/editor/resource_core/document.zig`
- `Sources/editor/resource_core/bridge.zig`
- `Sources/editor/resource_core/fake_bridge.zig`
- `Sources/src/EditorBridge/resource_bridge.h`
- `Sources/src/ResourceModel/items/squad/squad.h`
- `Sources/src/ResourceModel/items/weapon/weapon.h`
- `Sources/src/ResourceModel/items/trench/trench.h`
- `Sources/src/editor/SquadFrm.cpp`

## Expected Output

- `Sources/editor/resource_core/sub_editor_tools.zig`
- `Sources/editor/resource_core/root.zig`
- `Sources/editor/resource_core/fake_bridge.zig`
- `tools/zig/editor_bridge_test.cpp`

## Verification

zig build test-resource-core -Dtest-mode=run && zig build test-resource-bridge -Dtest-mode=run

## Observability Impact

Each failure in the tool tests prints the channel/node and the before/after values.
