# S06 Research: Weapon, Mine, Trench, Squad sub-editors

Depth: targeted. The infrastructure exists (S03 model, S04 bridge/core, S05 app). S06 adds the first real exporters and the first sub-editor-specific tools. Most of the risk is in what does not exist yet.

## Key findings

1. **No exporter is registered in production.** `NResourceModel::RegisterExporter` (`Sources/src/ResourceModel/exporter.{h,cpp}`) is only called from `resource_bridge_test.cpp` with test doubles on `mdc`. `BkResExport` answers `BK_EDITOR_REFUSED` for every real kind. S06 writes the first four: `wpn`, `mcp`, `trc`, `scp`. Signature: `bool (*)(const Project&, const SExportContext&, SExportOutcome&)`. Write only below `context.szStagingRoot`; the bridge does the all-or-nothing promotion. `bStatsOnly` (D-13) must skip graphics.
2. **All four `golden/` folders hold only `README.md` and `.gitkeep`.** Goldens are made on win-home only (`tools/zig/win-home/export-goldens.ps1 -Extensions wpn,mcp,trc,scp`). `test-resource-model` reports `GOLDEN <ext> pending`. The slice goal "committed golden parity" cannot be met on this machine. Plan it as: write the exporter and the comparator wiring now, record the goldens as pending for the maintainer on win-home, and do not count them done. Until then, check with the comparator against the engine readers (round trip: import shipped sample, export, compare stats field-equal) and with hand-derived expectations.
3. **No portable image pipeline exists for export.** MFC used `CParentFrame::ConvertAndSaveImage` (LoadImage, `SaveCompressedTexture`) and `ComposeSingleObject` (`BuildCompose.cpp`). Only `dxt_gate.*` (NDxt decode/encode) and the `spike/legacy_dxt.*` tolerance code are in ResourceModel. The `_h.dds` / DDS parity needs a TGA to DDS converter on NDxt plus a port of the compose step. Check `dxt-tolerance.json` and `dxt_gate.h` for the intended entry points before inventing new ones.
4. **Preview kinds.** `kPreviewKinds` in `Sources/src/EditorBridge/resource_bridge.cpp` (~line 3538) has only spt, unt, msh, pcp, eff. A comment there already says trench and squad join with their slices. Weapon and mine have no visual in MFC beyond the squad/trench scenes; mine builds a `ComposeSingleObject` sprite (`1.tga`, `1s.tga` to `1`). The preview shot for wpn is likely the effect or flash preview, so decide in planning what is captured. Add entries only where `IVisObjBuilder` has a real type.
5. **Model items exist** (`items/{weapon,mine,trench,squad}/*.cpp|h`, 1220 lines, versus 1726 lines of MFC tree items). S03 already round-trips them. Squad's formation geometry, zero point and direction arrow need to be undoable commands in `resource_core`. Check `resource_core/document.zig` and `history.zig` for the existing geometry command (S04 "geometry persists for every node and survives delete->undo") and reuse it.
6. **Data/Editor/TestProjects/07_Weapon, 12_Trench, 13_Squad, 14_Mine hold only a `README.md`** (manifest.json at the parent). Real samples for the import round trip are therefore the shipped runtime stats in `Data/` (check with `BkResImportFromGame`, bridge line ~4046) and the repo fixtures in `tools/zig/fixtures/resource_editor/{wpn,mcp,trc,scp}`. There is no GOG dependency in this slice.

## MFC export behaviour to port (authoritative: `Sources/src/editor/*Frm.cpp`)

- **Weapon** (`WeaponFrm.cpp:64,171`): `ExportFrameData` only calls `SaveRPGStats`. It fills `SWeaponRPGStats` from the common props, then one `SShell` per shoot-type child (trajectory, piercing, damage, area, speed, rate of fire, trace and track-break values, craters list, track-damage special bit 0, effect names and fire sound, two flash effects). It writes `tree.Add("RPG", &stats)`. When `bNewProjectJustCreated` it round-trips through `GetRPGStats` instead of filling. No graphics.
- **Mine** (`MineFrm.cpp:79,110`): `SaveRPGStats` (`szFlagModel = "1"`, `szWeapon`, weight), then `ComposeSingleObject( dir/1.tga, dir/1s.tga, resultDir/1, VNULL2 )`. `FindMinimalExportFileTime` checks only the result file.
- **Trench** (`TrenchFrm.cpp:457`): stats, then for 4 trench indices times each source item: copy the file named by the item to the result folder (basename only). For the first item only, `ConvertAndSaveImage` of `1.tga`, `1w.tga` and `1a.tga` from the source folder to `1`, `1w` and `1a` in the result folder. Up-to-date checks use the max source time (`FindMaximalSourceTime`) and min export time.
- **Squad** (`SquadFrm.cpp:216,300`): `SaveRPGStats` needs `IObjectsDB`: it enumerates all sprite and unit descs into a `SUnitsGDBStats` list, so the port's exporter needs the game's objects DB or a mounted data dir to resolve the squad members. Then it copies the squad icon picture (`GetSquadPicture`; a backslash path is used as is, otherwise relative to the project) to the result folder by basename. Confirm what `szIcon` is written as.
- The MFC frames all write the stats XML through the engine's own `CTreeAccessor` and `IDataTree`; the comparator (`comparator.cpp`, `EExportKind::WEAPON/SQUAD/MINE`...) reads them back with `GetAddStats<...>` and fails on unknown fields. Check the comparator table also has a trench entry, since the grep showed WEAPON, SQUAD, MINE at the top and trench was not seen in that excerpt.

## Natural seams for the planner

1. **Export plumbing and stats exporters** (`Sources/src/ResourceModel/items/*/` or a new `exporters/` dir): wpn, mcp, trc, scp stats XML via the engine's `CTreeAccessor`; register at module init; test through the existing `test-resource-model` and `test-resource-bridge` (replace the test-only `mdc` reliance, add real kinds). Do this first; it unblocks Export, Run Blitzkrieg and the auto scenario for four kinds.
2. **Image conversion**: TGA to DDS (`_h.dds`, `1`, `1w`, `1a`) through NDxt with the tolerance from `dxt-tolerance.json`, plus `ComposeSingleObject` for mine. This is the highest risk and the biggest unknown; spike it second, before committing to tasks for the rest.
3. **Core commands and tests** in `Sources/editor/resource_core`: squad formation drag, zero point, direction arrow; weapon shoot/damage/sound/effect/flash/crater tree insert/delete/edit; trench source add/remove. Each needs set+get before and after state undo/redo tests with the fake bridge.
4. **App UI**: toolbar entries and the formation overlay in `Sources/editor/resource_app` (`panels.zig`, `docks.zig`, `edit_logic.zig`, with the headless `*_logic.zig` tier `test-resource-app-logic`).
5. **Preview**: new `kPreviewKinds` entries (trench, squad, mine as applicable) with a measured captured frame, built on the S04 `BkResPreview*` pattern and the particle-source precedent.
6. **Auto scenario**: extend `Sources/editor/resource_app/scenario.zig` (actions: new, open, set_prop, undo, save, pack, import, run_game) with one scenario per kind or one covering the four.

## Verification (run in the foreground, one tier at a time)

`zig build test-resource-model -Dtest-mode=run`, `test-resource-bridge`, `test-resource-core`, `test-resource-app-logic`, `resource-editor-host-check`, `-smoke`, `-auto`; `test-editor-core` plus the Map Editor tiers if shared kit code is touched. Note from S05: GUI tiers fail with `SdlInitFailed: No available video device` under the gsd_exec sandbox, so run them from the real shell. The full sweep (`tools/zig/run-resource-sweep.sh`, ~27 min) is left to the maintainer. macOS and Windows results come from CI only.

## Constraints and watch-outs

- CRLF for all new text files; tests use only tracked data copied under `zig-out/local-test/`, never `Data/` writes or the user's profile.
- Update `06-PARITY.md` rows for the weapon, mine, trench and squad items. Mark them `done` only with evidence; golden parity stays "pending win-home".
- A5/S05 limitations: View toggles, background colour and expand/collapse all are not implemented yet; do not assume them.
- Do not claim goldens, macOS or Windows results that were not seen.
- Skills: none to install. Relevant installed skills: tdd (red-green per command), decompose-into-slices.

## Recommendation

Start with the exporters for stats (seam 1), then spike the image path (seam 2) since it decides whether DDS parity is attainable on Linux before win-home goldens exist. Treat golden parity as pending for the maintainer, and keep everything else (undo tests, preview shot, auto scenario) verifiable locally.
