---
id: T05
parent: S06
milestone: M001
key_files: []
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-05T12:59:02.437Z
blocker_discovered: false
---

# T05: Squad formation overlay (drag, zero point, direction arrow) and weapon/trench tree actions wired into the Resource Editor with headless tested logic; trench, squad and mine previews measured by captured frames.

**Squad formation overlay (drag, zero point, direction arrow) and weapon/trench tree actions wired into the Resource Editor with headless tested logic; trench, squad and mine previews measured by captured frames.**

## What Happened

Added Sources/editor/resource_app/squad_logic.zig: the overlay's View (world/screen), hitSlot, arrowAngle, the Overlay press/move/release/cancel state machine for the three SquadFrm modes (each gesture ends in one sub_editor_tools command through commit), and TreeAction/treeActionsFor/runTreeAction for weapon shoot types, craters and trench sources. panels.zig draws a Formation window (member markers, zero cross, direction arrow, mode radio buttons, Escape cancels) and adds the tree actions to the context menu; it only calls the T04 helpers. In resource_bridge.cpp the preview kinds for mcp (composed sprite 1), trc (entrenchment mesh) and scp (member sprites, built by BuildSquadMembers) are in kPreviewKinds; BkResPreviewPlayback now accepts a squad whose objects are the member sprites. resource_bridge_test.cpp has an s06-preview group that measures a captured frame for mine, trench and squad against the empty frame (the squad imports the shipped german_rifle_45 folder). Weapon has no preview (D015). A first attempt that duplicated the captures in the T11 group was reverted.

## Verification

Ran the task's Verify chain in the foreground: test-resource-app-logic, test-resource-bridge, install-resource-editor, resource-editor-host-check and resource-editor-smoke all passed on Linux x64 (Debug). Preview captures logged: mine 24.9% non-black, 0.073% changed vs empty; trench 25.9%, 1.10%; squad 25.4%, 0.60%, TGAs under zig-out/local-test/resource_editor/t02/s06-preview/. Not verified by hand: the Formation window's look and mouse feel in the live app; the overlay's gestures are covered by the logic tests only. No macOS or Windows result was seen. Full sweep left to the maintainer.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-app-logic -Dtest-mode=run && zig build test-resource-bridge -Dtest-mode=run && zig build install-resource-editor && zig build resource-editor-host-check && zig build resource-editor-smoke` | 0 | pass | 42000ms |

## Deviations

None.

## Known Issues

None.

## Files Created/Modified

None.
