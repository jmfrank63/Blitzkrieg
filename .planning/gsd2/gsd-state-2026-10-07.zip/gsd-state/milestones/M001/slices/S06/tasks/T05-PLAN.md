---
estimated_steps: 6
estimated_files: 8
skills_used: []
---

# T05: App wiring: squad formation overlay and toolbar, weapon/trench tree tools, preview kinds for trc/scp/mcp

Why: the tools need UI entries and the slice needs measured preview shots (D015).

Do:
1. In Sources/editor/resource_app, add toolbar entries per kind. For squad: a formation view overlay (member markers, drag to move, set zero point, direction arrow toggle), with hit-testing and drag-to-command logic in a headless *_logic.zig covered by test-resource-app-logic. The ImGui drawing goes in panels.zig/docks.zig. For weapon and trench: tree context actions that insert/delete the T04 node types. Only call the T04 helpers; do not build commands in UI code.
2. In Sources/src/EditorBridge/resource_bridge.cpp kPreviewKinds, add entries for trench (SGVOT_MESH, the entrenchment model as TrenchFrm.cpp:238 builds it), squad (member sprites, SquadFrm.cpp:344-364) and mine (the exported composed sprite "1"). Use the kind numbers the bridge already assigns to trc/scp/mcp. Weapon gets no entry (D015).
3. Add captured-frame checks in test-resource-bridge that measure lit pixels / differ from the empty background, using the existing particle-source preview test as the template.

Done when: test-resource-app-logic covers the overlay logic, test-resource-bridge passes the three new preview captures, and resource-editor-host-check and -smoke pass.

## Inputs

- `Sources/editor/resource_core/sub_editor_tools.zig`
- `Sources/editor/resource_app/panels.zig`
- `Sources/editor/resource_app/docks.zig`
- `Sources/editor/resource_app/edit_logic.zig`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/editor/TrenchFrm.cpp`
- `Sources/src/editor/SquadFrm.cpp`

## Expected Output

- `Sources/editor/resource_app/squad_logic.zig`
- `Sources/editor/resource_app/panels.zig`
- `Sources/editor/resource_app/docks.zig`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `tools/zig/editor_bridge_test.cpp`
- `build.zig`

## Verification

zig build test-resource-app-logic -Dtest-mode=run && zig build test-resource-bridge -Dtest-mode=run && zig build install-resource-editor && zig build resource-editor-host-check && zig build resource-editor-smoke

## Observability Impact

Each preview capture prints the measured lit percentage and the TGA path under zig-out/local-test.
