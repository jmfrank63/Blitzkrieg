---
id: T03
parent: S06
milestone: M001
key_files:
  - Sources/src/EditorBridge/resource_bridge_test.cpp
  - Sources/src/EditorBridge/resource_bridge.cpp
  - Sources/src/ResourceModel/comparator.cpp
key_decisions:
  - Trench import takes the folder name as key name when the stats have none
  - MFC-unreadable fields (trench segments and derived lists, squad Pos/Dir float noise) are excused in kRoundTripLosses with reasons
duration: 
verification_result: passed
completed_at: 2026-10-05T12:49:42.139Z
blocker_discovered: false
---

# T03: Four import-then-export round trips (wpn mg_37t, mcp mine_at, trc Entrenchment, scp german_rifle_45) of shipped samples pass in test-resource-bridge, compared field-equal through the engine readers, with MFC's own losses listed in the comparator's kRoundTripLosses.

**Four import-then-export round trips (wpn mg_37t, mcp mine_at, trc Entrenchment, scp german_rifle_45) of shipped samples pass in test-resource-bridge, compared field-equal through the engine readers, with MFC's own losses listed in the comparator's kRoundTripLosses.**

## What Happened

Added RoundTrips to resource_bridge_test.cpp: each shipped sample is copied under zig-out/local-test, imported with BkResImportFromGame into a new project of its kind, saved, exported stats-only, and compared with the shipped file via CompareRoundTrip (engine readers started by StartEngineReaders). Two fixes were needed to get all four green. (1) Trench import: a shipped trench's stats carry no key name, so the import now falls back to the folder name (as squad does); before, it failed with 'holds no trc RPG stats'. (2) Comparator kRoundTripLosses now holds measured, reasoned MFC limits: trench Segments/Lines/FirePlaces/Terminators/Arcs (CTrenchFrame::LoadRPGStats never read segments back, the rest derive from them, including their #count paths) and squad formation Order Pos/Dir (float rebuild from the zero point, a few 1e-5 to 1e-6). Each excused field prints as EXCUSED with its reason; anything else fails with its field path. Wpn and mcp are EQUAL with no excuses. Nothing writes into Data/.

## Verification

zig build test-resource-bridge -Dtest-mode=run exits 0 and prints four ROUNDTRIP lines, all EQUAL (wpn 47 fields, mcp 42, trc 160 with excused segment-derived fields, scp 218 with excused Pos/Dir float noise). zig build test-resource-model-comparator -Dtest-mode=run exits 0, VERDICT=PASS (goldens pending, left to win-home). Full resource sweep left to the maintainer.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 25000ms |
| 2 | `zig build test-resource-model-comparator -Dtest-mode=run` | 0 | pass | 30000ms |

## Deviations

The plan named editor_bridge_test.cpp; the round trips live in resource_bridge_test.cpp, the test-resource-bridge tier's source. Also changed resource_bridge.cpp (trench key-name fallback) and comparator.cpp (loss table).

## Known Issues

None.

## Files Created/Modified

- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/ResourceModel/comparator.cpp`
