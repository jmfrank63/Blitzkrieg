---
estimated_steps: 3
estimated_files: 3
skills_used: []
---

# T06: BK_EDITOR_AUTO scenarios for the four kinds, parity rows, tier run

Why: the slice demo requires one BK_EDITOR_AUTO scenario per kind and parity evidence.

Do: extend Sources/editor/resource_app/scenario.zig and the resource-editor-auto schedule in build.zig (~line 8204-8210). Add any S06 actions it lacks (e.g. a squad formation drag, a weapon node insert); unknown actions must still fail loudly. Per kind: open the fixture copy, do the kind's tool, undo, redo, save, export (expect success), and shot+differ for trc/scp/mcp. Then update .planning/phases/06-resource-editor-portable-port/06-PARITY.md rows B-03.1-6, B-04.1-3, B-05.1-3 and B-13.1-4 with evidence (test names). Golden parity is noted as "pending win-home (export-goldens.ps1 -Extensions wpn,mcp,trc,scp)". The weapon preview is "no behaviour in MFC" (D015). Run each tier in the foreground, one at a time, from the real shell: test-resource-model-comparator, -fidelity, test-resource-bridge, test-resource-core, test-resource-app-logic, install-resource-editor, resource-editor-host-check, -smoke, -auto, test-editor-core, map-editor-smoke. Record "full sweep left to the maintainer" and do not claim macOS/Windows.

Done when: resource-editor-auto passes with the S06 scenarios and the parity rows are updated.

## Inputs

- `Sources/editor/resource_app/scenario.zig`
- `Sources/editor/resource_app/squad_logic.zig`
- `Sources/editor/resource_core/sub_editor_tools.zig`
- `build.zig`
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`

## Expected Output

- `Sources/editor/resource_app/scenario.zig`
- `build.zig`
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`

## Verification

zig build resource-editor-auto && zig build resource-editor-smoke && zig build test-resource-app-logic -Dtest-mode=run && zig build test-editor-core -Dtest-mode=run && zig build map-editor-smoke

## Observability Impact

A scenario failure prints the frame number, the action and the reason. Shots are kept under zig-out/local-test for inspection.
