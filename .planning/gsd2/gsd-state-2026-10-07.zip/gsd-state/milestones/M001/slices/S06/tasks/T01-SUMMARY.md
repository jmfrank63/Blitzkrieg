---
id: T01
parent: S06
milestone: M001
key_files:
  - Sources/src/ResourceModel/exporter.h
  - Sources/src/ResourceModel/exporter.cpp
  - Sources/src/ResourceModel/items/stats_export.h
  - Sources/src/ResourceModel/items/stats_export.cpp
  - Sources/src/ResourceModel/items/weapon/weapon_export.cpp
  - Sources/src/ResourceModel/items/mine/mine_export.cpp
  - Sources/src/ResourceModel/items/trench/trench_export.cpp
  - Sources/src/ResourceModel/items/squad/squad_export.cpp
  - Sources/src/EditorBridge/resource_bridge.cpp
  - Sources/src/EditorBridge/resource_bridge_test.cpp
  - tools/zig/resource_model_comparator_test.cpp
  - build.zig
  - docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md
key_decisions:
  - Exporters are compiled into the EditorBridge archive and seeded in exporter.cpp's table (no static self-registration)
  - SExportContext gains std::function hooks findUnitKey (IObjectsDB) and meshFirePlaces (IVisObjBuilder), filled by the bridge; a missing hook fails the export naming the member or model
  - Exporters work on a re-loaded copy with CreateDefaultChilds so MFC's values[i] and GetChildItem(type,n) indexing applies
  - Output path: own_data export_file_name under szAddDir, else weapons\<folder>.xml or <addDir><folder>\1.xml
  - Squad zero shift (15.4,15.4) px maps to world (32.67,-10.89) under yaw 45 and pitch -120 in an orthographic 1:1 projection, verified against the engine view matrix
duration: 
verification_result: passed
completed_at: 2026-10-05T12:25:24.196Z
blocker_discovered: false
---

# T01: Production stats exporters for wpn, mcp, trc and scp port MFC's SaveRPGStats through the engine's CTreeAccessor. FindExporter now returns them and BkResExport writes them through staging.

**Production stats exporters for wpn, mcp, trc and scp port MFC's SaveRPGStats through the engine's CTreeAccessor. FindExporter now returns them and BkResExport writes them through staging.**

## What Happened

Added Sources/src/ResourceModel/items/stats_export.{h,cpp}, a shared helper. It makes a prepared copy of the project (re-load, then CreateDefaultChilds, as MFC's batch did) and converts values the way MFC's CVariant does. It also picks the output path (own_data/export_file_name below the kind's szAddDir, else the folder name) and writes through engine storage plus CreateDataTreeSaver(WRITE).

Four exporters port SaveRPGStats line for line:
- weapon_export.cpp: WeaponFrm FillRPGStats, one SShell per shoot type, trace probability /100, track-damage bit 0, effects, two flashes. Output goes to weapons\<folder>.xml.
- mine_export.cpp: szKeyName and szWeapon from the Weapon prop, szFlagModel "1", weight. Output goes to objects\simpleobjects\common\summer\mine\<folder>\1.xml, and szObjectName names "1".
- trench_export.cpp: name, HP, defences by item name and cover. Segment sources come from the 4 folders with MFC's index assignment; a missing source is MFC's "Cannot copy file" warning and is skipped. AABB is read from chunk 4 of the .mod via CreateStructureSaver, fire places come from the new SExportContext::meshFirePlaces hook, and indices are sorted and gap-filled.
- squad_export.cpp: szIcon is GetSquadPicture, plus type and members. MakeName goes through the new SExportContext::findUnitKey hook (D015). Formations follow MFC: units are paired with members in order, the zero point is shifted by zeroShift (15.4, 15.4) px converted to world with the squad frame camera, and fDir goes through ToDegree.

exporter.cpp seeds its table with the four exporters, because a static initialiser in an unreferenced archive member would be dropped by the linker.

The bridge has a new FillEngineLookups, used by ExportOne and the preview:
- findUnitKey reads IObjectsDB descs (sprite unit, path compared case-folded).
- meshFirePlaces copies the .mod to a scratch folder, mounts it as a storage layer and builds it with IVisObjBuilder SGVOT_MESH. It reads locators via IMeshAnimationEdit and matrices with the object at the origin, as TrenchFrm did.

Tests:
- The comparator tier now exports each fixture via FindExporter and reads the result back with ReadExport (0 unknown, 0 stale). It checks CompareStats EQUAL against hand-derived structs written by the engine: wpn 47, mcp 42, trc 28 and scp 20 fields. It also covers stats-only giving identical bytes, an own_data path, the trc missing-source warning, failure without a mesh reader, a segment from the shipped 5.mod, scp failing without or with an unknown lookup (errors name the member), mdc still unregistered, and the zero-shift sign checked against the engine's CreateViewMatrixRH.
- The bridge tier: the fixture loop now expects OK for the 4 kinds and reads each file with the engine, including the squad member resolved through the real IObjectsDB to USSR_Mosin. Batch now has mdc and wpn exported and unt skipped.
- A new S06Export bridge case rebuilds the shipped entrenchment from its 8 shipped .mod files and exports it through BkResExport with the real mesh builder. All 8 segments match the shipped Data 1.xml: lists, types, coverage, AABB and fire places, to the shipped file's 6 digits.

The spec amendment is recorded in docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md. GOLDEN lines still say pending.

## Verification

All three plan tiers pass on Linux x64.
- comparator: VERDICT=PASS (goldens pending), GOLDEN_SUMMARY pass=0 pending=20.
- fidelity: 505 PASS, 0 FAIL.
- bridge: "Project+Tree OK", no FAIL, including the shipped-trench comparison.

`zig build install-resource-editor install-map-editor` also links cleanly. TDD note: the tests were written alongside the exporters rather than strictly first. Before this task, the bridge fixture loop asserted that every kind was refused, so the new expectations were red until the exporters were registered. Goldens remain pending for win-home. macOS and Windows were not run.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-model-comparator -Dtest-mode=run` | 0 | pass | 19397ms |
| 2 | `zig build test-resource-model-fidelity -Dtest-mode=run` | 0 | pass | 1012ms |
| 3 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 25834ms |
| 4 | `zig build install-resource-editor install-map-editor` | 0 | pass | 0ms |

## Deviations

- The exporter .cpp files went into the EditorBridge archive source list in build.zig, not into resource_model_sources. That list builds the engine-free model tests, and the exporters need engine headers and StreamIO.
- Bridge tests were added to Sources/src/EditorBridge/resource_bridge_test.cpp, which is what test-resource-bridge builds, not tools/zig/editor_bridge_test.cpp.
- The trench needed a second context hook, meshFirePlaces (fire places come from IVisObjBuilder mesh locators), alongside findUnitKey.
- MFC's <History> node is not written; the comparator ignores it.
- The bNewProjectJustCreated defaults path is not ported, because the bridge exports saved projects only.
- Graphics (mine compose, trench copies and DDS, squad icon copy) are left to T02. The exporters write stats only in both modes for now.

## Known Issues

- Squad zero-point shift: the port uses the closed-form transform of the projection's linear part. MFC went through the scene matrices with an anchor translation, so the last float bits may differ from a golden; this is pending win-home.
- Trench locator matching uses strcmp where MFC compared pointers.
- With no source root, the default output folder is the project's folder name.

## Files Created/Modified

- `Sources/src/ResourceModel/exporter.h`
- `Sources/src/ResourceModel/exporter.cpp`
- `Sources/src/ResourceModel/items/stats_export.h`
- `Sources/src/ResourceModel/items/stats_export.cpp`
- `Sources/src/ResourceModel/items/weapon/weapon_export.cpp`
- `Sources/src/ResourceModel/items/mine/mine_export.cpp`
- `Sources/src/ResourceModel/items/trench/trench_export.cpp`
- `Sources/src/ResourceModel/items/squad/squad_export.cpp`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `tools/zig/resource_model_comparator_test.cpp`
- `build.zig`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`
