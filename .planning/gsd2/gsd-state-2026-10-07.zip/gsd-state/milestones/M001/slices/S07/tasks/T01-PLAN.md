---
estimated_steps: 7
estimated_files: 1
skills_used: []
---

# T01: Squad formation direction in MFC's convention: pure logic and tests

Why: S06 review item 1 (D016). squad_logic.zig arrowAngle returns atan2(dy, dx) and the overlay draws (cos a, sin a). MFC's CSquadFrame::UpdateFormationDirection (Sources/src/editor/SquadFrm.cpp:577) draws fFormationDir = a along world (-sin a, +cos a), and MFC's screen Y runs opposite to world Y (IScene GetPos2/GetPos3). An angle set in the port is stored about 90 degrees off, so the game faces the squad the wrong way.

Do:
1. In Sources/editor/resource_app/squad_logic.zig make View.toWorld/toScreen map Y the way MFC does (screen Y down is world Y down the screen, i.e. opposite), if they do not already; check every caller (hitSlot, the drag and zero-point gestures) still gets the same world points it should.
2. arrowAngle(centre, cursor) in world coordinates returns MFC's a = atan2(-dx, dy). Add arrowDirection(a) returning world (-sin a, +cos a), the one place the vector is defined, with a doc comment citing SquadFrm.cpp:577.
3. Pure-logic tests in the squad_logic test block (test-resource-app-logic): the four axis directions (cursor straight up, down, left and right of the centre in world terms) give the angle MFC's formula gives and arrowDirection(arrowAngle(..)) points back at the cursor; a screen-space drag goes through toWorld first and gives the same angle.

Do not change the trench DDS gamma: MFC's SaveCompressedTexture applies CreateGammaCorrection, so the port already matches (rejected review item).

Done when: test-resource-app-logic is green with the new cases.

## Inputs

- `Sources/editor/resource_app/squad_logic.zig`
- `Sources/src/editor/SquadFrm.cpp`

## Expected Output

- `Sources/editor/resource_app/squad_logic.zig`

## Verification

zig build test-resource-app-logic -Dtest-mode=run

## Observability Impact

Each axis case prints the expected and actual angle and vector on failure.
