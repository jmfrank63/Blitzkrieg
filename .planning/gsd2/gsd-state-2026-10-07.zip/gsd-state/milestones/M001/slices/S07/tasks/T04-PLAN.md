---
estimated_steps: 8
estimated_files: 4
skills_used: []
---

# T04: Commit the S06 preview captures as evidence

Why: S06 review item 2 (D016). S06 T05's summary describes mine, trench and squad preview captures, but they exist only under zig-out/local-test/resource_editor/t02/s06-preview/, which the test deletes and recreates. Do not claim committed evidence that is not in git.

Do:
1. Run test-resource-bridge in the foreground from the real shell (it needs a GPU device; the gsd_exec sandbox has none) so the s06-preview group writes fresh mine, trench and squad TGAs and logs their shares.
2. Copy those TGAs into tools/zig/fixtures/resource_editor/preview-scene/ under clear names (mine.tga, trench.tga, squad.tga), the way S04 committed mesh, sprite, particle and effect (see git log of that folder). Keep the files CRLF-exempt as the existing TGAs are (check .gitattributes).
3. Update preview-scene.md with a row per capture: source fixture, the non-black share and changed-vs-empty share as logged in this run, and the test that produces it.
4. If a capture cannot be produced on this machine, correct .gsd/milestones/M001/slices/S06/tasks/T05-SUMMARY.md instead, naming the zig-out path and saying the captures are not committed.

The summary cites only this task's run and the committed files.

Done when: the TGAs and preview-scene.md are in the working tree for the auto-commit (or the S06 summary is corrected) and test-resource-bridge is green.

## Inputs

- `tools/zig/fixtures/resource_editor/preview-scene/preview-scene.md`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `.gsd/milestones/M001/slices/S06/tasks/T05-SUMMARY.md`

## Expected Output

- `tools/zig/fixtures/resource_editor/preview-scene/preview-scene.md`
- `tools/zig/fixtures/resource_editor/preview-scene/mine.tga`
- `tools/zig/fixtures/resource_editor/preview-scene/trench.tga`
- `tools/zig/fixtures/resource_editor/preview-scene/squad.tga`

## Verification

zig build test-resource-bridge -Dtest-mode=run

## Observability Impact

preview-scene.md records the measured shares next to each committed capture.
