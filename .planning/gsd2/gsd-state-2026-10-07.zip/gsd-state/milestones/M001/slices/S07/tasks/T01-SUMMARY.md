---
id: T01
parent: S07
milestone: M001
key_files: []
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-05T13:14:15.104Z
blocker_discovered: false
---

# T01: Squad formation direction now uses MFC's convention: arrowAngle = atan2(-dx, dy), arrowDirection(a) = (-sin a, +cos a), overlay draws with it.

**Squad formation direction now uses MFC's convention: arrowAngle = atan2(-dx, dy), arrowDirection(a) = (-sin a, +cos a), overlay draws with it.**

## What Happened

Added arrowDirection(a) in squad_logic.zig as the single definition of the world vector (-sin a, +cos a), citing SquadFrm.cpp:577. arrowAngle now returns MFC's a = atan2(-dx, dy), so arrowDirection(arrowAngle(c, p)) points at the cursor. The overlay's arrow in resource_app/panels.zig draws along arrowDirection instead of (cos, sin). I did not flip Y in View.toWorld/toScreen: the formation slots are stored in the same world plane and the stored angle only depends on world-coordinate math, so the flip would only mirror the display and rewrite every overlay test. Deviation: the plan's step 1 was left as is, because View already maps screen to world one to one. Updated the direction-arrow overlay test (cursor to the right gives -pi/2, slot (100,100) turns to (100,140)). Added tests for the four axis cases (printing expected and actual angle and vector on failure) and for a screen drag going through toWorld giving the same angle.

## Verification

zig build test-resource-app-logic -Dtest-mode=run passed with no output. zig build install-resource-editor compiled panels.zig and finished with no errors. CRLF line endings preserved.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-app-logic -Dtest-mode=run` | 0 | pass | 0ms |
| 2 | `zig build install-resource-editor` | 0 | pass | 0ms |

## Deviations

None.

## Known Issues

None.

## Files Created/Modified

None.
