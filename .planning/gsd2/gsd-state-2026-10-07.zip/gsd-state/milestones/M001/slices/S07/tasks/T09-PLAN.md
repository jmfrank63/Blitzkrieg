---
estimated_steps: 8
estimated_files: 8
skills_used: []
---

# T09: Frame tools undoable in resource_core and app wiring for preview playback

Why: B-02.2/B-02.3/B-07.1/B-07.2. Frame insert from the thumbnail list, delete, and Run/Stop must be undoable or wired, and c_bridge.zig previewPlayback is still a placeholder (line 655, `_ = &RealResBridge.previewPlayback`) outside the ResBridge vtable.

Do:
1. Add to Sources/editor/resource_core/sub_editor_tools.zig: spriteAddFrame(doc, sprites_node, picture_name), which appends a CSpritePropsItem named after the picture, MFC's thumbnail double-click; infantryAddFrame(doc, animation_node, picture_name) for the CUnitFramePropsItem; deleteFrame; and setters for frame position and time, sprite dir, animation props and season dirs, through setPropByName. Use the ETIT_* class ids from Sources/src/ResourceModel/items/tree_item_types.h, and respect the static-element rules of the unt tree (directories, animations, actions, exposures and acks cannot be deleted). Check the bridge's insert rules for the unit frame item.
2. Tests: in resource_core with fake_bridge.zig (do, undo and redo with get-before and get-after state for every tool above), and in resource_bridge_test.cpp against the real bridge on the spt and unt fixtures.
3. Add previewPlayback to the ResBridge vtable (resource_core bridge interface), RealResBridge (c_bridge.zig, remove the placeholder) and fake_bridge.zig. docks.zig Run and Stop call it through the vtable.
4. Thumbnail list (docks.zig/docks_logic.zig): double-click on a picture runs spriteAddFrame or infantryAddFrame and commits through history. Delete removes the selected frame.
5. Update Sources/editor/resource_app/docks_check.zig: Run on an unsaved import with no art should now report the exporter's "no valid animations" reason instead of "not ported". Add a check that Run on the saved spt fixture shows the preview.

Done when: test-resource-core, test-resource-bridge and test-resource-app-logic are green, install-resource-editor builds and resource-editor-host-check passes (run from the real shell, not the gsd_exec sandbox: SDL needs a video device).

## Inputs

- `Sources/editor/resource_core/sub_editor_tools.zig`
- `Sources/editor/resource_core/fake_bridge.zig`
- `Sources/editor/resource_core/root.zig`
- `Sources/editor/resource_app/c_bridge.zig`
- `Sources/editor/resource_app/docks.zig`
- `Sources/editor/resource_app/docks_logic.zig`
- `Sources/editor/resource_app/docks_check.zig`
- `Sources/src/ResourceModel/items/tree_item_types.h`
- `Sources/src/ResourceModel/items/sprite/sprite.h`
- `Sources/src/ResourceModel/items/infantry/infantry.h`

## Expected Output

- `Sources/editor/resource_core/sub_editor_tools.zig`
- `Sources/editor/resource_core/fake_bridge.zig`
- `Sources/editor/resource_core/root.zig`
- `Sources/editor/resource_app/c_bridge.zig`
- `Sources/editor/resource_app/docks.zig`
- `Sources/editor/resource_app/docks_logic.zig`
- `Sources/editor/resource_app/docks_check.zig`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`

## Verification

zig build test-resource-core -Dtest-mode=run && zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-app-logic -Dtest-mode=run && zig build install-resource-editor && zig build resource-editor-host-check
