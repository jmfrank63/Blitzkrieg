---
estimated_steps: 6
estimated_files: 4
skills_used: []
---

# T08: Real golden comparison and the .unt round trips

Why: the golden check in tools/zig/resource_model_comparator_test.cpp Goldens() and resource_bridge_test.cpp (about 1775-1814) only counts files and logs pending; it never compares. B-02.7/B-02.8 need the Data/Old and WinSniper round trips and a shipped import.

Do:
1. Replace Goldens() with a real comparison for every extension that has an exporter (wpn, mcp, trc, scp, spt, unt). Export the fixture with the port into zig-out/local-test, then compare each golden file: stats via CompareStats with the kind's EExportKind; .san and _h.dds via CompareBytes; _c.dds via CompareDxt with the tolerance gate; _l.dds via the comparator's uncompressed-DDS compare. Print GOLDEN <ext> pass, GOLDEN <ext> FAIL <file>: <reason>, or GOLDEN <ext> pending: golden missing. Print GOLDEN_SUMMARY with real counts. A FAIL fails the tier. Pending does not. Make the bridge test's duplicate golden report consistent, or point it at the comparator.
2. Negative test: copy the port's own spt export into a stand-in golden folder under zig-out/local-test, flip one byte of 1.san, and require the comparison to report FAIL for 1.san. Do the same for one stats field of the unt 1.xml.
3. Round trips in resource_bridge_test.cpp: for all 14 Data/Old/**/*.unt plus Data/Editor/TestProjects/02_InfantryAnimation/WinSniper.unt, each copied under zig-out/local-test: open, export, read 1.xml through ReadRPGStats SInfantryRPGStats, and require no .san plus a warning (no source TGAs ship). Then import one shipped Data/Units/Humans unit with BkResImportFromGame unt, export it stats-only, and CompareStats(INFANTRY) against the shipped 1.xml. Tolerate only the fields MFC's FillRPGStats writes as constants (fRotateSpeed, nPriority, nUninstallRotate, nUninstallTransport, animdescs nAABB_A/nAABB_D), as an explicit list in the test, and mention it in a comment.

Done when: both tiers are green. The comparator log shows real GOLDEN lines (pending for every kind on this machine), the negative tests fail as required, and the 15-file loop passes.

## Inputs

- `tools/zig/resource_model_comparator_test.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `Sources/src/ResourceModel/comparator.h`
- `Sources/src/ResourceModel/comparator.cpp`
- `Sources/src/ResourceModel/items/infantry/infantry_export.cpp`
- `Sources/src/ResourceModel/items/sprite/sprite_export.cpp`
- `Data/Editor/TestProjects/02_InfantryAnimation/WinSniper.unt`
- `Data/Old/officer.unt`

## Expected Output

- `tools/zig/resource_model_comparator_test.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `Sources/src/ResourceModel/comparator.h`
- `Sources/src/ResourceModel/comparator.cpp`

## Verification

zig build test-resource-model-comparator -Dtest-mode=run && zig build test-resource-bridge -Dtest-mode=run

## Observability Impact

GOLDEN lines become pass/FAIL/pending with the failing file and reason, and GOLDEN_SUMMARY reports real counts.
