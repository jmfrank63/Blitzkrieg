---
id: T06
parent: S07
milestone: M001
key_files:
  - Sources/src/ResourceModel/items/sprite/sprite_export.cpp
  - Sources/src/ResourceModel/items/stats_export.h
  - Sources/src/ResourceModel/exporter.cpp
  - Sources/src/EditorBridge/resource_bridge_test.cpp
  - build.zig
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-05T13:38:16.784Z
blocker_discovered: false
---

# T06: Added the registered "spt" sprite exporter (ExportSprite: 1.san plus 1_c/1_l/1_h DDS) with tests for export, stats-only, missing frames, no frames, up-to-date skip, and measured preview Run/Stop.

**Added the registered "spt" sprite exporter (ExportSprite: 1.san plus 1_c/1_l/1_h DDS) with tests for export, stats-only, missing frames, no frames, up-to-date skip, and measured preview Run/Stop.**

## What Happened

The earlier session's tool calls belonged to T05; the tree was clean and sprite_export.cpp did not exist, so T06 was done from the top. Added Sources/src/ResourceModel/items/sprite/sprite_export.cpp, a line-for-line port of CSpriteFrame::ExportFrameData and CSpriteTreeRootItem::ComposeAnimations: one SAnimationDesc "effect", one dir, frame k -> dir.frames[k]=k, frame time from slot 1, shift from slots 2/3, directory from slot 0 resolved with a port of MFC's MakeFullPath (so "_." joins the frame name literally), files found case-insensitively. Output goes to the StatsFileName folder (effects\sprites\) as 1.san and 1_c/1_l(ARGB4444)/1_h.dds, with gamma from ReadGammaConfig. Missing frames warn naming the file and fall back to <data root>/editor/invalid.tga when present, otherwise the frame is left out (recorded as a warning). No frames or all frames missing: warning "no valid animations", nWritten 0, returns true. Stats-only writes nothing and warns. The non-forced up-to-date check ports FindMaximalSourceTime/FindMinimalExportFileTime including MFC's 1.tga comparison and counts nSkipped. szObjectName is <dir>1. Registered "spt" in exporter.cpp, declared in stats_export.h, added to build.zig. The preview needed no change (spt was already in the data-driven preview-kind table). Tests: new S07Sprite namespace in resource_bridge_test.cpp; T11's stand-in exporter now restores the previous registration instead of erasing it; the all-kinds export check has an spt branch.

## Verification

zig build test-resource-bridge -Dtest-mode=run passes (resource-bridge: Project+Tree OK) including the new sprite cases; zig build test-resource-model-comparator -Dtest-mode=run gives VERDICT=PASS (goldens pending). Preview measured: drew-vs-empty=0.007191, Run frames 140 ms apart differ (0.007191), Stop frames 200 ms apart equal (0.000000).

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 300000ms |
| 2 | `zig build test-resource-model-comparator -Dtest-mode=run` | 0 | pass (goldens pending) | 60000ms |

## Deviations

The fixture project's default directory "_." resolves, as in MFC, to "<project folder>\_.sprite-1frame.tga", which does not exist, so the fixture export composes nothing; the sprite tests use a generated frames\ folder instead. The up-to-date skip never triggers on a clean export folder, because MFC compared against a 1.tga it never wrote; the test plants a 1.tga.

## Known Issues

When the export has no data folder (preview) or it lacks editor\invalid.tga, a missing frame is left out rather than replaced; this should be recorded in PARITY. The golden comparison for spt stays pending until win-home goldens exist. Full resource sweep left to the maintainer.

## Files Created/Modified

- `Sources/src/ResourceModel/items/sprite/sprite_export.cpp`
- `Sources/src/ResourceModel/items/stats_export.h`
- `Sources/src/ResourceModel/exporter.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `build.zig`
