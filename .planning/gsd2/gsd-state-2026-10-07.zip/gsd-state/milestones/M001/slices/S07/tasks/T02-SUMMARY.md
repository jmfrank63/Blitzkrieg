---
id: T02
parent: S07
milestone: M001
key_files: []
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-05T13:15:10.699Z
blocker_discovered: false
---

# T02: Added a per-member test proving formation slot rotation equals MFC's CalculateNewPositions (0 to pi/2 and an arbitrary angle, with undo/redo and save/reopen); the rotation code already matched.

**Added a per-member test proving formation slot rotation equals MFC's CalculateNewPositions (0 to pi/2 and an arbitrary angle, with undo/redo and save/reopen); the rotation code already matched.**

## What Happened

Checked setFormationDirection and turnSlots in sub_editor_tools.zig against CSquadFrame::CalculateNewPositions (SquadFrm.cpp:603): x' = cx + (x-cx)cos d - (y-cy)sin d, y' = cy + (x-cx)sin d + (y-cy)cos d with d = new - previous FormationDir, in world coordinates, and the formation direction stored as the angle itself. The existing code already does exactly this, so no production change was needed. Added test "squad direction rotation equals MFC CalculateNewPositions": a three-member formation, direction reset to 0, then set to pi/2 and to 1.234. Each member is compared against an independent inline MFC formula (not turnSlots), and a failure prints the member index, the angle and the expected and actual positions. Each step goes through Harness.runTool, which also checks undo restores the old state, redo reapplies it, and save/reopen keeps it. Checked the Formation window arrow release in squad_logic.zig: it calls setFormationDirection with centre null, which reads the stored zero point as pivot, so dragging the arrow rotates slots about the zero point as MFC does. The file was kept CRLF.

## Verification

zig build test-resource-core -Dtest-mode=run and zig build test-resource-app-logic -Dtest-mode=run both exited 0 with no output.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-core -Dtest-mode=run` | 0 | pass | 0ms |
| 2 | `zig build test-resource-app-logic -Dtest-mode=run` | 0 | pass | 0ms |

## Deviations

None.

## Known Issues

None.

## Files Created/Modified

None.
