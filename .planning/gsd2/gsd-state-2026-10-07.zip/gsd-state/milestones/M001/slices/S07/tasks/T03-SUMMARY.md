---
id: T03
parent: S07
milestone: M001
key_files: []
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-05T13:18:08.026Z
blocker_discovered: false
---

# T03: The squad overlay now draws the arrow tip as MFC's world vector through the view, and the auto tier gained a squad_arrow gesture action plus an expect=squad_dir check with undo coverage.

**The squad overlay now draws the arrow tip as MFC's world vector through the view, and the auto tier gained a squad_arrow gesture action plus an expect=squad_dir check with undo coverage.**

## What Happened

panels.zig draws the tip as view.toScreen(zero + arrowDirection(a) * 40/scale) instead of a screen-space (cos, sin) offset. scenario.zig gained do=squad_arrow:<x>/<y>, which runs the Overlay direction gesture (press, move, release) so it goes through arrowAngle and setFormationDirection. It also gained expect=squad_dir:<radians>, which reads fFormationDir back through the bridge and compares within 1e-4, printing expected and stored angle on failure. Both are documented in the //! action list. build.zig's resource-editor-auto schedule now has frames 113-120: arrow straight up the world Y axis expects 0, arrow on the +X side expects -pi/2, then undo steps return to 0 and 1.0. Later frames were renumbered (the schedule now ends at 132).

## Verification

Ran the whole Verify chain in the foreground; every step exited 0 and resource-editor-auto printed PASS (118 actions over 133 frames).

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-app-logic -Dtest-mode=run && zig build install-resource-editor && zig build resource-editor-host-check && zig build resource-editor-smoke && zig build resource-editor-auto` | 0 | ✅ pass | 0ms |

## Deviations

None.

## Known Issues

None.

## Files Created/Modified

None.
