---
estimated_steps: 6
estimated_files: 3
skills_used: []
---

# T03: Overlay draws MFC's direction and an auto step drags the arrow

Why: S06 review item 1 (D016). panels.zig (around line 426) draws the arrow tip as centre + (cos a, sin a) * 40 in screen space, so even a correctly stored angle is drawn wrong.

Do:
1. In Sources/editor/resource_app/panels.zig draw the tip as view.toScreen(zero + arrowDirection(a) * length), using T01's helpers, so the drawn arrow is MFC's world vector mapped with MFC's Y direction.
2. Add a scenario action to Sources/editor/resource_app/scenario.zig, do=squad_arrow:<x>/<y>, that runs the Overlay arrow gesture (press on the arrow, move to the world point, release) so it goes through arrowAngle and setFormationDirection, plus expect=squad_dir:<radians> that reads fFormationDir back through the bridge and compares within 1e-4. Document both in the scenario's //! action list next to squad_dir.
3. In build.zig's resource-editor-auto schedule, after the existing squad_dir frame (111), add frames: squad_arrow to a point straight up the world Y axis from the zero point, expect=squad_dir:0; squad_arrow to a point on the world +X side, expect the angle MFC's formula gives (-pi/2); undo, expect the previous angle. Keep later frame numbers consistent.

Done when: the auto tier exits 0 with the new frames, the smoke and host-check are green.

## Inputs

- `Sources/editor/resource_app/panels.zig`
- `Sources/editor/resource_app/scenario.zig`
- `Sources/editor/resource_app/squad_logic.zig`
- `build.zig`

## Expected Output

- `Sources/editor/resource_app/panels.zig`
- `Sources/editor/resource_app/scenario.zig`
- `build.zig`

## Verification

zig build test-resource-app-logic -Dtest-mode=run && zig build install-resource-editor && zig build resource-editor-host-check && zig build resource-editor-smoke && zig build resource-editor-auto

## Observability Impact

expect=squad_dir failures print the frame, the expected and the stored angle.
