---
id: S07
parent: M001
milestone: M001
provides:
  - (none)
requires:
  []
affects:
  []
key_files: []
key_decisions: []
patterns_established:
  - (none)
observability_surfaces:
  - none
drill_down_paths:
  []
duration: ""
verification_result: passed
completed_at: 2026-10-05T14:21:14.693Z
blocker_discovered: false
---

# S07: S07

**Sprite (spt) and Infantry (unt) sub-editors: portable exporters, real per-file golden comparison, undoable frame tools, Run/Stop playback and BK_EDITOR_AUTO scenarios; Ack I/O marked "no behaviour in MFC".**

## What Happened

T01-T03 fixed the squad formation direction to MFC's convention (arrowAngle = atan2(-dx, dy), arrowDirection = (-sin a, +cos a)), proved formation slot rotation matches CalculateNewPositions with undo/redo and save/reopen, and added squad_arrow/squad_dir auto actions. T04 committed measured mine, trench and squad preview TGAs. T05 added the portable compose library (BuildAnimations/GetActionFromName), a generalised SaveCompressedTexture and a .san writer that reproduces a shipped Mp43 1.san byte for byte. T06 added the registered "spt" exporter (1.san plus 1_c/1_l/1_h DDS) and T07 the registered "unt" infantry exporter (1.xml via FillRPGStats, 3 seasons x 2 blood passes to .san plus DDS, localisation copies). T08 replaced the counting golden check with a real per-file comparison (stats via CompareStats, .san and _h.dds byte-equal, _c/_l DDS within tolerance) with negative tests, plus a 15-file .unt round-trip loop and a shipped-human import comparison. T09 added undoable sprite/infantry frame tools (add, delete, setters) and wired previewPlayback through the ResBridge vtable to the Run/Stop docks. T10 added spt and unt BK_EDITOR_AUTO blocks and updated the PARITY rows; 06-PARITY.md B-02.4 (Ack Import/Export) is marked "no behaviour in MFC" with the reason (only always-enabled UPDATE_COMMAND_UI handlers, no caller).

## Verification

Re-run now on Linux x64 debug: test-resource-core, test-resource-app-logic, test-resource-model-comparator and test-resource-bridge exit 0 (the only FAIL lines are the two expected negative-test PASS lines). resource-editor-host-check, -smoke and -auto exit 0 with SDL_VIDEODRIVER=offscreen (auto PASS, 173 actions over 188 frames); without it the closeout shell has no display and they fail with "No available video device". Golden comparison reports pass=0 fail=0 pending=20 because win-home MFC goldens do not exist yet. Full resource sweep left to the maintainer. macOS and Windows not verified here.

## Requirements Advanced

None.

## Requirements Validated

None.

## New Requirements Surfaced

None.

## Requirements Invalidated or Re-scoped

None.

## Operational Readiness

None.

## Deviations

None.

## Known Limitations

MFC goldens for spt/unt are pending on win-home (20 pending). Ack Import/Export not implemented (no MFC behaviour). Do not run the three resource-editor UI tiers in one parallel zig build invocation; they race on zig-out.

## Follow-ups

None.

## Files Created/Modified

None.
