---
id: T09
parent: S07
milestone: M001
key_files: []
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-05T14:10:53.606Z
blocker_discovered: false
---

# T09: Added undoable sprite/infantry frame tools (add, delete, setters) in resource_core and wired previewPlayback through the ResBridge vtable to the Run/Stop docks and thumbnail double-click.

**Added undoable sprite/infantry frame tools (add, delete, setters) in resource_core and wired previewPlayback through the ResBridge vtable to the Run/Stop docks and thumbnail double-click.**

## What Happened

sub_editor_tools.zig gained spriteAddFrame, infantryAddFrame, deleteFrame and property setters, all going through history so do/undo/redo are covered with fake_bridge tests plus refusal cases (static unt elements, bad node, empty picture name). resource_bridge_test.cpp checks the same against the real bridge on the spt and unt fixtures. previewPlayback is now a ResBridge vtable entry implemented in RealResBridge (placeholder removed) and fake_bridge; docks.zig Run/Stop call it through the vtable, and thumbnail double-click commits an add-frame through history. docks_check.zig now expects the exporter's reason for Run on an unsaved import and checks the saved spt preview draws pixels.

## Verification

Ran test-resource-core, test-resource-bridge, test-resource-app-logic, install-resource-editor and resource-editor-host-check; all exit 0. Host check reports docks PASS and the .spt preview drew 225 pixels.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-core -Dtest-mode=run` | 0 | pass | 1000ms |
| 2 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 29000ms |
| 3 | `zig build test-resource-app-logic -Dtest-mode=run` | 0 | pass | 1000ms |
| 4 | `zig build install-resource-editor` | 0 | pass | 4000ms |
| 5 | `zig build resource-editor-host-check` | 0 | pass | 6000ms |

## Deviations

None.

## Known Issues

None.

## Files Created/Modified

None.
