---
estimated_steps: 6
estimated_files: 3
skills_used: []
---

# T10: BK_EDITOR_AUTO spt and unt scenarios, parity rows, tier run

Why: the slice demo requires a BK_EDITOR_AUTO scenario per kind with Run/Stop preview shots, plus parity evidence.

Do:
1. Add these actions to Sources/editor/resource_app/scenario.zig: preview_run and preview_stop (through the docks and the vtable previewPlayback); frame:<picture>, which uses spriteAddFrame or infantryAddFrame on the first animation/sprites node; and delete_frame. Extend the schedule in build.zig resource-editor-auto with a spt block: open the fixture copy, frame:<picture>, export with expect=exported, preview_run, then shot a and shot b with differ a/b, preview_stop, then shot c and shot d with no differ (equal), shot_lit, undo, redo. Add a unt block: open the regenerated fixture copy, set a season dir prop, export, preview_run with shot_lit, preview_stop, undo, redo. Keep the earlier S05 and S06 frames and T03's squad_arrow frames working; append after the last existing frame or renumber consistently.
2. Update .planning/phases/06-resource-editor-portable-port/06-PARITY.md: B-02.1..8 and B-07.1..4 get their test names and auto actions. B-02.4 is "no behaviour in MFC": IDR_ACK_MENU items ID_IMPORT_ACK_FILE and ID_EXPORT_ACK_FILE have only always-Enable ON_UPDATE_COMMAND_UI handlers in AnimationFrm.cpp and MeshFrm.cpp, DisplayAcksMenu has no caller, and CUnitAckTypesItem and CUnitAckTypePropsItem are empty. The Ack set references are already pickers. B-07.4 is "no behaviour in MFC (no reverse path for sprites)". Golden rows say "pending win-home: export-goldens.ps1 -Extensions spt,unt". Also record the squad direction row's new evidence (T01-T03 tests and the squad_arrow auto step).
3. Run the tiers one at a time from the real shell (GUI tiers fail in the gsd_exec sandbox with SdlInitFailed): install-game, install-resource-editor, install-map-editor, resource-editor-host-check, resource-editor-smoke, resource-editor-auto, map-editor-smoke, test-editor-core, test-resource-app-logic. The full sweep is left to the maintainer; record that and list the tiers that were run.

Done when: resource-editor-auto exits 0 with the spt and unt blocks, the smoke tiers are green, and the PARITY rows are updated.

## Inputs

- `Sources/editor/resource_app/scenario.zig`
- `build.zig`
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`
- `Sources/editor/resource_core/sub_editor_tools.zig`
- `Sources/editor/resource_app/docks.zig`
- `tools/zig/fixtures/resource_editor/spt/project.spt`
- `tools/zig/fixtures/resource_editor/unt/project.unt`

## Expected Output

- `Sources/editor/resource_app/scenario.zig`
- `build.zig`
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`

## Verification

zig build install-resource-editor && zig build resource-editor-auto && zig build resource-editor-smoke && zig build test-resource-app-logic -Dtest-mode=run && zig build test-editor-core -Dtest-mode=run && zig build map-editor-smoke

## Observability Impact

Auto-scenario failures name the frame and the action; the differ and shot_lit checks print measured percentages.
