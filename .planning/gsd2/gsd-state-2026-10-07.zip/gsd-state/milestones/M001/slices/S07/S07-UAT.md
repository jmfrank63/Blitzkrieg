# S07: S07 — UAT

**Milestone:** M001
**Written:** 2026-10-05T14:21:14.694Z

# S07 UAT

**UAT Type:** automated tiers plus optional hand try

## Preconditions
- Linux x64, `zig build install-resource-editor` done, display or `SDL_VIDEODRIVER=offscreen`.

## Steps
1. `zig build test-resource-core test-resource-app-logic -Dtest-mode=run` - expect exit 0.
2. `zig build test-resource-model-comparator -Dtest-mode=run` - expect VERDICT=PASS, GOLDEN_SUMMARY fail=0, both golden negative tests PASS.
3. `zig build test-resource-bridge -Dtest-mode=run` - expect exit 0; sprite and infantry export, 15-file .unt loop, preview Run frames differ and Stop frames equal.
4. Run `resource-editor-host-check`, `resource-editor-smoke`, `resource-editor-auto` one at a time (not in parallel) - expect auto PASS including the spt and unt blocks.
5. Hand try: open the spt and unt fixtures, add and delete a frame, undo/redo, press Run then Stop in the preview.

## Edge cases
- Missing or empty frames produce export warnings, not crashes; static unt elements refuse frame edits.

## Not Proven By This UAT
- Byte-identical goldens against MFC output (pending win-home goldens), macOS and Windows runs, full resource sweep.
