---
estimated_steps: 6
estimated_files: 7
skills_used: []
---

# T06: Sprite exporter, preview kind and tests

Why: B-07.2/B-07.3. Without an exporter the sprite cannot be exported or previewed (ShowPreview needs outcome.szObjectName).

Do:
1. Add Sources/src/ResourceModel/items/sprite/sprite_export.cpp with ExportSprite, declared in items/stats_export.h next to the S06 exporters and listed in the exporter.cpp table as "spt". Port CSpriteFrame::ExportFrameData and CSpriteTreeRootItem::ComposeAnimations (Sources/src/editor/SpriteFrm.cpp, SpriteTreeItem.cpp about 40-130). Use one SAnimationDesc and one SDirDesc. The dir is CSpritesItem slot 0 ("_." default, relative to the project folder). Frame k maps to dirDesc.frames[k]=k and animDesc.frames[k]=(slot 2, slot 3); the frame time is slot 1. The file is <dir><frame name>.tga. A missing file falls back to editor invalid.tga, with a warning naming it (find where S06 or the bridge locates editor data, else warn and skip the frame, and record that in PARITY). No frames gives the warning "no valid animations" with nWritten 0 and returns true, as MFC's ExportFrameData does. Output goes to StatsFileName's folder (szAddDir "effects\\sprites\\") as 1.san plus SaveCompressedTexture(low ARGB4444). Gamma comes from NImageExport::ReadGammaConfig. bStatsOnly writes nothing and warns. A non-forced export skips when the files in context.szDataRoot are newer than every source and the project (port SpriteFrm's FindMaximalSourceTime and FindMinimalExportFileTime) and counts nSkipped. Fill outcome.szObjectName with the 1 stem.
2. Make the preview accept spt in resource_bridge.cpp: remove the not-ported refusal for spt only if it is not already data-driven by FindExporter.
3. Tests in resource_bridge_test.cpp, with the fixture tools/zig/fixtures/resource_editor/spt copied to zig-out/local-test: export file set, .san re-read (1 anim, frame count, positions), stats-only, missing frame, no frames, up-to-date skip, and forced re-export. Preview: Run captures two frames that differ, Stop captures two that are equal. Use a multi-frame copy of the fixture made in the test (add frame items through BkResInsertNode and write extra TGAs), skipping with "no GPU device" as the existing preview tests do. Also update the comparator test's "FindExporter(mdc) still null" check if needed.

Done when: test-resource-bridge passes with the new sprite cases and the preview cases measured.

## Inputs

- `Sources/src/editor/SpriteFrm.cpp`
- `Sources/src/editor/SpriteTreeItem.cpp`
- `Sources/src/ResourceModel/items/sprite/sprite.h`
- `Sources/src/ResourceModel/compose.h`
- `Sources/src/ResourceModel/image_export.h`
- `Sources/src/ResourceModel/items/stats_export.h`
- `Sources/src/ResourceModel/exporter.cpp`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `tools/zig/fixtures/resource_editor/spt/project.spt`
- `tools/zig/fixtures/resource_editor/spt/sprite-1frame.tga`

## Expected Output

- `Sources/src/ResourceModel/items/sprite/sprite_export.cpp`
- `Sources/src/ResourceModel/items/stats_export.h`
- `Sources/src/ResourceModel/exporter.cpp`
- `Sources/src/ResourceModel/exporter.h`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `build.zig`

## Verification

zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model-comparator -Dtest-mode=run
