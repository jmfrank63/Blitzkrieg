---
estimated_steps: 6
estimated_files: 9
skills_used: []
---

# T07: Infantry exporter, fixture art and tests

Why: B-02.5/B-02.6. Infantry is the larger port: stats, compose for 3 seasons x 2 blood passes, and localisation copies.

Do:
1. Add Sources/src/ResourceModel/items/infantry/infantry_export.cpp with ExportInfantry, declared in stats_export.h and listed in the exporter.cpp table as "unt". Port AnimationFrm.cpp ExportFrameData (line 570) and FillRPGStats (282-388) verbatim, including acks resized to 2, the fixed zeros (fRotateSpeed, nPriority, nUninstallRotate, nUninstallTransport), the generic weapon and grenade defaults (an empty or "_" grenade collapses to one gun), animtimes sized children+1 with the //CRAP +1, the fRunSpeed and fCrawlSpeed early break, and animdescs with nAABB_A and nAABB_D = -1. Write it with WriteStats as tree.Add("RPG",&stats) to StatsFileName(szAddDir "units\\humans\\"). Unless bStatsOnly is set, port CAnimationTreeRootItem::ComposeAnimations (AnimTreeItem.cpp 649-856): blood 0..1 x each season in CDirectoriesItem; 4-dir projects use GetDirName(i*2); a relative dir resolves against the project; vCommonFrameSize is half the first valid frame (default 32,32), once per blood pass; Death and "Death down" take <project>/blood/<dir> on blood pass 1 when blood/ exists; a missing frame falls back to invalid.tga with a warning, and nCurrentFrame is incremented only for valid files (keep the MFC quirk). Outputs are 1[b][w|a].san and DDS with low ARGB1555. A compose failure is a warning and the export still succeeds, as in MFC. Then copy the CLocalizationItem sources to name.txt, desc.txt and stats.txt with NImageExport::CopyFileInto; a missing source is a warning. Resolve frame paths case-insensitively (the Summer\\Up\\ style on Linux). szObjectName is the 1 stem.
2. Fixture: extend tools/zig/resource_editor_fixtures.zig so unt gets tiny generated TGA frames under Summer/<dir>/ and Winter/<dir>/, a blood/ variant for Death, one deliberately missing frame, frame child items naming them, and localisation text files. Regenerate with zig build make-resource-fixtures and commit the regenerated tools/zig/fixtures/resource_editor/unt/* and EXTENSIONS.md together. Fix every hash or size expectation this changes; the S03 fidelity and roundtrip tests must stay green.
3. Tests: comparator test (stats) exports the fixture and reads 1.xml back field-equal through comparator INFANTRY against hand-derived expectations. Bridge test (graphics) checks the expected san and DDS set, frame counts per animation that prove the missing-frame quirk, the blood substitution, stats-only (no .san), missing localisation (warning), and the up-to-date skip.

Done when: test-resource-model (full), test-resource-model-comparator, test-resource-bridge and test-resource-editor-fixtures are green.

## Inputs

- `Sources/src/editor/AnimationFrm.cpp`
- `Sources/src/editor/AnimTreeItem.cpp`
- `Sources/src/ResourceModel/items/infantry/infantry.h`
- `Sources/src/ResourceModel/compose.h`
- `Sources/src/ResourceModel/image_export.h`
- `Sources/src/ResourceModel/items/stats_export.h`
- `Sources/src/ResourceModel/comparator.h`
- `tools/zig/resource_editor_fixtures.zig`
- `tools/zig/fixtures/resource_editor/unt/project.unt`

## Expected Output

- `Sources/src/ResourceModel/items/infantry/infantry_export.cpp`
- `Sources/src/ResourceModel/items/stats_export.h`
- `Sources/src/ResourceModel/exporter.cpp`
- `tools/zig/resource_editor_fixtures.zig`
- `tools/zig/fixtures/resource_editor/unt/project.unt`
- `tools/zig/fixtures/resource_editor/EXTENSIONS.md`
- `tools/zig/resource_model_comparator_test.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `build.zig`

## Verification

zig build make-resource-fixtures && zig build test-resource-editor-fixtures && zig build test-resource-model -Dtest-mode=run && zig build test-resource-model-comparator -Dtest-mode=run && zig build test-resource-bridge -Dtest-mode=run

## Observability Impact

Warnings list each missing frame and localisation source, and the "no valid animations" compose result, as MFC's output pane did.
