---
estimated_steps: 6
estimated_files: 3
skills_used: []
---

# T02: Formation slot rotation equals MFC's CalculateNewPositions

Why: S06 review item 1 (D016). When the direction changes, MFC rotates every member about the zero point by the angle delta (CSquadFrame::CalculateNewPositions, SquadFrm.cpp:603, called from WM_ANGLE_CHANGED at line 429 with fFormationDir - fPrev): x' = cx + (x-cx)cos d - (y-cy)sin d, y' = cy + (x-cx)sin d + (y-cy)cos d, and each sprite's direction becomes SumAngle(fFormationDir, fDir). The port's rotation must use the same convention.

Do:
1. In Sources/editor/resource_core/sub_editor_tools.zig setFormationDirection (line ~283), make the slot rotation (when centre is given) exactly MFC's formula with d = new - previous fFormationDir, in world coordinates, and leave fFormationDir stored as MFC's a. If the per-member fDir is stored relative to the formation, keep it relative as MFC does.
2. Tests in test-resource-core with fake_bridge.zig: one formation of three members, set the direction from 0 to pi/2 and to an arbitrary angle, and require each member position equal MFC's formula (within float epsilon); undo restores the old positions and angle; redo reapplies.
3. Check the Formation window's arrow drag (squad_logic Overlay release) passes the zero point as centre so dragging the arrow rotates slots like MFC.

Done when: test-resource-core and test-resource-app-logic are green.

## Inputs

- `Sources/editor/resource_core/sub_editor_tools.zig`
- `Sources/editor/resource_core/fake_bridge.zig`
- `Sources/src/editor/SquadFrm.cpp`

## Expected Output

- `Sources/editor/resource_core/sub_editor_tools.zig`

## Verification

zig build test-resource-core -Dtest-mode=run && zig build test-resource-app-logic -Dtest-mode=run

## Observability Impact

The rotation test prints each member's expected and actual position on failure.
