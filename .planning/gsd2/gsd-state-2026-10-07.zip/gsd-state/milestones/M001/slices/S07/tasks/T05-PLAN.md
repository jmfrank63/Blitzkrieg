---
estimated_steps: 7
estimated_files: 6
skills_used: []
---

# T05: Portable BuildAnimations compose library and .san writer proof

Why: sprite and infantry exports both rest on SpriteCompose.cpp BuildAnimations (lines 104-~255) and GetActionFromName (line 386). That code includes MFC (StdAfx, ParentFrame, AfxMessageBox), and S06 ported only a one-frame shortcut (BuildSingleFrame in Sources/src/ResourceModel/image_export.cpp). This is the highest-risk step of the sprite and infantry work, so prove it first.

Do:
1. Add Sources/src/ResourceModel/compose.{h,cpp} (CRLF, built into the EditorBridge archive next to image_export.cpp in build.zig, addResourceBridge plus the bridge test module). Include SAnimationDesc and SDirDesc as in Sources/src/editor (grep their definition), BuildAnimations( std::vector<SAnimationDesc>*, SSpriteAnimationFormat*, file names, bool ) and GetActionFromName. Copy them line for line, minus MFC: message boxes become outcome warnings and errors, and paths use the slashed std::filesystem form already in image_export.cpp. Keep the computation order and float expressions identical, because .san bytes must match MFC.
2. Generalise NImageExport: add SaveCompressedTexture( context, IImage*, szName, gamma, EGFXPixelFormat lowFormat, outcome ) to image_export.h. Keep ARGB1555 as the default so mine and trench are unchanged. Also expose SaveAnimation (the CreateStructureSaver + saver.Add(1,&fmt) writer) and LoadPicture through the header so compose callers reuse them.
3. Tests in Sources/src/EditorBridge/resource_bridge_test.cpp (the hosted engine; follow the existing image export tests S06 added): (a) compose 3 tiny generated TGAs written under zig-out/local-test into 1 animation and 1 dir, re-read the .san with the engine's structure loader, and check animation index from GetActionFromName, frame list, rect count and fDepth; (b) two animations ("Idle", "Death") with 2 dirs and the expected indices; (c) compose twice and check byte-identical .san and .dds; (d) _c.dds decoded through NDxt within tools/zig/fixtures/resource_editor/dxt-tolerance.json (reuse dxt_gate.h); (e) writer identity: pick a shipped Data/Units/Humans/**/1.san with the case-insensitive DataFile-style resolver, load SSpriteAnimationFormat via CreateStructureSaver READ, re-save to a scratch file, and require identical bytes.
4. Do not change mine, trench or squad behaviour. test-resource-bridge's existing mine, trench and squad export checks must stay green.

Done when: the compose tests and the writer-identity test pass in test-resource-bridge and the comparator tier is still green.

## Inputs

- `Sources/src/editor/SpriteCompose.cpp`
- `Sources/src/ResourceModel/image_export.h`
- `Sources/src/ResourceModel/image_export.cpp`
- `Sources/src/ResourceModel/dxt_gate.h`
- `Sources/src/Formats/fmtAnimation.h`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `tools/zig/fixtures/resource_editor/dxt-tolerance.json`
- `build.zig`

## Expected Output

- `Sources/src/ResourceModel/compose.h`
- `Sources/src/ResourceModel/compose.cpp`
- `Sources/src/ResourceModel/image_export.h`
- `Sources/src/ResourceModel/image_export.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `build.zig`

## Verification

zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model-comparator -Dtest-mode=run

## Observability Impact

Compose failures name the frame file and the reason in SExportOutcome.szError and warnings; the writer-identity test prints the shipped file it used.
