---
id: T07
parent: S07
milestone: M001
key_files: []
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-05T13:55:42.984Z
blocker_discovered: false
---

# T07: Added the registered "unt" infantry exporter (FillRPGStats to 1.xml, 3 seasons x 2 blood passes to 1[b][w|a].san plus DDS, localisation copies) with comparator and bridge tests.

**Added the registered "unt" infantry exporter (FillRPGStats to 1.xml, 3 seasons x 2 blood passes to 1[b][w|a].san plus DDS, localisation copies) with comparator and bridge tests.**

## What Happened

Ported CAnimationFrame::FillRPGStats/ExportFrameData and CAnimationTreeRootItem::ComposeAnimations into Sources/src/ResourceModel/items/infantry/infantry_export.cpp (ExportInfantry, registered as "unt" in exporter.cpp, declared in stats_export.h, listed in build.zig). The frame-path helpers the sprite exporter had (case-folded lookup, MakeFullPath, IsRelatedPath, invalid.tga, change time) moved into stats_export.cpp/.h so both exporters share them. The compose keeps MFC's nCurrentFrame quirk (only valid files advance it), the blood\ substitution for Death and Death down, the half-first-frame common size per blood pass, and treats a compose failure as a warning while the stats are still written. Missing frames, missing localisation sources and "no valid animations" go into outcome warnings. Tests: the comparator test exports the fixture and compares 1.xml field-equal against hand-derived expectations (including the //CRAP +1 animtimes, Idle's one frame item, and an empty grenade collapsing to one gun) plus stats-only equality and the "no valid animations" warning. The bridge test S07Infantry builds three season folders of generated TGAs plus blood/, and checks the 24 .san/.dds files plus 1.xml/name.txt/desc.txt, the stats.txt warning, the missing-frame warning, Run/Death picture counts, the blood substitution (a 15-wide rect only in 1b.san), stats-only, the up-to-date skip and a newer-frame re-export. The older bridge checks that assumed unt was unported now treat it as exported, and the batch check uses msh as its unported kind.

## Verification

make-resource-fixtures (no files changed), test-resource-editor-fixtures, test-resource-model, test-resource-model-comparator and test-resource-bridge all exit 0 on Linux x64 debug. Golden comparison stays pending (no win-home goldens exist yet). Full resource sweep left to the maintainer.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build make-resource-fixtures` | 0 | pass | 1000ms |
| 2 | `zig build test-resource-editor-fixtures -Dtest-mode=run` | 0 | pass | 310ms |
| 3 | `zig build test-resource-model -Dtest-mode=run` | 0 | pass | 20290ms |
| 4 | `zig build test-resource-model-comparator -Dtest-mode=run` | 0 | pass | 20000ms |
| 5 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 27000ms |

## Deviations

None.

## Known Issues

None.

## Files Created/Modified

None.
