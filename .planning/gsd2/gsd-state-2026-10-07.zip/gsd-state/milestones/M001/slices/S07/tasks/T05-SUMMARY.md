---
id: T05
parent: S07
milestone: M001
key_files: []
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-05T13:31:09.487Z
blocker_discovered: false
---

# T05: Added a portable BuildAnimations/GetActionFromName compose library with outcome warnings, a generalised SaveCompressedTexture, and a .san writer that reproduces a shipped Mp43 1.san byte for byte.

**Added a portable BuildAnimations/GetActionFromName compose library with outcome warnings, a generalised SaveCompressedTexture, and a .san writer that reproduces a shipped Mp43 1.san byte for byte.**

## What Happened

Added Sources/src/ResourceModel/compose.{h,cpp}: SAnimationDesc, GetActionFromName and BuildAnimations ported line for line from SpriteCompose.cpp, with MFC message boxes turned into SExportOutcome warnings/errors and slashed std::filesystem paths. compose.cpp is built into the EditorBridge archive in build.zig. image_export now exposes LoadPicture, SaveAnimation and SaveCompressedTexture with a selectable low format (ARGB1555 stays the default, so mine and trench are unchanged). New hosted-engine tests in resource_bridge_test.cpp cover (a) three generated TGAs composed to one animation/dir (indices, frames, rect size, texture-map agreement, fDepth, depth pass), (b) two animations with two dirs, (c) byte-identical .san and .dds across two composes, (d) _c.dds decoded through NDxt within the DXT5 gate, (e) writer identity against the shipped Data/Units/Humans/German/Mp43/1.san. Writer identity initially failed: the engine's Zig structure saver writes the three top chunks as 0,1,2 while MFC's saver (and every shipped .san) writes 1,0,2. SaveAnimation now reorders the top chunks after saving (MoveMainChunkFirst), which makes the re-save byte-identical. Two test expectations were also corrected: the cropped picture is 10-i wide, and the synthetic frames use flat colours so the tiny image stays inside the DXT5 gate, which was calibrated on real images, and fully transparent pixels are excluded from the colour comparison.

## Verification

zig build test-resource-bridge -Dtest-mode=run and zig build test-resource-model-comparator -Dtest-mode=run both exit 0. The comparator reports GOLDEN_SUMMARY extensions=20 pass=0 pending=20 (VERDICT=PASS, goldens pending). Mine, trench and squad export checks stay green. Not run: other Map Editor tiers, since no shared editor code changed.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 30000ms |
| 2 | `zig build test-resource-model-comparator -Dtest-mode=run` | 0 | pass (goldens pending) | 10000ms |

## Deviations

None.

## Known Issues

None.

## Files Created/Modified

None.
