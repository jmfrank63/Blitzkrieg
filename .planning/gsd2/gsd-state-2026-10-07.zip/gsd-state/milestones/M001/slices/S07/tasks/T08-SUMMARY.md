---
id: T08
parent: S07
milestone: M001
key_files: []
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-05T14:03:41.416Z
blocker_discovered: false
---

# T08: Replaced the counting golden check with a real per-file comparison (with negative tests), added the 15-file .unt round-trip loop and a shipped-human import comparison.

**Replaced the counting golden check with a real per-file comparison (with negative tests), added the 15-file .unt round-trip loop and a shipped-human import comparison.**

## What Happened

Comparator tier: Goldens() now exports each fixture with its registered exporter and compares every golden file (stats via CompareStats with the kind's EExportKind, .san and _h.dds via CompareBytes, _c.dds and _l.dds via CompareDxt). It prints GOLDEN <ext> pass, GOLDEN <ext> FAIL <file>: <reason> or GOLDEN <ext> pending, plus a GOLDEN_SUMMARY with real counts; a FAIL fails the tier. On this machine every kind is pending because no win-home goldens exist. Negative tests copy the port's own spt export into a stand-in golden folder, flip one byte of 1.san, and require exactly that file to FAIL; the same for the unt 1.xml (MaxHP 100 to 101, reported as field RPG/MaxHP). Bridge tier: the duplicate GOLDEN report now says it does not compare and points at the comparator tier. Added UntRoundTrips: all 14 Data/Old .unt plus WinSniper.unt are copied under zig-out/local-test, opened and exported; each must write a 1.xml the engine reads as SInfantryRPGStats, compose no .san and carry a warning. Added a kRoundTrips entry that imports shipped Units/Humans/German/Gunner, exports it stats-only and compares with CompareRoundTrip against the shipped 1.xml. The first run showed differences beyond the constants the plan listed (Commands bits and AnimDescs Length), so these were added to kRoundTripLosses for INFANTRY with reasons, together with the plan's constants (RotateSpeed, Priority, UninstallRotate, UninstallTransport, AnimDescs AABB_A/AABB_D). They are printed as EXCUSED and not silently ignored.

## Verification

Both tiers exit 0 with no FAIL lines. The comparator log shows GOLDEN_SUMMARY pass=0 fail=0 pending=20 and all six negative-test checks passing. In the bridge tier, the Gunner round trip reports EQUAL over 215 fields with the excused fields listed, and the loop wrote 15 1.xml files and 0 .san files under zig-out/local-test. Passing checks are not printed individually, so the 15-file result is confirmed from the output folder. Full resource sweep left to the maintainer.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-model-comparator -Dtest-mode=run` | 0 | pass | 20000ms |
| 2 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 30000ms |

## Deviations

None.

## Known Issues

None.

## Files Created/Modified

None.
