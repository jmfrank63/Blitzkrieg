# S07: Sprite, Infantry sub-editors

**Goal:** First, four small fixes from the S06 review (D016): the squad formation direction uses MFC's angle convention when it is computed, drawn and applied, and the S06 preview captures become committed evidence. Then Sprite (.spt) and Infantry (.unt) become real sub-editors. Each gets a registered exporter that ports its MFC frame line for line. Sprite: ComposeAnimations to 1.san plus 1_c (DXT5), 1_l (ARGB4444) and 1_h (ARGB8888) .dds. Infantry: FillRPGStats to 1.xml "RPG", then ComposeAnimations for 3 seasons x 2 blood passes to 1[b][w|a].san plus DDS, then copies name/desc/stats.txt. Both rest on a portable BuildAnimations. Also in scope: undoable frame tools, preview Run/Stop shots measured by code, a BK_EDITOR_AUTO scenario, round trips over every Data/Old .unt plus WinSniper.unt and a shipped human import, and a real golden comparison that runs as soon as the win-home goldens exist (reported pending until then).
**Demo:** For each: committed golden parity (.san byte-identical, DDS within tolerance, stats field-equal), import-and-export round trip (including every `.unt` in `Data/Old` + `WinSniper.unt`), undo/redo tests, preview shot showing Run/Stop playback, `BK_EDITOR_AUTO` scenario. Infantry Ack I/O either implemented (if intent clear) or 06-PARITY.md B-02.4 marked `no behaviour in MFC` with reason.

## Must-Haves

- S06 review fixes (D016), done before the sprite and infantry work: squad_logic computes the formation direction as MFC does, a = atan2(-dx, dy) in world coordinates after mapping screen to world with MFC's Y direction, and the arrow points along world (-sin a, +cos a) (CSquadFrame::UpdateFormationDirection, SquadFrm.cpp:577). Pure-logic tests cover the four axis directions against MFC's formulas. Slot rotation equals CSquadFrame::CalculateNewPositions for one formation. panels.zig draws that vector. An auto-scenario step drags the arrow to a known world point and checks the stored angle. Trench DDS gamma stays as it is (MFC applies CreateGammaCorrection).
- The S06 mine, trench and squad preview captures are committed under tools/zig/fixtures/resource_editor/preview-scene/ with their measured shares in preview-scene.md, or S06 T05's summary is corrected to name the zig-out path and say they are not committed. No summary claims committed evidence that is not in git.
- FindExporter("spt") and FindExporter("unt") return production exporters, listed in the exporter.cpp table next to the S06 ones. BkResExport no longer refuses either kind.
- A portable BuildAnimations and GetActionFromName live in Sources/src/ResourceModel/compose.{h,cpp}, ported from Sources/src/editor/SpriteCompose.cpp without MFC. Tests in test-resource-bridge cover them: tiny TGAs composed, the .san re-read through SSpriteAnimationFormat with the expected frames, rects and anim indices, export twice gives byte-identical files, and _c.dds stays within the dxt-tolerance.json gate of the source.
- Independent writer proof: a shipped Data/Units/Humans/**/1.san read with the structure loader and re-saved with CreateStructureSaver gives identical bytes.
- Sprite: export, stats-only (nothing written, warning), missing frame (invalid.tga fallback plus warning), no frames (warning, nWritten==0), and up-to-date skip (nSkipped) are all tested. B-07.4 import is marked "no behaviour in MFC (no reverse path)".
- Infantry: the fixture project exports 1.xml, which reads back field-equal through comparator INFANTRY. The fixture's tiny summer and winter TGA frames, its blood variant and one missing frame produce the expected 1/1b/1w/1bw .san+DDS set, and the MFC nCurrentFrame quirk is asserted. Missing localisation sources become warnings. Stats-only skips the graphics.
- Every .unt in Data/Old (14) plus Data/Editor/TestProjects/02_InfantryAnimation/WinSniper.unt opens and exports from a copy under zig-out/local-test. 1.xml reads through ReadRPGStats SInfantryRPGStats, and no .san is written, with a warning, because those projects ship no source TGAs. Importing a shipped Data/Units/Humans unit and exporting it compares field-equal with the shipped 1.xml, apart from an explicit list of fields MFC's FillRPGStats zeroes.
- The golden comparison in tools/zig/resource_model_comparator_test.cpp is real for every kind that has an exporter. It exports the fixture and compares with golden/: stats through CompareStats, .san and _h.dds through CompareBytes, _c.dds through CompareDxt. An empty golden/ reports "pending", never "pass". A planted one-byte difference in a stand-in golden makes the comparison fail.
- Frame tools are undoable, with set+get before and after tested in test-resource-core (fake bridge) and test-resource-bridge (real): sprite frame insert, delete, position and frame time, sprite dir; infantry frame insert and delete, animation props, season dirs.
- The preview builds spt and unt from the exporter's szObjectName. previewPlayback is in the ResBridge vtable and fake bridge. A Run shot pair differs and a Stop shot pair is equal, measured by code.
- resource-editor-auto runs spt and unt blocks: new or open, insert frame, export, preview_run and preview_stop with shot_lit and differ, undo, redo.
- 06-PARITY.md rows B-02.1..8 and B-07.1..4 carry evidence. B-02.4 Ack Import/Export is "no behaviour in MFC": IDR_ACK_MENU has only always-enable UPDATE_COMMAND_UI handlers, DisplayAcksMenu has no caller, and the Ack item classes are empty. Golden rows say "pending win-home".
- These tiers stay green on Linux: test-resource-model, test-resource-model-comparator, test-resource-bridge, test-resource-core, test-resource-app-logic, test-editor-core, resource-editor-host-check, -smoke, -auto and map-editor-smoke. Each task runs only the tiers it touches; the full sweep is left to the maintainer at slice end.

## Proof Level

- This slice proves: Integration on Linux x64: the engine's own readers (structure loader for .san, CompareStats INFANTRY for 1.xml, NDxt decode for DDS), the real bridge, and the real app under BK_EDITOR_AUTO with captured frames measured by code. The squad direction fix is proved against MFC's formulas (UpdateFormationDirection, CalculateNewPositions) in pure-logic tests and one auto-scenario step. Byte parity of .san with MFC is proved only for the writer (shipped re-save identity); composer identity with MFC stays pending the win-home goldens (export-goldens.ps1 -Extensions spt,unt), which the maintainer runs. macOS and Windows are left to CI and not claimed.

## Integration Closure

The squad direction fix stays inside squad_logic.zig, panels.zig, sub_editor_tools.setFormationDirection and the scenario; the bridge keeps storing fFormationDir in CSquadFormationPropsItem (HOME_SQUAD_DIR), now with MFC's meaning. The spt and unt exporters go into the exporter.cpp table, so BkResExport, Batch CLI, Run Blitzkrieg and the preview (kPreviewKinds already maps spt to 4 and unt to 5, SGVOT_SPRITE) pick them up with no app-shell changes. Frame tools go through resource_core sub_editor_tools (insert_node, delete_node, set_prop), so undo, save and autosave come with them. Destination paths use S06's StatsFileName (szAddDir effects\sprites\ and units\humans\), gamma uses NImageExport::ReadGammaConfig, and DDS writing uses NImageExport, generalised to take the low format: ARGB4444 for sprite, ARGB1555 for infantry, mine and trench.

## Verification

- The squad direction tests print the expected and actual angle and arrow vector per axis case; the auto step prints the stored angle on failure. The exporters put MFC's message-box texts into SExportOutcome: missing frame files in warnings (with the invalid.tga fallback), "no valid animations" as a warning for infantry (MFC ignored the compose result) and as a warning with nWritten==0 for sprite, and missing localisation sources as warnings. The golden comparison prints "GOLDEN <ext> pass|FAIL <file> <reason>|pending" and a GOLDEN_SUMMARY line with real pass, fail and pending counts. Auto-scenario failures print the frame and the action.

## Tasks

- [x] **T01: Squad formation direction in MFC's convention: pure logic and tests** `est:1h`
  Why: S06 review item 1 (D016). squad_logic.zig arrowAngle returns atan2(dy, dx) and the overlay draws (cos a, sin a). MFC's CSquadFrame::UpdateFormationDirection (Sources/src/editor/SquadFrm.cpp:577) draws fFormationDir = a along world (-sin a, +cos a), and MFC's screen Y runs opposite to world Y (IScene GetPos2/GetPos3). An angle set in the port is stored about 90 degrees off, so the game faces the squad the wrong way.
  - Files: `Sources/editor/resource_app/squad_logic.zig`
  - Verify: zig build test-resource-app-logic -Dtest-mode=run

- [x] **T02: Formation slot rotation equals MFC's CalculateNewPositions** `est:1h`
  Why: S06 review item 1 (D016). When the direction changes, MFC rotates every member about the zero point by the angle delta (CSquadFrame::CalculateNewPositions, SquadFrm.cpp:603, called from WM_ANGLE_CHANGED at line 429 with fFormationDir - fPrev): x' = cx + (x-cx)cos d - (y-cy)sin d, y' = cy + (x-cx)sin d + (y-cy)cos d, and each sprite's direction becomes SumAngle(fFormationDir, fDir). The port's rotation must use the same convention.
  - Files: `Sources/editor/resource_core/sub_editor_tools.zig`, `Sources/editor/resource_core/fake_bridge.zig`, `Sources/editor/resource_app/squad_logic.zig`
  - Verify: zig build test-resource-core -Dtest-mode=run && zig build test-resource-app-logic -Dtest-mode=run

- [x] **T03: Overlay draws MFC's direction and an auto step drags the arrow** `est:1.5h`
  Why: S06 review item 1 (D016). panels.zig (around line 426) draws the arrow tip as centre + (cos a, sin a) * 40 in screen space, so even a correctly stored angle is drawn wrong.
  - Files: `Sources/editor/resource_app/panels.zig`, `Sources/editor/resource_app/scenario.zig`, `build.zig`
  - Verify: zig build test-resource-app-logic -Dtest-mode=run && zig build install-resource-editor && zig build resource-editor-host-check && zig build resource-editor-smoke && zig build resource-editor-auto

- [x] **T04: Commit the S06 preview captures as evidence** `est:45m`
  Why: S06 review item 2 (D016). S06 T05's summary describes mine, trench and squad preview captures, but they exist only under zig-out/local-test/resource_editor/t02/s06-preview/, which the test deletes and recreates. Do not claim committed evidence that is not in git.
  - Files: `tools/zig/fixtures/resource_editor/preview-scene/preview-scene.md`, `tools/zig/fixtures/resource_editor/preview-scene/mine.tga`, `tools/zig/fixtures/resource_editor/preview-scene/trench.tga`, `tools/zig/fixtures/resource_editor/preview-scene/squad.tga`
  - Verify: zig build test-resource-bridge -Dtest-mode=run

- [x] **T05: Portable BuildAnimations compose library and .san writer proof** `est:3h`
  Why: sprite and infantry exports both rest on SpriteCompose.cpp BuildAnimations (lines 104-~255) and GetActionFromName (line 386). That code includes MFC (StdAfx, ParentFrame, AfxMessageBox), and S06 ported only a one-frame shortcut (BuildSingleFrame in Sources/src/ResourceModel/image_export.cpp). This is the highest-risk step of the sprite and infantry work, so prove it first.
  - Files: `Sources/src/ResourceModel/compose.h`, `Sources/src/ResourceModel/compose.cpp`, `Sources/src/ResourceModel/image_export.h`, `Sources/src/ResourceModel/image_export.cpp`, `Sources/src/EditorBridge/resource_bridge_test.cpp`, `build.zig`
  - Verify: zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model-comparator -Dtest-mode=run

- [x] **T06: Sprite exporter, preview kind and tests** `est:2.5h`
  Why: B-07.2/B-07.3. Without an exporter the sprite cannot be exported or previewed (ShowPreview needs outcome.szObjectName).
  - Files: `Sources/src/ResourceModel/items/sprite/sprite_export.cpp`, `Sources/src/ResourceModel/items/stats_export.h`, `Sources/src/ResourceModel/exporter.cpp`, `Sources/src/ResourceModel/exporter.h`, `Sources/src/EditorBridge/resource_bridge.cpp`, `Sources/src/EditorBridge/resource_bridge_test.cpp`, `build.zig`
  - Verify: zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model-comparator -Dtest-mode=run

- [x] **T07: Infantry exporter, fixture art and tests** `est:3.5h`
  Why: B-02.5/B-02.6. Infantry is the larger port: stats, compose for 3 seasons x 2 blood passes, and localisation copies.
  - Files: `Sources/src/ResourceModel/items/infantry/infantry_export.cpp`, `Sources/src/ResourceModel/items/stats_export.h`, `Sources/src/ResourceModel/exporter.cpp`, `tools/zig/resource_editor_fixtures.zig`, `tools/zig/fixtures/resource_editor/unt/project.unt`, `tools/zig/fixtures/resource_editor/EXTENSIONS.md`, `tools/zig/resource_model_comparator_test.cpp`, `Sources/src/EditorBridge/resource_bridge_test.cpp`, `build.zig`
  - Verify: zig build make-resource-fixtures && zig build test-resource-editor-fixtures && zig build test-resource-model -Dtest-mode=run && zig build test-resource-model-comparator -Dtest-mode=run && zig build test-resource-bridge -Dtest-mode=run

- [x] **T08: Real golden comparison and the .unt round trips** `est:2.5h`
  Why: the golden check in tools/zig/resource_model_comparator_test.cpp Goldens() and resource_bridge_test.cpp (about 1775-1814) only counts files and logs pending; it never compares. B-02.7/B-02.8 need the Data/Old and WinSniper round trips and a shipped import.
  - Files: `tools/zig/resource_model_comparator_test.cpp`, `Sources/src/EditorBridge/resource_bridge_test.cpp`, `Sources/src/ResourceModel/comparator.h`, `Sources/src/ResourceModel/comparator.cpp`
  - Verify: zig build test-resource-model-comparator -Dtest-mode=run && zig build test-resource-bridge -Dtest-mode=run

- [x] **T09: Frame tools undoable in resource_core and app wiring for preview playback** `est:2.5h`
  Why: B-02.2/B-02.3/B-07.1/B-07.2. Frame insert from the thumbnail list, delete, and Run/Stop must be undoable or wired, and c_bridge.zig previewPlayback is still a placeholder (line 655, `_ = &RealResBridge.previewPlayback`) outside the ResBridge vtable.
  - Files: `Sources/editor/resource_core/sub_editor_tools.zig`, `Sources/editor/resource_core/fake_bridge.zig`, `Sources/editor/resource_core/root.zig`, `Sources/editor/resource_app/c_bridge.zig`, `Sources/editor/resource_app/docks.zig`, `Sources/editor/resource_app/docks_logic.zig`, `Sources/editor/resource_app/docks_check.zig`, `Sources/src/EditorBridge/resource_bridge_test.cpp`
  - Verify: zig build test-resource-core -Dtest-mode=run && zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-app-logic -Dtest-mode=run && zig build install-resource-editor && zig build resource-editor-host-check

- [x] **T10: BK_EDITOR_AUTO spt and unt scenarios, parity rows, tier run** `est:2h`
  Why: the slice demo requires a BK_EDITOR_AUTO scenario per kind with Run/Stop preview shots, plus parity evidence.
  - Files: `Sources/editor/resource_app/scenario.zig`, `build.zig`, `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`
  - Verify: zig build install-resource-editor && zig build resource-editor-auto && zig build resource-editor-smoke && zig build test-resource-app-logic -Dtest-mode=run && zig build test-editor-core -Dtest-mode=run && zig build map-editor-smoke

## Files Likely Touched

- Sources/editor/resource_app/squad_logic.zig
- Sources/editor/resource_core/sub_editor_tools.zig
- Sources/editor/resource_core/fake_bridge.zig
- Sources/editor/resource_app/panels.zig
- Sources/editor/resource_app/scenario.zig
- build.zig
- tools/zig/fixtures/resource_editor/preview-scene/preview-scene.md
- tools/zig/fixtures/resource_editor/preview-scene/mine.tga
- tools/zig/fixtures/resource_editor/preview-scene/trench.tga
- tools/zig/fixtures/resource_editor/preview-scene/squad.tga
- Sources/src/ResourceModel/compose.h
- Sources/src/ResourceModel/compose.cpp
- Sources/src/ResourceModel/image_export.h
- Sources/src/ResourceModel/image_export.cpp
- Sources/src/EditorBridge/resource_bridge_test.cpp
- Sources/src/ResourceModel/items/sprite/sprite_export.cpp
- Sources/src/ResourceModel/items/stats_export.h
- Sources/src/ResourceModel/exporter.cpp
- Sources/src/ResourceModel/exporter.h
- Sources/src/EditorBridge/resource_bridge.cpp
- Sources/src/ResourceModel/items/infantry/infantry_export.cpp
- tools/zig/resource_editor_fixtures.zig
- tools/zig/fixtures/resource_editor/unt/project.unt
- tools/zig/fixtures/resource_editor/EXTENSIONS.md
- tools/zig/resource_model_comparator_test.cpp
- Sources/src/ResourceModel/comparator.h
- Sources/src/ResourceModel/comparator.cpp
- Sources/editor/resource_core/root.zig
- Sources/editor/resource_app/c_bridge.zig
- Sources/editor/resource_app/docks.zig
- Sources/editor/resource_app/docks_logic.zig
- Sources/editor/resource_app/docks_check.zig
- .planning/phases/06-resource-editor-portable-port/06-PARITY.md
