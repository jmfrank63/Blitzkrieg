---
id: T10
parent: S07
milestone: M001
key_files: []
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-05T14:17:56.560Z
blocker_discovered: false
---

# T10: Added spt and unt BK_EDITOR_AUTO blocks (frame, export, Run/Stop measured shots, undo/redo, delete_frame) and updated the PARITY rows; all tiers listed ran green.

**Added spt and unt BK_EDITOR_AUTO blocks (frame, export, Run/Stop measured shots, undo/redo, delete_frame) and updated the PARITY rows; all tiers listed ran green.**

## What Happened

scenario.zig gained preview_run, preview_stop, frame:<picture> and delete_frame (through the docks logic and the ResBridge previewPlayback vtable). The resource-editor-auto schedule gained an spt block (frames 139-167) and a unt block (170-187). Frame 26 now exports for real instead of expecting a refusal. The sprite block needed two different frames (sprite-1frame.tga plus mcp art-16x16.tga) because one frame cannot animate; the Run shots then differ (0.02% > 0.001%) and the Stop shots are pixel-equal. The unt block needed a frame picture added to the first animation before the engine could build the preview. 06-PARITY.md: B-02.1..8 and B-07.1..4 now carry test names and auto actions; B-02.4 is "no behaviour in MFC" with the MFC evidence; B-07.4 is "no behaviour in MFC (no reverse path for sprites)"; golden rows say pending win-home (export-goldens.ps1 -Extensions spt,unt); B-03.4 records the T01-T03 squad direction evidence. Full resource sweep left to the maintainer. Tiers run here (Linux x64 only, no macOS or Windows result seen): install-game, install-resource-editor, install-map-editor, resource-editor-host-check, resource-editor-smoke, resource-editor-auto, map-editor-smoke, test-editor-core, test-resource-app-logic.

## Verification

resource-editor-auto PASS (173 actions over 188 frames). resource-editor-smoke, resource-editor-host-check, map-editor-smoke exit 0. test-resource-app-logic and test-editor-core exit 0 (cached from the earlier run, source unchanged since). Full sweep left to the maintainer.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build install-game install-resource-editor install-map-editor` | 0 | pass | 4000ms |
| 2 | `zig build resource-editor-host-check` | 0 | pass | 30000ms |
| 3 | `zig build resource-editor-smoke` | 0 | pass | 30000ms |
| 4 | `zig build resource-editor-auto` | 0 | pass | 60000ms |
| 5 | `zig build map-editor-smoke` | 0 | pass | 13000ms |
| 6 | `zig build test-resource-app-logic -Dtest-mode=run` | 0 | pass | 1000ms |
| 7 | `zig build test-editor-core -Dtest-mode=run` | 0 | pass | 1000ms |

## Deviations

None.

## Known Issues

None.

## Files Created/Modified

None.
