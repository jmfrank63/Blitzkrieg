---
estimated_steps: 7
estimated_files: 12
skills_used: []
---

# T02: Object fixture art, Object exporter + importer, golden comparison pending

Why: B-10.4 and B-10.5. No obt exporter exists. The fixture project.obt refers to 1/1s/1w/1ws/1a/1as.tga, which do not exist, and it has no own_data/desc.

Do:
1. Fixture: extend tools/zig/resource_editor_fixtures.zig so obt generates small deterministic sprite+shadow TGAs (1, 1s, 1w, 1ws, 1a, 1as) and a non-trivial own_data/desc in project.obt: a passability grid with a non-zero origin, transparency tiles at values 1..7, two trans-lines, a zero point and a sprite_pos. Mirror the S07/S08 pattern. Run make-resource-fixtures, then update EXTENSIONS.md and obt/golden/README.md. Re-run test-resource-editor-fixtures, because fixture hashes are pinned.
2. Port ComposeSingleObjectPack (Sources/src/editor/BuildCompose.cpp 147-234) and SaveIconFile (GridFrm.cpp) into Sources/src/ResourceModel/compose.{h,cpp}, reusing NImageExport and the existing sprite-pack code (CSpritesPackBuilder). S10 Building calls these as they are.
3. Add Sources/src/ResourceModel/items/object/object_export.cpp: CObjectFrame::ExportFrameData + SaveRPGStats (ObjectFrm.cpp 436-737) and CObjTreeItem::ComposeAnimations (summer 1, winter 1w, Africa 1a), using GridProjection/TilesToGrid/DirTilesFromTransLines from T01. Support bStatsOnly. Register { "obt", &ExportObject } in exporter.cpp. Add the import half (LoadRPGStats 738-838) to the per-kind switch in BkResImportFromGame (resource_bridge.cpp ~5189), and mark obt as ported there.
4. Tests in Sources/src/EditorBridge/resource_bridge_test.cpp: export the fixture from a zig-out/local-test copy; SObjectRPGStats read by the engine is field-equal across import -> export -> import; DDS within the dxt gate; icon.tga present; a second forced export is byte-identical. Pick a shipped object under Data/Objects (resolve paths case-insensitively); import -> export of it gives stats field-equal to its shipped 1.xml. The comparator (tools/zig/resource_model_comparator_test.cpp) includes obt and prints 'GOLDEN obt pending'.

Done when: the verify tiers exit 0, the obt golden line says pending, and nothing was written into Data/.

## Inputs

- `Sources/src/editor/ObjectFrm.cpp`
- `Sources/src/editor/ObjTreeItem.cpp`
- `Sources/src/editor/BuildCompose.cpp`
- `Sources/src/editor/GridFrm.cpp`
- `Sources/src/ResourceModel/grid_projection.h`
- `Sources/src/ResourceModel/items/object/object.h`
- `Sources/src/ResourceModel/items/mesh/mesh_export.cpp`
- `Sources/src/ResourceModel/image_export.h`
- `Sources/src/ResourceModel/compose.h`
- `Sources/src/ResourceModel/exporter.cpp`
- `tools/zig/resource_editor_fixtures.zig`
- `tools/zig/fixtures/resource_editor/obt/project.obt`
- `tools/zig/resource_model_comparator_test.cpp`

## Expected Output

- `tools/zig/resource_editor_fixtures.zig`
- `tools/zig/fixtures/resource_editor/obt/project.obt`
- `tools/zig/fixtures/resource_editor/EXTENSIONS.md`
- `tools/zig/fixtures/resource_editor/obt/golden/README.md`
- `Sources/src/ResourceModel/compose.h`
- `Sources/src/ResourceModel/compose.cpp`
- `Sources/src/ResourceModel/items/object/object_export.cpp`
- `Sources/src/ResourceModel/exporter.cpp`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `tools/zig/resource_model_comparator_test.cpp`
- `build.zig`

## Verification

zig build make-resource-fixtures && zig build test-resource-editor-fixtures && zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model-comparator -Dtest-mode=run && zig build test-resource-model -Dtest-mode=run

## Observability Impact

Missing season sprites are SExportOutcome warnings. The comparator prints 'GOLDEN obt pass|FAIL|pending'.
