---
id: T04
parent: S09
milestone: M001
key_files:
  - Sources/editor/resource_core/grid_tools.zig
  - Sources/editor/resource_core/root.zig
  - Sources/src/EditorBridge/resource_bridge.cpp
  - Sources/src/EditorBridge/resource_bridge_test.cpp
  - Sources/editor/resource_core/bridge.zig
  - Sources/editor/resource_app/c_bridge.zig
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-05T16:35:28.028Z
blocker_discovered: false
---

# T04: Added bridge channels 17-19 (transparency_cells, fence_transparences, sprite_pos), origin-consistent object passability, and kind-agnostic grid_tools.zig (brush, trans-line, set zero, clear, sprite centre/drag) with undo/redo tests.

**Added bridge channels 17-19 (transparency_cells, fence_transparences, sprite_pos), origin-consistent object passability, and kind-agnostic grid_tools.zig (brush, trans-line, set zero, clear, sprite centre/drag) with undo/redo tests.**

## What Happened

The C++ bridge (HomeOf, Read/WriteFrameGeometry, Load/StoreGeometry, RewriteObjectGrids, Get/Set entry points) and the Zig bridge.zig and c_bridge.zig already carried channels 17-19 from the earlier session. Setting object passability_cells or transparency_cells holds the edit in the tile frame, and the save crops it with the origin of the zero point it ends with. Channels with no home now refuse with a message naming the channel and the project kind. This session wrote Sources/editor/resource_core/grid_tools.zig, parameterised by node and channel: BrushStroke (press/move/release, Bresenham between moves, value 0 erases, trimmed result, one geometry command, cancel restores), TransLineTool (press selects a line by its middle or starts one, move, release adds it, right click drops the drag or deletes the selected line, cancel), setZero, clearGrid, centreSpriteOnTile and SpriteDrag. It is wired into root.zig. fake_bridge.zig needed no change because it is family-based. Added 9 core tests that read the geometry before the edit, after it, after undo and after redo, and assert one undo step per stroke and no history entry for a cancelled gesture. Added S09Channels bridge tests: get/set/get/save/reopen/get for object passability and transparency and for fence passability and transparences, plus sprite_pos on both kinds. They also cover the 0..7 refusal, the cross-kind refusal messages, and the exported object origin matching GridProjection::OriginOfGrid for the final zero point.

## Verification

Ran test-resource-core, test-resource-bridge, test-resource-app-logic and test-editor-core, all exit 0. Fence export origin was not asserted precisely; the fence channels are checked by round trip only.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-core -Dtest-mode=run` | 0 | pass | 510ms |
| 2 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 120000ms |
| 3 | `zig build test-resource-app-logic -Dtest-mode=run` | 0 | pass | 1460ms |
| 4 | `zig build test-editor-core -Dtest-mode=run` | 0 | pass | 1130ms |

## Deviations

Centre-on-tile takes the tile centre from the caller, computed with GridProjection, so the core stays free of the camera. A stroke yields a single geometry command rather than a composite, which is still one undo step. fake_bridge.zig was not modified.

## Known Issues

The fence export origin is not asserted against an expected value in the new channel test. The round trip proves the channel only.

## Files Created/Modified

- `Sources/editor/resource_core/grid_tools.zig`
- `Sources/editor/resource_core/root.zig`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `Sources/editor/resource_core/bridge.zig`
- `Sources/editor/resource_app/c_bridge.zig`
