---
id: T06
parent: S09
milestone: M001
key_files: []
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-05T17:02:28.759Z
blocker_discovered: false
---

# T06: Added measured BK_EDITOR_AUTO obt and fnc blocks (grid, transparency, trans-line, zero/centre, undo/redo, save, export, overlay shots counted by code), fixed two app bugs they exposed, and updated PARITY B-10/B-11 and the spec channel table.

**Added measured BK_EDITOR_AUTO obt and fnc blocks (grid, transparency, trans-line, zero/centre, undo/redo, save, export, overlay shots counted by code), fixed two app bugs they exposed, and updated PARITY B-10/B-11 and the spec channel table.**

## What Happened

The scenario verbs (grid_cell, grid_trans, trans_line, grid_zero, fence_centre, sprite_move, and expect=grid_cell/trans_cell/lines/zero_tile/sprite_tile/shot_colour) were already in scenario.zig, and the obt/fnc schedule blocks in build.zig. Running resource-editor-auto exposed four problems, all fixed: (1) grid_logic.tileAt panicked converting a NaN/huge pointer position to int, so it now rejects non-finite or out-of-range points; (2) the scenario cell reader returned 'cannot be read' for tiles past the grid's current end, but the grid grows on paint, so it now reads 0; (3) panels kept a stale Object GridEditor after an Object project was replaced by a Fence one, so the fence read used the object's channel and was refused. It now drops the editor when the kind changes; (4) the schedule had 7 redos for 4 undos, trimmed to match. The auto scenario now passes: obt shots measured for 0xff0000 locked and 0x606000 transparency (base max, drawn min, undone max, drawn differs from undone), fnc likewise with 0xff0000 and 0x808000, and both exported into scratch MODs and the 1.xml and 1_c.dds files checked. PARITY rows B-10.1-5 and B-11.1-5 are marked done with evidence; goldens stay pending win-home. The spec channel table gained channels 17-19 and a D020 entry covering GridProjection and the origin-consistent passability rule. The earlier docks check had been fixed to expect .bld import refusal because .obt import is now ported.

## Verification

Ran from the real shell with XDG_RUNTIME_DIR set: install-resource-editor, resource-editor-auto (PASS, 349 actions over 332 frames), resource-editor-smoke, resource-editor-host-check, test-resource-app-logic, test-resource-core, test-editor-core, map-editor-smoke, all exit 0. Full resource sweep left to the maintainer. macOS and Windows CI not seen. The fnc export origin is covered by round trip only.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build install-resource-editor && zig build resource-editor-auto` | 0 | pass | 0ms |
| 2 | `zig build resource-editor-smoke` | 0 | pass | 0ms |
| 3 | `zig build resource-editor-host-check` | 0 | pass | 0ms |
| 4 | `zig build test-resource-app-logic -Dtest-mode=run` | 0 | pass | 1000ms |
| 5 | `zig build test-resource-core -Dtest-mode=run` | 0 | pass | 1000ms |
| 6 | `zig build test-editor-core -Dtest-mode=run` | 0 | pass | 1000ms |
| 7 | `zig build map-editor-smoke` | 0 | pass | 12000ms |

## Deviations

None.

## Known Issues

None.

## Files Created/Modified

None.
