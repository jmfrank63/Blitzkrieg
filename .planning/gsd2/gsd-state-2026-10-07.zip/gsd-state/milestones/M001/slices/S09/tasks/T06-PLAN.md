---
estimated_steps: 7
estimated_files: 4
skills_used: []
---

# T06: BK_EDITOR_AUTO obt/fnc blocks with measured overlay shots, PARITY rows, spec channel table, tier run

Why: the slice demo asks for a preview shot with the grid + transparency overlay, measured by code, and one auto scenario per kind. The parity rows and the spec must record the evidence and the new channels.

Do:
1. Add scenario verbs to Sources/editor/resource_app/scenario.zig and document them in its header: do=grid_cell:<x>/<y>/<val>, do=grid_trans:<x>/<y>/<val>, do=trans_line:<x1>/<y1>/<x2>/<y2>, do=grid_zero:<x>/<y>, do=fence_centre, do=sprite_move:<dx>/<dy>. Each goes through grid_logic/grid_tools, the same path as the UI.
2. Add obt and fnc blocks to the resource-editor-auto scenario (copy the msh block's form): copy the fixture to a scratch path, open, draw locked tiles and transparency, add a trans-line, set zero (obt) / centre on tile (fnc), undo, redo, save, export into the scratch MOD, capture a shot. Code measures the TGA (kit.auto_schedule.Tga): pixel counts of 0xffff0000 and of at least one transparency yellow must be above a threshold, and undo must remove them in a second shot.
3. Update .planning/phases/06-resource-editor-portable-port/06-PARITY.md rows B-10.1..B-10.5 and B-11.1..B-11.5 with evidence (test names, tiers); goldens stay 'pending win-home'. Rows that S05's tree/inspector/thumbnail work already covers are marked done with that evidence. Add channels 17-19, the passability origin rule and D020 to the spec's channel table in docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md.
4. Run the tiers one at a time from the real shell with XDG_RUNTIME_DIR=/run/user/$UID set (without it, GUI tiers fail with SdlInitFailed, which is an environment limit). Record in the summary that the full sweep is left to the maintainer and that macOS/Windows CI was not seen.

Done when: every verify tier exits 0 and the parity rows and spec are updated.

## Inputs

- `Sources/editor/resource_app/scenario.zig`
- `Sources/editor/resource_app/grid_logic.zig`
- `Sources/editor/resource_core/grid_tools.zig`
- `build.zig`
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`

## Expected Output

- `Sources/editor/resource_app/scenario.zig`
- `build.zig`
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`

## Verification

zig build install-resource-editor && zig build resource-editor-auto && zig build resource-editor-smoke && zig build resource-editor-host-check && zig build test-resource-app-logic -Dtest-mode=run && zig build test-resource-core -Dtest-mode=run && zig build test-editor-core -Dtest-mode=run && zig build map-editor-smoke

## Observability Impact

The auto log prints each shot's measured overlay colour counts and the threshold, and a failure names the colour.
