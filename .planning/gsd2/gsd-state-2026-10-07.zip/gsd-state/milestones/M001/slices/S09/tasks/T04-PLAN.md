---
estimated_steps: 7
estimated_files: 8
skills_used: []
---

# T04: Bridge channels 17-19, passability origin consistency, and kind-agnostic grid tools in resource_core

Why: the slice goal says every grid tool is undoable, with get/set state checked before and after. Today object transparency cells, fence transparences and sprite position have no channel, and setting passability_cells leaves the desc origin stale.

Do:
1. Append the channels transparency_cells=17 (bytes_grid, values 0..7, object), fence_transparences=18 (tile list, same family as locked_tiles) and sprite_pos=19 (point2, object sprite_pos / fence SpritePos) in Sources/src/EditorBridge/resource_bridge.h/.cpp (HomeOf, ReadFrameGeometry, WriteFrameGeometry, LoadGeometry, StoreGeometry), Sources/editor/resource_core/bridge.zig (GeometryChannel + family), fake_bridge.zig and resource_app/c_bridge.zig. Append only; do not renumber. Setting passability_cells (tile frame) must rewrite desc passability as the cropped grid plus a matching origin through T01's helpers. Writes stay in MFC's own_data/desc layout, and HasNoPrivateGeometry stays true.
2. resource_bridge_test.cpp: for each new channel and passability_cells on obt and fnc: get -> set -> get -> save -> reopen -> get equal, then export and read the stats back with the expected origin.
3. Add Sources/editor/resource_core/grid_tools.zig, parameterised by node + channel so S10/S11 reuse it: brush stroke (press/move/release over tiles, value; value 0 erases as SetTileInListOfTiles does) -> one composite; transparency brush; trans-line two-click state machine (press, move, release, cancel; right click deletes the selected line); set zero; centre fence sprite on tile (CenterSpriteAboutTile, FenceFrm.cpp 684-708); sprite move drag. Each emits geometry/composite commands with before/after snapshots. Wire it into resource_core/root.zig.
4. Tests in resource_core (test-resource-core) against fake_bridge: for each tool, assert readGeometry before the edit, after it, after undo and after redo; a stroke is one undo step; a cancelled trans-line leaves no history entry.

Done when: the verify tiers exit 0.

## Inputs

- `Sources/src/EditorBridge/resource_bridge.h`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/editor/resource_core/bridge.zig`
- `Sources/editor/resource_core/fake_bridge.zig`
- `Sources/editor/resource_core/sub_editor_tools.zig`
- `Sources/editor/resource_core/root.zig`
- `Sources/editor/resource_app/c_bridge.zig`
- `Sources/src/ResourceModel/grid_projection.h`
- `Sources/src/editor/ObjectFrm.cpp`
- `Sources/src/editor/FenceFrm.cpp`
- `Sources/src/editor/GridFrm.cpp`

## Expected Output

- `Sources/src/EditorBridge/resource_bridge.h`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `Sources/editor/resource_core/bridge.zig`
- `Sources/editor/resource_core/fake_bridge.zig`
- `Sources/editor/resource_core/grid_tools.zig`
- `Sources/editor/resource_core/root.zig`
- `Sources/editor/resource_app/c_bridge.zig`

## Verification

zig build test-resource-core -Dtest-mode=run && zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-app-logic -Dtest-mode=run && zig build test-editor-core -Dtest-mode=run

## Observability Impact

A channel that is unknown or out of range for a kind returns a bridge status naming the channel and kind.
