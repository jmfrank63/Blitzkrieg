---
estimated_steps: 6
estimated_files: 12
skills_used: []
---

# T03: Fence fixture art, Fence exporter + importer with index-hole refusal

Why: B-11.4 and B-11.5. The fnc fixture's Fences directory is empty, and no fnc exporter exists.

Do:
1. Fixture: extend resource_editor_fixtures.zig so fnc has a fences directory holding <item>.tga and <item>s.tga for each FENCE_PROPS item. project.fnc gets at least one segment per direction, with locked tiles, transparences and a SpritePos. Point the 'Fences directory' value at it. Run make-resource-fixtures and update EXTENSIONS.md and fnc/golden/README.md.
2. Add Sources/src/ResourceModel/items/fence/fence_export.cpp: CFenceFrame::ExportFrameData (FenceFrm.cpp 416-472), including the refusal when freeIndexes.size() > 1 (keep MFC's message, translated, in SExportOutcome); FenceTreeRootItem::ComposeFences (4 directions x 4 insert types x segments, SaveShadowFile, ComposeSingleSprite with bFence=true, ported into compose.{h,cpp} beside T02's helpers); FillSegmentProps (956-1076) via T01's TilesToGrid. Support bStatsOnly. Register { "fnc", &ExportFence }. Port CFenceFrame::LoadRPGStats (346-381) into BkResImportFromGame.
3. Tests in resource_bridge_test.cpp: fixture export, SFenceRPGStats field-equal across import -> export -> import, DDS within the dxt gate, and a refusal test (a fixture copy with an index hole is refused, writes no files, and names the reason). Data/Fences/ussr/summer/townfence round-trips import -> export field-equal with its shipped 1.xml. The comparator prints 'GOLDEN fnc pending'.

Done when: the verify tiers exit 0 and the fnc golden line says pending.

## Inputs

- `Sources/src/editor/FenceFrm.cpp`
- `Sources/src/editor/FenceTreeItem.cpp`
- `Sources/src/editor/SpriteCompose.cpp`
- `Sources/src/ResourceModel/items/fence/fence.h`
- `Sources/src/ResourceModel/grid_projection.h`
- `Sources/src/ResourceModel/compose.h`
- `Sources/src/ResourceModel/items/object/object_export.cpp`
- `Sources/src/ResourceModel/exporter.cpp`
- `tools/zig/resource_editor_fixtures.zig`
- `tools/zig/fixtures/resource_editor/fnc/project.fnc`
- `Data/Fences/ussr/summer/townfence/1.xml`

## Expected Output

- `tools/zig/resource_editor_fixtures.zig`
- `tools/zig/fixtures/resource_editor/fnc/project.fnc`
- `tools/zig/fixtures/resource_editor/EXTENSIONS.md`
- `tools/zig/fixtures/resource_editor/fnc/golden/README.md`
- `Sources/src/ResourceModel/compose.h`
- `Sources/src/ResourceModel/compose.cpp`
- `Sources/src/ResourceModel/items/fence/fence_export.cpp`
- `Sources/src/ResourceModel/exporter.cpp`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `tools/zig/resource_model_comparator_test.cpp`
- `build.zig`

## Verification

zig build make-resource-fixtures && zig build test-resource-editor-fixtures && zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model-comparator -Dtest-mode=run && zig build test-resource-model -Dtest-mode=run

## Observability Impact

The index-hole refusal and missing segment sprites are reported in SExportOutcome. The comparator prints 'GOLDEN fnc pass|FAIL|pending'.
