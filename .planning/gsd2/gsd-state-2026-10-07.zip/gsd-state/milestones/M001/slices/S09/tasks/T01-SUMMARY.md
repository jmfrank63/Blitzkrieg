---
id: T01
parent: S09
milestone: M001
key_files: []
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-05T15:53:14.104Z
blocker_discovered: false
---

# T01: Added headless NResourceModel::GridProjection (tile/screen math, explicit-camera Pos2/Pos3, grid<->tile-list helpers, Bresenham one-way line tiles) plus SAINormalTile list helpers, wired into test-resource-model.

**Added headless NResourceModel::GridProjection (tile/screen math, explicit-camera Pos2/Pos3, grid<->tile-list helpers, Bresenham one-way line tiles) plus SAINormalTile list helpers, wired into test-resource-model.**

## What Happened

The grid_projection.{h,cpp}, ai_tiles additions, test file and build.zig wiring existed from the interrupted session. Verification found two defects, both fixed. The test exe did not link because variant.cpp was missing from its source list, so I added it. Debug builds also trapped on left-shifting negative values in FillBresenham, so I replaced the shifts with multiplication by 2. The camera is an explicit SGroundCamera input because CScene::GetPos2 is a camera matrix, not a constant. Tile<->screen is closed form from the fixed origin (-622, 296) and the 32x16 cell size. All new files are CRLF.

## Verification

test-resource-grid-projection passes and prints "resource-grid-projection OK". test-resource-model passes with the new test in the aggregate (VERDICT=PASS). test-editor-bridge also passes, since the bridge now compiles grid_projection.cpp. Golden comparisons remain pending as before; the full sweep is left to the maintainer. macOS and Windows were not run.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-grid-projection -Dtest-mode=run` | 0 | ✅ pass | 20000ms |
| 2 | `zig build test-resource-model -Dtest-mode=run` | 0 | ✅ pass | 25000ms |
| 3 | `zig build test-editor-bridge -Dtest-mode=run` | 0 | ✅ pass | 60000ms |

## Deviations

None.

## Known Issues

None.

## Files Created/Modified

None.
