---
estimated_steps: 7
estimated_files: 6
skills_used: []
---

# T01: GridProjection, normal tiles and tile-list <-> grid+origin helpers (C++), tested headless

Why: every grid tool, both exporters and both importers depend on MFC's tile math. S10 (Building) and S11 (Bridge) reuse it too. test-resource-model must run without a window (D020).

Do:
1. Read Sources/src/editor/GridFrm.cpp (ComputeGameTileCoordinates, GetGameTileCoordinates, fOX=-622, fOY=296, fCellSizeX/Y, alpha=asin(1/sqrt5), SetTileInListOfTiles, SetTileInListOfNormalTiles, DeleteTileInListOfNormalTiles, MyFillBrezenham) and the ObjectFrm.cpp/FenceFrm.cpp code that turns tiles into desc passability/visibility + vOrigin (ObjectFrm SaveRPGStats 534-737, LoadRPGStats 738-838, UpdateNormalForSelectedLine 908-950; FenceFrm FillSegmentProps 956-1076).
2. Read Sources/src/Scene/Scene.cpp GetPos2/GetPos3 and the editor's camera set-up to find the screen<->world transform the MFC editor used. If it is a fixed isometric camera, write it in closed form with a comment that names the source lines. If it is not constant, record the camera parameters it depends on as explicit inputs.
3. Add Sources/src/ResourceModel/grid_projection.{h,cpp} (NResourceModel::GridProjection): ScreenToTile, TileCorners, Pos2To3/Pos3To2. Port SAINormalTile and CListOfNormalTiles into items/ai_tiles.{h,cpp}. Add helpers TilesToGrid(tiles) -> (cropped bbox grid, mostLeft corner) and GridToTiles, and the vOrigin = spritePos - mostLeft3 rule. Add DirTilesFromTransLines(lines), which applies Bresenham with the line normal the way MFC does.
4. Add the files to the ResourceModel source list in build.zig. Add tools/zig/resource_grid_projection_test.cpp to the test-resource-model aggregate (copy the way an existing sub-test such as the comparator is wired). Test: tile -> corners -> tile round trips over the 60x60 grid; three tile/screen pairs computed by hand from the MFC formulas; the bbox+origin helper on a hand case with non-zero origin; dirTiles from a diagonal line.

Done when: test-resource-model passes and includes the new test; files are CRLF.

## Inputs

- `Sources/src/editor/GridFrm.cpp`
- `Sources/src/editor/GridFrm.h`
- `Sources/src/editor/ObjectFrm.cpp`
- `Sources/src/editor/FenceFrm.cpp`
- `Sources/src/Scene/Scene.h`
- `Sources/src/ResourceModel/items/ai_tiles.h`
- `build.zig`

## Expected Output

- `Sources/src/ResourceModel/grid_projection.h`
- `Sources/src/ResourceModel/grid_projection.cpp`
- `Sources/src/ResourceModel/items/ai_tiles.h`
- `Sources/src/ResourceModel/items/ai_tiles.cpp`
- `tools/zig/resource_grid_projection_test.cpp`
- `build.zig`

## Verification

zig build test-resource-model -Dtest-mode=run

## Observability Impact

The test prints each hand-computed case with its expected and actual values when it fails.
