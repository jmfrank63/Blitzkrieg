---
id: T02
parent: S09
milestone: M001
key_files: []
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-05T16:12:09.404Z
blocker_discovered: false
---

# T02: Added the Object (.obt) exporter and importer with generated fixture art, ported ComposeSingleObjectPack and SaveIconFile, and bridge tests; golden comparison stays pending.

**Added the Object (.obt) exporter and importer with generated fixture art, ported ComposeSingleObjectPack and SaveIconFile, and bridge tests; golden comparison stays pending.**

## What Happened

The fixture generator now writes six 32-bit sprite and shadow TGAs (1, 1s, 1w, 1ws, 1a, 1as). project.obt has an own_data/desc block: passability with origin (2,1), transparency tiles 1..7, two trans-lines, a zero point and a sprite_pos, plus a "human" pass class. compose.{h,cpp} now hold ComposeSingleObjectPack and SaveIconFile, reusing NImageExport and CSpritesPackBuilder. items/object/object_export.{h,cpp} port ExportFrameData, SaveRPGStats and ComposeAnimations for summer, winter and Africa, read and write own_data/desc, and honour stats-only. exporter.cpp registers obt. SExportContext gained a groundCamera hook that the bridge fills from IScene. BkResImportFromGame now imports obt (LoadRPGStats half). Imported frame data is staged through Save and Load so that it survives a later save, because only a project read from text keeps own_data and desc in the root's layout. The first fixture shadow was fully hidden by the sprite, so Pack failed on it; the shadow is now offset. The old tests that expected obt to be refused were updated (import now refuses fnc instead). New S09Object tests cover the fixture export and a shipped object (Objects/SimpleObjects/europe/summer/e_milestone/01). Objects/TerraObjects/.../E_Bank_3/04 was tried first and dropped, because its 2002 file has a different field set.

## Verification

Ran on Linux x64 only; macOS and Windows not run. make-resource-fixtures, test-resource-editor-fixtures, test-resource-bridge, test-resource-model-comparator and test-resource-model all exit 0. The bridge tier shows: the fixture's DDS decode as DXT5 and all 64 opaque pixels are within the colour gate; _l/_h/.san and shadow files are written; a second forced export is byte-identical; a deleted 1w.tga warns and leaves no 1w DDS; the fixture import->export->import compares 44 fields with 0 differences; the shipped e_milestone/01 compares 41 fields with 0 differences; the shipped folder listing is unchanged. The comparator prints "GOLDEN obt pending". The full resource sweep is left to the maintainer. The Map Editor tiers were not run.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build make-resource-fixtures` | 0 | pass | 15000ms |
| 2 | `zig build test-resource-editor-fixtures` | 0 | pass | 10000ms |
| 3 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 40000ms |
| 4 | `zig build test-resource-model-comparator -Dtest-mode=run` | 0 | pass | 15000ms |
| 5 | `zig build test-resource-model -Dtest-mode=run` | 0 | pass | 15000ms |

## Deviations

None.

## Known Issues

None.

## Files Created/Modified

None.
