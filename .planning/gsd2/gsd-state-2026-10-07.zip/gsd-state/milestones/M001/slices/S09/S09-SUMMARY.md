---
id: S09
parent: M001
milestone: M001
provides:
  - (none)
requires:
  []
affects:
  []
key_files: []
key_decisions: []
patterns_established:
  - (none)
observability_surfaces:
  - none
drill_down_paths:
  []
duration: ""
verification_result: passed
completed_at: 2026-10-05T17:06:59.051Z
blocker_discovered: false
---

# S09: Object, Fence sub-editors (grid-frame tools)

**Object (.obt) and Fence (.fnc) sub-editors with undoable grid tools, ported exporters/importers, measured overlay shots and BK_EDITOR_AUTO scenarios; MFC goldens pending win-home.**

## What Happened

T01 added headless GridProjection and tile-list helpers (C++) matching MFC GridFrm math. T02 and T03 added generated fixture art, the obt and fnc exporters and importers (ComposeSingleObjectPack, SaveIconFile, ComposeFences, FillSegmentProps, LoadRPGStats), the fence index-hole refusal, and bridge round-trip tests including shipped samples (e_milestone/01, townfence) with 0 field differences. T04 added bridge channels 17-19 (transparency_cells, fence_transparences, sprite_pos), origin-consistent object passability, and kind-agnostic resource_core/grid_tools.zig (brush, trans-line, set zero, clear, sprite centre/drag) with undo/redo tests asserting geometry before, after, undo and redo. T05 added grid_logic.zig (view<->tile mapping, tool modes, overlay rules), grid toolbar and overlay drawing in panels, obt/fnc preview wiring. T06 added measured BK_EDITOR_AUTO obt/fnc blocks (locked red and transparency overlay pixel counts measured in captured shots), fixed four bugs they exposed (NaN tileAt panic, grid read past end, stale GridEditor on kind change, redo/undo imbalance), and updated PARITY B-10/B-11 and the spec channel table.

## Verification

Re-run fresh at closeout on Linux x64, all exit 0: test-resource-model, test-resource-model-comparator, test-resource-core, test-resource-app-logic, test-editor-core, test-resource-bridge, install-resource-editor, resource-editor-auto, resource-editor-smoke, resource-editor-host-check, map-editor-smoke. Golden comparisons print 'GOLDEN obt/fnc pending' (win-home). Full resource sweep left to the maintainer. macOS and Windows not run (CI).

## Requirements Advanced

None.

## Requirements Validated

None.

## New Requirements Surfaced

None.

## Requirements Invalidated or Re-scoped

None.

## Operational Readiness

None.

## Deviations

None.

## Known Limitations

Goldens pending win-home; fence export origin not asserted precisely; macOS/Windows unverified.

## Follow-ups

None.

## Files Created/Modified

None.
