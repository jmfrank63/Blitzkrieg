# S09: Object, Fence sub-editors (grid-frame tools) — UAT

**Milestone:** M001
**Written:** 2026-10-05T17:06:59.053Z

# S09 UAT

**UAT Type:** artifact-driven and automated-tier on Linux x64.

## Preconditions
- Linux x64 machine, `XDG_RUNTIME_DIR` set, repo built.

## Steps
1. `zig build test-resource-model -Dtest-mode=run` → passes; GridProjection tests with non-zero origin included.
2. `zig build test-resource-bridge -Dtest-mode=run` → obt and fnc fixture exports, shipped-sample round trips (0 differences), fence index-hole refusal, channels 17-19 get/set/save/reopen all pass.
3. `zig build test-resource-core -Dtest-mode=run` and `test-resource-app-logic` → every grid tool verified before/after/undo/redo; view<->tile mapping agrees with C++.
4. `zig build install-resource-editor && zig build resource-editor-auto` → obt and fnc blocks pass; log shows measured overlay colour counts.
5. `resource-editor-smoke`, `resource-editor-host-check`, `map-editor-smoke`, `test-editor-core` → pass.

## Expected
All exit 0; comparator prints `GOLDEN obt pending` and `GOLDEN fnc pending`.

## Edge cases
- Fence with index holes is refused with MFC's message and writes no files.
- Cancelled gesture adds no history entry.
- Switching Object to Fence project drops the stale grid editor.

## Not Proven By This UAT
- MFC golden equality (needs win-home run).
- macOS and Windows behaviour (CI).
- Full resource sweep (maintainer).
- Fence export origin is covered by round trip only.
