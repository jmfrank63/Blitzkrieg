---
estimated_steps: 7
estimated_files: 7
skills_used: []
---

# T05: App: grid-frame toolbar, view<->tile mapping, overlay drawing, obt/fnc preview

Why: B-10.2/B-10.3 and B-11.2/B-11.3 need the tools in the app, with the grid and transparency overlay drawn over the preview.

Do:
1. Add Sources/editor/resource_app/grid_logic.zig (headless): the view<->tile mapping, in the same trig as GridProjection (fOX/fOY/cell size/alpha plus T01's screen step); the tool mode (Move, Draw grid, Draw transparency with value 0..7, Set zero, One-way line, Centre on tile); and mapping mouse events to grid_tools.zig calls. Add overlay colour rules (locked 0xffff0000, unlocked/entrance 0xff00ff00, transparency 1..7 = 0xff202000 + (v-1)*0x202000, trans-lines, zero cross). Add a per-kind tool registration that S10/S11 extend, alongside squad_logic.zig and mesh_logic.zig.
2. Draw the 60x60 grid, tiles, lines and zero with ImGui draw lists over the preview, in the module that hosts the squad/mesh overlays (main.zig or panels.zig). Add the toolbar entries and the transparency combo. For fence: insert-type and segment selection through the thumbnail list (SetActiveFenceInsertItem, ClickOnThumbList, DoubleClickOnThumbList), using the S05 thumbnail dock.
3. Make sure obt and fnc have a sprite preview kind in the bridge (reuse the sprite preview from S06 where one exists; otherwise add it to BkResPreview*). Capture one frame per kind in resource_bridge_test.cpp.
4. test-resource-app-logic: mapping round trips, plus agreement with the C++ GridProjection on the same sample points (hard-code T01's hand-computed cases in both tests); tool mode transitions; colour rules.

Done when: the verify tiers exit 0.

## Inputs

- `Sources/editor/resource_app/squad_logic.zig`
- `Sources/editor/resource_app/mesh_logic.zig`
- `Sources/editor/resource_app/main.zig`
- `Sources/editor/resource_app/panels.zig`
- `Sources/editor/resource_app/docks.zig`
- `Sources/editor/resource_core/grid_tools.zig`
- `Sources/src/ResourceModel/grid_projection.h`
- `Sources/src/editor/GridFrm.cpp`
- `Sources/src/editor/FenceFrm.cpp`

## Expected Output

- `Sources/editor/resource_app/grid_logic.zig`
- `Sources/editor/resource_app/main.zig`
- `Sources/editor/resource_app/panels.zig`
- `Sources/editor/resource_app/docks.zig`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `build.zig`

## Verification

zig build test-resource-app-logic -Dtest-mode=run && zig build test-resource-core -Dtest-mode=run && zig build test-resource-bridge -Dtest-mode=run && zig build install-resource-editor && zig build resource-editor-host-check && zig build resource-editor-smoke

## Observability Impact

The status line names the active grid tool and the tile under the cursor.
