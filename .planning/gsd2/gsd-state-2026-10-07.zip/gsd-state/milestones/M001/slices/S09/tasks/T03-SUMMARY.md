---
id: T03
parent: S09
milestone: M001
key_files:
  - Sources/src/ResourceModel/items/fence/fence_export.cpp
  - Sources/src/ResourceModel/compose.cpp
  - Sources/src/ResourceModel/compose.h
  - Sources/src/ResourceModel/exporter.cpp
  - Sources/src/EditorBridge/resource_bridge.cpp
  - Sources/src/EditorBridge/resource_bridge_test.cpp
  - tools/zig/resource_editor_fixtures.zig
  - tools/zig/fixtures/resource_editor/fnc/project.fnc
  - tools/zig/resource_model_comparator_test.cpp
  - build.zig
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-05T16:24:33.483Z
blocker_discovered: false
---

# T03: Added the Fence (.fnc) exporter and importer with generated fixture art, ported ComposeFences, FillSegmentProps and LoadRPGStats, and the index-hole refusal; golden comparison stays pending.

**Added the Fence (.fnc) exporter and importer with generated fixture art, ported ComposeFences, FillSegmentProps and LoadRPGStats, and the index-hole refusal; golden comparison stays pending.**

## What Happened

Extended resource_editor_fixtures.zig so the fnc fixture has a fences directory with <item>.tga and <item>s.tga per FENCE_PROPS item, and gave project.fnc at least one segment per direction with locked tiles, transparences and a SpritePos. Added items/fence/fence_export.cpp porting CFenceFrame::ExportFrameData (with the freeIndexes>1 refusal, message kept and translated, reported in SExportOutcome and writing no files), FenceTreeRootItem::ComposeFences (4 directions x 4 insert types, shadow file, ComposeSingleSprite with bFence), and FillSegmentProps via T01's TilesToGrid; bStatsOnly is supported and 'fnc' is registered in exporter.cpp. Ported LoadRPGStats into BkResImportFromGame. Bridge tests cover fixture export, SFenceRPGStats import->export->import, DDS within the dxt gate, the index-hole refusal, and a townfence round trip (461 fields, 0 differences, 80 excused). The previous session was cut off before recording completion; on resume I found two test compile errors (const GetBuffer on CArray2D, missing Scene.h include for IScene) and fixed them.

## Verification

All five verify commands exit 0 after the test fixes. The comparator prints 'GOLDEN fnc pending'. The bridge test prints FENCE ORIGIN matching expected, FENCE GRAPHICS within the gate, FENCE HOLE with 0 files written, and ROUNDTRIP fnc townfence with 0 differences.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build make-resource-fixtures` | 0 | pass | 5000ms |
| 2 | `zig build test-resource-editor-fixtures` | 0 | pass | 850ms |
| 3 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 20000ms |
| 4 | `zig build test-resource-model-comparator -Dtest-mode=run` | 0 | pass | 20850ms |
| 5 | `zig build test-resource-model -Dtest-mode=run` | 0 | pass | 20230ms |

## Deviations

none

## Known Issues

GOLDEN fnc is pending until goldens are exported on win-home. The full resource sweep is left to the maintainer.

## Files Created/Modified

- `Sources/src/ResourceModel/items/fence/fence_export.cpp`
- `Sources/src/ResourceModel/compose.cpp`
- `Sources/src/ResourceModel/compose.h`
- `Sources/src/ResourceModel/exporter.cpp`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `tools/zig/resource_editor_fixtures.zig`
- `tools/zig/fixtures/resource_editor/fnc/project.fnc`
- `tools/zig/resource_model_comparator_test.cpp`
- `build.zig`
