---
id: T05
parent: S09
milestone: M001
key_files:
  - Sources/editor/resource_app/grid_logic.zig
  - Sources/editor/resource_app/panels.zig
  - Sources/editor/resource_app/docks.zig
  - Sources/editor/resource_app/docks_check.zig
  - Sources/src/EditorBridge/resource_bridge.cpp
  - Sources/src/EditorBridge/resource_bridge_test.cpp
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-05T16:44:29.191Z
blocker_discovered: false
---

# T05: Added headless grid_logic.zig (view<->tile mapping, tool modes, overlay colour rules, per-kind registration), grid-frame toolbar and overlay drawing in panels.zig, and obt/fnc preview wiring with a bridge capture.

**Added headless grid_logic.zig (view<->tile mapping, tool modes, overlay colour rules, per-kind registration), grid-frame toolbar and overlay drawing in panels.zig, and obt/fnc preview wiring with a bridge capture.**

## What Happened

Added Sources/editor/resource_app/grid_logic.zig with the view<->tile mapping (same trig as GridProjection), tool modes (Move, Draw grid, Draw transparency 0..7, Set zero, One-way line, Centre on tile), mouse-to-grid_tools mapping and overlay colour rules, plus a per-kind registration for S10/S11. panels.zig draws the 60x60 grid, tiles, lines and zero over the preview, with toolbar entries and a transparency combo; docks/docks_logic gained fence insert-type and segment selection via the thumbnail dock. The bridge has obt/fnc preview kinds and resource_bridge_test.cpp captures a frame per kind. Resuming after interruption, I found no T05 summary on disk, reran the verify tiers, and found resource-editor-host-check failing: docks_check.zig still asserted that importing .obt from game data is refused, but T02 ported that importer. I switched that assertion (and the PASS message in main.zig) to .build (.bld), which is still unported.

## Verification

Ran every verify tier in the foreground: test-resource-app-logic, test-resource-core, test-resource-bridge, install-resource-editor, resource-editor-host-check (after the fix) and resource-editor-smoke all exit 0. The full resource sweep is left to the maintainer.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-app-logic -Dtest-mode=run` | 0 | pass | 510ms |
| 2 | `zig build test-resource-core -Dtest-mode=run` | 0 | pass | 1240ms |
| 3 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 33470ms |
| 4 | `zig build install-resource-editor` | 0 | pass | 60000ms |
| 5 | `zig build resource-editor-host-check` | 0 | pass (after docks_check fix) | 60000ms |
| 6 | `zig build resource-editor-smoke` | 0 | pass | 30000ms |

## Deviations

Updated docks_check.zig and main.zig so the unported-import refusal check targets .bld instead of .obt, since .obt import now exists. Durations for the last three evidence rows are approximate.

## Known Issues

None.

## Files Created/Modified

- `Sources/editor/resource_app/grid_logic.zig`
- `Sources/editor/resource_app/panels.zig`
- `Sources/editor/resource_app/docks.zig`
- `Sources/editor/resource_app/docks_check.zig`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
