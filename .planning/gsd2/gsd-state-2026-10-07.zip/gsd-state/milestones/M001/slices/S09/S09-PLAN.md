# S09: Object, Fence sub-editors (grid-frame tools)

**Goal:** Object (.obt) and Fence (.fnc) sub-editors: grid tools (passability, zero, transparency cells, one-way trans-lines, centre-on-tile, move) all undoable, with get/set state checked before and after each edit; ported exporters and importers; repo-fixture golden comparison (pending win-home); a measured preview shot of grid + transparency overlay; one BK_EDITOR_AUTO scenario per kind. Covers 06-PARITY B-10.1..B-10.5 and B-11.1..B-11.5.
**Demo:** Grid tools (passability, zero, transparency, trans-lines) all undoable with set+get before and after state. Golden parity on repo fixtures; import-and-export round trip; preview shot showing grid + transparency overlay; auto scenario.

## Must-Haves

- test-resource-model has GridProjection and tile-list/grid/origin tests that match values computed by hand from MFC GridFrm.cpp; a non-zero vOrigin case is included.
- Exporters for obt and fnc are registered in exporter.cpp. Each exports the fixture, and the stats read back through the engine's own readers are field-equal to themselves after import -> export. A shipped Data/Objects sample and the Data/Fences/ussr/summer/townfence sample round-trip import -> export field-equal. A fence with index holes is refused with MFC's message.
- The comparator prints 'GOLDEN obt pending' and 'GOLDEN fnc pending'. These are never shown as pass without a win-home golden.
- New bridge channels transparency_cells=17, fence_transparences=18 and sprite_pos=19 are mirrored in resource_bridge.h/.cpp, bridge.zig, fake_bridge.zig and c_bridge.zig. Setting passability_cells updates the desc origin consistently. HasNoPrivateGeometry stays true.
- In test-resource-core, every grid tool (brush stroke, transparency brush, trans-line, set zero, centre fence on tile, sprite move) asserts geometry before the edit, after it, after undo and after redo.
- test-resource-app-logic covers the view<->tile mapping, which must agree with the C++ GridProjection on shared sample points, and the toolbar/tool state.
- resource-editor-auto runs the obt and fnc blocks: edit, undo/redo, save, export, and a captured shot. Code measures the locked red 0xffff0000 and transparency yellow overlay pixels in that shot.
- 06-PARITY rows B-10.x and B-11.x carry evidence (goldens pending win-home). The spec's channel table records channels 17-19.
- Map Editor smoke and the editor-core tiers stay green.

## Proof Level

- This slice proves: Contract and integration on Linux x64: the engine's own readers prove the exported stats, measured TGA captures prove the overlays, and headless core/app tests prove undo. MFC golden equality is pending the maintainer's win-home run. macOS and Windows are left to CI, and the full sweep is left to the maintainer.

## Integration Closure

The app's grid toolbar drives resource_core/grid_tools.zig. That emits geometry commands through c_bridge.zig to the BkRes* geometry channels, which save in MFC's own_data/desc layout. BkResExport then calls the registered obt/fnc exporters, which use GridProjection and the compose helpers. BkResImportFromGame reads shipped 1.xml back. S10 and S11 reuse GridProjection, the compose helpers, grid_tools.zig and the scenario verbs as they are.

## Verification

- Export refusals and warnings, such as fence index holes or missing sprites, go into SExportOutcome and the app status line. The comparator prints GOLDEN obt/fnc pass|FAIL|pending. Auto scenario logs name each measured overlay colour count.

## Tasks

- [x] **T01: GridProjection, normal tiles and tile-list <-> grid+origin helpers (C++), tested headless** `est:3h`
  Why: every grid tool, both exporters and both importers depend on MFC's tile math. S10 (Building) and S11 (Bridge) reuse it too. test-resource-model must run without a window (D020).
  - Files: `Sources/src/ResourceModel/grid_projection.h`, `Sources/src/ResourceModel/grid_projection.cpp`, `Sources/src/ResourceModel/items/ai_tiles.h`, `Sources/src/ResourceModel/items/ai_tiles.cpp`, `tools/zig/resource_grid_projection_test.cpp`, `build.zig`
  - Verify: zig build test-resource-model -Dtest-mode=run

- [x] **T02: Object fixture art, Object exporter + importer, golden comparison pending** `est:4h`
  Why: B-10.4 and B-10.5. No obt exporter exists. The fixture project.obt refers to 1/1s/1w/1ws/1a/1as.tga, which do not exist, and it has no own_data/desc.
  - Files: `tools/zig/resource_editor_fixtures.zig`, `tools/zig/fixtures/resource_editor/obt/project.obt`, `tools/zig/fixtures/resource_editor/EXTENSIONS.md`, `tools/zig/fixtures/resource_editor/obt/golden/README.md`, `Sources/src/ResourceModel/compose.h`, `Sources/src/ResourceModel/compose.cpp`, `Sources/src/ResourceModel/items/object/object_export.cpp`, `Sources/src/ResourceModel/exporter.cpp`, `Sources/src/EditorBridge/resource_bridge.cpp`, `Sources/src/EditorBridge/resource_bridge_test.cpp`, `tools/zig/resource_model_comparator_test.cpp`, `build.zig`
  - Verify: zig build make-resource-fixtures && zig build test-resource-editor-fixtures && zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model-comparator -Dtest-mode=run && zig build test-resource-model -Dtest-mode=run

- [x] **T03: Fence fixture art, Fence exporter + importer with index-hole refusal** `est:4h`
  Why: B-11.4 and B-11.5. The fnc fixture's Fences directory is empty, and no fnc exporter exists.
  - Files: `tools/zig/resource_editor_fixtures.zig`, `tools/zig/fixtures/resource_editor/fnc/project.fnc`, `tools/zig/fixtures/resource_editor/EXTENSIONS.md`, `tools/zig/fixtures/resource_editor/fnc/golden/README.md`, `Sources/src/ResourceModel/compose.h`, `Sources/src/ResourceModel/compose.cpp`, `Sources/src/ResourceModel/items/fence/fence_export.cpp`, `Sources/src/ResourceModel/exporter.cpp`, `Sources/src/EditorBridge/resource_bridge.cpp`, `Sources/src/EditorBridge/resource_bridge_test.cpp`, `tools/zig/resource_model_comparator_test.cpp`, `build.zig`
  - Verify: zig build make-resource-fixtures && zig build test-resource-editor-fixtures && zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model-comparator -Dtest-mode=run && zig build test-resource-model -Dtest-mode=run

- [x] **T04: Bridge channels 17-19, passability origin consistency, and kind-agnostic grid tools in resource_core** `est:4h`
  Why: the slice goal says every grid tool is undoable, with get/set state checked before and after. Today object transparency cells, fence transparences and sprite position have no channel, and setting passability_cells leaves the desc origin stale.
  - Files: `Sources/src/EditorBridge/resource_bridge.h`, `Sources/src/EditorBridge/resource_bridge.cpp`, `Sources/src/EditorBridge/resource_bridge_test.cpp`, `Sources/editor/resource_core/bridge.zig`, `Sources/editor/resource_core/fake_bridge.zig`, `Sources/editor/resource_core/grid_tools.zig`, `Sources/editor/resource_core/root.zig`, `Sources/editor/resource_app/c_bridge.zig`
  - Verify: zig build test-resource-core -Dtest-mode=run && zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-app-logic -Dtest-mode=run && zig build test-editor-core -Dtest-mode=run

- [x] **T05: App: grid-frame toolbar, view<->tile mapping, overlay drawing, obt/fnc preview** `est:4h`
  Why: B-10.2/B-10.3 and B-11.2/B-11.3 need the tools in the app, with the grid and transparency overlay drawn over the preview.
  - Files: `Sources/editor/resource_app/grid_logic.zig`, `Sources/editor/resource_app/main.zig`, `Sources/editor/resource_app/panels.zig`, `Sources/editor/resource_app/docks.zig`, `Sources/src/EditorBridge/resource_bridge.cpp`, `Sources/src/EditorBridge/resource_bridge_test.cpp`, `build.zig`
  - Verify: zig build test-resource-app-logic -Dtest-mode=run && zig build test-resource-core -Dtest-mode=run && zig build test-resource-bridge -Dtest-mode=run && zig build install-resource-editor && zig build resource-editor-host-check && zig build resource-editor-smoke

- [x] **T06: BK_EDITOR_AUTO obt/fnc blocks with measured overlay shots, PARITY rows, spec channel table, tier run** `est:3h`
  Why: the slice demo asks for a preview shot with the grid + transparency overlay, measured by code, and one auto scenario per kind. The parity rows and the spec must record the evidence and the new channels.
  - Files: `Sources/editor/resource_app/scenario.zig`, `build.zig`, `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`, `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`
  - Verify: zig build install-resource-editor && zig build resource-editor-auto && zig build resource-editor-smoke && zig build resource-editor-host-check && zig build test-resource-app-logic -Dtest-mode=run && zig build test-resource-core -Dtest-mode=run && zig build test-editor-core -Dtest-mode=run && zig build map-editor-smoke

## Files Likely Touched

- Sources/src/ResourceModel/grid_projection.h
- Sources/src/ResourceModel/grid_projection.cpp
- Sources/src/ResourceModel/items/ai_tiles.h
- Sources/src/ResourceModel/items/ai_tiles.cpp
- tools/zig/resource_grid_projection_test.cpp
- build.zig
- tools/zig/resource_editor_fixtures.zig
- tools/zig/fixtures/resource_editor/obt/project.obt
- tools/zig/fixtures/resource_editor/EXTENSIONS.md
- tools/zig/fixtures/resource_editor/obt/golden/README.md
- Sources/src/ResourceModel/compose.h
- Sources/src/ResourceModel/compose.cpp
- Sources/src/ResourceModel/items/object/object_export.cpp
- Sources/src/ResourceModel/exporter.cpp
- Sources/src/EditorBridge/resource_bridge.cpp
- Sources/src/EditorBridge/resource_bridge_test.cpp
- tools/zig/resource_model_comparator_test.cpp
- tools/zig/fixtures/resource_editor/fnc/project.fnc
- tools/zig/fixtures/resource_editor/fnc/golden/README.md
- Sources/src/ResourceModel/items/fence/fence_export.cpp
- Sources/src/EditorBridge/resource_bridge.h
- Sources/editor/resource_core/bridge.zig
- Sources/editor/resource_core/fake_bridge.zig
- Sources/editor/resource_core/grid_tools.zig
- Sources/editor/resource_core/root.zig
- Sources/editor/resource_app/c_bridge.zig
- Sources/editor/resource_app/grid_logic.zig
- Sources/editor/resource_app/main.zig
- Sources/editor/resource_app/panels.zig
- Sources/editor/resource_app/docks.zig
- Sources/editor/resource_app/scenario.zig
- .planning/phases/06-resource-editor-portable-port/06-PARITY.md
- docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md
