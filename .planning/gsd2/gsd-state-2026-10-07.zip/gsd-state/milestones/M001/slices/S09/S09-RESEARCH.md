# S09 Research: Object and Fence sub-editors (grid-frame tools)

**Depth: targeted, with one high-risk finding.** The bridge and core already carry most grid geometry channels. Missing: any Object/Fence exporter (no exporter is registered for any kind yet), any grid tool in the app, a bridge channel for transparency cells, and fixture art.

## Summary

S09 covers parity rows B-10.1..B-10.5 (Object, `.obt`) and B-11.1..B-11.5 (Fence, `.fnc`) in `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`. All ten are `todo`. The slice goal is:
- grid tools: passability, zero, transparency cells, one-way trans-lines, centre-fence-on-tile, move;
- every tool undoable, with set+get before/after state;
- golden parity, import round trip, a measured preview shot showing grid + transparency overlay, one `BK_EDITOR_AUTO` scenario.

S05 shipped only the shared shell. `grep geometry Sources/editor/resource_app/*.zig` finds only `c_bridge.zig` (the adapter). No panel, tool or overlay uses it yet, and the exporter registry (`Sources/src/ResourceModel/exporter.{h,cpp}`, `RegisterExporter`/`FindExporter`) has no registrations. `BkResExport` refuses every kind. S06 and S07 are not done, so S09 may be the first exporter to land. Check the order before planning. If S06 lands first, reuse its exporter pattern, comparator wiring and import pattern.

## What exists (reuse)

### MFC sources (the oracle)

All in `Sources/src/editor/`:
- `GridFrm.{h,cpp}` (94 + 420 lines), `CGridFrame`:
  - `ETBStyle` tool modes: MOVE_OBJECT, DRAW_GRID, DRAW_PASS, DRAW_TRANSEPARENCE, SET_ZERO, SET_ENTRANCE, SHOOT/FIRE/SMOKE modes, DRAW_ONE_WAY_TRANSEPARENCE.
  - `ComputeGameTileCoordinates(pt) -> (ftX, ftY)` and `GetGameTileCoordinates(tx, ty) -> 4 corners`: pure trig with `fOX = -622`, `fOY = 296` (static in GridFrm.cpp) and `fCellSizeX/Y`, `alpha = asin(1/sqrt 5)`. Portable as plain math.
  - `SetTileInListOfTiles` (val 0 erases; update-or-append), `SetTileInListOfNormalTiles`, `DeleteTileInListOfNormalTiles`.
  - Tile colours: locked `0xffff0000`, unlocked/entrance `0xff00ff00`, transparency 1..7 = `0xff202000 .. 0xffe0e000` step `0x202000`.
  - `MyCreateGrid`: 60x60 tiles.
  - `SaveIconFile`: writes `icon.tga`, 64 px, cropped on alpha. Shared by Object, Fence and Building.
- `ObjectFrm.{h,cpp}` (1553 lines): `CObjectFrame`. Key members: `lockedTiles`, `transeparences`, `dirTiles` (`CListOfNormalTiles`), `transLines`, `m_zeroPos`, `zeroShift`, `m_transValue` (0..7 combo), `m_SpriteLoadPos`.
  - `ExportFrameData` (436-533) and `SaveRPGStats` (534-737) build `SObjectRPGStats`: Basic Info -> `fMaxHP`, six `defences`, sounds, `dwAIClasses`, effects, `passability` + `vOrigin`, `visibility` + `vVisOrigin`. Then `ComposeAnimations`, `icon.tga` from the first graphic, copy of `name.txt`.
  - `LoadRPGStats` (738-838) is the import half. It rebuilds tiles from `desc` through the scene projection.
  - `Save/LoadFrameOwnData` (840-906): `own_data` = `sprite_pos`, `krest_pos`, `export_file_name`, `TransLines`. Load also reads legacy `export_dir`.
  - Mouse tools: `OnLButtonDown` (952-1117), `OnRButtonDown`, `OnMouseMove`, `OnLButtonUp`. The trans-line tool is a two-click state machine (`bDragging`, `currentLine`, `m_nSelected`). When a line is finished it also writes `dirTiles` along `MyFillBrezenham(p1->p2 in tile coords)` with normal value `UpdateNormalForSelectedLine()` (908-950).
- `ObjTreeItem.{h,cpp}` (384 lines): `ComposeAnimations` loops the graphics children in the order summer ("1"), winter ("1w"), Africa ("1a") and calls `ComposeSingleObjectPack(sprite, shadow, result, zeroPos, pass, vOrigin)` (`BuildCompose.cpp` 147-234, shared with Building / S10).
- `FenceFrm.{h,cpp}` (1076 lines), `FenceTreeItem.{h,cpp}` (504 lines):
  - `ExportFrameData` (416-472) refuses when `freeIndexes.size() > 1`: segments with deleted-index holes cannot be exported.
  - `FenceTreeRootItem::ComposeFences` walks 4 directions x 4 insert types x segments. Per segment it makes `<item>.tga` and `<item>s.tga` (`SaveShadowFile`) from the fences directory, then packs the sprites (`ComposeSingleSprite(..., bFence=true)`), then fills `SSegmentRPGStats` (`FillSegmentProps`, 956-1076).
  - `FillSegmentProps`: `passability` is the min/max bbox of `lockedTiles`, and `vOrigin = vSpritePos - mostLeft3`. `visibility` is the same for `transeparences`.
  - `CenterSpriteAboutTile` (684-708), `SaveMyData`/`LoadMyData` (934-955). The fence frame has no zero point and no trans-lines.
- Sprite and compose helpers, not yet ported (`grep` finds them only under `Sources/src/editor`): `BuildCompose.cpp` (323), `SpriteCompose.cpp` (597: `ComposeSingleSprite`, `BuildSpritesPack`, `SaveCompressedTexture/Shadow`, `SaveTexture8888`).

### ResourceModel (C++)

- `items/object/object.{h,cpp}` (228 lines) and `items/fence/fence.{h,cpp}` (185 lines): the tree items and their InitDefaultValues are ported.
- `CFencePropsItem` carries `vSpritePos`, `lockedTiles`, `transeparences` and `nSegmentIndex` as item fields. They are read and written by `ReadData`/`WriteData` as `LockedTiles` / `Transparences` / `SpritePos`.
- `items/ai_tiles.h` (`SAITile`, `CListOfTiles`) exists. `SAINormalTile` (object `dirTiles`) is NOT ported.
- Object frame state lives in `own_data` / `desc`, which has no tree item. The bridge session acts as the frame (`resource_bridge.cpp` ~661-700, `HomeOf`, `ReadFrameGeometry` ~913, `WriteFrameGeometry` ~1020, `LoadGeometry` / `StoreGeometry` ~1270 / ~1325). On save only edited channels are written back; the rest of the chunk stays as read.

### Bridge (`Sources/src/EditorBridge/resource_bridge.{h,cpp}`)

- Channels already wired and tested (`resource_bridge_test.cpp` `ObjectGeometryInMfcLayout`, `ItemGeometryInMfcLayout`): `passability_cells` (object/building root, `desc/passability`), `locked_tiles` (fence segment or bridge part, `LockedTiles` field), `transparency_lines` (object root, `own_data/TransLines`, 4 floats per line), `zero_point` (object/building root, `own_data/krest_pos`).
- No ABI channel exists for any of the following (the spec lists fence/bridge `Transparences` as a known gap):
  1. object transparency cells (`desc/visibility`) and the `dirTiles` normals;
  2. fence `Transparences`, which round-trip only as item fields;
  3. fence `vSpritePos` (move);
  4. object `sprite_pos` (move);
  5. `vOrigin` / `vVisOrigin`.
- Import (`BkResImportFromGame`) is infantry only. Every other kind answers "not ported yet; it comes with its sub-editor". S09 must add obt and fnc.
- Preview: `BkResPreviewBegin/Show/Stop/Playback/Camera` exist. Preview kinds are in a table near `resource_bridge.cpp` ~3524-3560. `msh` is set up with SGVOT_MESH; object and fence need an SGVOT_SPRITE-style entry. Preview builds from a real export into a temp storage, so an exporter must exist first.

### Core (Zig, `Sources/editor/resource_core`)

- `GeometryChannel` enum (passability_cells=0, locked_tiles=1, transparency_lines=2, zero_point=3, ..., bridge_span_marks=10 ...), `GeometryValue` = bytes_grid / points2 / aimed / vec3 / point2.
- `ResourceCommand.geometry{node, channel, before, after}` and `.composite` (a gesture collapses into ONE undo step). There are root.zig tests for undo/redo of passability, locked_tiles, transparency_lines, zero_point and entrance against `fake_bridge.zig` (1060 lines; it serves all channels).
- This proves the set+get before/after pattern at the core level. The app level has none of it.

### App (`Sources/editor/resource_app`)

- `edit_logic.zig` (inspector widgets), `panels*.zig`, `docks*.zig` (thumbnail list, direction button, function window), `scenario.zig` (BK_EDITOR_AUTO verbs: `new`, `open`, `set_prop`, `undo`, `save`, `pack`, `import`, `run_game`, shot/differ; named actions are dispatched in `Runner.command` ~408), `tools_*.zig` (shared tools).
- There is NO per-kind tool/overlay framework and no view-to-tile mapping. The app has no grid overlay code. The design spec (section "Overlays": grid, passability, points ... drawn with ImGui draw lists) is the plan.

### Fixtures

- `tools/zig/fixtures/resource_editor/obt/` holds `project.obt` and `mesh-2x2x2.obj` only. The generator (`tools/zig/resource_editor_fixtures.zig:90`) gives obt `.art = .mesh`. The project references `1.tga`, `1s.tga`, `1w.tga`, `1ws.tga`, `1a.tga`, `1as.tga`, and none of these exist, so Object export and preview cannot run against the fixture.
- The fixture has no `own_data` or `desc` (`grep` over all `project.*` shows none), so no passability, trans-lines, zero or transparency are present.
- `fnc/` holds `project.fnc` and `art-16x16.tga`. The fence directory is empty (`Fences directory` value = ""). The segment items need `<itemName>.tga` plus a `<itemName>s.tga` shadow in the source directory. Check that the fixture contains at least one FENCE_PROPS item per direction.
- `golden/` holds `.gitkeep` and `README.md` only. Goldens are produced on win-home (`tools/zig/win-home/export-goldens.ps1 -Extensions obt`). `test-resource-model` reports "GOLDEN obt pending: golden missing". **No agent on this Linux machine can produce a golden.** "Golden parity on repo fixtures" can only be met by the golden test being implemented, and it stays "pending, maintainer runs on win-home" per the S03 pattern, never "done". Do not mark B-10.4 / B-11.4 done off a self-made golden.

## Highest risks (prove first)

1. **Tile <-> world projection needs the engine's scene.** MFC computes `vOrigin = zero - mostLeft3`, where `mostLeft3 = IScene::GetPos3(tile corner in screen px)` and the zero pos goes through `GetPos2/GetPos3` plus the zero shift. The export is therefore a function of the preview camera (`GetPos2/GetPos3`). The tile math (`fOX`, `fOY`, `fCellSize`) is pure; the screen<->world step is not. Decide up front where this lives. Recommendation: in the C++ exporter and bridge, using the preview `IScene` (or its constant projection, which is a fixed isometric camera in the editor) behind one small helper, e.g. `NResourceModel::GridProjection` with `Pos2To3` / `Pos3To2`. Test it against hand-computed MFC values. Check whether the engine has a headless way to get the same transform (`Scene.cpp` `GetPos2/GetPos3`, `SceneDraw.cpp`) without a GPU, because `test-resource-model` must not need a window. If the camera is constant, derive the affine form once, hard-code it with a comment, and assert it against the live `IScene` in `test-resource-bridge`.
2. **The bridge's `passability_cells` stores raw `desc/passability`, but the true MFC data is a tile list plus `vOrigin`.** A grid set through the ABI (cell (x,y) = tile (x,y) in the object's tile frame, as for locked_tiles) must, on save and export, be converted to the cropped bbox grid and a new `vOrigin`. Otherwise passability will not line up with the sprite when the engine reads `desc`. Today the bridge writes the grid and leaves `origin` as read (the spec says so: "Other desc fields stay as read. That includes origin, visibility"). Settle the cell-origin convention (cells relative to the tile (0,0) of the grid at `fOX/fOY`, as `locked_tiles` does for fences, vs. the bbox-relative desc layout). Then make the passability set update `origin` consistently, and test import -> set -> export -> import round trip with non-zero origin.
3. **No exporter exists.** Port `CObjectFrame::ExportFrameData` / `SaveRPGStats` and `CFenceFrame::ExportFrameData` / `ComposeFences` / `FillSegmentProps`, `ComposeSingleObjectPack`, `ComposeSingleSprite`, `SaveShadowFile` and `SaveIconFile` into `ResourceModel` (new `items/object/object_export.cpp`, `items/fence/fence_export.cpp`, `compose/` shared with S10 Building and S11 Bridge). `CSpritesPackBuilder` (`Sources/src/RandomMapGen/IB_Types.h`), `IImageProcessor` and `NDxt` are the portable pieces. Register the exporters with `RegisterExporter("obt", ...)` and `RegisterExporter("fnc", ...)`. Look at `legacy_dxt.*` in `ResourceModel/spike` and `dxt-tolerance.json`: the `.san`/DDS parity is "DDS within tolerance, `.san` byte-identical", and the bridge sprite-pack writer must be the one the Building slice reuses.
4. **Fixture art is missing** (above). Extend `resource_editor_fixtures.zig` to generate the sprites, e.g. a small `1.tga` + `1s.tga` set for obt and a fences directory with `<name>.tga` / `<name>s.tga` for fnc, and give the projects non-trivial geometry: a passability grid, some transparency tiles, two trans-lines, a zero point, fence segments with locked tiles and transparences. Re-run `zig build make-resource-fixtures` and update `EXTENSIONS.md`. Changing a fixture changes hashes that other tiers pin (see `test-resource-editor-fixtures`, the sweep `tools/zig/run-resource-sweep.sh`), so re-verify those.
5. **Object transparency cells and `dirTiles` have no channel.** The slice goal says "transparency" and "preview shot showing grid + transparency overlay". Add channels to the ABI and `GeometryChannel` (suggest `transparency_cells` as a bytes_grid with values 0..7, and `transparency_normals` for the direction tiles, or one grid that uses MFC's `(val << 4) | 0x08` encoding as in `desc/visibility`). Also fence `Transparences` (as a tile list like locked_tiles) and the sprite-move channels (`sprite_pos`). Each new channel must be mirrored in `bridge.zig` `GeometryChannel`, `fake_bridge.zig`, `c_bridge.zig` pairs, `resource_bridge.h`/`.cpp`, `HomeOf` and the spec's channel table (the AGENTS.md rule: record the change in the spec). Keep the numbering append-only (channels 16+) because Zig and C share the ints.
6. **Trans-lines drive `dirTiles`.** `STransLine` also has a computed normal (`UpdateNormalForSelectedLine`) that sets the `dirTiles` value along a Bresenham line. A core-level trans-line command that only sets the point list would not reproduce `desc/visibility` on export. The exporter must derive `dirTiles` from the lines (as `LoadFrameOwnData` does for the normals) or the tool must write both in one composite command. The derived approach is safer: the data is a function of the saved lines (verify against MFC which saves only `TransLines`, and that `dirTiles` is rebuilt from `desc` on load only).
7. **Fence export refusal on index holes** (`freeIndexes.size() > 1`) must be kept: the exporter returns an error with the same message, and the app shows it. Test it.

## Natural seams (task decomposition)

1. **Model and projection (C++):** `GridProjection` (tile<->world, `fOX/fOY`, `fCellSize`), `SAINormalTile` port, and the tile list <-> cropped grid + origin helpers used by both Object (`lockedTiles`, `transeparences`, `dirTiles`) and Fence (`FillSegmentProps`), written once. This is the reusable grid seam for **S10 (Building: passability, entrance, fire/smoke points use the same tile math and `SaveIconFile`)** and **S11 (Bridge: `UnLockedTiles`, `Transparences`, per-part `locked_tiles`)**. Test headless in `test-resource-model` (new file beside `comparator`) with tile <-> corners <-> tile round trips and the bbox/origin helper on hand-computed cases.
2. **Bridge channels and tests:** new channels (transparency cells, fence transparences, sprite pos), `passability_cells` origin consistency, and import for obt and fnc (`BkResImportFromGame` is infantry-only: generalise to a per-kind importer table that S06/S07/S10 can add to; port `CObjectFrame::LoadRPGStats` and `CFenceFrame::LoadRPGStats`, lines 346-381 for fence). Test in `resource_bridge_test.cpp` (tier `test-resource-bridge`): channel get -> set -> get, save, reopen, no private geometry (`HasNoPrivateGeometry`), plus exports.
3. **Exporters (C++):** Object and Fence exporters + composers. Test through the comparator (`test-resource-model-comparator`) for goldens (pending) and self-consistency (stats read through the engine's own `SObjectRPGStats` / `SFenceRPGStats` operator&, exact floats). Also import(export(project)) round trip, and import of a shipped object/fence from `Data` (find real samples under `Data/` first; the S06/S07 "shipped sample" pattern, and the sweep `run-resource-sweep.sh` for the maintainer).
4. **Core + fake bridge:** extend `fake_bridge.zig` and `GeometryChannel`, add the grid tool logic as plain-event functions in a new `resource_core/grid_tools.zig` (or `resource_app/grid_logic.zig`): brush stroke -> one `composite` of geometry commands with before/after snapshots; trans-line two-click state machine; set-zero; centre-fence-on-tile; move. These take plain input events (`tile_x`, `tile_y`, `val`, `button`) and emit commands, as the spec says. Make them kind-agnostic: parameterise by node + channel so S10 and S11 reuse them as is. Unit tests in `test-resource-core` with set+get before/after (assert `geometryRead` before the edit, after, after undo, after redo, for each tool).
5. **App UI (Zig + ImGui):** a grid-frame toolbar (Move, Draw grid, transparency value combo 0..7, Set zero, one-way line, Centre on tile), grid and overlay drawing with ImGui draw lists over the preview (needs the view<->tile mapping from seam 1 exposed either through the bridge or reimplemented in Zig as the same trig, with a test that both agree), the key/mouse handling, and a per-kind tool registration that S10/S11 extend. Test headlessly in `test-resource-app-logic`.
6. **Preview + auto:** add the object (sprite scene) and fence preview kinds, then a `BK_EDITOR_AUTO` scenario `obt`/`fnc`: open, draw tiles, transparency, a trans-line, set zero, undo, redo, save, export, capture the shot, and have the code measure the overlay colours (locked red `0xffff0000`, transparency yellows `0xff202000..`) in the TGA. Needs new scenario verbs, e.g. `do=grid_cell:<x>,<y>,<val>`, `do=trans_line:...`, `do=set_zero:...` in `scenario.zig`. Capture and measure with `kit.auto_schedule.Tga`, as the existing shots do. Then `resource-editor-auto` runs it.
7. **Parity doc + spec:** update 06-PARITY.md rows B-10.1..B-11.5 with evidence (goldens "pending win-home"), and the spec channel table.

## Verification commands (each well under 10 minutes; foreground)

- `zig build test-resource-core` and `zig build test-resource-app-logic` (headless, fast, first proof for tools and undo).
- `zig build test-resource-model` (aggregate: fidelity, comparator, references; goldens report pending).
- `zig build test-resource-bridge` (needs engine, skips with "no GPU device" where there is none; covers the geometry, import, export, preview captures).
- `zig build test-resource-editor-fixtures` after changing fixtures; `zig build make-resource-fixtures` to regenerate.
- `zig build install-game install-resource-editor` then `resource-editor-host-check`, `resource-editor-smoke`, `resource-editor-auto`. Under the gsd_exec sandbox the GUI tiers fail with "SdlInitFailed: No available video device"; run them from the real shell, one at a time.
- Keep the Map Editor tiers green if any kit or shared code is touched (see AGENTS.md list).
- Full sweep `tools/zig/run-resource-sweep.sh` (~27 min) is left to the maintainer; record that in the slice summary. macOS and Windows CI results cannot be seen here; do not claim them. Never write into shipped `Data/`; use `zig-out/local-test/...`.

## Constraints and gotchas

- CRLF for all new text files; match surrounding comment style (Zig doc comments say why).
- Geometry values are written with MFC's `%g` (six significant digits); keep `HasNoPrivateGeometry` true.
- The channel enum ints are a shared ABI between `bridge.zig`/`resource_bridge.cpp`; append only.
- A stats-only export (D-13) must leave existing graphics alone; honour `bStatsOnly` in the new exporters.
- MFC messages are in Windows-1251 mojibake comments (read-only); do not "fix" them.
- Import must be tested on a real shipped object and fence folder (`1.xml` from `Data`); `desc` tile reconstruction depends on projection (risk 1), so cover a non-zero `vOrigin` case.
- B-10.1/B-11.1 (tree) and B-11.3 (thumbnail list) are largely covered by S05's tree, inspector and thumbnail dock; confirm and mark `done` with evidence rather than rebuilding. "Insert" and per-segment properties for fence (`SetActiveFenceInsertItem`, `EditFence`, `SwitchToEditMode`, `ClickOnThumbList`, `DoubleClickOnThumbList`) still need UI wiring.

## Reusable seams to note for S10 (Building) and S11 (Bridge)

- `GridProjection` and the tile list <-> grid + origin helpers (C++), including `SaveIconFile`.
- The compose helpers `ComposeSingleObjectPack` / `ComposeSingleSprite` (Building and Bridge call the same ones).
- Kind-agnostic grid tool functions emitting `geometry` and `composite` commands, with the toolbar/overlay registration point in the app.
- The per-kind importer table in `BkResImportFromGame` and the exporter registration pattern.
- New channels such as transparency cells and tile lists (the Bridge's `UnLockedTiles` / `Transparences` are on the spec's known-gap list and fit the same channel type).
- The scenario verbs for grid actions.
