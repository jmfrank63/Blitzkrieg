---
id: T05
parent: S15
milestone: M001
key_files:
  - Sources/editor/resource_app/gui_logic.zig
  - Sources/editor/resource_app/gui_dock.zig
  - Sources/editor/resource_app/docks.zig
  - Sources/editor/resource_app/main.zig
  - Sources/editor/resource_app/settings.zig
  - Sources/editor/resource_app/panels_logic.zig
key_decisions:
  - Gestures only preview while the button is down and commit once on release, so Escape has nothing to roll back.
  - Create new template writes only to <settings dir>/templates, flat, named <Folder>NN.xml; hidden runs have no folder and the item is disabled.
duration: 
verification_result: passed
completed_at: 2026-10-06T04:32:15.903Z
blocker_discovered: false
---

# T05: Added the GUI canvas, template palette, inspector, align menu and clipboard to the Resource Editor app, with gesture logic in gui_logic.zig tested against the fake bridge.

**Added the GUI canvas, template palette, inspector, align menu and clipboard to the Resource Editor app, with gesture logic in gui_logic.zig tested against the fake bridge.**

## What Happened

gui_logic.zig (no ImGui) holds the canvas View (1024x768 fitted), the Selection (primary first; click, shift-click, rubber band), and an Overlay with modes free/select/drag/resize/draw. Press/move only preview; release commits ONE gui_tools command through tools.commit, and Escape cancels with no history entry. It also covers arrow nudge, delete, copy/cut/paste through an app clipboard (paste puts the copied group's top left 50 inside the root, as OnEditPaste), palette drop and armed draw (inserted under the topmost dialog under the point, else the root), align and equal size, inspector rect and attribute edits, a status line, palette parsing, and templateFromClipboard/nextTemplateName for Create new template. gui_dock.zig draws the canvas (outlined rects, class labels, highlighted primary, 8 handles, previews), the Templates palette (drag source and armed click), the inspector (Pos/Size/anchors as one rect edit; ElementID, VisibleFlag, ActiveFlag, TextKey and others as SetAttr commands), a context menu and an Edit-menu Align submenu. Create new template writes only into the user folder (settings.templatesPath, beside the settings file; empty and disabled in hidden runs). Wired into docks.zig, main.zig and settings.zig; gui_logic is registered via panels_logic.zig's test block, which is the root of test-resource-app-logic. T01's Mission image path is untouched.

## Verification

All five verify commands exit 0. test-resource-app-logic reports 181/181 tests passed, including 12 new gui_logic tests: view fit, drag with anchors kept, handle resize with MINIMAL clamp, rubber band, align and equal size with undo and redo, paste offset, cut, Escape, template drop and armed draw, nudge and inspector edits, palette parse, template text, status line. New files are CRLF.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-app-logic -Dtest-mode=run` | 0 | pass (181/181 tests) | 1000ms |
| 2 | `zig build test-resource-core -Dtest-mode=run` | 0 | pass | 700ms |
| 3 | `zig build install-resource-editor` | 0 | pass | 4000ms |
| 4 | `zig build resource-editor-host-check` | 0 | pass | 5800ms |
| 5 | `zig build resource-editor-smoke` | 0 | pass | 5700ms |

## Deviations

The Align menu is in the canvas context menu, a canvas toolbar and the Edit menu (GuiDock.drawEditMenuItems, called from main.zig), not in tools_ui.zig, because Tools has no access to the GUI dock state. The canvas, palette and inspector are drawn from a new gui_dock.zig that docks.zig owns, instead of inside docks.zig. Live drag feedback is a preview outline, not the window moving during the drag.

## Known Issues

The canvas, palette, inspector and Create new template have no interactive or scenario coverage yet: no real-bridge drive of the ImGui code and no measured Game frame (resource-editor-auto-gui is a later task). Create new template's file write is not unit-tested, only its text and name helpers. The git tree still shows T04's files (document.zig, history.zig, root.zig, gui_geometry.zig, gui_tools.zig) as uncommitted. Full sweep left to the maintainer.

## Files Created/Modified

- `Sources/editor/resource_app/gui_logic.zig`
- `Sources/editor/resource_app/gui_dock.zig`
- `Sources/editor/resource_app/docks.zig`
- `Sources/editor/resource_app/main.zig`
- `Sources/editor/resource_app/settings.zig`
- `Sources/editor/resource_app/panels_logic.zig`
