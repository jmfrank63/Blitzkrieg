---
estimated_steps: 3
estimated_files: 11
skills_used: []
---

# T01: S14 review fix: Mission image view shows map_h.dds as CMissionFrame does (D032)

Why: D032, hard steers 2026-10-06T03:21 and 03:30. This task runs before every GUI task, and the slice must not complete without it. CMissionFrame (Sources/src/editor/MissionFrm.cpp:206-226) checks whether the Final map exists as Maps\<name>.bzm or .xml. If it does, it creates map_h.dds beside the project with CMinimapCreation::Create1Minimap when that file is missing, and it always shows map_h.dds. Today Sources/editor/resource_app/docks.zig:532 and image_logic.zig:65 (sourcePath) pass <project>/map.xml to BkEditorMinimapImage, which prefers map.tga, and they call BkResMissionMinimap only when that decode fails. So a project with both map.tga and a Final map shows map.tga and never generates the minimap.
Do: (1) Give Mission its own path in image_logic.zig, pure with no ImGui. Add a function that, for kind mission, returns the map_h.dds path beside the project, plus a decision: create when the Final map is set and map_h.dds is missing, show when it exists, and say why when there is no Final map. Keep sourcePath's TGA-first behaviour for chapter, campaign and medal unchanged. Read map_h.dds through the engine decoder: either a BkEditor/BkRes entry point that decodes a named .dds, or BkEditorMinimapImage with a base whose .tga does not exist, whichever the bridge already supports. Do not copy or rename map.tga. If a new ABI entry is needed, add it to resource_bridge.h/.cpp, resource_core/bridge.zig, fake_bridge.zig and c_bridge.zig. (2) In docks.zig, the Mission image branch calls BkResMissionMinimap first when the decision says create and the document is not read-only, then decodes map_h.dds. A refused minimap shows the bridge's message and no picture. An existing map_h.dds is not regenerated on selection, matching MFC's GetFileAttributes check. (3) Tests, using only tracked fixtures copied to zig-out/local-test: image_logic tests in test-resource-app-logic for the mission decision table (Final map set with map_h.dds missing gives create then show; map_h.dds present gives show without create; no Final map gives the message; chapter, campaign and medal paths unchanged). Fake-bridge tests that selection on a scratch mission with map.tga and no map_h.dds calls missionMinimap once and a second selection does not call it again. A resource_bridge_test.cpp case on a scratch copy of tools/zig/fixtures/resource_editor/mip/final-map with map.tga present and no map_h.dds: after the minimap is made, the decoded picture has map_h.dds's size and pixels, not map.tga's. (4) Add a step to resource-editor-auto-mip in build.zig: copy map.tga into the scratch project before image_select, with Final map road3d available and no map_h.dds. After selection, expect the file {dir}/mip/map_h.dds, and measure that the shown picture is the generated minimap, not map.tga: compare the shot's picture against map_h.dds decoded by code, extending scenario.zig's shot_picture or adding an expect such as image_source:map_h.dds. Keep the existing marker, undo, redo and export checks passing and the step under about 3 minutes. (5) Mark the PARITY row for the Mission image frame in .planning/phases/06-resource-editor-portable-port/06-PARITY.md done with the test names and the auto step. Use CRLF. Do not touch the in-progress GUI files (Sources/src/ResourceModel/ui_screen.*, which belong to T02) beyond leaving them as they are.
Done when: verify exits 0, D032 can be marked resolved, and git status shows nothing this task touched as modified or untracked.

## Inputs

- `Sources/src/editor/MissionFrm.cpp`
- `Sources/editor/resource_app/image_logic.zig`
- `Sources/editor/resource_app/docks.zig`
- `Sources/editor/resource_app/docks_logic.zig`
- `Sources/editor/resource_app/scenario.zig`
- `Sources/editor/resource_app/c_bridge.zig`
- `Sources/editor/resource_core/bridge.zig`
- `Sources/editor/resource_core/fake_bridge.zig`
- `Sources/src/EditorBridge/bridge.h`
- `Sources/src/EditorBridge/resource_bridge.h`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `tools/zig/fixtures/resource_editor/mip/final-map/project.mip`
- `build.zig`

## Expected Output

- `Sources/editor/resource_app/image_logic.zig`
- `Sources/editor/resource_app/docks.zig`
- `Sources/editor/resource_app/scenario.zig`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `build.zig`
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`

## Verification

zig build test-resource-app-logic -Dtest-mode=run && zig build test-resource-core -Dtest-mode=run && zig build test-resource-bridge -Dtest-mode=run && zig build install-resource-editor && zig build resource-editor-auto-mip && zig build resource-editor-auto-chc && zig build resource-editor-auto-mdc

## Observability Impact

The image frame says which file it decoded and whether it created map_h.dds; a refused minimap shows BkResMissionMinimap's message. The auto-mip step prints the measured picture comparison.
