---
id: T02
parent: S15
milestone: M001
key_files: []
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-06T03:45:05.610Z
blocker_discovered: false
---

# T02: Added CUiScreen, a text-preserving UI screen model (open, SetRect, SetAttribute, InsertFromTemplate, Delete, CopyText/Paste, Save, SaveAsBase), checked against the engine's IDataTree reader on every shipped screen and template.

**Added CUiScreen, a text-preserving UI screen model (open, SetRect, SetAttribute, InsertFromTemplate, Delete, CopyText/Paste, Save, SaveAsBase), checked against the engine's IDataTree reader on every shipped screen and template.**

## What Happened

Continued the uncommitted drafts: ui_screen.{h,cpp} in NResourceModel with a span-keeping parser, plus ui_screen_test.cpp, wired into the ResourceModel library and the test-resource-model comparator in build.zig and tools/zig/resource_model_comparator_test.cpp (RunUiScreenTests). The first run failed on one assertion: 37 of 112 shipped Data/UI screens have child windows with no WindowPos (scrollbar buttons placed by PositionFlag alone, e.g. AddUnitToMission.xml:161). That was a wrong test premise, not a model bug, so the check now reports how many screens Validate flags and requires only that not all are flagged. The new files were LF and were converted to CRLF as required.

## Verification

zig build test-resource-model -Dtest-mode=run exits 0 with VERDICT=PASS and 29 ui_screen PASS lines. They cover: byte-identical unedited save for every Data/UI base screen and every Data/Editor/UI template; model windows equal to the engine reader's; the MainMenu edit scenario (move, resize, insert Button00, delete) read back through the engine; a GUI_Composer_Project root opening and SaveAsBase giving a readable base root; malformed input failing with file and line; refused edits leaving the screen untouched.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-model -Dtest-mode=run` | 0 | pass | 0ms |

## Deviations

None.

## Known Issues

None.

## Files Created/Modified

None.
