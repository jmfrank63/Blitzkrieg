---
id: T03
parent: S15
milestone: M001
key_files: []
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-06T04:17:15.985Z
blocker_discovered: false
---

# T03: Added the BkResGui* bridge ABI (windows, set rects, insert template, delete, copy/paste, attrs, templates), the gui exporter writing <mod>/data/ui/<Screen>.xml as a <base> screen, and mirrored them in the Zig bridge, fake bridge and C adapter.

**Added the BkResGui* bridge ABI (windows, set rects, insert template, delete, copy/paste, attrs, templates), the gui exporter writing <mod>/data/ui/<Screen>.xml as a <base> screen, and mirrored them in the Zig bridge, fake bridge and C adapter.**

## What Happened

A gui-kind session now holds a CUiScreen. BkResOpen opens a .gui or .xml with a <base> or GUI_Composer_Project root as kind gui (20), and the palette-tree fixture still opens as before. BkResSave goes through the safe-save path. The BkResGui* entry points are documented in resource_bridge.h and traced under BK_DEBUG_LOG. gui_export.{h,cpp} is registered in exporter.cpp and build.zig. It writes SaveAsBase to the plain overlay path data/ui/<Screen>.xml (the screen name comes from the opened file) and refuses targets inside shipped Data, naming the path and the reason. bridge.zig, fake_bridge.zig (in-memory window list with the same id semantics) and c_bridge.zig mirror the ABI. resource_bridge_test.cpp has new tests on a MainMenu.xml copy. They cover: open as gui, windows list, set rects then save and reopen, insert/delete/copy/paste counts, export read back by the engine IDataTree reader with the edited rect, shipped-Data refusal, and the palette fixture round-trip.

## Verification

Ran the four verify commands in the foreground after the interrupted session; all exited 0.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 69000ms |
| 2 | `zig build test-resource-core -Dtest-mode=run` | 0 | pass | 60000ms |
| 3 | `zig build test-resource-model -Dtest-mode=run` | 0 | pass | 60000ms |
| 4 | `zig build test-editor-bridge -Dtest-mode=run` | 0 | pass | 120000ms |

## Deviations

None.

## Known Issues

None.

## Files Created/Modified

None.
