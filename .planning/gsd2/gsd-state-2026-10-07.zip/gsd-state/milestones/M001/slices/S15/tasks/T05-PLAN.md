---
estimated_steps: 3
estimated_files: 7
skills_used: []
---

# T05: GUI canvas dock, template palette, align menu, clipboard and inspector in the app

Why: B-21.1 to B-21.7 need the interactive editor. This follows the squad_logic.zig and image_logic.zig overlay pattern of press, move and release, with one command on release.
Do: (1) Add Sources/editor/resource_app/gui_logic.zig with no ImGui: the canvas view (1024x768 canvas scaled to fit, screen and canvas transforms), the selection (primary plus others, click, shift-click, rubber band), and the modes free, select, drag, resize and draw, after GUIFrame2.cpp. The overlay's press, move, release and cancel commit one T04 command on release; Escape cancels with no history entry. It also handles arrow nudge, drop of a palette template at a canvas point, align and equal-size menu actions on the selection, and copy, cut and paste through an app clipboard with Ctrl+C/X/V. Paste offsets the copy as MFC's OnEditPaste does (GUIFrame.cpp:441-537). Register it in build.zig's test-resource-app-logic with fake-bridge tests: drag moves by the dragged canvas delta with the anchor kept; handle resize; rubber-band select; align on two selected controls; undo and redo each; paste offset; Escape cancels. (2) Draw the canvas in docks.zig or panels.zig the way the image dock does: an invisible-button canvas, outlined rects with class labels, a highlighted primary selection, and 8 handles. Add the palette dock: a tree of Data/Editor/UI/<Folder> templates plus the user template folder from settings.zig, filled through BkResGuiTemplates, with drag onto the canvas. Add "Create new template" from the selected control (OnCreatenewtemplate, GUIFrame2.cpp:1030), which writes to the user folder only. Put the Align menu (left, top, right, bottom, equal size) on the canvas context menu and in tools_ui.zig. The inspector shows the selected control's attributes (ElementID, PositionFlag, Pos, Size, VisibleFlag, ActiveFlag, TextKey and others) through BkResGuiGetAttr and BkResGuiSetAttr as undoable SetAttr commands. New maps to an empty <base> screen; opening a Data/UI screen works. Keep T01's Mission image path unchanged. Use CRLF.
Done when: verify exits 0 and git status is clean for touched files.

## Inputs

- `Sources/editor/resource_app/image_logic.zig`
- `Sources/editor/resource_app/squad_logic.zig`
- `Sources/editor/resource_app/docks.zig`
- `Sources/editor/resource_app/panels.zig`
- `Sources/editor/resource_app/tools_ui.zig`
- `Sources/editor/resource_app/settings.zig`
- `Sources/editor/resource_app/main.zig`
- `Sources/editor/resource_core/gui_geometry.zig`
- `Sources/editor/resource_core/gui_tools.zig`
- `Sources/editor/resource_app/c_bridge.zig`
- `Sources/src/editor/GUIFrame.cpp`
- `Sources/src/editor/GUIFrame2.cpp`

## Expected Output

- `Sources/editor/resource_app/gui_logic.zig`
- `Sources/editor/resource_app/docks.zig`
- `Sources/editor/resource_app/panels.zig`
- `Sources/editor/resource_app/tools_ui.zig`
- `Sources/editor/resource_app/settings.zig`
- `Sources/editor/resource_app/main.zig`

## Verification

zig build test-resource-app-logic -Dtest-mode=run && zig build test-resource-core -Dtest-mode=run && zig build install-resource-editor && zig build resource-editor-host-check && zig build resource-editor-smoke

## Observability Impact

The canvas status line names the mode, the selection and the last committed command.
