---
estimated_steps: 3
estimated_files: 8
skills_used: []
---

# T06: resource-editor-auto-gui with a Game-measured frame; CI, sweep, PARITY and spec

Why: the slice demo is to place, align, save and test-launch, with the Game loading the edited screen cleanly (D031 item 6, and D028's per-editor auto steps). The slice's last task: it must not finish before T01 (D032) is complete.
Do: (1) Add a gui scenario block in Sources/editor/resource_app/scenario.zig and a resource-editor-auto-gui entry in build.zig's resource_auto_steps, keeping the concatenation compile check. Steps: copy Data/UI/MainMenu.xml into {dir} as the project and open it; drag Buttons/Button00 from the palette with real pointer events to a known canvas point; move it; resize it with a handle; select it plus one shipped button and align left. Measure each step's rects by code through the document, and the drawn frame with shot_colour or a new expect such as gui_rect:<id>/x/y/w/h. Then undo back to the placed state and redo; save; reopen and check the rects are equal; export; run_game with a BK_AUTO_UI shot. The scenario already sets BK_AUTO_UI to 400:shot,440:exit at :1788; reuse it. Add a game-frame check: one baseline Game run with an unedited MainMenu export, then the edited run. Require the frames to differ inside the moved shipped button's old and new rects, scaled from the 1024x768 canvas to the Game shot size, and to be nearly equal elsewhere. Scan the Game log for screen-load errors such as 'can not be loaded' and NI_ASSERT, extending the kit/testlaunch.zig parsers if needed. Keep the step under about 3 minutes. (2) Add the step to .github/workflows/cross-platform.yml where the other resource-editor-auto-* steps run, to tools/zig/run-resource-sweep.sh TIERS, and to AGENTS.md's Resource Editor list. (3) In .planning/phases/06-resource-editor-portable-port/06-PARITY.md, mark B-21.1 to B-21.8 done with evidence (test names, auto step, measured values). Record "Create radio button from selected" and the Set-equal-size and align handlers' absence in MFC as "no behaviour in MFC", with the port's definition. Record MFC's Run and Test-button live mode as replaced by F7 Run Blitzkrieg with the exported mod. (4) In docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md, record D031: screen as document, text preservation, <base> on export, outlined drawing instead of an engine render, and Linux-local proof with macOS and Windows by CI (the roadmap's 'macOS local' becomes 'Linux local' on this machine). Also record D032 (the Mission image frame shows map_h.dds, created first when missing, as CMissionFrame does). Leave the full sweep to the maintainer and record the tiers run. Do not claim macOS or Windows results.
Done when: verify exits 0 and git status shows nothing the task touched as modified or untracked.

## Inputs

- `Sources/editor/resource_app/scenario.zig`
- `Sources/editor/resource_app/gui_logic.zig`
- `Sources/editor/kit/testlaunch.zig`
- `Sources/src/Game/GameMain.cpp`
- `build.zig`
- `.github/workflows/cross-platform.yml`
- `tools/zig/run-resource-sweep.sh`
- `AGENTS.md`
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`
- `Data/UI/MainMenu.xml`

## Expected Output

- `Sources/editor/resource_app/scenario.zig`
- `build.zig`
- `.github/workflows/cross-platform.yml`
- `tools/zig/run-resource-sweep.sh`
- `AGENTS.md`
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`

## Verification

zig build install-game && zig build install-resource-editor && zig build resource-editor-auto-gui && zig build resource-editor-auto-core && zig build resource-editor-auto-mip && zig build resource-editor-auto-mdc && zig build test-editor-core -Dtest-mode=run && zig build map-editor-smoke

## Observability Impact

The auto step prints the measured rects per gesture, the undo and redo values, the differing pixel counts at the old and new rects in the Game frame, and any load-error line found in the Game log.
