---
id: T01
parent: S15
milestone: M001
key_files:
  - Sources/editor/resource_app/image_logic.zig
  - Sources/editor/resource_app/docks.zig
  - Sources/editor/resource_app/scenario.zig
  - Sources/src/EditorBridge/bridge.cpp
  - Sources/src/EditorBridge/bridge.h
  - Sources/src/EditorBridge/resource_bridge_test.cpp
  - build.zig
  - .planning/phases/06-resource-editor-portable-port/06-PARITY.md
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-06T03:41:57.425Z
blocker_discovered: false
---

# T01: The Mission image frame now always shows map_h.dds and creates it first when the Final map is set and the file is missing, as CMissionFrame does (D032).

**The Mission image frame now always shows map_h.dds and creates it first when the Final map is set and the file is missing, as CMissionFrame does (D032).**

## What Happened

image_logic.zig has a pure missionPicture decision (show, create_then_show, no_final_map) and prepareMission, which calls BkResMissionMinimap. sourcePath returns null for a Mission, and chapter, campaign and medal keep their TGA-first behaviour. BkEditorMinimapImage now treats a path ending in .dds as that one picture, with no .tga tried first. docks.zig decides from fileExists on map_h.dds, so an existing file is not regenerated on selection. A refused minimap shows the bridge's message and no picture. The note says which file was decoded and whether it was created. Tests: two image_logic tests (the decision table with the fake's minimap request count, and the refusal path); bridge checks in resource_bridge_test.cpp that map_h.dds decodes by its own name and that a missing .dds is refused; a new scenario predicate shot_minimap. resource-editor-auto-mip now starts with map.tga present and no map_h.dds, expects map_h.dds after selection, and measures the shot against both pictures. In the last run 176 of 256 samples were within 12 of map_h.dds and 0 matched map.tga; the rest lie outside the window's visible area. I changed one thing mid-task: shot_minimap first used a mean-difference threshold, but the window clips part of the picture, so it gates on sample counts instead. Also fixed a non-NUL-terminated path passed to the C call. The 06-PARITY B-14.2 row is updated, in CRLF. The ui_screen.* files and the comparator and build.zig lines for them belong to T02 and were left alone.

## Verification

Ran the plan's verify commands: test-resource-app-logic, test-resource-core and test-resource-bridge with -Dtest-mode=run, install-resource-editor, and resource-editor-auto-mip, -chc and -mdc. All exited 0, after the shot_minimap fixes.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-app-logic -Dtest-mode=run` | 0 | pass | 60000ms |
| 2 | `zig build test-resource-core -Dtest-mode=run` | 0 | pass | 30000ms |
| 3 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 120000ms |
| 4 | `zig build install-resource-editor` | 0 | pass | 60000ms |
| 5 | `zig build resource-editor-auto-mip` | 0 | pass | 120000ms |
| 6 | `zig build resource-editor-auto-chc` | 0 | pass | 120000ms |
| 7 | `zig build resource-editor-auto-mdc` | 0 | pass | 120000ms |

## Deviations

None.

## Known Issues

git status still shows the T02 files (ui_screen.*, the comparator test, the ui_screen_test.cpp line in build.zig) as modified or untracked. They belong to T02 and were left as they were. The bridge test's "differing bytes" check passes mainly because the fixture map.tga is 20x12 and the minimap is 512x512; the auto-mip pixel measurement is the stronger proof.

## Files Created/Modified

- `Sources/editor/resource_app/image_logic.zig`
- `Sources/editor/resource_app/docks.zig`
- `Sources/editor/resource_app/scenario.zig`
- `Sources/src/EditorBridge/bridge.cpp`
- `Sources/src/EditorBridge/bridge.h`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `build.zig`
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`
