---
estimated_steps: 3
estimated_files: 4
skills_used: []
---

# T04: gui_geometry.zig and undoable GUI commands in resource_core

Why: the anchored-coordinate inversion is the main correctness trap (D031 item 3). Every gesture must be one undo step with redo.
Do: (1) Add Sources/editor/resource_core/gui_geometry.zig, pure and without the bridge. Port GetElementRect and SetElementRect from Sources/src/editor/GUIFrame2.cpp:16-120 line for line. The horizontal anchor is flag & 0xf (LEFT=1, HMID=2, RIGHT=3) and the vertical anchor is flag & 0xf0 (TOP=0x10, VMID=0x20, BOTTOM=0x30); keep MFC's VMID sign. Provide the canvas rect from the parent chain on a 1024x768 root, and its inverse to the element's own offsets. Port the 8-handle hit test and resize (R_LEFT..R_LEFT_BOTTOM, WIDTH=3, MINIMAL=5) from the same file, and the arrow-key nudge from OnKeyDown at :125. Read what it does before porting. Add align left/top/right/bottom and equal size against the primary (first-selected) control in canvas space, each inverted per element anchor; MFC has no handler for these (D031 item 4). (2) Add GUI commands in Sources/editor/resource_core/sub_editor_tools.zig, or a new gui_tools.zig exported from root.zig. SetRects stores the before and after int tuples. Insert stores the template path and the resulting id; on undo it deletes, and on redo it re-inserts with the same id, or remaps through the stored text. Delete and Cut store the CopyText of the removed subtree and its parent and position for undo. Paste is an insert from text. SetAttr is a property set. Each goes through history.zig with one entry per gesture. (3) Tests: resolve and inverse on all 9 anchor combinations against hand-derived numbers written in the test, with a comment citing the GUIFrame2.cpp lines; round trip inverse(resolve(x)) == x; three real MainMenu.xml elements (values copied into the test) resolve to their known canvas places; resize clamps at MINIMAL; align and equal size on mixed anchors. Against fake_bridge: every command undoes to the exact previous ints and redoes to the edited ints, insert then undo then redo keeps the window list equal, and delete then undo restores the subtree. Register the module in build.zig's test-resource-core. Use CRLF.
Done when: verify exits 0 and git status is clean for touched files.

## Inputs

- `Sources/src/editor/GUIFrame2.cpp`
- `Sources/src/editor/GUIFrame.cpp`
- `Sources/editor/resource_core/history.zig`
- `Sources/editor/resource_core/document.zig`
- `Sources/editor/resource_core/sub_editor_tools.zig`
- `Sources/editor/resource_core/bridge.zig`
- `Sources/editor/resource_core/fake_bridge.zig`
- `Sources/editor/resource_core/root.zig`
- `Data/UI/MainMenu.xml`

## Expected Output

- `Sources/editor/resource_core/gui_geometry.zig`
- `Sources/editor/resource_core/gui_tools.zig`
- `Sources/editor/resource_core/root.zig`

## Verification

zig build test-resource-core -Dtest-mode=run

## Observability Impact

Test failures print the flag, the input rect and the expected and actual ints.
