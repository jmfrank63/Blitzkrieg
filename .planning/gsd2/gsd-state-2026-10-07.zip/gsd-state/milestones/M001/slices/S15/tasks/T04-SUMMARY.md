---
id: T04
parent: S15
milestone: M001
key_files:
  - Sources/editor/resource_core/gui_geometry.zig
  - Sources/editor/resource_core/gui_tools.zig
  - Sources/editor/resource_core/history.zig
  - Sources/editor/resource_core/document.zig
  - Sources/editor/resource_core/root.zig
key_decisions:
  - Canvas resolve follows the engine's CSimpleWindow::Reposition, not MFC's editor-side GetElementRect/SetElementRect, because MFC's RIGHT/BOTTOM/VMID cannot round-trip and the slice measures a Game frame.
  - GUI commands store logical window ids with a Document-held IdMap, because the bridge never reuses ids and redo must keep later commands valid.
duration: 
verification_result: passed
completed_at: 2026-10-06T04:25:17.451Z
blocker_discovered: false
---

# T04: Added gui_geometry.zig (anchored resolve/inverse, handle hit test and resize, move, align, equal size) and gui_tools.zig (undoable GUI commands through ResourceCommand.gui with a logical-id map), tested against the fake bridge.

**Added gui_geometry.zig (anchored resolve/inverse, handle hit test and resize, move, align, equal size) and gui_tools.zig (undoable GUI commands through ResourceCommand.gui with a logical-id map), tested against the fake bridge.**

## What Happened

gui_geometry.zig is pure. It resolves a window's canvas rect up the parent chain and inverts a canvas rect back to the window's own ints for all 9 anchor combinations. The resolve follows the engine's CSimpleWindow::Reposition (UIBasic.cpp:643-675), not MFC's GetElementRect/SetElementRect. MFC's RIGHT/BOTTOM return inverted rects that SetElementRect cannot invert, its HMID/VMID drop the parent origin, and its VMID sign is flipped. The slice is measured against a Game frame and the plan requires inverse(resolve(x))==x, so the engine semantics won. The 8-handle hit test and the per-edge resize clamps (WIDTH=3, MINIMAL=5, including MFC's strict/non-strict one-pixel differences) are ported from GUIFrame2.cpp. MFC has no arrow-key nudge (OnKeyDown only handles Delete) and no align/equal-size handler, so moveBy, align_ and equalize are new, working in canvas space against the first-selected window and inverting per element anchor. HMID truncates both edges, so an odd stored size renders one pixel narrower; inverse() takes the current ints as a hint so moves keep the size. Commands: history.zig gains GuiCommand (set_rects, create for template insert and paste, delete for delete and cut, set_attr) as ResourceCommand.gui. Document apply/undoOne/redoOne dispatch to gui_tools and skip the tree reload. Because the bridge never reuses window ids, commands store logical ids and Document.gui_ids (an IdMap) maps them to current ids. An undo of an insert or delete captures the clipboard text, and the redo or undo pastes it back and remaps. Builders: setRects (null when nothing changed), insertTemplate, paste, copy, delete (drops the root, refuses it, dedups nested selections), cut, setAttr. Both modules are exported from root.zig, so test-resource-core runs their tests.

## Verification

zig build test-resource-core -Dtest-mode=run: 103 pass. Temporarily changing one expected int made it fail (102 pass, 1 fail), then restoring it gave 103 pass, so the new tests run. zig build test-resource-app-logic -Dtest-mode=run: 167 pass. This checks that the new ResourceCommand variant compiles in the app-side code. git status shows only the five task files (document.zig, history.zig and root.zig modified; gui_geometry.zig and gui_tools.zig new), all CRLF. The full resource sweep is left to the maintainer.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-core -Dtest-mode=run` | 0 | pass (103/103) | 700ms |
| 2 | `zig build test-resource-app-logic -Dtest-mode=run` | 0 | pass (167/167) | 700ms |

## Deviations

["Resolve uses the engine's Reposition semantics instead of a line-for-line port of MFC's GetElementRect/SetElementRect, and does not keep MFC's VMID sign, because MFC's version is inconsistent with the engine and cannot round-trip (see narrative). Hand-derived test numbers follow the engine. There is no arrow-key nudge to port, so moveBy is new. Undo of a delete restores windows at the end of their parent's children, because BkResGuiPaste has no position."]

## Known Issues

["Undoing a set_attr on an attribute the window did not have writes an empty value, since the bridge cannot remove an attribute. Document.gui_ids must be cleared by the app when a screen is opened or closed (IdMap.clear); no caller does it yet. Not run: the real-bridge and Game tiers, which belong to later S15 tasks."]

## Files Created/Modified

- `Sources/editor/resource_core/gui_geometry.zig`
- `Sources/editor/resource_core/gui_tools.zig`
- `Sources/editor/resource_core/history.zig`
- `Sources/editor/resource_core/document.zig`
- `Sources/editor/resource_core/root.zig`
