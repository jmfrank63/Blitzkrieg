# S15: GUI Editor — UAT

**Milestone:** M001
**Written:** 2026-10-06T04:53:25.377Z

# S15 UAT

**UAT Type:** mixed (automated Linux run plus manual hand try)

## Preconditions
- Linux build: `zig build install-game install-resource-editor`; XDG_RUNTIME_DIR and a display available.

## Steps
1. Run `zig build resource-editor-auto-gui`. Expected: `auto PASS`, game log clean, game frames differ only inside the old/new/placed rects.
2. Launch ResourceEditor, open Data/UI/MainMenu.xml, drag a Button from the palette, move it, resize it, align with another window. Expected: canvas and inspector rects update.
3. Undo and redo four times. Expected: rects return exactly to placed and final states.
4. Save, close, reopen. Expected: rects unchanged.
5. Export and launch the Game with the mod. Expected: the edited MainMenu loads without screen-load errors and shows the button.

## Edge cases
- Escape during a drag leaves no history entry.
- Export into shipped Data is refused with a message.
- Screens with children lacking WindowPos open and save byte-identically.

## Not Proven By This UAT
- macOS and Windows runs (CI and Johannes's hand try).
- The full resource sweep (maintainer).
