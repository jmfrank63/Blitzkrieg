---
estimated_steps: 3
estimated_files: 11
skills_used: []
---

# T03: BkResGui* bridge ABI, gui exporter, and Zig adapters

Why: the app and the headless core reach the model only through the C ABI. Export must write a screen the Game reads for a -mod (D031 items 1 and 6).
Do: (1) In Sources/src/EditorBridge/resource_bridge.{h,cpp}, a gui-kind session holds a CUiScreen. BkResOpen on a .gui or .xml whose root is <base>, or GUI_Composer_Project with window content, opens it as kind gui (Kind.gui_frame = 20). Keep the S03 palette-tree project.gui fixture opening as before. BkResSave writes CUiScreen::Save through the existing safe-save path. Add entry points after the BkResGet/SetMissionObjectives pattern: BkResGuiWindows (a flat int list per window: id, parent, ClassTypeID, ElementID, flag, x, y, w, h, visible), BkResGuiSetRects (a batch of id, flag, x, y, w, h), BkResGuiInsertTemplate (parent, template path, x, y -> id), BkResGuiDelete, BkResGuiCopy and BkResGuiPaste (clipboard as text), BkResGuiGetAttr and BkResGuiSetAttr, and BkResGuiTemplates (folder and file list from <data>/Editor/UI/<Folder>/ plus a user template folder passed by the app). Document each in the header and trace each under BK_DEBUG_LOG. (2) Add the gui exporter: Sources/src/ResourceModel/items/gui/gui_export.{h,cpp}, registered as {"gui", &ExportGui} in exporter.cpp's table and in build.zig. It writes SaveAsBase into the staging root at the path the Game resolves for -mod. Check how the mod storage layers <mod>/data over Data for ui\<name>.xml (StreamIO mod storage, and OpenLayoutStream's ui\ModStyles\<MOD.Folder> route). Pick the path the Game actually reads, prefer the plain overlay data/ui/<Screen>.xml, and record the choice in the header comment. The screen name comes from the opened file name. Refuse a target inside shipped Data and name why. (3) Mirror the ABI in Sources/editor/resource_core/bridge.zig, fake_bridge.zig (an in-memory window list with the same id semantics, used by the headless tests) and Sources/editor/resource_app/c_bridge.zig. (4) Add tests to Sources/src/EditorBridge/resource_bridge_test.cpp, on a MainMenu.xml copy under zig-out/local-test: open as gui; the windows list matches T02's model; set rects, then save, then reopen gives equal ints; insert, then delete, then copy and paste give the expected ids and counts; export writes a <base> file at the chosen path that the engine IDataTree reader opens with the edited rect; shipped-Data export is refused; the old palette fixture still round-trips. Run test-resource-core so the fake bridge compiles. Use CRLF.
Done when: verify exits 0, the Map Editor bridge tier is green, and git status is clean for touched files.

## Inputs

- `Sources/src/ResourceModel/ui_screen.h`
- `Sources/src/ResourceModel/ui_screen.cpp`
- `Sources/src/ResourceModel/exporter.h`
- `Sources/src/ResourceModel/exporter.cpp`
- `Sources/src/ResourceModel/items/gui/gui.h`
- `Sources/src/UI/UIScreen.cpp`
- `Sources/src/EditorBridge/resource_bridge.h`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/editor/resource_core/bridge.zig`
- `Sources/editor/resource_core/fake_bridge.zig`
- `Sources/editor/resource_app/c_bridge.zig`
- `Data/UI/MainMenu.xml`

## Expected Output

- `Sources/src/EditorBridge/resource_bridge.h`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `Sources/src/ResourceModel/items/gui/gui_export.h`
- `Sources/src/ResourceModel/items/gui/gui_export.cpp`
- `Sources/src/ResourceModel/exporter.cpp`
- `Sources/editor/resource_core/bridge.zig`
- `Sources/editor/resource_core/fake_bridge.zig`
- `Sources/editor/resource_app/c_bridge.zig`

## Verification

zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-core -Dtest-mode=run && zig build test-resource-model -Dtest-mode=run && zig build test-editor-bridge -Dtest-mode=run

## Observability Impact

BK_DEBUG_LOG traces every BkResGui* call. Export refusals name the path and the reason.
