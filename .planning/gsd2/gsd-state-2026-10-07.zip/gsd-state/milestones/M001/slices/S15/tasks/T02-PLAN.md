---
estimated_steps: 3
estimated_files: 5
skills_used: []
---

# T02: CUiScreen: text-preserving UI screen model with engine-reader oracle

Why: D031 items 1 and 2. Runs after T01. MFC's GUI editor edited the screen itself: CGUIFrame::SpecificInit at Sources/src/editor/GUIFrame.cpp:201 calls CUIScreen::Load(name,false), which reads the root GUI_Composer_Project (Sources/src/UI/UIScreen.cpp:179-196). The game reads <base> roots through OpenLayoutStream (UIScreen.cpp:96). No screen model exists today; uncommitted drafts of ui_screen.{h,cpp} and ui_screen_test.cpp plus build.zig and comparator edits may already be in the working tree from an interrupted session: read and continue them rather than starting over. Engine field names come from CSimpleWindow::operator&(IDataTree&) (Sources/src/UI/UIBasic.cpp:108), CMultipleWindow::operator& (:1319, Children) and CWindowState (UIInternal.cpp:419).
Do: (1) Add Sources/src/ResourceModel/ui_screen.{h,cpp}, namespace NResourceModel, class CUiScreen with no engine or MFC types. It parses the XML into a node tree that keeps the original text spans, so comments, whitespace and attribute order survive. Check whether ResourceModel's xml layer (Sources/src/ResourceModel/xml.*) preserves comments and spans; if it does not, write a small span-keeping parser here. It exposes windows in document order with a stable id, parent id, ClassTypeID, ElementID, PositionFlag, WindowPos x/y, WindowSize x/y and VisibleFlag. A child window is an <item> under a window's Children element; check MainMenu.xml for the exact nesting. Operations: SetRect(id, flag, x, y, w, h), which rewrites only those attributes; SetAttribute(id, name, value) for the inspector; InsertFromTemplate(parent id, template text, x, y), where the template is a Data/Editor/UI/*/*.xml <base> body re-rooted as <item>, appended to the parent's Children (created when absent) with its WindowPos set, and returning the new id; Delete(ids); CopyText(ids) and Paste(parent id, text, dx, dy) for the clipboard; Save(text out). The root is kept as opened (<base> or GUI_Composer_Project); SaveAsBase writes the <base> root for export. Errors name the line and the reason. (2) Add the sources to the ResourceModel library in build.zig. (3) Add tests to the test-resource-model tier, either as a new Sources/src/ResourceModel/ui_screen_test.cpp registered in build.zig or in the existing model test file; reuse the tier's case-insensitive Data path helper. For every Data/UI/*.xml whose root is <base>, plus every Data/Editor/UI/*/*.xml: open, then an unedited save is byte-identical. On a copy of MainMenu.xml under zig-out/local-test, move one button, resize another, insert Data/Editor/UI/Buttons/Button00.xml and delete one control. Then read the saved file through the engine's IDataTree reader, the same CreateDataTreeSaver route the comparator uses, and check that exactly the edited WindowPos, WindowSize and PositionFlag values changed and the item count changed by +1/-1. A GUI_Composer_Project-rooted copy opens, and SaveAsBase gives a <base> root that the reader opens. Malformed input fails with the line number. New files use CRLF.
Done when: verify exits 0 and git status shows nothing the task touched as modified or untracked.

## Inputs

- `Sources/src/UI/UIScreen.cpp`
- `Sources/src/UI/UIBasic.cpp`
- `Sources/src/UI/UIInternal.cpp`
- `Sources/src/editor/GUIFrame.cpp`
- `Sources/src/ResourceModel/exporter.h`
- `Data/UI/MainMenu.xml`
- `Data/UI/CloudBackups.xml`
- `Data/Editor/UI/Buttons/Button00.xml`
- `build.zig`

## Expected Output

- `Sources/src/ResourceModel/ui_screen.h`
- `Sources/src/ResourceModel/ui_screen.cpp`
- `Sources/src/ResourceModel/ui_screen_test.cpp`

## Verification

zig build test-resource-model -Dtest-mode=run

## Observability Impact

Parse and save errors name the file, the line and the reason. The tests print which screens were checked.
