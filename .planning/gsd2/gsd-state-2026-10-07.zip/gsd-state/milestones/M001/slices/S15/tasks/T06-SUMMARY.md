---
id: T06
parent: S15
milestone: M001
key_files: []
key_decisions:
  - gui_rect tolerance is 3 canvas px because pointer placement at canvas scale ~0.57 quantizes to about 2 px
  - A root with no positive WindowPos size resolves to the full 1024x768 canvas so child clamps do not collapse to nothing
  - The auto step places the button at 700,640 on the root, where nothing later covers it, rather than inside a dialog that later windows overdraw
duration: 
verification_result: passed
completed_at: 2026-10-06T04:50:24.207Z
blocker_discovered: false
---

# T06: Added resource-editor-auto-gui, which places, moves, resizes, aligns, undoes, redoes, saves, exports and test-launches MainMenu and measures the Game frame, with CI, sweep, AGENTS, PARITY B-21 and spec D031/D032 updated.

**Added resource-editor-auto-gui, which places, moves, resizes, aligns, undoes, redoes, saves, exports and test-launches MainMenu and measures the Game frame, with CI, sweep, AGENTS, PARITY B-21 and spec D031/D032 updated.**

## What Happened

Added the gui scenario to build.zig (resource_auto_gui, wired into resource_auto_steps and the concatenation check) and the runner verbs in scenario.zig: gui_open, gui_place, gui_pick, gui_drag, gui_resize, gui_align, gui_snapshot, gui_mark, game_shot, expect gui_rect, gui_same, game_log_clean and game_frames. The run goes like this. MainMenu is opened as a project and exported, and the Game shows it as the baseline frame. Buttons/Button00 is dragged from the palette with real pointer events to 700,640, moved by +20/-10, resized by +30/+20 and the shipped el21000 is moved by +300. The two are aligned left. Four undos return exactly to the placed state and four redos to the final state, both compared by rects. After save, close and reopen the rects are unchanged. The second export is shown by the Game. The Game frames must differ at el21000's old rect (7941 of 43032 px), its new rect (6955 of 43098 px) and the placed button (10396 of 19240 px), and 0 of 1920000 px differ elsewhere. The Game log has 0 screen-load or assertion lines in both runs. Running it exposed three defects, which I fixed. (1) Palette.load allocated the template buffer one byte short of the bridge's closing NUL, so the palette stayed empty on the real bridge. The fake bridge writes no NUL, so the tests missed it. (2) A root without a WindowPos size, like MainMenu's, resolved to a 0x0 canvas rect, so a resize clamped to 0,0 and produced a negative size. A root with no positive size now fills the 1024x768 canvas. The constants moved to gui_geometry. (3) The scenario's first drop point sat under later windows, so I moved it to a free spot where the button lands on the root. Pointer placement at canvas scale ~0.57 quantizes by about 2 px, so gui_rect uses tolerance 3. The step is also in cross-platform.yml for the Windows and macOS jobs, in run-resource-sweep.sh TIERS and in AGENTS.md's list. 06-PARITY.md B-21.1 to B-21.8 are done with evidence, and "Create radio button from selected" and the missing Set equal size and align handlers are recorded as no behaviour in MFC with the port's definition. MFC's Run and Test-button live mode is recorded as replaced by F7 Run Blitzkrieg with the exported mod. The design spec records D031 and D032. Proof is Linux local only; macOS and Windows are left to CI. The full sweep is left to the maintainer.

## Verification

Ran on Linux: zig build install-game, install-resource-editor, test-resource-core, test-resource-app-logic, test-editor-core, resource-editor-auto-gui, -core, -mip, -mdc and map-editor-smoke, all exit 0. The full tools/zig/run-resource-sweep.sh is left to the maintainer. No macOS or Windows result is claimed.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build install-game` | 0 | pass | 4000ms |
| 2 | `zig build install-resource-editor` | 0 | pass | 8000ms |
| 3 | `zig build test-resource-core -Dtest-mode=run` | 0 | pass | 20000ms |
| 4 | `zig build test-resource-app-logic -Dtest-mode=run` | 0 | pass | 20000ms |
| 5 | `zig build resource-editor-auto-gui` | 0 | pass | 41000ms |
| 6 | `zig build resource-editor-auto-core` | 0 | pass | 19000ms |
| 7 | `zig build resource-editor-auto-mip` | 0 | pass | 8000ms |
| 8 | `zig build resource-editor-auto-mdc` | 0 | pass | 6000ms |
| 9 | `zig build test-editor-core -Dtest-mode=run` | 0 | pass | 20000ms |
| 10 | `zig build map-editor-smoke` | 0 | pass | 16000ms |

## Deviations

None.

## Known Issues

None.

## Files Created/Modified

None.
