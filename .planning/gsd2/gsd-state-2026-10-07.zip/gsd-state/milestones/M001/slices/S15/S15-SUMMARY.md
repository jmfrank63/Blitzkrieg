---
id: S15
parent: M001
milestone: M001
provides:
  - (none)
requires:
  []
affects:
  []
key_files: []
key_decisions:
  - Canvas resolve follows the engine's CSimpleWindow::Reposition, not MFC's element rects
  - GUI commands use logical window ids via a Document-held IdMap
  - gui_rect tolerance is 3 canvas px
patterns_established:
  - (none)
observability_surfaces:
  - none
drill_down_paths:
  []
duration: ""
verification_result: passed
completed_at: 2026-10-06T04:53:25.376Z
blocker_discovered: false
---

# S15: GUI Editor

**The Resource Editor edits Data/UI screens (place, move, resize, align, undo/redo, save) and the real Game loads the exported screen cleanly, proved by a measured Game frame on Linux.**

## What Happened

T01 made the Mission image frame show map_h.dds, creating it first as CMissionFrame does. T02 added CUiScreen, a text-preserving UI screen model checked byte-identical and against the engine's IDataTree reader on every shipped screen and template. T03 added the BkResGui* bridge ABI, the gui exporter (writes <mod>/data/ui/<Screen>.xml as a <base> screen, refuses shipped Data) and Zig/fake/C bridge mirrors. T04 added gui_geometry (anchored resolve/inverse following the engine's CSimpleWindow::Reposition rather than MFC's non-invertible element rects) and undoable gui_tools commands with a logical-id map. T05 added the canvas, template palette, inspector, align menu and clipboard; gestures commit one command on release. T06 added the resource-editor-auto-gui scenario: it opens and exports MainMenu, drags Button00 from the palette with real pointer events, moves, resizes and aligns, undoes and redoes four steps, saves, reopens, exports, test-launches the Game and measures its frames against the baseline, with CI, sweep, AGENTS, PARITY B-21 and spec D031/D032 updated.

## Verification

Fresh in this unit: zig build resource-editor-auto-gui PASS (61 actions, game log clean, Game frame differences confined to the old, new and placed rects); zig build test-resource-core exit 0; git status clean. During T06: install-game, install-resource-editor, test-resource-core, resource-editor-auto-gui/core/etc and map-editor-smoke passed; test-resource-model PASS with 29 ui_screen checks. Note: the gsd_exec sandbox lacks XDG_RUNTIME_DIR, so GUI tiers need it set. macOS and Windows not run here; left to CI and hand try. Full sweep left to the maintainer.

## Requirements Advanced

None.

## Requirements Validated

None.

## New Requirements Surfaced

None.

## Requirements Invalidated or Re-scoped

None.

## Operational Readiness

None.

## Deviations

None.

## Known Limitations

None.

## Follow-ups

None.

## Files Created/Modified

None.
