---
estimated_steps: 7
estimated_files: 4
skills_used: []
---

# T06: BK_EDITOR_AUTO msh block, PARITY rows, spec note and tier run

Why: the slice demo needs a BK_EDITOR_AUTO scenario for unit edit, export and test launch, plus parity evidence.

Do:
1. Sources/editor/resource_app/scenario.zig: extend do=import to msh with a tracked shipped unit (8_8_cm_FlaK18, three models) or open a copied fixture with do=copy. New verbs: do=mesh_variant:<0|1|2>, do=pick_locator:<name> (through mesh_logic.pickLocator at the locator's screen point, not by name lookup), expect=selected:<name>, and do=locators:<0|1>. Document them in the header comment list.
2. build.zig resource-editor-auto schedule: add a msh block. Import or open; set_prop on a Common value; undo; redo; preview_on; shot_lit per variant with differ between them; locators on and pick_locator plus expect=selected; mod_dir; export; expect=exported for units\\technics\\...\\1.xml and a copied .mod; run_game with waitgame. Keep earlier blocks unchanged.
3. .planning/phases/06-resource-editor-portable-port/06-PARITY.md rows B-01.1..B-01.9: evidence (test names, committed captures) or 'no behaviour in MFC' with a reason. The golden part of B-01.8 says 'pending win-home'. In docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md, record D019 (locators derived and rebuilt, a bridge open+save writes them, an exception to the byte-identical rule at bridge level only) and the fixture source-art choice from T03.
4. Run the tiers one at a time in the foreground and cite only the commands really run. The full sweep is left to the maintainer.

Done when: every verify command exits 0 and the auto log shows the msh block passing.

## Inputs

- `Sources/editor/resource_app/scenario.zig`
- `Sources/editor/resource_app/mesh_logic.zig`
- `build.zig`
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`

## Expected Output

- `Sources/editor/resource_app/scenario.zig`
- `build.zig`
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`

## Verification

zig build install-resource-editor && zig build resource-editor-auto && zig build resource-editor-smoke && zig build resource-editor-host-check && zig build test-resource-app-logic -Dtest-mode=run && zig build test-resource-core -Dtest-mode=run && zig build test-editor-core -Dtest-mode=run && zig build map-editor-smoke

## Observability Impact

Auto-scenario failures print the frame number, the action and the expected versus actual selection, file or share.
