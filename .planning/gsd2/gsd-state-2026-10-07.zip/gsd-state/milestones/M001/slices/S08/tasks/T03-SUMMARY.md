---
id: T03
parent: S08
milestone: M001
key_files:
  - Sources/src/ResourceModel/items/mesh/mesh_export.cpp
  - Sources/src/EditorBridge/resource_bridge_test.cpp
  - tools/zig/resource_editor_fixtures.zig
  - tools/zig/fixtures/resource_editor/EXTENSIONS.md
  - tools/zig/fixtures/resource_editor/msh/golden/README.md
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-05T14:56:16.750Z
blocker_discovered: false
---

# T03: msh exporter now ports ExportFrameData (models, six season textures, icons, localisation, up-to-date skip) with in-repo fixture art; the msh golden line reads pending.

**msh exporter now ports ExportFrameData (models, six season textures, icons, localisation, up-to-date skip) with in-repo fixture art; the msh golden line reads pending.**

## What Happened

mesh_export.cpp ports ExportFrameData: every .mod beside the combat model is copied, the six alive/dead season textures and the optional 1p*/icon512 pictures go through NImageExport, icon.tga (64 px) and icon (128 px) are built from the project's icon.tga, and name/desc/stats are copied. FindMaximalSourceTime/FindMinimalExportFileTime give the non-forced skip (nSkipped). Missing pictures are warnings, as MFC's message box was. Fixture source art: 1.mod, 2.mod, 3.mod copied from the shipped 8_8_cm_FlaK18; resource_editor_fixtures.zig generates 16x16 targas (1, 1w, 1a, 2, 2w, 2a, icon) whose channels are exact in RGB565, plus name/desc/stats.txt, so the pictures can be held to the shipped-texture dxt gate (arbitrary hash colours gave p99 3-4 against the gate's 2). EXTENSIONS.md and msh/golden/README.md record the source unit and art. Bridge tests (S08Mesh::Graphics): .mod byte-equal, every _c.dds within the DXT5 gate (measured delta 0), name/desc copied, a second forced export byte-identical, a plain export over an up-to-date one reports skipped, a deleted 1w.tga warns and leaves no 1w DDS. The older generic export test that expected the fixture msh to fail for lack of models now expects success. The comparator already included msh and prints 'GOLDEN msh pending'.

## Verification

make-resource-fixtures, test-resource-editor-fixtures, test-resource-bridge, test-resource-model-comparator and test-resource-model all exit 0 on Linux x64. Full resource sweep left to the maintainer. Nothing run on macOS or Windows.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build make-resource-fixtures` | 0 | pass | 0ms |
| 2 | `zig build test-resource-editor-fixtures` | 0 | pass | 0ms |
| 3 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 36000ms |
| 4 | `zig build test-resource-model-comparator -Dtest-mode=run` | 0 | pass | 0ms |
| 5 | `zig build test-resource-model -Dtest-mode=run` | 0 | pass | 0ms |

## Deviations

None.

## Known Issues

None.

## Files Created/Modified

- `Sources/src/ResourceModel/items/mesh/mesh_export.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `tools/zig/resource_editor_fixtures.zig`
- `tools/zig/fixtures/resource_editor/EXTENSIONS.md`
- `tools/zig/fixtures/resource_editor/msh/golden/README.md`
