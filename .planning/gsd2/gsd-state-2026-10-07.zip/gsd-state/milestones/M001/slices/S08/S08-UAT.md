# S08: S08 — UAT

**Milestone:** M001
**Written:** 2026-10-05T15:36:45.737Z

# S08 UAT

**UAT Type:** automated tiers on Linux x64, plus optional manual look.

## Preconditions
- Linux x64 with a desktop session; `XDG_RUNTIME_DIR` set.
- `zig build install-resource-editor` done.

## Steps
1. Run `zig build resource-editor-auto`. Expected: exit 0; the msh block edits a unit, undoes/redoes, captures combat/install/transportable shots, exports and test-launches.
2. Run `zig build test-resource-bridge -Dtest-mode=run`. Expected: green, including the shipped-unit stats field-equal check and the current.msh golden.
3. Run `zig build test-resource-core -Dtest-mode=run` and `test-resource-app-logic -Dtest-mode=run`. Expected: green, including locator move, platform selection and model switch undo/redo, and locator pick selecting the right tree locator.
4. Run `resource-editor-smoke` and `resource-editor-host-check`. Expected: exit 0.
5. Optional: open a .msh in ResourceEditor and switch model variants.

## Edge cases
- Without `XDG_RUNTIME_DIR` the host tiers fail with SdlInitFailed; this is an environment issue, not a regression.

## Not Proven By This UAT
- macOS and Windows behaviour (CI only).
- Visual quality of the overlay in a real window (proved by tests and captures only).
- The full resource sweep (maintainer).
