---
estimated_steps: 7
estimated_files: 5
skills_used: []
---

# T01: Mesh stats exporter (FillRPGStats/SaveRPGStats) proved against the shipped 8_cm_GrWr34 1.xml

Why: this is the slice's first proof and its highest risk. MeshFrm.cpp FillRPGStats (L300-1120, about 820 lines of order-sensitive platform, gun, jogging, defence and crater bookkeeping) must reproduce what MFC exported. The oracle is in the repo: Data/Editor/TestProjects/06_Mesh/current.msh is byte-identical to the shipped Data/Units/Technics/German/Artillery/8_cm_GrWr34/current.msh, whose MFC export is the shipped 1.xml.

Do:
1. New Sources/src/ResourceModel/items/mesh/mesh_export.cpp. Shape it like items/infantry/infantry_export.cpp and items/weapon/weapon_export.cpp: NStatsExport::PreparedCopy, ChildItem/RequireChild, Value*, StatsFileName with szAddDir "units\\technics\\" (check MFC's szAddDir in MeshFrm.cpp), WriteStats with tree.Add("RPG", &stats). Port FillRPGStats line for line into SMechUnitRPGStats (Main/RPGStats.h). Per D019, where MFC asks pCombatObject/pInstallObject/pTransObject's IMeshAnimation for node names, read the skeleton nodes from the same .mod through CreateStructureSaver READ, as FillRPGStats already does for chunks 1/3/4/5/6. Resolve .mod paths relative to the project folder with NStatsExport::MakeFullPath/FoldedFile, ignoring case. A missing combat .mod is an error ('Can not load combat mechanics file'); a missing install or transportable .mod is skipped as in MFC. A platform/gun locator that is not found is handled as MFC does (nModelPart -1 etc.) and adds a warning. Port the IObjectsDB use (around L774) the way S06 handled the squad (an object lookup in SExportContext the bridge fills from IObjectsDB) if FillRPGStats needs it.
2. Declare ExportMesh in items/stats_export.h. Add { "msh", &ExportMesh } to the exporter.cpp table. Add mesh_export.cpp to the EditorBridge archive file lists in build.zig, next to infantry_export.cpp; grep build.zig for infantry_export.cpp to find every list.
3. Test in Sources/src/EditorBridge/resource_bridge_test.cpp (tier test-resource-bridge). Copy the shipped 8_cm_GrWr34 folder (tracked) and 06_Mesh/current.msh to zig-out/local-test/resource_editor/s08/..., open current.msh there, run BkResExportStatsOnly into a scratch export root, and compare the produced 1.xml with the shipped 1.xml through NResourceModel::CompareStats (EExportKind::MECH_UNIT, exact floats). Expect zero differences. Also assert that a stats-only export writes no .mod or DDS, and that a project whose combat .mod is missing fails with the MFC message and promotes nothing.
4. Update the test that asserted .msh export is refused, if one exists (grep resource_bridge_test.cpp and Sources/editor/resource_app for 'msh' refusals).

Done when: the comparator reports field-equal against the shipped 1.xml, and test-resource-bridge and test-resource-model-comparator exit 0. Notes: run each zig build step in the foreground on its own. AGENTS.md: CRLF for new files, never write into Data/.

## Inputs

- `Sources/src/editor/MeshFrm.cpp`
- `Sources/src/editor/MeshTreeItem.h`
- `Sources/src/ResourceModel/items/mesh/mesh.h`
- `Sources/src/ResourceModel/items/mesh/mesh.cpp`
- `Sources/src/ResourceModel/items/infantry/infantry_export.cpp`
- `Sources/src/ResourceModel/items/weapon/weapon_export.cpp`
- `Sources/src/ResourceModel/items/squad/squad_export.cpp`
- `Sources/src/ResourceModel/items/stats_export.h`
- `Sources/src/ResourceModel/exporter.h`
- `Sources/src/ResourceModel/exporter.cpp`
- `Sources/src/ResourceModel/comparator.h`
- `Data/Editor/TestProjects/06_Mesh/current.msh`
- `Data/Units/Technics/German/Artillery/8_cm_GrWr34/1.xml`
- `Data/Units/Technics/German/Artillery/8_cm_GrWr34/1.mod`
- `Data/Units/Technics/German/Artillery/8_cm_GrWr34/2.mod`

## Expected Output

- `Sources/src/ResourceModel/items/mesh/mesh_export.cpp`
- `Sources/src/ResourceModel/items/stats_export.h`
- `Sources/src/ResourceModel/exporter.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `build.zig`

## Verification

zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model-comparator -Dtest-mode=run && zig build test-resource-model -Dtest-mode=run

## Observability Impact

SExportOutcome carries MFC's message texts: missing combat .mod as szError, a locator not found for a platform or gun as a warning. A comparator failure prints the field path and both values.
