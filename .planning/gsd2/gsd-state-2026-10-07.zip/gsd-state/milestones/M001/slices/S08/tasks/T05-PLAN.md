---
estimated_steps: 8
estimated_files: 12
skills_used: []
---

# T05: Core and app: locator pick, variant and visibility toolbar, locator dropdowns, undoable mesh tools

Why: B-01.1, B-01.3, B-01.4, B-01.5, B-01.6 and B-01.7 in the app, plus the slice's undo/redo demands (locator move, platform selection, model switch).

Do:
1. Add previewMeshVariant, previewDirection, previewShowLocators and meshLocators to the ResBridge vtable in Sources/editor/resource_core/bridge.zig, with the real adapter in Sources/editor/resource_app/c_bridge.zig and a fake in resource_core/fake_bridge.zig. The fake keeps a locator list and rebuilds the Locators children when the Graphics combat model name changes, so undo of a model switch is testable headlessly.
2. Pure logic in a new Sources/editor/resource_app/mesh_logic.zig, tested in test-resource-app-logic: pickLocator(locators, click xy, radius px) gives the nearest locator within the radius or null, and nodeForLocator finds the Locators child with that node id. Picking sets the tree selection only; assert the history length is unchanged.
3. Dropdowns (B-01.5, MFC LoadGunPointPropsComboBox L1545, LoadGunPartPropsComboBox L1598, LoadGunCarriagePropsComboBox L1661, LoadPlatformPropsComboBox L1699): check Sources/src/ResourceModel/combos.cpp. If the gun point, part, carriage and platform lists are not there, add them, reading the Locators children (and the Platforms children where MFC does) of the open project, so the inspector offers them.
4. Undo/redo tests in test-resource-core (fake bridge) and test-resource-bridge (real), each with set+get before and after: set_prop of a gun point/part/carriage locator reference; set_prop of a platform's locator choice; set_prop of the Graphics combat model name, where the locator children change and undo restores them; insert_node/delete_node of a platform and of a gun under Platforms (MFC MyKeyDown Insert/Delete).
5. App UI (panels.zig/docks.zig, following the squad and sprite overlays): a msh preview toolbar with combat, install and transportable buttons plus show locators and bounding box toggles. Locator overlay markers and the active locator line drawn with the ImGui draw list from meshLocators screen positions (D-18). Right-click in the preview calls pickLocator and selects the node. The direction dock's angle calls previewDirection when the kind is msh. Use the existing docks_check/host-check pattern to assert the toolbar and pick wiring headlessly where possible.

Done when: the listed tiers exit 0. Notes: run the GUI tiers from a normal shell; under no display set SDL_VIDEODRIVER=offscreen as S07 did.

## Inputs

- `Sources/src/editor/MeshFrm.cpp`
- `Sources/src/editor/MeshTreeItem.cpp`
- `Sources/src/EditorBridge/resource_bridge.h`
- `Sources/editor/resource_core/bridge.zig`
- `Sources/editor/resource_core/fake_bridge.zig`
- `Sources/editor/resource_core/sub_editor_tools.zig`
- `Sources/editor/resource_app/c_bridge.zig`
- `Sources/editor/resource_app/panels.zig`
- `Sources/editor/resource_app/docks.zig`
- `Sources/editor/resource_app/docks_logic.zig`
- `Sources/editor/resource_app/squad_logic.zig`
- `Sources/src/ResourceModel/combos.cpp`

## Expected Output

- `Sources/editor/resource_core/bridge.zig`
- `Sources/editor/resource_core/fake_bridge.zig`
- `Sources/editor/resource_core/sub_editor_tools.zig`
- `Sources/editor/resource_core/root.zig`
- `Sources/editor/resource_app/c_bridge.zig`
- `Sources/editor/resource_app/mesh_logic.zig`
- `Sources/editor/resource_app/panels.zig`
- `Sources/editor/resource_app/docks.zig`
- `Sources/editor/resource_app/docks_check.zig`
- `Sources/src/ResourceModel/combos.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `build.zig`

## Verification

zig build test-resource-core -Dtest-mode=run && zig build test-resource-app-logic -Dtest-mode=run && zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model -Dtest-mode=run && zig build install-resource-editor && zig build resource-editor-host-check && zig build resource-editor-smoke

## Observability Impact

The undo tests print the property, before, after-undo and after-redo values on failure. A pick miss in the app logs the click and the nearest locator distance.
