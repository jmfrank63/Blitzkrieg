---
id: T07
parent: S08
milestone: M001
key_files:
  - Sources/editor/resource_app/squad_logic.zig
  - Sources/editor/resource_app/panels.zig
  - Sources/editor/resource_app/scenario.zig
  - docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md
key_decisions:
  - Flip Y in View.toScreen/toWorld and the canvas origin to match MFC's GetPos2 projection; D016 angle convention untouched.
duration: 
verification_result: passed
completed_at: 2026-10-05T15:32:48.579Z
blocker_discovered: false
---

# T07: Squad overlay View now flips world Y so +Y runs up the screen as in MFC (D018); tests, canvas origin, squad_arrow step and spec updated.

**Squad overlay View now flips world Y so +Y runs up the screen as in MFC (D018); tests, canvas origin, squad_arrow step and spec updated.**

## What Happened

MFC projects the formation through IScene::GetPos2. The camera looks toward +Y (Scene/Camera.cpp:10,76-79, pitch -135 degrees) and the viewport matrix negates Y (GFX/GraphicsEngine.cpp:895), so world +Y is up the screen. The port had no flip, so the overlay showed the formation mirrored top to bottom. View.toScreen/toWorld in squad_logic.zig now flip Y, and the canvas origin in panels.zig uses +zero.y*scale. The existing overlay tests go through a scr() helper that maps world points to screen points. A new test checks that a screen point above the zero point maps to larger world Y and that an upward drag gives angle 0. The squad_arrow scenario step now maps its world point through overlay.view.toScreen. The angle convention (D016) is unchanged. The D018 finding is recorded in the design spec under Amendments.

## Verification

Ran test-resource-app-logic and resource-editor-auto in the foreground; both exit 0 (auto: PASS, 233 actions).

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-app-logic -Dtest-mode=run` | 0 | pass | 60000ms |
| 2 | `zig build resource-editor-auto` | 0 | pass | 120000ms |

## Deviations

None.

## Known Issues

None.

## Files Created/Modified

- `Sources/editor/resource_app/squad_logic.zig`
- `Sources/editor/resource_app/panels.zig`
- `Sources/editor/resource_app/scenario.zig`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`
