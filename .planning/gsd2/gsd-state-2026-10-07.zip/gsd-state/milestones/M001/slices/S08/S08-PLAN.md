# S08: Unit (mesh) sub-editor

**Goal:** The Unit (mesh, .msh) editor becomes a real sub-editor. A registered "msh" exporter ports CMeshFrame::FillRPGStats/SaveRPGStats and ExportFrameData line for line, reading the .mod files through the engine's structure loader (D019). An importer ports CMeshFrame::GetRPGStats. Locators are rebuilt from the combat .mod as MFC did. The preview shows the combat, install and transportable variants, and the app picks locators and shows locators and bounding boxes. Locator references, platform choice and model switch are undoable. A BK_EDITOR_AUTO msh block runs edit, export and test launch.
**Demo:** Captured 3D mesh preview per model variant (combat, install, transportable); locator pick selects the correct locator in the tree; golden parity on the in-repo `current.msh` fixture; import of a shipped unit then stats-only export is field-equal; undo/redo tests for locator move, platform selection, model switch; `BK_EDITOR_AUTO` scenario for unit edit then export then test launch.

## Must-Haves

- FindExporter("msh") returns a production exporter listed in the exporter.cpp table. BkResExport no longer refuses .msh.
- The oracle proof: Data/Editor/TestProjects/06_Mesh/current.msh, copied with the shipped 8_cm_GrWr34 folder into zig-out/local-test, exports stats-only, and its 1.xml compares field-equal (CompareStats MECH_UNIT, exact floats) with the shipped Data/Units/Technics/German/Artillery/8_cm_GrWr34/1.xml.
- BkResImportFromGame(msh) works. Importing at least 5 shipped units (one with 3.mod such as 8_8_cm_FlaK18, a tank, a truck or tractor, an AA gun, and an aircraft if Data/Units/Technics has one), then stats-only export, compares field-equal with each shipped 1.xml. The only exceptions are an explicit per-field list of what MFC's GetRPGStats does not carry back, each with its MeshFrm.cpp line. The ".msh import refused" assertions are flipped.
- The full export of the repo fixture tools/zig/fixtures/resource_editor/msh/project.msh, with committed source art (.mod copied from a tracked shipped unit plus small generated TGAs), writes 1.xml, the copied *.mod (byte-equal to source), 1/1w/1a/2/2w/2a DDS (within dxt-tolerance.json of the source TGAs), icons and name/desc.txt. A second export is byte-identical. A missing texture is a warning. Up-to-date sources are counted in nSkipped. The golden comparison reports "GOLDEN msh pending" until win-home fills golden/, never "pass".
- Locators are rebuilt in the tree from the combat .mod skeleton after open, import and a combat-model change. The rebuild is not in undo history and does not mark dirty (D019).
- The preview captures three variants (combat, install, transportable) of an imported 3-model unit. Each has >= 1% non-black-non-magenta pixels and each pair differs by >= 0.1% of pixels, measured by code. The captures are committed as preview-scene/mesh-{combat,install,transportable}.tga with their shares in preview-scene.md.
- Locator world-to-screen positions come from the bridge. Pure Zig pick logic picks the nearest locator within a pixel radius, and selecting it selects that locator's tree node. Picking adds no history entry.
- Undo/redo tests with set+get before and after in test-resource-core (fake bridge) and test-resource-bridge (real) cover: a gun point/part/carriage locator reference ("locator move"), a platform's locator choice ("platform selection"), the Graphics combat model name with locator rebuild ("model switch"), and platform/gun insert and delete.
- resource-editor-auto runs a msh block: import or open, set_prop, undo, redo, mesh_variant shots that differ, pick_locator with expect=selected, export, expect=exported, run_game with waitgame.
- 06-PARITY.md rows B-01.1..B-01.9 carry evidence or "no behaviour in MFC" with a reason. The golden row says "pending win-home". The spec records D019 and the fixture source-art choice.
- These stay green on Linux: test-resource-model, test-resource-model-comparator, test-resource-bridge, test-resource-core, test-resource-app-logic, test-editor-core, resource-editor-host-check, -smoke, -auto and map-editor-smoke. The full sweep is left to the maintainer.

## Proof Level

- This slice proves: Integration on Linux x64. Stats parity is proved against shipped MFC output, the 1.xml files under Data/Units/Technics, through the engine's own reader (CompareStats MECH_UNIT). That is the strongest local oracle. Graphics byte parity with MFC stays pending the win-home golden (export-goldens.ps1 -Extensions msh), which the maintainer runs. Locally the .mod copy is byte-equal and DDS is within tolerance. Preview and locator claims are proved by captured TGAs measured by code. macOS and Windows are left to CI and not claimed.

## Integration Closure

The exporter goes into the exporter.cpp table, so BkResExport, Export Stats Only, Batch, Run Blitzkrieg and BkResPreviewShow (kPreviewKinds already maps kind 6 to SGVOT_MESH) pick it up with no shell changes. The importer joins the BkResImportFromGame switch next to InfantryStatsToTree and the other StatsToTree functions. The new bridge calls are a preview variant switch, a preview direction, locator enumeration with screen positions, and locator/bbox visibility. They enter the ResBridge vtable (c_bridge.zig real, fake_bridge.zig fake), so the app, docks and scenario use them like previewPlayback. Tree-level tools go through resource_core sub_editor_tools (set_prop, insert_node, delete_node), so undo, save and autosave come with them.

## Verification

- The exporter puts MFC's message-box texts into SExportOutcome: missing combat mechanics file (error), missing texture or .mod (warning), and the locator not found for a platform or gun (warning naming the locator). Comparator failures print the field path with both values. The golden comparison prints "GOLDEN msh pass|FAIL|pending" with the reason. The locator rebuild is traced with DebugTrace (BK_DEBUG_LOG=1): the node count and the .mod path. Auto-scenario failures print the frame and the action.

## Tasks

- [x] **T01: Mesh stats exporter (FillRPGStats/SaveRPGStats) proved against the shipped 8_cm_GrWr34 1.xml** `est:4h`
  Why: this is the slice's first proof and its highest risk. MeshFrm.cpp FillRPGStats (L300-1120, about 820 lines of order-sensitive platform, gun, jogging, defence and crater bookkeeping) must reproduce what MFC exported. The oracle is in the repo: Data/Editor/TestProjects/06_Mesh/current.msh is byte-identical to the shipped Data/Units/Technics/German/Artillery/8_cm_GrWr34/current.msh, whose MFC export is the shipped 1.xml.
  - Files: `Sources/src/ResourceModel/items/mesh/mesh_export.cpp`, `Sources/src/ResourceModel/items/stats_export.h`, `Sources/src/ResourceModel/exporter.cpp`, `Sources/src/EditorBridge/resource_bridge_test.cpp`, `build.zig`
  - Verify: zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model-comparator -Dtest-mode=run && zig build test-resource-model -Dtest-mode=run

- [x] **T02: Mesh import (GetRPGStats) and the shipped-unit round trips** `est:3h`
  Why: B-01.9. BkResImportFromGame answers REFUSED for .msh. The import plus stats-only export over several shipped units proves both directions of the port against MFC's own output.
  - Files: `Sources/src/EditorBridge/resource_bridge.cpp`, `Sources/src/EditorBridge/resource_bridge_test.cpp`, `Sources/editor/resource_app/main.zig`, `Sources/editor/resource_app/docks_check.zig`
  - Verify: zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-app-logic -Dtest-mode=run && zig build install-resource-editor && zig build resource-editor-host-check

- [x] **T03: Graphics export (ExportFrameData), fixture source art and the msh golden comparison** `est:3.5h`
  Why: B-01.8. The non-stats half of the export: copied *.mod, alive and dead season DDS, icons, name/desc. The repo fixture project.msh refers to 1.mod/2.mod/3.mod and 1/1w/1a/2/2w/2a.tga, but its folder holds only mesh-2x2x2.obj. Without source art, neither the local test nor the win-home golden can run.
  - Files: `tools/zig/fixtures/resource_editor/msh/1.mod`, `tools/zig/fixtures/resource_editor/msh/2.mod`, `tools/zig/fixtures/resource_editor/msh/3.mod`, `tools/zig/resource_editor_fixtures.zig`, `tools/zig/fixtures/resource_editor/EXTENSIONS.md`, `tools/zig/fixtures/resource_editor/msh/golden/README.md`, `Sources/src/ResourceModel/items/mesh/mesh_export.cpp`, `Sources/src/EditorBridge/resource_bridge_test.cpp`, `tools/zig/resource_model_comparator_test.cpp`
  - Verify: zig build make-resource-fixtures && zig build test-resource-editor-fixtures && zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model-comparator -Dtest-mode=run && zig build test-resource-model -Dtest-mode=run

- [x] **T04: Bridge: locator rebuild, preview model variants, direction, locator positions and visibility** `est:4h`
  Why: B-01.2, B-01.3, B-01.6 and B-01.7, plus the data B-01.4 picks from. The bridge builds only the combat object. Locators are not rebuilt (MFC's SetCombatMesh did it on every load), and nothing hands locator positions to the app.
  - Files: `Sources/src/EditorBridge/resource_bridge.h`, `Sources/src/EditorBridge/resource_bridge.cpp`, `Sources/src/EditorBridge/resource_bridge_test.cpp`, `Sources/src/ResourceModel/items/mesh/mesh_export.cpp`, `tools/zig/fixtures/resource_editor/preview-scene/mesh-combat.tga`, `tools/zig/fixtures/resource_editor/preview-scene/mesh-install.tga`, `tools/zig/fixtures/resource_editor/preview-scene/mesh-transportable.tga`, `tools/zig/fixtures/resource_editor/preview-scene/preview-scene.md`
  - Verify: zig build test-resource-bridge -Dtest-mode=run && zig build test-editor-bridge

- [x] **T05: Core and app: locator pick, variant and visibility toolbar, locator dropdowns, undoable mesh tools** `est:4h`
  Why: B-01.1, B-01.3, B-01.4, B-01.5, B-01.6 and B-01.7 in the app, plus the slice's undo/redo demands (locator move, platform selection, model switch).
  - Files: `Sources/editor/resource_core/bridge.zig`, `Sources/editor/resource_core/fake_bridge.zig`, `Sources/editor/resource_core/sub_editor_tools.zig`, `Sources/editor/resource_core/root.zig`, `Sources/editor/resource_app/c_bridge.zig`, `Sources/editor/resource_app/mesh_logic.zig`, `Sources/editor/resource_app/panels.zig`, `Sources/editor/resource_app/docks.zig`, `Sources/editor/resource_app/docks_check.zig`, `Sources/src/ResourceModel/combos.cpp`, `Sources/src/EditorBridge/resource_bridge_test.cpp`, `build.zig`
  - Verify: zig build test-resource-core -Dtest-mode=run && zig build test-resource-app-logic -Dtest-mode=run && zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model -Dtest-mode=run && zig build install-resource-editor && zig build resource-editor-host-check && zig build resource-editor-smoke

- [x] **T06: BK_EDITOR_AUTO msh block, PARITY rows, spec note and tier run** `est:2.5h`
  Why: the slice demo needs a BK_EDITOR_AUTO scenario for unit edit, export and test launch, plus parity evidence.
  - Files: `Sources/editor/resource_app/scenario.zig`, `build.zig`, `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`, `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`
  - Verify: zig build install-resource-editor && zig build resource-editor-auto && zig build resource-editor-smoke && zig build resource-editor-host-check && zig build test-resource-app-logic -Dtest-mode=run && zig build test-resource-core -Dtest-mode=run && zig build test-editor-core -Dtest-mode=run && zig build map-editor-smoke

## Files Likely Touched

- Sources/src/ResourceModel/items/mesh/mesh_export.cpp
- Sources/src/ResourceModel/items/stats_export.h
- Sources/src/ResourceModel/exporter.cpp
- Sources/src/EditorBridge/resource_bridge_test.cpp
- build.zig
- Sources/src/EditorBridge/resource_bridge.cpp
- Sources/editor/resource_app/main.zig
- Sources/editor/resource_app/docks_check.zig
- tools/zig/fixtures/resource_editor/msh/1.mod
- tools/zig/fixtures/resource_editor/msh/2.mod
- tools/zig/fixtures/resource_editor/msh/3.mod
- tools/zig/resource_editor_fixtures.zig
- tools/zig/fixtures/resource_editor/EXTENSIONS.md
- tools/zig/fixtures/resource_editor/msh/golden/README.md
- tools/zig/resource_model_comparator_test.cpp
- Sources/src/EditorBridge/resource_bridge.h
- tools/zig/fixtures/resource_editor/preview-scene/mesh-combat.tga
- tools/zig/fixtures/resource_editor/preview-scene/mesh-install.tga
- tools/zig/fixtures/resource_editor/preview-scene/mesh-transportable.tga
- tools/zig/fixtures/resource_editor/preview-scene/preview-scene.md
- Sources/editor/resource_core/bridge.zig
- Sources/editor/resource_core/fake_bridge.zig
- Sources/editor/resource_core/sub_editor_tools.zig
- Sources/editor/resource_core/root.zig
- Sources/editor/resource_app/c_bridge.zig
- Sources/editor/resource_app/mesh_logic.zig
- Sources/editor/resource_app/panels.zig
- Sources/editor/resource_app/docks.zig
- Sources/src/ResourceModel/combos.cpp
- Sources/editor/resource_app/scenario.zig
- .planning/phases/06-resource-editor-portable-port/06-PARITY.md
- docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md
