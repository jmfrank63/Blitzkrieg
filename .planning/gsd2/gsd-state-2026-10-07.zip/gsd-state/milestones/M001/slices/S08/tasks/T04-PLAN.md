---
estimated_steps: 6
estimated_files: 8
skills_used: []
---

# T04: Bridge: locator rebuild, preview model variants, direction, locator positions and visibility

Why: B-01.2, B-01.3, B-01.6 and B-01.7, plus the data B-01.4 picks from. The bridge builds only the combat object. Locators are not rebuilt (MFC's SetCombatMesh did it on every load), and nothing hands locator positions to the app.

Do:
1. Locator rebuild (D019): after BkResOpen/import of a .msh project, and after a set_prop on the Graphics combat model name, replace the Locators item's children with one CMeshLocatorPropsItem per skeleton node of the combat .mod (name = node name, nLocatorID = index), as SetCombatMesh (MeshFrm.cpp L1762-1885) did. Read the skeleton through the structure loader shared with mesh_export.cpp; factor a small helper if it helps. The rebuild does not mark the project dirty and is not an undo step. Trace the node count and path with DebugTrace.
2. New ABI in resource_bridge.h/.cpp, following the existing BkResPreview* conventions and Guarded wrapper: BkResPreviewMeshVariant(session, int variant) where 0 is combat, 1 install and 2 transportable (SetCombatMesh/SetInstallMesh/SetTransportableMesh build objects from the 1st/2nd/3rd model name; verify the mapping in the Graphics item and the exporter's output names); BkResPreviewDirection(session, int angle) (MFC UpdateLocators SetDirection from the direction dock); BkResPreviewShowLocators(session, int locators, int bounding_boxes) (the editor\\locator\\1 sprites and SCENE_SHOW_BBS, L1946-1984); BkResMeshLocators(session, BkResLocator *out, int cap, int *count), where BkResLocator = {node id, name[64], world xyz, screen xy}. Screen positions come from the preview scene's own transform (IScene GetPos2), the way bridge.cpp BkEditorWorldToScreen does for the Map Editor. An unavailable variant (no 3.mod) answers REFUSED with a message.
3. Tests in resource_bridge_test.cpp, preview group (skipped with 'no GPU device' where there is none). Import a copy of 8_8_cm_FlaK18 and capture the three variants: each >= 1% non-black-non-magenta, each pair changed >= 0.1%, measured as the existing preview checks do. Commit the captures as tools/zig/fixtures/resource_editor/preview-scene/mesh-combat.tga, mesh-install.tga and mesh-transportable.tga, with their shares in preview-scene.md (D016). Locator checks: the count equals the skeleton node count and the names equal the tree's Locators children. A set_prop of the combat model name to 2.mod rebuilds the children and undoing it restores them. One locator's screen point lies inside the viewport, and a capture with locators shown differs from one without within a few pixels of that point (measured). Direction 90 moves that locator's screen point.

Done when: test-resource-bridge exits 0 and the three captures plus preview-scene.md are committed.

## Inputs

- `Sources/src/editor/MeshFrm.cpp`
- `Sources/src/EditorBridge/resource_bridge.h`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `Sources/src/ResourceModel/items/mesh/mesh_export.cpp`
- `tools/zig/fixtures/resource_editor/preview-scene/preview-scene.md`

## Expected Output

- `Sources/src/EditorBridge/resource_bridge.h`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `Sources/src/ResourceModel/items/mesh/mesh_export.cpp`
- `tools/zig/fixtures/resource_editor/preview-scene/mesh-combat.tga`
- `tools/zig/fixtures/resource_editor/preview-scene/mesh-install.tga`
- `tools/zig/fixtures/resource_editor/preview-scene/mesh-transportable.tga`
- `tools/zig/fixtures/resource_editor/preview-scene/preview-scene.md`

## Verification

zig build test-resource-bridge -Dtest-mode=run && zig build test-editor-bridge

## Observability Impact

DebugTrace (BK_DEBUG_LOG=1) logs each locator rebuild with the node count and .mod path. A missing variant model answers REFUSED with a message naming the file.
