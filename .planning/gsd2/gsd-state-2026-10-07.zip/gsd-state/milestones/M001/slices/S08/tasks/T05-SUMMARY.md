---
id: T05
parent: S08
milestone: M001
key_files: []
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-05T15:24:30.722Z
blocker_discovered: false
---

# T05: Unit editor app: ResBridge gains mesh variant, direction, locator visibility and locator reads; pickLocator and nodeForLocator tested; locator combos computed from the Locators children; a unit preview toolbar with a locator overlay and right-click pick; undo and redo tests for locator references, platform choice, model switch and platform and gun insert and delete.

**Unit editor app: ResBridge gains mesh variant, direction, locator visibility and locator reads; pickLocator and nodeForLocator tested; locator combos computed from the Locators children; a unit preview toolbar with a locator overlay and right-click pick; undo and redo tests for locator references, platform choice, model switch and platform and gun insert and delete.**

## What Happened

The vtable (bridge.zig), the real adapter (c_bridge.zig) and the fake (fake_bridge.zig) carry previewMeshVariant, previewDirection, previewShowLocators and meshLocators. The fake rebuilds the Locators children when the combat model name changes, so undo of a model switch is testable headlessly. mesh_logic.zig holds pickLocator, nodeForLocator, pickAndSelect (selection only, history unchanged), missText (click and nearest-marker distance for the observability line), the Toolbar state and the undo/redo tests. MeshLocatorStrings (MFC's four LoadGun*/LoadPlatform*PropsComboBox) computes the lists from the open project's Locators children and ends each with NA. I first put it in combos.cpp, which broke the test-resource-model references target because that target does not link the tree-item sources. I moved the definition to items/mesh/mesh.cpp and kept the declaration in combos.h. In the app, panels.zig draws a Unit preview toolbar with combat, install and transportable radios and the two toggles, and draws locator markers and the active locator line in the foreground draw list from the engine's screen positions. A right-click outside any window picks the nearest marker and selects its tree node, or reports the click and nearest distance in the status line. docks.zig turns the previewed unit when the direction needle drags and the open project is a unit. I did not add docks_check wiring beyond the mesh_logic headless tests. The overlay's visual placement was not captured in a screenshot here.

## Verification

test-resource-core, test-resource-app-logic, test-resource-bridge and test-resource-model exited 0. install-resource-editor, resource-editor-host-check and resource-editor-smoke exited 0 on Linux. The GUI tiers ran with the default environment, with no live-display capture of the overlay.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-core -Dtest-mode=run` | 0 | pass | 1000ms |
| 2 | `zig build test-resource-app-logic -Dtest-mode=run` | 0 | pass | 1000ms |
| 3 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 32000ms |
| 4 | `zig build test-resource-model -Dtest-mode=run` | 0 | pass | 23000ms |
| 5 | `zig build install-resource-editor` | 0 | pass | 30000ms |
| 6 | `zig build resource-editor-host-check -Dtest-mode=run` | 0 | pass | 6000ms |
| 7 | `zig build resource-editor-smoke -Dtest-mode=run` | 0 | pass | 5000ms |

## Deviations

None.

## Known Issues

None.

## Files Created/Modified

None.
