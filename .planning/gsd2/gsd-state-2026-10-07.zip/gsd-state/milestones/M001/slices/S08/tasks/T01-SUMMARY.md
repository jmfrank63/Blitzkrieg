---
id: T01
parent: S08
milestone: M001
key_files:
  - Sources/src/ResourceModel/items/mesh/mesh_export.cpp
  - Sources/src/ResourceModel/exporter.cpp
  - Sources/src/ResourceModel/exporter.h
  - Sources/src/ResourceModel/items/stats_export.h
  - Sources/src/EditorBridge/resource_bridge.cpp
  - Sources/src/EditorBridge/resource_bridge_test.cpp
  - build.zig
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-05T14:36:08.831Z
blocker_discovered: false
---

# T01: Registered "msh" exporter ports CMeshFrame::FillRPGStats/SaveRPGStats, reading the .mod files through the structure loader. The .mod-derived fields equal the shipped 8_cm_GrWr34 1.xml to its six printed digits; the project-property fields could not be compared.

**Registered "msh" exporter ports CMeshFrame::FillRPGStats/SaveRPGStats, reading the .mod files through the structure loader. The .mod-derived fields equal the shipped 8_cm_GrWr34 1.xml to its six printed digits; the project-property fields could not be compared.**

## What Happened

Added items/mesh/mesh_export.cpp (ExportMesh), registered as "msh" in exporter.cpp, declared in stats_export.h and added to the EditorBridge archive list in build.zig. FillRPGStats is ported line for line into SMechUnitRPGStats. Per D019, node names and bind-pose matrices come from the .mod skeleton (chunk 1) walked with the engine's matrix stack; chunks 3/4/5/6 give animations and boxes. A missing combat .mod fails with MFC's "Can not load combat mechanics file". Missing install and transportable .mod files are skipped as in MFC. A platform or gun locator that is no node of the model gets nModelPart/nShootPoint -1 and a warning naming it. The IObjectsDB weapon lookup became SExportContext::isBallisticWeapon, which the bridge fills from IObjectsDB. DebugTrace logs the .mod path and node count. A new S08Mesh test in resource_bridge_test.cpp copies the shipped 8_cm_GrWr34 .mod files plus 06_Mesh/current.msh, runs a stats-only export, and checks that no .mod or DDS is written. It also checks that a project with no combat .mod fails with MFC's message and promotes nothing. The two old "msh is not ported" assertions were updated: the fixture loop now expects the combat-model failure, and the batch test uses a pcp as its not-ported example. Import of msh stays refused until the importer task. The plan's oracle assumption does not hold: the shipped 1.xml is a 2003 export printed to six digits, and current.msh holds template property values (camouflage 1, empty first platform locator, armor 6, no commands) that differ from that export. An exact-float CompareStats therefore cannot be field-equal. The test partitions CompareStats' differences. The 68 differences in the project's own property values are listed as not compared. The .mod-derived fields (AABBs, people, ammo and gunner points, shoot point, direction, anim descs) must match within the golden's six digits, and they do, with 0 differences. The exact-float proof of the property half belongs to the import-then-export round trip in the importer task.

## Verification

Ran three tiers, each in the foreground and each exiting 0: test-resource-bridge (including the new S08Mesh checks), test-resource-model-comparator and test-resource-model. Not run: the full resource sweep, which is left to the maintainer. Linux only; nothing was verified on macOS or Windows.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 300000ms |
| 2 | `zig build test-resource-model-comparator -Dtest-mode=run` | 0 | pass | 60000ms |
| 3 | `zig build test-resource-model -Dtest-mode=run` | 0 | pass | 60000ms |

## Deviations

The plan expected a field-equal comparison against the shipped 1.xml with exact floats. That is not possible: the 1.xml is a 2003 six-digit export and current.msh holds template property values. The test compares the .mod-derived fields at six digits and does not compare the project-property fields.

## Known Issues

None.

## Files Created/Modified

- `Sources/src/ResourceModel/items/mesh/mesh_export.cpp`
- `Sources/src/ResourceModel/exporter.cpp`
- `Sources/src/ResourceModel/exporter.h`
- `Sources/src/ResourceModel/items/stats_export.h`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `build.zig`
