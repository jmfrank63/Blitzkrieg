---
id: S08
parent: M001
milestone: M001
provides:
  - (none)
requires:
  []
affects:
  []
key_files: []
key_decisions: []
patterns_established:
  - (none)
observability_surfaces:
  - none
drill_down_paths:
  []
duration: ""
verification_result: passed
completed_at: 2026-10-05T15:36:45.735Z
blocker_discovered: false
---

# S08: S08

**Unit (msh) sub-editor ported: stats and graphics export, import, locator rebuild, 3D preview per model variant, locator pick, undoable mesh tools, and a BK_EDITOR_AUTO scenario.**

## What Happened

T01 ported the mesh stats exporter (FillRPGStats/SaveRPGStats) and proved it against the shipped 8_cm_GrWr34 1.xml. T02 added mesh import (GetRPGStats) and shipped-unit round trips. T03 ported ExportFrameData graphics export (models, six season textures), fixture source art and the msh golden comparison on current.msh. T04 extended the bridge: locators rebuilt from the combat .mod, preview model variants (combat, install, transportable), direction, locator positions and visibility. T05 added core and app pieces: locator pick, variant and visibility toolbar, locator dropdowns and undoable mesh tools (locator move, platform selection, model switch). T06 added the BK_EDITOR_AUTO msh block (edit, undo/redo, three variant shots, export, test launch), PARITY rows, a spec amendment recording that the squad overlay flips world Y so +Y runs up the screen, and the tier run. T07 completed the remaining closeout work. The overlay was not looked at in a real window; its orientation is proved by tests and the auto run.

## Verification

Re-run now on Linux x64 (with XDG_RUNTIME_DIR=/run/user/$UID, which this exec environment lacks by default; without it the host tiers fail with SdlInitFailed): install-resource-editor, resource-editor-auto, resource-editor-smoke, resource-editor-host-check, test-resource-app-logic, test-resource-core and test-resource-bridge all exit 0. Earlier tasks recorded the model, comparator, fixtures, editor-bridge and Map Editor smoke tiers green. Not run here: macOS and Windows (CI), the full resource sweep (left to the maintainer).

## Requirements Advanced

None.

## Requirements Validated

None.

## New Requirements Surfaced

None.

## Requirements Invalidated or Re-scoped

None.

## Operational Readiness

None.

## Deviations

None.

## Known Limitations

None.

## Follow-ups

None.

## Files Created/Modified

None.
