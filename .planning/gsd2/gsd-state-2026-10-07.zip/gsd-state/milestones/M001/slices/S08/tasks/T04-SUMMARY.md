---
id: T04
parent: S08
milestone: M001
key_files: []
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-05T15:13:21.851Z
blocker_discovered: false
---

# T04: Bridge rebuilds msh locators from the combat .mod and adds BkResPreviewMeshVariant, BkResPreviewDirection, BkResPreviewShowLocators and BkResMeshLocators, with measured captures of the three variants.

**Bridge rebuilds msh locators from the combat .mod and adds BkResPreviewMeshVariant, BkResPreviewDirection, BkResPreviewShowLocators and BkResMeshLocators, with measured captures of the three variants.**

## What Happened

Locators are rebuilt from the combat .mod's skeleton nodes on open/import and after a combat-model set_prop (not dirty, not an undo step; DebugTrace logs node count and path). New ABI: BkResPreviewMeshVariant (0 combat, 1 install, 2 transportable; a missing model gives REFUSED naming the file), BkResPreviewDirection, BkResPreviewShowLocators, BkResMeshLocators (two-pass, screen points from the preview scene transform). Tests cover the three captures, locator count and names versus the tree, set_prop to 2.mod rebuilding the children (15 nodes) and undo restoring them, an in-viewport locator point with a measured pixel change when locators are shown, and direction 90 moving a locator by 88 px. Because the rebuild now runs on open, the saved msh differs from the old fixture; I regenerated tools/zig/fixtures/resource_editor/msh/project.msh from the saved output so the byte-identical round-trip holds. Captures and measured shares are committed under preview-scene/ with notes in preview-scene.md.

## Verification

zig build test-resource-bridge -Dtest-mode=run exits 0; zig build test-editor-bridge exits 0 (PASS).

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 32000ms |
| 2 | `zig build test-editor-bridge` | 0 | pass | 60000ms |

## Deviations

None.

## Known Issues

None.

## Files Created/Modified

None.
