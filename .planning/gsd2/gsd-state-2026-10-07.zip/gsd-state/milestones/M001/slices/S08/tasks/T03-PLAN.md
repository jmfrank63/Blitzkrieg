---
estimated_steps: 7
estimated_files: 9
skills_used: []
---

# T03: Graphics export (ExportFrameData), fixture source art and the msh golden comparison

Why: B-01.8. The non-stats half of the export: copied *.mod, alive and dead season DDS, icons, name/desc. The repo fixture project.msh refers to 1.mod/2.mod/3.mod and 1/1w/1a/2/2w/2a.tga, but its folder holds only mesh-2x2x2.obj. Without source art, neither the local test nor the win-home golden can run.

Do:
1. Fixture source art. Copy 1.mod, 2.mod and 3.mod from one tracked shipped unit that ships all three (for example Data/Units/Technics/German/Artillery/8_8_cm_FlaK18) into tools/zig/fixtures/resource_editor/msh/. Prefer a unit whose node names match the locator names project.msh references; if it references none, any 3-model unit will do. Extend tools/zig/resource_editor_fixtures.zig to generate small deterministic TGAs (1, 1w, 1a, 2, 2w, 2a and any icon source the project names) for msh, the way S07 did for unt. Record the source unit and the art in tools/zig/fixtures/resource_editor/EXTENSIONS.md and msh/golden/README.md.
2. In mesh_export.cpp port ExportFrameData (MeshFrm.cpp L1313-1545) after the stats: copy every *.mod in the combat model's folder; ConvertAndSaveImage for 1/1w/1a/2/2w/2a and the rest of the list (1p*, icon.tga 64 px, icon 128 px, icon512, name.txt/desc.txt from the localisation item). Reuse NImageExport (image_export.h, SaveCompressedTexture with MFC's low format and gamma) and the localisation copy that infantry_export.cpp uses. Port FindMaximalSourceTime/FindMinimalExportFileTime (L2137-2306) for the non-forced up-to-date skip (nSkipped). A missing texture is a warning, as MFC's message box was.
3. Tests in resource_bridge_test.cpp: export the fixture from a zig-out/local-test copy. The .mod files must be byte-equal to their sources, every DDS within the dxt-tolerance.json gate of its source TGA (dxt_gate), name/desc copied, and a second forced export byte-identical. A non-forced export over an up-to-date export reports nSkipped > 0. A deleted 1w.tga gives a warning and no 1w DDS.
4. The golden comparison in tools/zig/resource_model_comparator_test.cpp (S07 T08 made it real per kind with an exporter) must include msh and report 'GOLDEN msh pending' while golden/ holds only README.md. Run make-resource-fixtures and test-resource-editor-fixtures after the generator change.

Done when: the listed tiers exit 0 and the golden line for msh says pending, not pass.

## Inputs

- `Sources/src/editor/MeshFrm.cpp`
- `Sources/src/ResourceModel/items/mesh/mesh_export.cpp`
- `Sources/src/ResourceModel/items/infantry/infantry_export.cpp`
- `Sources/src/ResourceModel/image_export.h`
- `Sources/src/ResourceModel/dxt_gate.h`
- `tools/zig/fixtures/resource_editor/dxt-tolerance.json`
- `tools/zig/fixtures/resource_editor/msh/project.msh`
- `tools/zig/resource_editor_fixtures.zig`
- `tools/zig/resource_model_comparator_test.cpp`
- `Data/Units/Technics/German/Artillery/8_8_cm_FlaK18/3.mod`

## Expected Output

- `tools/zig/fixtures/resource_editor/msh/1.mod`
- `tools/zig/fixtures/resource_editor/msh/2.mod`
- `tools/zig/fixtures/resource_editor/msh/3.mod`
- `tools/zig/resource_editor_fixtures.zig`
- `tools/zig/fixtures/resource_editor/EXTENSIONS.md`
- `tools/zig/fixtures/resource_editor/msh/golden/README.md`
- `Sources/src/ResourceModel/items/mesh/mesh_export.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `tools/zig/resource_model_comparator_test.cpp`

## Verification

zig build make-resource-fixtures && zig build test-resource-editor-fixtures && zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model-comparator -Dtest-mode=run && zig build test-resource-model -Dtest-mode=run

## Observability Impact

Missing textures and .mod files are warnings in SExportOutcome. The golden comparison prints 'GOLDEN msh pass|FAIL <file> <reason>|pending'.
