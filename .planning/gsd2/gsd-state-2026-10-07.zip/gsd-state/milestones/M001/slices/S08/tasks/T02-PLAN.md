---
estimated_steps: 6
estimated_files: 4
skills_used: []
---

# T02: Mesh import (GetRPGStats) and the shipped-unit round trips

Prerequisite: T07 (D018 squad overlay Y direction) must be complete before this task starts.

Why: B-01.9. BkResImportFromGame answers REFUSED for .msh. The import plus stats-only export over several shipped units proves both directions of the port against MFC's own output.

Do:
1. In Sources/src/EditorBridge/resource_bridge.cpp add MechStatsToTree(const SMechUnitRPGStats &, NResourceModel::CTreeItem &root), porting CMeshFrame::GetRPGStats (MeshFrm.cpp L1136-1300) line for line next to InfantryStatsToTree/SquadStatsToTree. Add the msh case to BkResImportFromGame (around L4576), using the same read pattern (StatsFileIn, CTreeAccessor tree.Add("RPG", &rpgStats)), CreateDefaultChilds and a fresh Project. Graphics model names keep their defaults (1.mod/2.mod/3.mod) as in MFC, so the imported project sits beside the shipped .mod files.
2. Flip the refusal assertions: the app's docks check in Sources/editor/resource_app/main.zig or docks_check.zig ('.msh import refused'), and any in resource_bridge_test.cpp. Point any remaining refusal check at a kind that is still unported, such as .obt.
3. Test in resource_bridge_test.cpp. For at least 5 shipped units copied into zig-out/local-test/resource_editor/s08/import/<name>/ (8_8_cm_FlaK18 with 3.mod, a tank, a truck or tractor, an AA gun, and an aircraft if Data/Units/Technics has one; find them with case-insensitive lookups), import, save, reopen, run stats-only export, and CompareStats MECH_UNIT against that unit's shipped 1.xml. Fields MFC's GetRPGStats does not carry back (if any) go in an explicit allow list, each with its MeshFrm.cpp line and reason, and the test fails on any difference outside the list. Also assert that the imported project's tree has the MFC child set (Common, Defences, Graphics, Platforms, Joggings, Locators, Avia, Effects, Sound, Track).

Done when: test-resource-bridge exits 0 with every unit field-equal (allow list printed), test-resource-app-logic exits 0, and the app docks check passes.

## Inputs

- `Sources/src/editor/MeshFrm.cpp`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `Sources/src/ResourceModel/items/mesh/mesh_export.cpp`
- `Sources/editor/resource_app/main.zig`
- `Sources/editor/resource_app/docks_check.zig`
- `Data/Units/Technics/German/Artillery/8_8_cm_FlaK18/1.xml`

## Expected Output

- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `Sources/editor/resource_app/main.zig`
- `Sources/editor/resource_app/docks_check.zig`

## Verification

zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-app-logic -Dtest-mode=run && zig build install-resource-editor && zig build resource-editor-host-check

## Observability Impact

The round-trip test prints one line per unit with the compared field count and the allow-listed fields it skipped.
