---
estimated_steps: 5
estimated_files: 4
skills_used: []
---

# T07: Squad overlay screen Y direction matches MFC (D018)

RUNS NEXT, BEFORE T02 (hard steer 2026-10-05T14:40; the id T07 is only a label, execution order is T07, T02, T03, T04, T05, T06). Scope is S08-RESEARCH.md section 0 (D018). After the S07 review the squad overlay's View (Sources/editor/resource_app/squad_logic.zig toScreen/toWorld) maps world Y to screen Y without a flip, so the overlay may show the formation mirrored top to bottom compared with MFC's SquadFrm view. MFC projects with IScene::GetPos2 through the isometric camera. Input and drawing share the View, so the stored angle (D016) already matches the drawn arrow; this task is about the picture only and does not change the angle convention.
1. From MFC's camera/GetPos2 code (Sources/src/editor/SquadFrm.cpp plus the scene/camera sources it calls) work out which screen direction world +Y takes. Cite file:line evidence.
2. If it differs from the port: flip Y in View.toScreen/toWorld and the canvas origin in panels.zig (around lines 415-429). Update the app-logic tests and the resource-editor-auto squad steps that use screen coordinates (e.g. squad_arrow). Add a test that starts from a screen point above the zero point and checks the world direction.
3. If it matches: record the finding with the MFC file:line evidence in docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md and close.
Done when: the direction is established with evidence, the code or the spec is updated accordingly, and the verify tiers pass. Completing this task closes the D018 override.

## Inputs

- `Sources/src/editor/SquadFrm.cpp`
- `Sources/editor/resource_app/squad_logic.zig`
- `Sources/editor/resource_app/panels.zig`
- `.gsd/milestones/M001/slices/S08/S08-RESEARCH.md`

## Expected Output

- `Sources/editor/resource_app/squad_logic.zig`
- `Sources/editor/resource_app/panels.zig`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`

## Verification

zig build test-resource-app-logic -Dtest-mode=run && zig build resource-editor-auto

## Observability Impact

None; pure app logic and test scenario change.
