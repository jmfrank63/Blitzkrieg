---
id: T02
parent: S08
milestone: M001
key_files:
  - Sources/src/EditorBridge/resource_bridge.cpp
  - Sources/src/EditorBridge/resource_bridge_test.cpp
  - Sources/editor/resource_app/main.zig
  - Sources/editor/resource_app/docks_check.zig
  - Sources/src/ResourceModel/variant.cpp
  - Sources/src/ResourceModel/items/mesh/mesh_export.cpp
  - Sources/src/ResourceModel/items/infantry/infantry_export.cpp
key_decisions:
  - Fixed CVariant::SetType int64-to-string to MFC's hex form instead of allow-listing the Commands/Exposures differences.
duration: 
verification_result: passed
completed_at: 2026-10-05T14:47:18.110Z
blocker_discovered: false
---

# T02: Mesh import (MechStatsToTree, port of CMeshFrame::GetRPGStats) added to BkResImportFromGame; six shipped units import, save, reopen and export stats-only field-equal to their 1.xml outside a documented allow list.

**Mesh import (MechStatsToTree, port of CMeshFrame::GetRPGStats) added to BkResImportFromGame; six shipped units import, save, reopen and export stats-only field-equal to their 1.xml outside a documented allow list.**

## What Happened

Added MechStatsToTree and MeshTypeName in resource_bridge.cpp, a line-for-line port of CMeshFrame::GetRPGStats. Platforms and guns are first built to the stats' counts, because an import starts from the default tree. The msh case in BkResImportFromGame reads the unit's 1.xml with the engine's own reader; graphics model names keep their defaults, so the project sits beside the shipped .mod files. The refusal assertions now use .obt (resource_bridge_test.cpp, docks_check.zig, main.zig). New test S08Mesh::ImportRoundTrips imports 8_8_cm_FlaK18, 8_cm_GrWr34, Pz_III_Ausf_E, Opel_Blitz_Cargo, 2_cm_FlaK30_38 and FW_190, checks the MFC child set, saves, reopens, exports stats-only and runs CompareStats MECH_UNIT against each shipped 1.xml. The allow list (printed by the test) holds only the platform and gun locator combos that GetRPGStats leaves at "NA" (MeshFrm.cpp:1274-1298). The first run showed the Commands and Exposures bit masks truncated to 32 bits after reopen. Cause: the port's CVariant::SetType converted an int64 to a string with "%i", where MFC's SetType (COI/Variant.cpp) writes _ui64toa(...,16) and OptimizeInt64 reads it back as hex. Fixed in variant.cpp (hex string for VK_INT64) and in ValueInt64 of mesh_export.cpp and infantry_export.cpp (parse VK_STR as hex). After that every unit shows 0 differences outside the allow list.

## Verification

test-resource-bridge exits 0; each of the 6 units prints "0 other" differences (280-348 fields compared); test-resource-app-logic exits 0; install-resource-editor succeeds; resource-editor-host-check passes and the docks check passes with ".obt import refused". Full resource sweep left to the maintainer.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 35000ms |
| 2 | `zig build test-resource-app-logic -Dtest-mode=run` | 0 | pass | 1400ms |
| 3 | `zig build install-resource-editor` | 0 | pass | 30000ms |
| 4 | `zig build resource-editor-host-check` | 0 | pass | 10000ms |

## Deviations

The plan's prerequisite (T07, D018) was not complete when this task ran; T02 does not depend on T07's code, so it ran anyway. Also changed shared model code (variant.cpp, infantry_export.cpp) to fix the int64 round trip.

## Known Issues

T01's golden line "ROUNDTRIP msh 8_cm_GrWr34: DIFFERENT" still prints (project-property fields could not be compared, per T01); not changed here. T07 (D018) is still open. Other tiers (editor-bridge, Map Editor) were not rerun after the variant.cpp change.

## Files Created/Modified

- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `Sources/editor/resource_app/main.zig`
- `Sources/editor/resource_app/docks_check.zig`
- `Sources/src/ResourceModel/variant.cpp`
- `Sources/src/ResourceModel/items/mesh/mesh_export.cpp`
- `Sources/src/ResourceModel/items/infantry/infantry_export.cpp`
