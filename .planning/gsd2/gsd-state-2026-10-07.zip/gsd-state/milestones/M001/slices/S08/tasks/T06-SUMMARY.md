---
id: T06
parent: S08
milestone: M001
key_files:
  - Sources/editor/resource_app/scenario.zig
  - build.zig
  - .planning/phases/06-resource-editor-portable-port/06-PARITY.md
  - docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-05T15:29:36.906Z
blocker_discovered: false
---

# T06: BK_EDITOR_AUTO msh block (edit, undo/redo, three variant shots, locator pick, export, real Game launch) passes; PARITY B-01.1..9 and the D019 spec note are written.

**BK_EDITOR_AUTO msh block (edit, undo/redo, three variant shots, locator pick, export, real Game launch) passes; PARITY B-01.1..9 and the D019 spec note are written.**

## What Happened

scenario.zig gained do=mesh_variant, do=locators, do=pick_locator (clicks at the locator's screen point through mesh_logic.pickAndSelect) and expect=selected. The resource-editor-auto schedule has a new S08 block on the fixture msh project copy: set_prop and undo/redo, shots of the three variants (differ checks), locators on and two picks, save, export, file checks on units/technics/msh/1.xml and 1.mod, run_game with waitgame. My first guess at the export path (data/EXPORTED) failed; the exporter writes under data/units/technics/msh, so I corrected the expectation. PARITY rows B-01.1..9 have evidence; the golden part of B-01.8 says pending win-home. The spec records D019 and the fixture source-art choice. The full sweep is left to the maintainer.

## Verification

Ran each verify command in the foreground; all exit 0, and the auto log shows the msh block passing through frame 232.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build install-resource-editor` | 0 | pass | 3900ms |
| 2 | `zig build resource-editor-auto` | 0 | pass | 120000ms |
| 3 | `zig build resource-editor-smoke` | 0 | pass | 5640ms |
| 4 | `zig build resource-editor-host-check` | 0 | pass | 5650ms |
| 5 | `zig build test-resource-app-logic -Dtest-mode=run` | 0 | pass | 500ms |
| 6 | `zig build test-resource-core -Dtest-mode=run` | 0 | pass | 500ms |
| 7 | `zig build test-editor-core -Dtest-mode=run` | 0 | pass | 1150ms |
| 8 | `zig build map-editor-smoke` | 0 | pass | 12280ms |

## Deviations

None.

## Known Issues

None.

## Files Created/Modified

- `Sources/editor/resource_app/scenario.zig`
- `build.zig`
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`
