# S17 Replan

**Milestone:** M001
**Slice:** S17
**Blocker Task:** T02
**Created:** 2026-10-06T18:40:32.068Z

## Blocker Description

Hard steer 2026-10-06T18:40: CI run 37507439455 at 162a7f0a4 is red. Linux x86_64, Linux ARM and likely macOS arm64 'Resource bridge tier' fail because the sparse checkout lacks the Data that test-resource-model and test-resource-bridge read, and a tier aborts on an uncaught std::filesystem_error. Windows MSVC 'Editor core tier' fails: test-editor-core builds for native and needs imm32 through Dear ImGui.

## What Changed

New T04 (CI green on every job) inserted before the docs task, which becomes T05 with unchanged content. T04: minimal per-tier sparse-checkout Data lists in every job, no resource tier aborts on a missing data folder (FAIL naming the path), proven in the sparse /tmp/bk-cmp worktree; editor test tiers built for the requested target with imm32 linked (or IMGUI_DISABLE_WIN32_DEFAULT_IME_FUNCTIONS) on Windows, proven on win-home D:\bk-ci with Zig 0.16.
