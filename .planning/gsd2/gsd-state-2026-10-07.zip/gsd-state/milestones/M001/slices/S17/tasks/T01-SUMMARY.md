---
id: T01
parent: S17
milestone: M001
key_files: []
key_decisions: []
duration: 
verification_result: mixed
completed_at: 2026-10-06T17:37:24.874Z
blocker_discovered: false
---

# T01: Added the test-resource-mod-roundtrip tier: engine-reader discovery of a mod's resources, import then export then field-by-field comparison with one accept table, a tracked mini-mod fixture, and a 'skipped: no mod' path.

**Added the test-resource-mod-roundtrip tier: engine-reader discovery of a mod's resources, import then export then field-by-field comparison with one accept table, a tracked mini-mod fixture, and a 'skipped: no mod' path.**

## What Happened

Built the D053 tier. tools/zig/resource_mod_roundtrip_test.cpp is an engine-hosted executable (same build as test-resource-bridge: rdynamic, $ORIGIN rpath, hidden not-focusable SDL window, GPU-skip with BK_REQUIRE_ENGINE). build.zig's addResourceBridge now takes a ResourceBridgeTier spec so both tiers share one build; the new step test-resource-mod-roundtrip takes -Dmod-root (exported as BK_MOD_ROOT) or an inherited BK_MOD_ROOT.

Discovery walks the mod for .xml files and suggests candidate kinds by folder (weapons, effects/particles, terrain roads/rivers, scenarios/campaigns, 1.xml per top folder), then classifies each by what the engine's reader accepts: NResourceModel::ReadExport must read the chunk with no node left unread, and the reader that consumed the most chunks wins. A road or river is moved to the other kind when the importer's own type check refuses it. Importable kinds come from the code (kind <= 3, unt, msh, obt, fnc, bld, bdg, pcp, 3rd, 3rv, mip, chc, cgc, mdc), and the stale BkResImportFromGame doc comment in resource_bridge.h is corrected to list them.

Per resource: copy the stats (keeping the path below the mod root, so medal/scenario export file names survive) plus the siblings the kind needs (.mod for msh, .dds for mdc/mip/chc/cgc) into zig-out/local-test/mod-roundtrip/<set>/<kind>/<n>/src, import, save beside the copy, export stats-only to a scratch export root, and compare the export with the copy through CompareRoundTrip. Differences are FAIL unless the single kAcceptRules table (kind, path substring, reason, optional 'mod ships no siblings' condition), the comparator's own round-trip losses, or six-digit float printing accepts them. The table holds: msh not-carried-back platforms/guns (06-PARITY), MODName/MODVersion written from the export root for mip/chc/cgc, MFC's own 'You should specify ...' export refusal, and the files-referenced-but-not-shipped cases (msh .mod, medal/mission/chapter/campaign picture rectangles). Output is one MOD <kind> <path> EQUAL|ACCEPTED <reason>|FAIL <field>: <mod value> vs <port value> line per resource, MOD SUMMARY per kind, and a MOD GUARD line: the mod's files (path, size, mtime) are snapshotted before and after and any change fails the run. BK_MOD_KINDS limits a run to some kinds so the real run can be split under the tier budget.

The tracked mini-mod tools/zig/fixtures/mod-roundtrip/data is built only from Data/ files (one weapon, unit, squad, mine, medal, road, particle, mission, chapter, campaign) and always runs first, so CI exercises the non-skip path; without a mod root the tier then prints 'skipped: no mod'. The tier is registered in tools/zig/run-resource-sweep.sh and in all five platform jobs of cross-platform.yml (BK_REQUIRE_ENGINE set where the bridge step sets it). It is not in test-resources-all: that aggregate is window-and-GPU-free, and this tier needs the engine started like test-resource-bridge, which is not in it either.

A smoke run against the real AchtungPanzer2 data with BK_MOD_KINDS=wpn,mdc found 196 weapons and 17 medals, imported them all, left the mod's 18007 files unchanged, and took 22 s; its 84 weapon and 17 medal FAILs (extra shell fields the port writes, medal fields) are the real findings for T02, not harness defects.

## Verification

Ran zig build test-resource-mod-roundtrip (exit 0: fixture run over 10 resources, 2 EQUAL and 8 ACCEPTED each with a reason, MOD GUARD unchanged, then 'skipped: no mod'), zig build test-resource-bridge (exit 0, Project+Tree OK) and zig build resource-editor-batch (exit 0). Also ran the tier with -Dmod-root against AchtungPanzer2 for wpn and mdc to prove the real path (discovery, import, guard); its failures are findings for T02. macOS and Windows were not run here; they are covered by the cross-platform workflow when the branch is pushed. The full resource sweep is left to the maintainer.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-mod-roundtrip` | 0 | pass | 4960ms |
| 2 | `zig build test-resource-bridge` | 0 | pass | 77950ms |
| 3 | `zig build resource-editor-batch` | 0 | pass | 6700ms |
| 4 | `BK_MOD_KINDS=wpn,mdc zig build test-resource-mod-roundtrip -Dmod-root=<AchtungPanzer2/data>` | 1 | expected: harness path proven, 101 real findings left for T02 | 21990ms |

## Deviations

None.

## Known Issues

None.

## Files Created/Modified

None.
