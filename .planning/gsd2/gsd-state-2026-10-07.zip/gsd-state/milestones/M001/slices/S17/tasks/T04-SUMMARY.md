---
id: T04
parent: S17
milestone: M001
key_files:
  - build.zig
  - .github/workflows/cross-platform.yml
  - tools/zig/resource_model_test.cpp
  - Sources/editor/kit/imgui/msvc_fltused.c
key_decisions:
  - Resource tiers need the Windows job's measured Data list plus Medals and Old; ELK, AmericanELK, movies, Music and Bugs are left out
  - Windows test tiers link vcruntimed and the SDK library paths, and the MSVC ImGui lib drops thread-safe statics and defines _fltused, instead of linking the full CRT next to Zig's libc
duration: 
verification_result: mixed
completed_at: 2026-10-06T19:42:21.563Z
blocker_discovered: false
---

# T04: Sparse-checkout Data lists for every resource-tier job, resource tiers FAIL naming a missing folder instead of aborting, and the Windows MSVC editor test tiers now link (imm32, vcruntime, fltused shim).

**Sparse-checkout Data lists for every resource-tier job, resource tiers FAIL naming a missing folder instead of aborting, and the Windows MSVC editor test tiers now link (imm32, vcruntime, fltused shim).**

## What Happened

Sparse checkout: traced Data accesses in a full worktree, then bisected in /tmp/bk-cmp. install-game stages nearly all of Data, so the resource tiers need the Windows job's measured list plus Medals and Old (the unt round trip). Dropping Sounds, Cursor, Icons, Fonts or Water makes a tier fail; ELK, AmericanELK, movies, Music and Bugs are not needed. cross-platform.yml: Linux x64, Linux arm and macOS x64 now use that list (with all of Scenarios, 146 MB); the Windows MSVC and macOS arm lists gained Medals and Old; MinGW runs no Data tier and is unchanged. Missing-data handling: tools/zig/resource_model_test.cpp used throwing directory_iterator calls; a ListDirectory helper now reports 'FAIL folder-present:<path> cannot be listed'. Every other resource tier already used error_code iterators. Removing Data/Editor in the sparse worktree and running model, bridge, mod-roundtrip and core gives FAIL lines naming the missing paths and zero aborts. Windows: reproduced 'could not open libimm32.a' on win-home D:\bk-ci. Fix in build.zig: the ImGui library links imm32 on Windows targets; the kit, editor core and resource core test modules get the MSVC library paths and vcruntimed on Windows hosts; the MSVC ImGui build uses -fno-threadsafe-statics and Sources/editor/kit/imgui/msvc_fltused.c supplies _fltused, because the tests link Zig's libc and the full CRT duplicates its TLS symbols.

## Verification

Windows native (win-home, Zig 0.16.0, x86_64-windows-msvc): test-editor-core, test-editor-kit and test-resource-core pass (105 tests in the core run); test-map-editor-view, -panels, -testlaunch and -auto each pass when run alone; editor-overlay-spike-build links (full-CRT consumer of the same ImGui lib). Linux: test-editor-core, test-editor-kit, test-resource-core, test-resource-model and test-resource-bridge pass in the main tree. /tmp/bk-cmp on the exact Linux sparse list from the workflow: test-resource-model, test-resource-bridge, test-resource-mod-roundtrip, test-resource-core, test-map-files and test-mission-data pass. The Linux-hosted 'zig build test-editor-core -Dtarget=x86_64-windows-msvc' from the plan's Verify line panics on missing -Dmsvc-include and SDK paths, as it does on the base commit; the Windows result comes from win-home. No CI result, and nothing for macOS, was seen.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-editor-core` | 0 | pass | 5000ms |
| 2 | `zig build test-resource-model -Dtest-mode=run` | 0 | pass | 60000ms |
| 3 | `zig build test-resource-bridge` | 0 | pass | 80000ms |
| 4 | `win-home: zig build test-editor-core test-editor-kit test-resource-core -Dtarget=x86_64-windows-msvc -Dtest-mode=run` | 0 | pass | 120000ms |
| 5 | `win-home: zig build editor-overlay-spike-build -Dtarget=x86_64-windows-msvc` | 0 | pass | 90000ms |
| 6 | `/tmp/bk-cmp sparse: zig build test-resource-model test-resource-bridge test-resource-mod-roundtrip test-resource-core test-map-files test-mission-data -Dtest-mode=run` | 0 | pass | 100000ms |
| 7 | `/tmp/bk-cmp sparse without Data/Editor: same resource tiers` | 1 | expected FAIL lines naming the missing path, no abort | 100000ms |

## Deviations

The map-editor test tiers were run on win-home individually; run together once they hit a single_instance thread panic (CONNECTION_REFUSED) that looks like concurrency between the tiers, not this change. The staged MapEditor install on win-home could not be completed because that worktree lacks Data, so its link was checked through the overlay spike instead.

## Known Issues

The CI result for the new sparse lists and the macOS jobs was not seen; the maintainer pushes and relays it. The uncommitted T03 files in git status are not part of T04.

## Files Created/Modified

- `build.zig`
- `.github/workflows/cross-platform.yml`
- `tools/zig/resource_model_test.cpp`
- `Sources/editor/kit/imgui/msvc_fltused.c`
