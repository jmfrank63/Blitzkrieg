---
estimated_steps: 4
estimated_files: 5
skills_used: []
---

# T04: Make every CI job green: sparse-checkout Data lists, no tier aborts on missing data, Windows editor tier links imm32

Hard steer D055. CI run 37507439455 at 162a7f0a4 is red (Windows MinGW passes). Two causes.

(1) Sparse checkout. .github/workflows/cross-platform.yml checks out only Data/Maps, Data/Terrain/sets/*/{tileset,crosset}.xml, Roads3D/Rivers xml and Data/Scenarios, but test-resource-model and test-resource-bridge read shipped Data (partys.xml / Player side lists, objects, units, weapons, effects, Editor/TestProjects, ...). Reproduce first in /tmp/bk-cmp (a worktree already on that sparse list): zig build test-resource-model -Dtest-mode=run fails the CChapterCommonPropsItem/CCampaignCommonPropsItem 'Player side' combo count and aborts on an uncaught std::filesystem_error from a directory_iterator on a missing Data folder. Fix A: list in every job's sparse-checkout exactly the Data paths each resource tier needs (minimal, no full Data). Fix B: no tier ever aborts on a missing data folder; report a FAIL naming the missing path instead of an uncaught exception (guard every directory_iterator and file open in the resource tiers and shared helpers). Prove it: update the /tmp/bk-cmp sparse list with 'git sparse-checkout set --no-cone --stdin' to the new list and run test-resource-model, test-resource-bridge and the other resource tiers there; also run once with a deliberately missing folder to see the FAIL line.

(2) Windows MSVC 'Editor core tier'. test-editor-core compiles its test for native (ignores -Dtarget) and pulls in Dear ImGui via the editor kit, whose default IME hook needs imm32, which only the MapEditor exe links (build.zig about line 9797); lld-link reports "could not open 'libimm32.a'". Fix: build the editor test tiers for the requested target and link imm32 (or define IMGUI_DISABLE_WIN32_DEFAULT_IME_FUNCTIONS for test builds) for Windows targets. Reproduce and prove on Windows natively: ssh win-home, worktree D:\bk-ci, Zig 0.16 at C:\Users\jmfrank\scoop\apps\zig\0.16.0\zig.exe (the default zig there is 0.17, do not use it); copy changed files with scp (or fetch after the maintainer pushes) and run zig build test-editor-core -Dtarget=x86_64-windows-msvc -Dtest-mode=run in D:\bk-ci; also the other editor test tiers that share the kit. Keep the Linux tiers green.

Do not push; the maintainer pushes and relays the CI result. Claim no macOS or Windows CI result that was not seen; the win-home run is a native Windows result and is reported as such. Write files with CRLF. git status must be clean at the end. Verify with plain zig build commands only.

## Inputs

- `.github/workflows/cross-platform.yml`
- `.gsd/OVERRIDES.md`
- `build.zig`

## Expected Output

- `Minimal sparse-checkout Data lists in every job of cross-platform.yml`
- `Resource tiers report FAIL naming a missing path instead of aborting`
- `Editor test tiers built for the requested target and linking imm32 on Windows`
- `Evidence from /tmp/bk-cmp (sparse) and win-home D:\bk-ci (x86_64-windows-msvc)`

## Verification

zig build test-editor-core && zig build test-resource-model -Dtest-mode=run && zig build test-resource-bridge && zig build test-editor-core -Dtarget=x86_64-windows-msvc

## Observability Impact

grep for 'pending win-home' in 06-PARITY returns nothing; the mod rows quote T03's MOD SUMMARY counts.
