---
id: T02
parent: S17
milestone: M001
key_files:
  - tools/zig/resource_mod_roundtrip_test.cpp
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-06T18:00:19.144Z
blocker_discovered: false
---

# T02: Ran the mod round trip on AchtungPanzer2 (read-only): failed=0 for every kind, every difference accepted with a source- or byte-backed reason in the tier's accept table; no port bug found.

**Ran the mod round trip on AchtungPanzer2 (read-only): failed=0 for every kind, every difference accepted with a source- or byte-backed reason in the tier's accept table; no port bug found.**

## What Happened

The previous session's edits were not on disk (tree clean at the T01 commit), so I re-ran the T01 tier on the real mod. First run: failures in wpn 84, msh 46, mdc 17, bdg 16, 3rv 8, obt 7, unt 2, cgc 1 (plus one msh import refusal). I triaged each against the engine/exporter source and the mod bytes and found no port bug, so no port code changed and no new repo fixture was needed. All were proven differences, added to kAcceptRules in tools/zig/resource_mod_roundtrip_test.cpp (plus an optional fMaxDelta tolerance on a rule, and an accept path for import refusals).

Rules added:
- wpn: the mod omits per-shell BrokeTrackProbability, TraceProbability and TraceSpeedCoeff. The reader defaults them and the export writes them. No value line differs.
- mdc: the mod ships compiled textures (1_h.dds), not the source .tga that the export measures. A stats-only export keeps MFC's zero ImageRect (medal_export.cpp).
- bdg: segment Origin and VisOrigin differ by at most 1e-3 (the largest seen was 5.5e-4). The cause is the same as the existing fence rule, the project's six-digit sprite position.
- 3rv: the mod's rivers carry MiniMapBorderColor 6C4D0BFF. The river frame neither holds nor writes it.
- cgc: the mod's MapImage is under scenarios\custom. The import keeps a value that lacks the project's prefix whole, and the export prefixes it again.
- obt: seven stub objects have no Defence nodes, no sounds, and the old struct-form effects. The reader defaults them and the export writes defaults.
- unt/msh import refusals: three stubs have an empty KeyName. The importer's contract (engine reader finds no stats) refuses them, so they count as accepted and not imported.
- msh: the mesh export derives locator-based fields from the .mod beside the stats (ExhaustPoints, DamagePoints, EntrancePoint, TowPoint, PeoplePoints, HookPoint, wheels, Gunners, AmmoPoint, ShootDustPoint, FatalitySmokePoint, AABB*, AnimDescs), and the mod's stats disagree with its shipped models. Verified by bytes for one case: G_vt_Opel_Blitz_41x/1.mod holds no LExhaust node while its stats list ExhaustPoints 10. These rules are class-level, not proven file by file. In msh, UninstallRotate and UninstallTransport are 1.4013e-045 in 18 files, which ToAIUnits turns into 0 (int(1.4e-45*1000)), the same as the absent field.

Per-kind table of the real mod run (found / imported / equal / accepted / failed):
- wpn 196/196/112/84/0
- mcp 0 found
- trc 0 found
- scp 86/86/0/86/0
- unt 67/65/0/67/0 (2 stubs not imported)
- msh 377/376/0/377/0 (1 stub not imported)
- obt 621/621/614/7/0
- fnc 2/2/0/2/0
- bld 377/377/377/0/0
- bdg 23/23/0/23/0
- pcp 6/6/0/6/0
- 3rd 35/35/17/18/0
- 3rv 8/8/0/8/0
- mip 51/51/0/51/0
- chc 12/12/0/12/0
- cgc 1/1/0/1/0
- mdc 17/17/0/17/0
- msh, bld, 3rd found-only counts as printed. Full sweep and resource-editor-auto-<ext> tiers were not run because no importer or exporter code changed; the sweep is left to the maintainer.

## Verification

zig build test-resource-mod-roundtrip -Dmod-root=<AchtungPanzer2 data> exit 0 with every MOD SUMMARY failed=0 (about 2m20s). Without a mod root the tier exits 0 and prints 'skipped: no mod' (the fixture mini-mod still runs). test-resource-bridge exit 0 (1m19s). resource-editor-game-reads-it exit 0 (2m06s). The mod tree was only read. Only tools/zig/resource_mod_roundtrip_test.cpp changed; the sweep script and CI entries were already committed with T01.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-mod-roundtrip -Dmod-root=/home/johannes/Downloads/achtung_panzer_2_ostfront/AchtungPanzer2/data` | 0 | pass | 140000ms |
| 2 | `zig build test-resource-mod-roundtrip` | 0 | pass (skipped: no mod) | 4900ms |
| 3 | `zig build test-resource-bridge` | 0 | pass | 78700ms |
| 4 | `zig build resource-editor-game-reads-it` | 0 | pass | 126150ms |

## Deviations

The prior session's work was lost, so T02 was redone from the T01 state. No port bugs were found, so no importer or exporter fix or fixture regression test was needed.

## Known Issues

The msh locator-derived rules accept by field class, not file by file. Only G_vt_Opel_Blitz_41x was proven by bytes against its .mod. mcp and trc found 0 resources in this mod.

## Files Created/Modified

- `tools/zig/resource_mod_roundtrip_test.cpp`
