---
estimated_steps: 1
estimated_files: 4
skills_used: []
---

# T05: Refresh 06-PARITY, spec and .planning/STATE.md to the real M001 end state

Docs and test-hygiene task, formerly T04, unchanged in content. Runs after T03 and T04; use T03's final per-kind table and fix list, not T02's counts (D054 supersedes T02's accept table). Write files with CRLF. 06-PARITY: replace B-09.14 and B-14.5 with the AchtungPanzer2 mod round-trip rows (D053) quoting T03's per-kind found/imported/equal/accepted/failed counts and the port bugs fixed; refresh the header and every 'golden pending win-home' text (all 20 MFC goldens exist, comparator pass=10 accepted=10 fail=0 pending=0); retire the GOG-only pending test cases in resource_bridge_test.cpp. Spec: record the counts, fixes, D052, D053, D054 and D055 (CI fixes). .planning/STATE.md: S16 complete, MFC deleted in c6b4329c6, PRE_DELETE b8aa895bb, comparator pass=10 accepted=10 fail=0 pending=0, maintainer's full Linux sweep at c6b4329c6 VERDICT=PASS with 41 tiers, hand try deferred (D052), CI relayed by the maintainer and not claimed, S17 mod round trip with T03's counts and T04's CI fixes. git status must be clean at the end.

## Inputs

- `.gsd/milestones/M001/slices/S17/tasks/T03-SUMMARY.md`
- `.gsd/milestones/M001/slices/S17/tasks/T04-SUMMARY.md`
- `.gsd/DECISIONS.md`

## Expected Output

- `06-PARITY with mod round-trip rows and no 'golden pending win-home' text`
- `spec updated with counts, fixes and D052-D055`
- `.planning/STATE.md at the real M001 end state`

## Verification

zig build test-resource-bridge && zig build test-resource-model-comparator && zig build test-resource-mod-roundtrip
