---
estimated_steps: 5
estimated_files: 3
skills_used: []
---

# T02: Ran the mod round trip on AchtungPanzer2 (read-only): failed=0 for every kind, every difference accepted with a source- or byte-backed reason in the tier's accept table; no port bug found.

Run the T01 tier against the real mod at /home/johannes/Downloads/achtung_panzer_2_ostfront/AchtungPanzer2/data. Treat it as read-only: no mod file may be written, committed or copied into the repo outside zig-out/local-test.

For every FAIL, decide whether it is a port bug or a proven difference. Port bugs: fix them in the importer or exporter, add a regression test on a repo fixture, never on mod data, and re-run. Proven differences: add an acceptance rule with a reason backed by source or bytes. Examples are a mod field the 2003 engine ignores, or a resource the mod ships in a form the editor never produced.

Record the final per-kind table (found, imported, equal, accepted, failed, and the reasons) in the task summary.

Keep the other tiers that the fixes touch green: test-resource-bridge, resource-editor-batch, resource-editor-game-reads-it, and the resource-editor-auto-<ext> tiers of the kinds changed.

The Verify line carries the mod root as a build option, so the real run is reproducible with a plain zig build command on this machine.

## Inputs

- `tools/zig/resource_mod_roundtrip_test.cpp`
- `Sources/src/EditorBridge/resource_bridge.cpp`

## Expected Output

- `mod run with failed=0 for every kind, or each remaining failure explained and accepted with reason`
- `per-kind counts table in T02-SUMMARY.md`
- `regression tests on repo fixtures for any port bug fixed`

## Verification

zig build test-resource-mod-roundtrip -Dmod-root=/home/johannes/Downloads/achtung_panzer_2_ostfront/AchtungPanzer2/data && zig build test-resource-mod-roundtrip && zig build test-resource-bridge && zig build resource-editor-game-reads-it

## Observability Impact

MOD SUMMARY lines per kind from the real mod, quoted in the summary.
