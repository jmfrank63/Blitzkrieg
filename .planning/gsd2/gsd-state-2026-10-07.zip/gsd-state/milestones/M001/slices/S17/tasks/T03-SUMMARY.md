---
id: T03
parent: S17
milestone: M001
key_files:
  - tools/zig/resource_mod_roundtrip_test.cpp
  - Sources/src/EditorBridge/resource_bridge.cpp
  - Sources/src/ResourceModel/items/mesh/mesh_export.cpp
  - Sources/src/ResourceModel/items/fence/fence_export.cpp
  - Sources/src/ResourceModel/items/stats_export.cpp
  - tools/zig/fixtures/mod-roundtrip/README.md
key_decisions:
  - Imported resources keep what the reader reads but the frame has no item for in the project's desc element, written back while the tree still agrees
  - msh model-derived fields come from the kept stats only while the 1/2/3.mod content fingerprint matches the import
  - Comparator value excuses are held to six-digit print or a per-kind bound in the mod tier
  - chc export refusals stay accepted (MFC check, 06-PARITY), proved per file
duration: 
verification_result: passed
completed_at: 2026-10-06T19:06:09.961Z
blocker_discovered: false
---

# T03: Fixed the mod round-trip port bugs (cgc, 3rv, unt/msh/fnc empty KeyName, unt Length, 3rd AI mask, obt armor, msh locators/platforms/guns, fence VisOrigin, picture rects, pcp zero tracks) with fixtures that fail without each fix, and rebuilt the accept table with per-file proofs; failed=0 on AchtungPanzer2.

**Fixed the mod round-trip port bugs (cgc, 3rv, unt/msh/fnc empty KeyName, unt Length, 3rd AI mask, obt armor, msh locators/platforms/guns, fence VisOrigin, picture rects, pcp zero tracks) with fixtures that fail without each fix, and rebuilt the accept table with per-file proofs; failed=0 on AchtungPanzer2.**

## What Happened

Per D054 port bugs were fixed, not accepted. FIXES: (1) cgc: a MapImage already under scenarios\ is not prefixed again. (2) 3rv: the import keeps type, priority, passability, AI mask, soil, minimap colours and layer widths in the project's desc element and the export writes them back. (3) unt, msh and fnc import with an empty KeyName, labelled by the folder. (4) unt: animation Length kept for frame-less animations. (5) 3rd: AI class mask kept while the four flags agree. (6) obt: armor min/max kept, so a stub reads 40-90 as the reader does. (7) msh: platform/gun locator numbers kept for NA combos; the stats' own RPG element plus a content fingerprint of 1/2/3.mod kept, and the export writes the model-derived fields (boxes, animations, locator points) from it while the models are the imported ones. (8) fnc: segment origins kept with a grid fingerprint (a visibility grid was a whole tile off on the editor camera's lattice). (9) mdc/mip/chc/cgc: the picture rectangle is kept and used by a stats-only export when the .tga is missing. (10) pcp: an omitted randomiser track imports as zeros as SParticleSourceData::Init reads it (was 1). TIER: kAcceptRules rewritten; every rule has a proof (mod bytes or model node names), a numeric bound or an engine-writer reason; class-level wpn/mdc/bdg/obt/3rd/mip/msh rules removed; comparator value excuses held to six-digit print or bounds (scp 1e-4, fnc 6e-4); the scratch export root takes the mod's own name/version; BK_MOD_DETAIL=1 lists each accepted field per file. FIXTURES: river_test, road_aimask, campaigns/test, stub_soldier, stub_stone, townfence_vis, mortar_stub; each failed when its fix was temporarily switched off by an env toggle (since removed). RESULT on the real mod (found/imported/equal/accepted/failed): wpn 196/196/112/84/0; scp 86/86/0/86/0; unt 67/67/67/0/0; msh 377/377/342/35/0; obt 621/621/614/7/0; fnc 2/2/2/0/0; bld 377/377/377/0/0; bdg 23/23/0/23/0; pcp 6/6/0/6/0; 3rd 35/35/21/14/0; 3rv 8/8/5/3/0; mip 51/51/51/0/0; chc 12/12/0/12/0; cgc 1/1/1/0/0; mdc 17/17/17/0/0. REMAINING ACCEPTED, per class: wpn 84 files, 3rv 3, obt 7: engine writer emits default-valued fields the older export omitted (plus obt stubs' struct-form effects, unread); msh 35: UninstallRotate/Transport written as 1.4013e-045 (proved by the mod's bytes); bdg 23: origin noise max 5.95e-4 (six-digit sprite position); scp 86: slot noise max 4.6e-5; pcp 6 and 3rd 14: six-digit print noise max 1.9e-6; chc 12: MFC's own export check (no placeholders / player side) kept per 06-PARITY, proved by the file's empty PlaceHolders. Full sweep left to the maintainer.

## Verification

Ran the plan's tiers in the foreground, all green: test-resource-mod-roundtrip with -Dmod-root (165 s, failed=0, mod unchanged), without a mod (fixture only, 'skipped: no mod'), test-resource-bridge, resource-editor-game-reads-it, resource-editor-auto-cgc/3rv/unt/msh. Also auto-fnc/obt/pcp/3rd/mdc/mip/chc/bdg/wpn/core, test-resource-model, resource-editor-batch and -smoke. Each fixture failed with its fix disabled. Not run: macOS/Windows (CI), full sweep.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-mod-roundtrip -Dmod-root=/home/johannes/Downloads/achtung_panzer_2_ostfront/AchtungPanzer2/data` | 0 | pass | 165000ms |
| 2 | `zig build test-resource-mod-roundtrip` | 0 | pass | 6000ms |
| 3 | `zig build test-resource-bridge` | 0 | pass | 86000ms |
| 4 | `zig build resource-editor-game-reads-it` | 0 | pass | 130000ms |
| 5 | `zig build resource-editor-auto-cgc` | 0 | pass | 8000ms |
| 6 | `zig build resource-editor-auto-3rv` | 0 | pass | 10000ms |
| 7 | `zig build resource-editor-auto-unt` | 0 | pass | 9000ms |
| 8 | `zig build resource-editor-auto-msh` | 0 | pass | 23000ms |

## Deviations

None.

## Known Issues

None known beyond the accepted classes listed. macOS/Windows not seen; full sweep left to the maintainer.

## Files Created/Modified

- `tools/zig/resource_mod_roundtrip_test.cpp`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/ResourceModel/items/mesh/mesh_export.cpp`
- `Sources/src/ResourceModel/items/fence/fence_export.cpp`
- `Sources/src/ResourceModel/items/stats_export.cpp`
- `tools/zig/fixtures/mod-roundtrip/README.md`
