# S17: S17

**Goal:** Close M001's needs-attention validation. Replace the unreachable GOG INTEX2 rows B-09.14 and B-14.5 with a round trip on the AchtungPanzer2 third-party mod (D053), record the deferred macOS/Windows hand try as a decision (D052), and bring 06-PARITY, the spec and .planning/STATE.md to the real end state.
**Demo:** With -Dmod-root (or BK_MOD_ROOT) pointing at the AchtungPanzer2 data, zig build test-resource-mod-roundtrip imports every resource of each importable kind, re-exports it into zig-out/local-test and prints per-kind counts of equal, accepted-difference and failed resources, each difference with a reason. Without a mod root it prints 'skipped: no mod'. 06-PARITY, the spec and .planning/STATE.md show the real M001 end state.

## Must-Haves

- zig build test-resource-mod-roundtrip prints 'skipped: no mod' and exits 0 without a mod root; with -Dmod-root (or BK_MOD_ROOT) it imports every resource of every kind BkResImportFromGame accepts, re-exports each one under zig-out/local-test, compares it field by field through the engine's own readers and prints per-kind counts (found, imported, equal, accepted with reason, failed) with every difference listed with its reason.
- A tracked mini-mod fixture under tools/zig/fixtures drives the same harness, so the tier has a non-skip path in CI and in the sweep.
- The mod is never written to, and none of its files is committed or copied into the repo outside zig-out/local-test.
- The tier was run here against /home/johannes/Downloads/achtung_panzer_2_ostfront/AchtungPanzer2/data; its per-kind counts are recorded in 06-PARITY and in the spec; every failure is fixed as a port bug or accepted with a proven reason.
- B-09.14 and B-14.5 are replaced by the mod round-trip rows; the 06-PARITY header and every 'golden pending win-home' text are refreshed (all 20 MFC goldens exist, comparator pass=10 accepted=10 fail=0 pending=0); the GOG-only pending test cases are retired.
- .planning/STATE.md reflects: S16 complete, MFC deleted in c6b4329c6, PRE_DELETE b8aa895bb, comparator pass=10 accepted=10 fail=0 pending=0, the maintainer's full Linux sweep at c6b4329c6 VERDICT=PASS with 41 tiers, the hand try deferred (D052), CI run 37502565127 relayed by the maintainer and not claimed.
- Existing tiers touched stay green on Linux; git status is clean.

## Proof Level

- This slice proves: Engine readers compare the re-exported files with the mod's originals, field by field, on real third-party data. Linux only; macOS and Windows come from CI and are relayed by the maintainer.

## Integration Closure

The new tier is registered in build.zig, in test-resources-all (if that does not break the tier budget), in tools/zig/run-resource-sweep.sh and in .github/workflows/cross-platform.yml. In CI it runs the fixture path, and the mod path is skipped.

## Verification

- Each resource gets one line, MOD <kind> <relative path> EQUAL|ACCEPTED <reason>|FAIL <field>: <mod value> vs <port value>. A final MOD SUMMARY <kind> found= imported= equal= accepted= failed= line per kind follows. Without a mod root the tier prints 'skipped: no mod'.

## Tasks

- [x] **T01: Added the test-resource-mod-roundtrip tier: engine-reader discovery of a mod's resources, import then export then field-by-field comparison with one accept table, a tracked mini-mod fixture, and a 'skipped: no mod' path.** `est:3h`
  Build the test tier for D053, tests first, and keep it under the 3-minute tier budget (split per kind group if needed).
  - Files: `build.zig`, `tools/zig/resource_mod_roundtrip_test.cpp`, `tools/zig/fixtures/mod-roundtrip/`, `Sources/src/EditorBridge/resource_bridge.h`, `tools/zig/run-resource-sweep.sh`, `.github/workflows/cross-platform.yml`
  - Verify: zig build test-resource-mod-roundtrip && zig build test-resource-bridge && zig build resource-editor-batch

- [x] **T02: Ran the mod round trip on AchtungPanzer2 (read-only): failed=0 for every kind, every difference accepted with a source- or byte-backed reason in the tier's accept table; no port bug found.** `est:3h`
  Run the T01 tier against the real mod at /home/johannes/Downloads/achtung_panzer_2_ostfront/AchtungPanzer2/data. Treat it as read-only: no mod file may be written, committed or copied into the repo outside zig-out/local-test.
  - Files: `tools/zig/resource_mod_roundtrip_test.cpp`, `Sources/src/EditorBridge/resource_bridge.cpp`, `Sources/src/EditorBridge/resource_bridge_test.cpp`
  - Verify: zig build test-resource-mod-roundtrip -Dmod-root=/home/johannes/Downloads/achtung_panzer_2_ostfront/AchtungPanzer2/data && zig build test-resource-mod-roundtrip && zig build test-resource-bridge && zig build resource-editor-game-reads-it

- [x] **T03: Fix the mod round-trip port bugs (cgc, 3rv, unt/msh empty KeyName) and re-justify every accept rule per file** `est:4h`
  Hard steer D054 (Johannes: 'we are not taking over this bug, we are going to fix it'). Port bugs are fixed with tests, never accepted. The mod is read-only; none of its files is committed or copied outside zig-out/local-test. Write files with CRLF. Tests first: add a tracked fixture case for each bug under tools/zig/fixtures/mod-roundtrip or resource_bridge_test.cpp, see it fail, then fix.
  - Files: `Sources/src/EditorBridge/resource_bridge.cpp`, `Sources/src/EditorBridge/resource_bridge.h`, `Sources/src/EditorBridge/resource_bridge_test.cpp`, `tools/zig/resource_mod_roundtrip_test.cpp`, `tools/zig/fixtures/mod-roundtrip/`
  - Verify: zig build test-resource-mod-roundtrip -Dmod-root=/home/johannes/Downloads/achtung_panzer_2_ostfront/AchtungPanzer2/data && zig build test-resource-mod-roundtrip && zig build test-resource-bridge && zig build resource-editor-game-reads-it && zig build resource-editor-auto-cgc && zig build resource-editor-auto-3rv && zig build resource-editor-auto-unt && zig build resource-editor-auto-msh

- [x] **T04: Make every CI job green: sparse-checkout Data lists, no tier aborts on missing data, Windows editor tier links imm32** `est:4h`
  Hard steer D055. CI run 37507439455 at 162a7f0a4 is red (Windows MinGW passes). Two causes.
  - Files: `.github/workflows/cross-platform.yml`, `build.zig`, `Sources/src/ResourceModel`, `Sources/src/EditorBridge/resource_bridge_test.cpp`, `tools/zig`
  - Verify: zig build test-editor-core && zig build test-resource-model -Dtest-mode=run && zig build test-resource-bridge && zig build test-editor-core -Dtarget=x86_64-windows-msvc

- [x] **T05: Refresh 06-PARITY, spec and .planning/STATE.md to the real M001 end state** `est:1.5h`
  Docs and test-hygiene task, formerly T04, unchanged in content. Runs after T03 and T04; use T03's final per-kind table and fix list, not T02's counts (D054 supersedes T02's accept table). Write files with CRLF. 06-PARITY: replace B-09.14 and B-14.5 with the AchtungPanzer2 mod round-trip rows (D053) quoting T03's per-kind found/imported/equal/accepted/failed counts and the port bugs fixed; refresh the header and every 'golden pending win-home' text (all 20 MFC goldens exist, comparator pass=10 accepted=10 fail=0 pending=0); retire the GOG-only pending test cases in resource_bridge_test.cpp. Spec: record the counts, fixes, D052, D053, D054 and D055 (CI fixes). .planning/STATE.md: S16 complete, MFC deleted in c6b4329c6, PRE_DELETE b8aa895bb, comparator pass=10 accepted=10 fail=0 pending=0, maintainer's full Linux sweep at c6b4329c6 VERDICT=PASS with 41 tiers, hand try deferred (D052), CI relayed by the maintainer and not claimed, S17 mod round trip with T03's counts and T04's CI fixes. git status must be clean at the end.
  - Files: `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`, `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`, `.planning/STATE.md`, `Sources/src/EditorBridge/resource_bridge_test.cpp`
  - Verify: zig build test-resource-bridge && zig build test-resource-model-comparator && zig build test-resource-mod-roundtrip

## Files Likely Touched

- build.zig
- tools/zig/resource_mod_roundtrip_test.cpp
- tools/zig/fixtures/mod-roundtrip/
- Sources/src/EditorBridge/resource_bridge.h
- tools/zig/run-resource-sweep.sh
- .github/workflows/cross-platform.yml
- Sources/src/EditorBridge/resource_bridge.cpp
- Sources/src/EditorBridge/resource_bridge_test.cpp
- Sources/src/ResourceModel
- tools/zig
- .planning/phases/06-resource-editor-portable-port/06-PARITY.md
- docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md
- .planning/STATE.md
