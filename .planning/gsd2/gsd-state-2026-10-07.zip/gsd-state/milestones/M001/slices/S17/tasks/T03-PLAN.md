---
estimated_steps: 6
estimated_files: 5
skills_used: []
---

# T03: Fix the mod round-trip port bugs (cgc, 3rv, unt/msh empty KeyName) and re-justify every accept rule per file

Hard steer D054 (Johannes: 'we are not taking over this bug, we are going to fix it'). Port bugs are fixed with tests, never accepted. The mod is read-only; none of its files is committed or copied outside zig-out/local-test. Write files with CRLF. Tests first: add a tracked fixture case for each bug under tools/zig/fixtures/mod-roundtrip or resource_bridge_test.cpp, see it fail, then fix.

(1) cgc: an imported MapImage under scenarios\custom is exported with the project prefix added a second time. The export must write the path the game reads; the round trip is equal.

(2) 3rv: the mod's MiniMapBorderColor is lost on import->export. Keep every field the engine reader reads, even if MFC's river frame had no UI for it: store it in the model and write it back unchanged. Check the other river fields the reader reads the same way.

(3) unt and msh refuse import when KeyName is empty. Same bug class S11/T07 fixed for buildings: an empty KeyName is a valid value and the import label comes from the folder. Import them and round-trip them (found 67 unt, 2 refused; 377 msh, 1 refused).

(4) Re-justify every remaining accept rule in kAcceptRules file by file, not class-level. For scp (0 of 86 equal), unt (0/67), msh (0/377), bdg (0/23), fnc (0/2) and pcp (0/6) list per file which fields differ and why. An accept rule is allowed only for a difference proven from the engine source or the mod's own bytes for that file (for example the mod's stats contradict its own .mod, as G_vt_Opel_Blitz_41x/1.mod has no LExhaust node while its stats list ExhaustPoints 10). Anything else is a port bug to fix. The msh locator-derived rules and the UninstallRotate/UninstallTransport 1.4013e-045 rule must be proven per file or fixed; remove the class-level wpn, mdc, bdg, obt, 3rd and mip rules too if they cannot be shown per file (re-check each kind, not only those named). Rules keyed per file carry the file path and the mod byte or source line that proves them.

Report the per-kind table again (found/imported/equal/accepted/failed) and the list of fixes in the task summary. Verify with plain zig build commands only; run the touched resource-editor-auto-<ext> tiers in the foreground; the full sweep is left to the maintainer.

## Inputs

- `.gsd/OVERRIDES.md`
- `.gsd/DECISIONS.md`
- `tools/zig/resource_mod_roundtrip_test.cpp`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `.gsd/milestones/M001/slices/S17/tasks/T02-SUMMARY.md`

## Expected Output

- `cgc import/export round trip writes the MapImage path the game reads (no second project prefix)`
- `3rv stores and writes back MiniMapBorderColor and every other field the engine reader reads`
- `unt and msh import with an empty KeyName (label from the folder) and round-trip`
- `fixture regression tests for each fix, written first`
- `kAcceptRules re-justified file by file; class-level rules removed`
- `per-kind table found/imported/equal/accepted/failed and list of fixes reported`

## Verification

zig build test-resource-mod-roundtrip -Dmod-root=/home/johannes/Downloads/achtung_panzer_2_ostfront/AchtungPanzer2/data && zig build test-resource-mod-roundtrip && zig build test-resource-bridge && zig build resource-editor-game-reads-it && zig build resource-editor-auto-cgc && zig build resource-editor-auto-3rv && zig build resource-editor-auto-unt && zig build resource-editor-auto-msh

## Observability Impact

MOD SUMMARY lines per kind from the real mod after the fixes, quoted in the summary; every remaining ACCEPTED line names its file and the source line or mod byte that proves it.
