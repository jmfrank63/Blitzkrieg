---
id: S17
parent: M001
milestone: M001
provides:
  - (none)
requires:
  []
affects:
  []
key_files: []
key_decisions: []
patterns_established:
  - (none)
observability_surfaces:
  - none
drill_down_paths:
  []
duration: ""
verification_result: passed
completed_at: 2026-10-06T19:47:56.016Z
blocker_discovered: false
---

# S17: S17

**test-resource-mod-roundtrip imports every resource of each importable kind from a third-party mod, re-exports it, and reports per-kind equal, accepted and failed counts with reasons; 06-PARITY, the spec and STATE.md show the M001 end state.**

## What Happened

S17 added the test-resource-mod-roundtrip tier (-Dmod-root or BK_MOD_ROOT). It discovers resources through the engine's own readers, imports each one, exports it into zig-out/local-test and compares field by field. Each difference is classified as accepted with a stated reason, or failed. A tracked mini-mod fixture under tools/zig/fixtures/mod-roundtrip always runs first. The tier was run read-only against AchtungPanzer2 and ended with failed=0 for every kind after the port bugs were fixed (cgc, 3rv, unt/msh/fnc empty keys). Sparse-checkout Data lists were added for the CI resource jobs, and 06-PARITY was refreshed with the AchtungPanzer2 round-trip rows. The final closeout run here used the fixture only, with no mod root.

## Verification

Re-ran `zig build test-resource-mod-roundtrip` with BK_MOD_ROOT unset, using the real Wayland session. It printed per-kind SUMMARY lines on the 19-file fixture with failed=0 for every kind: 11 resources EQUAL, the rest ACCEPTED with reasons. It then printed "skipped: no mod (set BK_MOD_ROOT ...)" and "resource-mod-roundtrip: OK", exit 0. The fixture guard reported 19 files unchanged. In a shell without a display the tier prints "skipped: no video driver" and does not run the round trip. The AchtungPanzer2 run itself was done in earlier tasks and not repeated here. No macOS or Windows result was seen.

## Requirements Advanced

None.

## Requirements Validated

None.

## New Requirements Surfaced

None.

## Requirements Invalidated or Re-scoped

None.

## Operational Readiness

None.

## Deviations

None.

## Known Limitations

At closeout `git status` still shows modified ResourceModel export sources (campaign, chapter, infantry, medal, mission, object, particle, river3d, road3d, stats_export.h) and untracked files under tools/zig/fixtures/mod-roundtrip/data. The tier ran green with them, so a clean checkout would likely lack them. They must be committed by the maintainer before pushing. This unit may not run git.

## Follow-ups

Commit the uncommitted export sources and mod-roundtrip fixtures. Run tools/zig/run-resource-sweep.sh.

## Files Created/Modified

None.
