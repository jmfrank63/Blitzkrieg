---
estimated_steps: 9
estimated_files: 6
skills_used: []
---

# T01: Added the test-resource-mod-roundtrip tier: engine-reader discovery of a mod's resources, import then export then field-by-field comparison with one accept table, a tracked mini-mod fixture, and a 'skipped: no mod' path.

Build the test tier for D053, tests first, and keep it under the 3-minute tier budget (split per kind group if needed).

(1) Add the step test-resource-mod-roundtrip to build.zig. It takes the mod root from BK_MOD_ROOT or from the build option -Dmod-root, which the step exports as BK_MOD_ROOT. Without either it prints 'skipped: no mod' and exits 0. The executable reuses the Linux pitfalls already solved: rdynamic, a $ORIGIN rpath, a 16 MiB worker stack, stopping ISFX before unload, and the case-insensitive DataFile path helper.

(2) Take the importable kinds from the code, not from the stale header comment. BkResImportFromGame in Sources/src/EditorBridge/resource_bridge.cpp ports kind <= 3, unt, msh, obt, fnc, bld, bdg, pcp, 3rd, 3rv, mdc, mip, chc and cgc. Also fix the stale BkResImportFromGame doc comment in resource_bridge.h.

(3) Discover the mod's resources per kind by what the engine reads. Use runtime folders that hold 1.xml, the flat weapons\*.xml, roads3d/rivers3d <name>.xml, and the stats files of the maps/scenarios/medals entries. Classify each one by the type the engine's reader accepts, not by folder name, and count found per kind.

(4) For each resource: copy the needed part of the mod read-only into zig-out/local-test/mod-roundtrip/<kind>/... Never open a mod file for writing; check this by comparing the mod's files' mtime and size before and after the run. Then BkResImportFromGame, save the project, BkResExport into a scratch export root, and read the original and the re-export through the engine's own operator& / serializer into the stats structs. Compare them field by field, and for each kind list the fields that differ.

(5) Each difference is FAIL unless a written rule accepts it with a reason. Rules: graphics-source fields stay empty on import (header contract); MFC behaviours already accepted in 06-PARITY; files the mod references but does not ship. Keep the rules in one table in the test source so that T02 can extend it.

(6) Add a tiny tracked mini-mod under tools/zig/fixtures/mod-roundtrip/, built from existing repo fixtures or Data/ and never from AchtungPanzer2 files. The tier always runs over it first, so CI exercises the non-skip path.

(7) Register the tier in tools/zig/run-resource-sweep.sh and .github/workflows/cross-platform.yml, and in test-resources-all if that stays within budget.

Verify runs the fixture path, the skip path and the bridge tests. The real mod run is T02.

## Inputs

- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `tools/zig/editor_bridge_test.cpp`
- `.gsd/DECISIONS.md`

## Expected Output

- `tools/zig/resource_mod_roundtrip_test.cpp`
- `tools/zig/fixtures/mod-roundtrip/`
- `test-resource-mod-roundtrip step in build.zig that skips without a mod root and passes over the tracked mini-mod fixture, printing per-resource MOD lines and per-kind MOD SUMMARY lines`
- `tier wired into tools/zig/run-resource-sweep.sh and .github/workflows/cross-platform.yml`

## Verification

zig build test-resource-mod-roundtrip && zig build test-resource-bridge && zig build resource-editor-batch

## Observability Impact

Prints MOD <kind> <path> EQUAL|ACCEPTED <reason>|FAIL <field> lines and MOD SUMMARY lines per kind; 'skipped: no mod' without a mod root.
