# S17: S17 — UAT

**Milestone:** M001
**Written:** 2026-10-06T19:47:56.017Z

# S17 UAT

**UAT Type:** artifact-driven (local Linux x64 run)

## Preconditions
- Linux desktop session (XDG_RUNTIME_DIR and WAYLAND_DISPLAY set), a built tree, and optionally the AchtungPanzer2 data folder.

## Steps
1. Run `env -u BK_MOD_ROOT zig build test-resource-mod-roundtrip`. Expected: per-kind `MOD SUMMARY` lines for the fixture with failed=0, then `skipped: no mod` and `resource-mod-roundtrip: OK`.
2. Run `zig build test-resource-mod-roundtrip -Dmod-root=<AchtungPanzer2 data>`. Expected: per-kind equal, accepted and failed counts; failed=0; each ACCEPTED line states its reason.
3. Open 06-PARITY, the spec and .planning/STATE.md. Expected: the AchtungPanzer2 round-trip rows and the M001 end state are present.

## Edge cases
- A shell without a display prints `skipped: no video driver` or `no GPU device` instead of running the round trip.
- A mod with no resources of a kind reports found=0 for it.

## Not Proven By This UAT
- macOS and Windows results (CI only).
- The AchtungPanzer2 run, which was done in earlier tasks.
- Full resource sweep (left to the maintainer).
