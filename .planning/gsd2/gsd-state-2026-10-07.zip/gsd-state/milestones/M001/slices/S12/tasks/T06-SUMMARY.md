---
id: T06
parent: S12
milestone: M001
key_files: []
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-05T21:53:07.532Z
blocker_discovered: false
---

# T06: BK_EDITOR_AUTO gains keyframe/curve/camera/import verbs and a pcp+eff block with measured Run/Stop/Camera shots; PARITY rows and spec D026 updated; Get particle info, simple/complex toggle and the effect direction arrow remain not done.

**BK_EDITOR_AUTO gains keyframe/curve/camera/import verbs and a pcp+eff block with measured Run/Stop/Camera shots; PARITY rows and spec D026 updated; Get particle info, simple/complex toggle and the effect direction arrow remain not done.**

## What Happened

scenario.zig gained verbs curve, keyframe (add/move/delete/reset/zoom), camera, import_file, import_refused, preview_refused and predicates keys, key, zoom, camera. build.zig's resource-editor-auto has a pcp and eff block: keyframe add/move/delete/reset each undone and redone with keys read back, zoom steps, save and export, Run/Stop/Camera shots measured by pixel difference (running frames differ 0.41%, stopped frames equal, horizontal camera differs 0.17%), edited curve shot, shipped flame.xml import, eff import refused, eff export, and Run of the eff naming its missing particle source. The resource-editor-host-check docks half asserted the old 'not ported yet' refusal for .pcp import, which now succeeds, so it was moved to the .eff refusal ('no reverse path'). PARITY rows B-06.1..7, B-08.1..3, 5, 6 and A-15 were updated with evidence; D026 written in the spec. B-06.3, B-06.4 and B-08.3 are recorded as not done (follow-up needed). Goldens are pending win-home; full sweep left to the maintainer; verified on Linux only.

## Verification

All slice verify tiers ran in the foreground on Linux x64 and exit 0 (host-check after the docks_check fix). No macOS or Windows result seen.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build install-resource-editor` | 0 | pass | 4000ms |
| 2 | `zig build resource-editor-auto` | 0 | pass (697 actions over 551 frames) | 45000ms |
| 3 | `zig build resource-editor-smoke` | 0 | pass | 5400ms |
| 4 | `zig build resource-editor-host-check` | 0 | pass after docks_check.zig fix | 5000ms |
| 5 | `zig build test-resource-app-logic -Dtest-mode=run` | 0 | pass | 600ms |
| 6 | `zig build test-resource-core -Dtest-mode=run` | 0 | pass | 600ms |
| 7 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 57700ms |
| 8 | `zig build test-resource-model -Dtest-mode=run` | 0 | pass | 20600ms |
| 9 | `zig build test-resource-model-comparator -Dtest-mode=run` | 0 | pass | 19800ms |
| 10 | `zig build test-editor-core -Dtest-mode=run` | 0 | pass | 1200ms |
| 11 | `zig build map-editor-smoke` | 0 | pass | 12400ms |

## Deviations

None.

## Known Issues

None.

## Files Created/Modified

None.
