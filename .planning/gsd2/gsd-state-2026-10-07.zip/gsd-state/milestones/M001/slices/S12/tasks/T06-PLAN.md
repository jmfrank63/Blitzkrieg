---
estimated_steps: 3
estimated_files: 4
skills_used: []
---

# T06: BK_EDITOR_AUTO pcp/eff blocks with measured shots, PARITY rows, spec, tier run

Why: the demo needs keyframe edits, Run/Stop and Camera proved in an auto scenario with measured preview shots; PARITY and spec record evidence. Last task of the slice.
Do: add verbs to Sources/editor/resource_app/scenario.zig (e.g. keyframe=add|move|delete|reset|zoomx_in|zoomx_out|zoomy_in|zoomy_out with an expect on key count/values, run, stop, camera) and pcp and eff blocks in build.zig's resource-editor-auto next to the bdg block: copy fixtures to {dir}/pcp and {dir}/eff; select a track, add/move/delete/reset each followed by undo and redo with keys asserted; zoom; Run and shoot, Stop and shoot, Camera toggle and shoot, edit a curve and shoot; code measures non-blank pixels and differences against thresholds; export and check the particle xml and effect xml exist; pcp import round trip of a shipped particle via the import verb. Fix bugs it exposes. Update .planning/phases/06-resource-editor-portable-port/06-PARITY.md B-06.1..B-06.7, B-08.1..B-08.3, B-08.5, B-08.6 and A-15 with evidence (goldens pending win-home) and the spec docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md with D026 (knobs/camera ABI, effect import refusal, curve quirks). Run GUI tiers from the shell, not the gsd_exec sandbox (no video device there). Full sweep left to the maintainer; never claim macOS/Windows.
Done when: all verify tiers exit 0.

## Inputs

- `Sources/editor/resource_app/scenario.zig`
- `Sources/editor/resource_app/keyframe_logic.zig`
- `Sources/editor/resource_app/docks.zig`
- `build.zig`
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`

## Expected Output

- `Sources/editor/resource_app/scenario.zig`
- `build.zig`
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`

## Verification

zig build install-resource-editor && zig build resource-editor-auto && zig build resource-editor-smoke && zig build resource-editor-host-check && zig build test-resource-app-logic -Dtest-mode=run && zig build test-resource-core -Dtest-mode=run && zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model -Dtest-mode=run && zig build test-resource-model-comparator -Dtest-mode=run && zig build test-editor-core -Dtest-mode=run && zig build map-editor-smoke

## Observability Impact

Auto shots print measured pixel counts and differences against thresholds; keyframe verbs print key counts before/after/undo/redo.
