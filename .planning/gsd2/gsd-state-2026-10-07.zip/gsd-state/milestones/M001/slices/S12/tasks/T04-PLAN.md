---
estimated_steps: 3
estimated_files: 2
skills_used: []
---

# T04: Pure keyframe curve logic with MFC quirks and one-undo-per-gesture (TDD)

Why: B-06.1/B-06.2 curve editing must match CKeyFrameEditor (Sources/src/editor/KeyFrame.cpp) and be undoable; pure logic is testable without a GUI.
Do: tests first. Add Sources/editor/resource_app/keyframe_logic.zig (wire it into the test-resource-app-logic tier the way grid_logic.zig is wired in build.zig) porting: GetScreenByValue/GetValueByScreen (584-630) with scroll offsets; SetDimentions from BkResKeyframeKnobs (471-560); OnLButtonDown 762 (hit test on screen x only within SELECT_SIZE; a hit sets y to click y clamped to [MinY,MaxY] and starts a drag; a miss inside both ranges inserts sorted by x and starts a drag); OnMouseMove 846 (neighbour clamp by NODE_SPACE px, key 0 x fixed, x clamped to MaxX, y to MaxY, no lower clamp while dragging; edge scroll); Delete (key 0 protected, deletes the last-touched index); ResetNodes (keep first key, the dock's Reset all); zoom in/out X and Y (647-722). A Gesture holds the keys before; on button up (or delete/reset/zoom-free commit) it produces one geometry command over channel .particle_keyframes via resource_core's ResourceCommand so a whole drag is one undo step (MFC posts WM_KEY_FRAME_UPDATE on L-up). Zoom changes view only, not data, and is not an undo step; record that. Tests: each quirk above, sorted insert, two keys never share x, delete of key 0 refused, reset keeps first, zoom ranges, and for add/move/delete/reset: keys before, after, undo and redo exact (z stays 0) against resource_core's fake bridge. Record intentional deviations (if any) for PARITY.
Done when: verify exits 0 with the new tests.

## Inputs

- `Sources/src/editor/KeyFrame.cpp`
- `Sources/src/editor/KeyFrame.h`
- `Sources/src/editor/KeyFrameDock.cpp`
- `Sources/editor/resource_core/bridge.zig`
- `Sources/editor/resource_core/history.zig`
- `Sources/editor/resource_core/fake_bridge.zig`
- `Sources/editor/resource_app/grid_logic.zig`
- `Sources/editor/resource_app/c_bridge.zig`

## Expected Output

- `Sources/editor/resource_app/keyframe_logic.zig`
- `build.zig`

## Verification

zig build test-resource-app-logic -Dtest-mode=run && zig build test-resource-core -Dtest-mode=run
