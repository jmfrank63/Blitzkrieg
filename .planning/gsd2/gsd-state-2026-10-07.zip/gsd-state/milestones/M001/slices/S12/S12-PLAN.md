# S12: Particle, Effect sub-editors (keyframe curve editor)

**Goal:** The Particle (.pcp, kind 11) and Effect (.eff, kind 12) sub-editors work end to end, ported from CParticleFrame/CKeyFrameEditor and CEffectFrame. Particle curves are edited in the Function window with a keyframe curve editor (add, move, delete, reset all, zoom X/Y), each gesture one undoable command. Real exporters write the engine's SParticleSourceData/SSmokinParticleSourceData and SEffectDesc; the pcp importer round-trips every shipped Data/Effects/Particles source; effect import is refused (no MFC reverse path). Run/Stop and Camera drive the preview. Interpolate Vector Items is recorded as no behaviour in MFC (D026).
**Demo:** Keyframe editor edits (add, move, delete, reset, zoom) all undoable. Run and Stop + Camera switch work via auto scenario. Golden parity per sub-editor; import round trip; preview shot. Interpolate Vector Items either implemented or marked `no behaviour in MFC`.

## Must-Haves

- pcp export of the repo fixture (simple and complex/smokin source) writes the particle xml, a second forced export is byte-identical, and the file read back through SParticleSourceData/SSmokinParticleSourceData operator& carries the model's keys per track; nothing is written into Data/.
- Every shipped Data/Effects/Particles/*.xml holding particle KeyData (copied read-only to zig-out/local-test) imports to a pcp tree and exports field-equal through the comparator; the test prints 'PARTICLES checked=N files=N unimportable=U' with any unimportable file named with a specific reason, and a listed file that now imports fails the test.
- eff export of the repo fixture writes SEffectDesc with sprite and func-particle children (smokin vs simple chosen from the referenced particle source, as EffectFrm.cpp SaveRPGStats); meshes, maya particles and lights are not exported, as in MFC; import of eff answers REFUSED naming 'no reverse path in MFC'.
- 'GOLDEN pcp pending' and 'GOLDEN eff pending' lines (win-home); no MFC golden parity is claimed.
- BkResGetKeyframeKnobs and BkResPreviewCameraMode exist, are tested in test-resource-bridge, and are mirrored in resource_core bridge.zig, fake_bridge.zig and resource_app c_bridge.zig.
- keyframe_logic.zig tests cover value<->screen mapping, x-only hit test, sorted insert, drag clamps (NODE_SPACE, key 0 x-fixed, MaxX/MaxY), delete (key 0 protected, last-touched key), reset all (keep first), zoom in/out X and Y, and that one gesture yields one undo step whose undo/redo restore the keys exactly.
- The Function window shows the curve of the selected key-frame node; Particle toolbar has Run, Stop, Camera, Get particle info and the simple/complex switch; Effect has Run, Stop, Camera, direction and whole-number child positions.
- resource-editor-auto has pcp and eff blocks: keyframe add/move/delete/reset/zoom each undone and redone with keys asserted; Run then Stop and Camera toggle with captured preview shots measured by code (non-blank, Run differs from Stop/empty, edited curve differs from original); pcp import round trip and eff export checked.
- 06-PARITY.md B-06.1..B-06.7, B-08.1..B-08.6 and A-15 carry evidence; B-08.4 marked 'no behaviour in MFC' with the grep as evidence.
- Tiers green on Linux: test-resource-model, test-resource-model-comparator, test-resource-bridge, test-resource-core, test-resource-app-logic, test-editor-core, install-resource-editor, resource-editor-host-check, resource-editor-smoke, resource-editor-auto, map-editor-smoke. Full sweep left to the maintainer; macOS/Windows by CI only.

## Proof Level

- This slice proves: Contract and integration. Exported particle/effect data is proved through the engine's own readers (operator& on the engine structs, comparator) and by driving the real preview with the real exporter; the curve editor's MFC quirks are proved by pure-logic tests; preview claims are proved by code measuring captured TGA/PNG. MFC golden equality stays pending until win-home.

## Integration Closure

Kinds 11 (pcp) and 12 (eff) gain exporters in exporter.cpp's table, pcp gains an importer in resource_bridge.cpp's BkResImportFromGame (bPorted), and the preview uses the real exporters instead of the test stand-ins. Two ABI calls (keyframe knobs, camera mode) ripple through resource_core and the app. The Function window (A-15) hosts the curve editor. BK_EDITOR_AUTO gains keyframe/run/stop/camera verbs and pcp/eff blocks that S16 consumes.

## Verification

- Export/import failures name the file and track. The shipped scan prints 'PARTICLES checked=N files=N unimportable=U' with offender paths. Auto shots print measured pixel counts against thresholds. GOLDEN lines say pending with the reason.

## Tasks

- [x] **T01: Particle (.pcp) exporter and importer with shipped-particle round trip** `est:4h`
  Why: B-06.5/B-06.6/B-06.7 and the real preview need a real pcp exporter; FindExporter("pcp") is null today (Sources/src/ResourceModel/exporter.cpp Exporters() lists wpn..bdg only) and BkResImportFromGame refuses kind 11 (resource_bridge.cpp bPorted ~5741). Highest risk, first proof (D026).
  Do: (1) Add Sources/src/ResourceModel/items/particle/particle_export.{h,cpp} with ExportParticle, ParticleStatsToTree, ported line for line from Sources/src/editor/ParticleFrm.cpp: FillRPGStats 274 (simple, 17 tracks via CopyFramesListToKeyTrack), FillRPGStats2 338 (smokin), SaveRPGStats 386 (one (0,0) key per track for a just-created project), GetRPGStats/GetRPGStats2 441/452 and LoadRPGStats 477 (SSourceType.ComplexParticleSource chooses the struct). Use the engine's SParticleSourceData / SSmokinParticleSourceData (Sources/src/Scene/ParticleSourceData.h) operator& through NStatsExport::WriteStats and the stats_export.h helpers (PreparedCopy, ChildItem, Value*); never hand-write XML. Find out from the model (Sources/src/ResourceModel/items/particle/particle.{h,cpp}) how simple vs complex is stored and document it. Check that key_frame_tree_item.{h,cpp} knobs (fMinValX..fStepY, bResizeMode) match ParticleTreeItem.cpp InitDefaultValues per track; fix any drift. (2) Register {"pcp", &ExportParticle} in exporter.cpp and declare it in stats_export.h; add particle_export.cpp to build.zig's ResourceModel source list next to bridge_export.cpp (~4135). (3) In resource_bridge.cpp add kind 11 to bPorted and the import switch (read the particle xml with the engine reader, fill the tree), keeping the existing preview kind 11 (WrapParticleSource). (4) Tests in Sources/src/EditorBridge/resource_bridge_test.cpp: fixture tools/zig/fixtures/resource_editor/pcp/project.pcp exports (simple and, via a fixture variant or a test-time tree edit, complex), second forced export byte-identical, read back through operator& and compare keys per track to the model; import->export->import field-equal; 'GOLDEN pcp pending' line; update the batch test (~1962) and import-refusal test (~2051) that today expect pcp not ported; replace the ParticleSourceExporter stand-in (~2405) with the real exporter and keep a captured preview frame check. Shipped scan: copy every Data/Effects/Particles/*.xml read-only to zig-out/local-test, import each holding particle KeyData, export field-equal through the comparator (extend comparator.{h,cpp} for the particle structs if it lacks them; unknown fields fail), print 'PARTICLES checked=N files=N unimportable=U'; non-particle xml files are counted and named as skipped with the reason, never silently dropped (D022 strictness); a listed unimportable file that imports fails the test. Resolve Data paths case-insensitively (DataFile helper). Update tools/zig/fixtures/resource_editor/pcp/golden/README.md with the win-home step (export-goldens.ps1 -Extensions pcp). Keep new files CRLF.
  Done when: the verify tiers exit 0 and the summary records the real PARTICLES counts.
  - Files: `Sources/src/ResourceModel/items/particle/particle_export.h`, `Sources/src/ResourceModel/items/particle/particle_export.cpp`, `Sources/src/ResourceModel/items/stats_export.h`, `Sources/src/ResourceModel/exporter.cpp`, `Sources/src/ResourceModel/comparator.h`, `Sources/src/ResourceModel/comparator.cpp`, `Sources/src/ResourceModel/key_frame_tree_item.cpp`, `Sources/src/EditorBridge/resource_bridge.cpp`, `Sources/src/EditorBridge/resource_bridge_test.cpp`, `build.zig`, `tools/zig/fixtures/resource_editor/pcp/golden/README.md`
  - Verify: zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model -Dtest-mode=run && zig build test-resource-model-comparator -Dtest-mode=run && zig build test-resource-core -Dtest-mode=run

- [x] **T02: Effect (.eff) exporter, effect import refusal, Interpolate evidence** `est:3h`
  Why: B-08.5/B-08.6 and B-08.4. FindExporter("eff") is null; MFC EffectFrm.cpp has no GetRPGStats/LoadRPGStats, so there is no reverse path (D026).
  Do: (1) Add Sources/src/ResourceModel/items/effect/effect_export.{h,cpp} with ExportEffect ported from CEffectFrame::SaveRPGStats (EffectFrm.cpp:170): Common sound; Animations -> SSpriteEffectDesc (path Effects\\sprites\\<name>, start, repeat, pos); Func Particles -> open Effects\\particles\\<name>.xml from the export context's data root (case-insensitive FoldedFile), read SSourceType to choose SSmokinParticleEffectDesc vs SParticleEffectDesc (start, duration, pos, scale). Meshes, Maya particles and lights are not exported, as in MFC; say so in a comment. Write SEffectDesc through the engine's operator& via NStatsExport::WriteStats. A referenced particle that is missing is a refusal naming the file (check what MFC did and match it; record any deviation). Register {"eff", &ExportEffect} in exporter.cpp, declare in stats_export.h, add effect_export.cpp to build.zig next to particle_export.cpp. (2) In resource_bridge.cpp make importing kind 12 answer REFUSED with 'importing .eff is refused: MFC's effect editor has no reverse path (EffectFrm.cpp has no GetRPGStats/LoadRPGStats)', like spt. (3) Tests in resource_bridge_test.cpp: eff fixture (tools/zig/fixtures/resource_editor/eff/project.eff; extend it and resource_editor_fixtures.zig only as needed so it has one sprite and one func particle child referencing tracked data copied to zig-out/local-test) exports; a second forced export byte-identical; read back SEffectDesc and compare sprites/particles fields to the tree; import refusal message; 'GOLDEN eff pending'; replace the EffectExporter stand-in (~2407) with the real exporter in the preview capture. (4) Record B-08.4 evidence: grep -rn -i interpolate Sources/src/editor/*.cpp shows only ON_UPDATE_COMMAND_UI (EffectFrm.cpp:34, 395); write it into .planning/phases/06-resource-editor-portable-port/06-PARITY.md B-08.4 as 'no behaviour in MFC'. Update eff/golden/README.md. Keep new files CRLF.
  Done when: verify exits 0.
  - Files: `Sources/src/ResourceModel/items/effect/effect_export.h`, `Sources/src/ResourceModel/items/effect/effect_export.cpp`, `Sources/src/ResourceModel/items/stats_export.h`, `Sources/src/ResourceModel/exporter.cpp`, `Sources/src/EditorBridge/resource_bridge.cpp`, `Sources/src/EditorBridge/resource_bridge_test.cpp`, `build.zig`, `tools/zig/resource_editor_fixtures.zig`, `tools/zig/fixtures/resource_editor/eff/project.eff`, `tools/zig/fixtures/resource_editor/eff/golden/README.md`, `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`
  - Verify: zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model -Dtest-mode=run && zig build test-resource-model-comparator -Dtest-mode=run

- [x] **T03: Bridge ABI: keyframe knobs getter and preview camera mode, mirrored in resource_core and app** `est:2h`
  Why: the curve widget needs each key-frame node's range/step (CKeyFrameEditor::SetDimentions), which the bridge does not expose; MFC's Camera button (ParticleFrm.cpp:144, EffectFrm.cpp OnButtonCamera) swaps SetHorizontalCamera/SetDefaultCamera, which BkResPreviewCamera(wx,wy,zoom) cannot express (D026).
  Do: (1) In Sources/src/EditorBridge/resource_bridge.h add a BkResKeyframeKnobs struct {min_x,max_x,min_y,max_y,step_x,step_y,resize_mode} and BkResGetKeyframeKnobs(session,node,out) (BAD_ARGUMENT for a node that is not a CKeyFrameTreeItem), and BkResPreviewCameraMode(session,horizontal) applying the scene's horizontal or default camera as MFC does; keep CRLF and document both. Implement in resource_bridge.cpp. (2) Tests in resource_bridge_test.cpp: knobs of several pcp tracks equal ParticleTreeItem.cpp InitDefaultValues; a non-keyframe node is BAD_ARGUMENT; camera mode toggles in a preview session and a captured frame differs between modes (measured by code). (3) Mirror in Sources/editor/resource_core/bridge.zig (vtable/interface), fake_bridge.zig (store knobs per node and the camera flag) and Sources/editor/resource_app/c_bridge.zig; core tests that the fake returns the knobs and refuses non-keyframe nodes.
  Done when: verify exits 0.
  - Files: `Sources/src/EditorBridge/resource_bridge.h`, `Sources/src/EditorBridge/resource_bridge.cpp`, `Sources/src/EditorBridge/resource_bridge_test.cpp`, `Sources/editor/resource_core/bridge.zig`, `Sources/editor/resource_core/fake_bridge.zig`, `Sources/editor/resource_core/root.zig`, `Sources/editor/resource_app/c_bridge.zig`
  - Verify: zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-core -Dtest-mode=run && zig build test-resource-app-logic -Dtest-mode=run && zig build test-editor-core -Dtest-mode=run

- [x] **T04: Pure keyframe curve logic with MFC quirks and one-undo-per-gesture (TDD)** `est:3h`
  Why: B-06.1/B-06.2 curve editing must match CKeyFrameEditor (Sources/src/editor/KeyFrame.cpp) and be undoable; pure logic is testable without a GUI.
  Do: tests first. Add Sources/editor/resource_app/keyframe_logic.zig (wire it into the test-resource-app-logic tier the way grid_logic.zig is wired in build.zig) porting: GetScreenByValue/GetValueByScreen (584-630) with scroll offsets; SetDimentions from BkResKeyframeKnobs (471-560); OnLButtonDown 762 (hit test on screen x only within SELECT_SIZE; a hit sets y to click y clamped to [MinY,MaxY] and starts a drag; a miss inside both ranges inserts sorted by x and starts a drag); OnMouseMove 846 (neighbour clamp by NODE_SPACE px, key 0 x fixed, x clamped to MaxX, y to MaxY, no lower clamp while dragging; edge scroll); Delete (key 0 protected, deletes the last-touched index); ResetNodes (keep first key, the dock's Reset all); zoom in/out X and Y (647-722). A Gesture holds the keys before; on button up (or delete/reset/zoom-free commit) it produces one geometry command over channel .particle_keyframes via resource_core's ResourceCommand so a whole drag is one undo step (MFC posts WM_KEY_FRAME_UPDATE on L-up). Zoom changes view only, not data, and is not an undo step; record that. Tests: each quirk above, sorted insert, two keys never share x, delete of key 0 refused, reset keeps first, zoom ranges, and for add/move/delete/reset: keys before, after, undo and redo exact (z stays 0) against resource_core's fake bridge. Record intentional deviations (if any) for PARITY.
  Done when: verify exits 0 with the new tests.
  - Files: `Sources/editor/resource_app/keyframe_logic.zig`, `build.zig`
  - Verify: zig build test-resource-app-logic -Dtest-mode=run && zig build test-resource-core -Dtest-mode=run

- [x] **T05: Function window curve widget, Particle and Effect toolbars** `est:3h`
  Why: A-15, B-06.1..B-06.4, B-08.1..B-08.3: users edit curves and drive the preview in the app.
  Do: (1) In Sources/editor/resource_app/docks.zig replace the function_window_note placeholder (docks_logic.zig:356, docks.zig:426) with the curve widget for the selected CKeyFrameTreeItem node: ImDrawList grid, keys and polyline; left click add/move and drag through keyframe_logic; Delete key; right-click menu with Zoom in/out X/Y (IDR_KEYFRAME_ZOOM_MENU) and Reset all; one command per gesture; empty-state text when the selection has no keyframes. (2) Particle toolbar (panels.zig/main.zig as other kinds are wired): Run, Stop (existing PreviewSync in docks_logic.zig), Camera via BkResPreviewCameraMode, Get particle info (ParticleFrm.cpp:129, show what MFC showed), simple/complex source switch (ParticleFrm.cpp:649-700 UpdateSourceType; frame state, not project data, unless T01 found otherwise). (3) Effect: Run, Stop, Camera; direction dock drives the effect angle (EffectFrm.cpp UpdateEffectAngle 113); child X/Y/Z positions edited as whole numbers through the effect_keyframes channel with BAD_ARGUMENT surfaced, one command per edit. App-logic tests for any new pure logic in docks_logic.zig.
  Done when: verify exits 0 and opening the pcp and eff fixtures in resource-editor-smoke does not regress.
  - Files: `Sources/editor/resource_app/docks.zig`, `Sources/editor/resource_app/docks_logic.zig`, `Sources/editor/resource_app/panels.zig`, `Sources/editor/resource_app/main.zig`
  - Verify: zig build test-resource-app-logic -Dtest-mode=run && zig build test-resource-core -Dtest-mode=run && zig build install-resource-editor && zig build resource-editor-smoke

- [x] **T06: BK_EDITOR_AUTO pcp/eff blocks with measured shots, PARITY rows, spec, tier run** `est:3h`
  Why: the demo needs keyframe edits, Run/Stop and Camera proved in an auto scenario with measured preview shots; PARITY and spec record evidence. Last task of the slice.
  Do: add verbs to Sources/editor/resource_app/scenario.zig (e.g. keyframe=add|move|delete|reset|zoomx_in|zoomx_out|zoomy_in|zoomy_out with an expect on key count/values, run, stop, camera) and pcp and eff blocks in build.zig's resource-editor-auto next to the bdg block: copy fixtures to {dir}/pcp and {dir}/eff; select a track, add/move/delete/reset each followed by undo and redo with keys asserted; zoom; Run and shoot, Stop and shoot, Camera toggle and shoot, edit a curve and shoot; code measures non-blank pixels and differences against thresholds; export and check the particle xml and effect xml exist; pcp import round trip of a shipped particle via the import verb. Fix bugs it exposes. Update .planning/phases/06-resource-editor-portable-port/06-PARITY.md B-06.1..B-06.7, B-08.1..B-08.3, B-08.5, B-08.6 and A-15 with evidence (goldens pending win-home) and the spec docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md with D026 (knobs/camera ABI, effect import refusal, curve quirks). Run GUI tiers from the shell, not the gsd_exec sandbox (no video device there). Full sweep left to the maintainer; never claim macOS/Windows.
  Done when: all verify tiers exit 0.
  - Files: `Sources/editor/resource_app/scenario.zig`, `build.zig`, `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`, `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`
  - Verify: zig build install-resource-editor && zig build resource-editor-auto && zig build resource-editor-smoke && zig build resource-editor-host-check && zig build test-resource-app-logic -Dtest-mode=run && zig build test-resource-core -Dtest-mode=run && zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model -Dtest-mode=run && zig build test-resource-model-comparator -Dtest-mode=run && zig build test-editor-core -Dtest-mode=run && zig build map-editor-smoke

## Files Likely Touched

- Sources/src/ResourceModel/items/particle/particle_export.h
- Sources/src/ResourceModel/items/particle/particle_export.cpp
- Sources/src/ResourceModel/items/stats_export.h
- Sources/src/ResourceModel/exporter.cpp
- Sources/src/ResourceModel/comparator.h
- Sources/src/ResourceModel/comparator.cpp
- Sources/src/ResourceModel/key_frame_tree_item.cpp
- Sources/src/EditorBridge/resource_bridge.cpp
- Sources/src/EditorBridge/resource_bridge_test.cpp
- build.zig
- tools/zig/fixtures/resource_editor/pcp/golden/README.md
- Sources/src/ResourceModel/items/effect/effect_export.h
- Sources/src/ResourceModel/items/effect/effect_export.cpp
- tools/zig/resource_editor_fixtures.zig
- tools/zig/fixtures/resource_editor/eff/project.eff
- tools/zig/fixtures/resource_editor/eff/golden/README.md
- .planning/phases/06-resource-editor-portable-port/06-PARITY.md
- Sources/src/EditorBridge/resource_bridge.h
- Sources/editor/resource_core/bridge.zig
- Sources/editor/resource_core/fake_bridge.zig
- Sources/editor/resource_core/root.zig
- Sources/editor/resource_app/c_bridge.zig
- Sources/editor/resource_app/keyframe_logic.zig
- Sources/editor/resource_app/docks.zig
- Sources/editor/resource_app/docks_logic.zig
- Sources/editor/resource_app/panels.zig
- Sources/editor/resource_app/main.zig
- Sources/editor/resource_app/scenario.zig
- docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md
