---
id: T02
parent: S12
milestone: M001
key_files: []
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-05T21:21:58.401Z
blocker_discovered: false
---

# T02: Real .eff exporter (sprites, plain and smokin function particles chosen by the source's ComplexParticleSource, root <effect>), registered; .eff import refused naming MFC's missing reverse path; B-08.4 recorded as no behaviour in MFC.

**Real .eff exporter (sprites, plain and smokin function particles chosen by the source's ComplexParticleSource, root <effect>), registered; .eff import refused naming MFC's missing reverse path; B-08.4 recorded as no behaviour in MFC.**

## What Happened

Added effect_export.{h,cpp} (ExportEffect, EffectImportRefusal), ported from CEffectFrame::SaveRPGStats: Common sound, Animations -> SSpriteEffectDesc, Function Particles -> SParticleEffectDesc or SSmokinParticleEffectDesc depending on the source xml's KeyData/ComplexParticleSource. The source is looked up in the export data root, then the staging root; a missing source is a refusal naming the file (MFC showed a message box and skipped it; deviation recorded in the file comment). Meshes, Maya particles and lights are not exported, as in MFC. WriteStats gained an optional root-name parameter; the effect is written with root <effect> as MFC does for E_EFFECT_FRAME (ParentFrame.cpp:1073) and as every shipped effect has it, which the comparator requires. Registered {"eff"} in exporter.cpp and build.zig; the bridge's import of kind 12 answers REFUSED with the MFC reason. Tests: eff fixture export without source is refused naming particle-2key; with a shipped plain source the engine reads back one sprite and one particle with the tree's fields; second forced export byte-identical; comparator reads the export (17 fields, 0 messages); a smokin source lands in smokinParticles; import refusal message; GOLDEN eff pending. The preview capture now uses the real exporter through a test wrapper that stages a shipped sprite folder and particle source (effect drew 3.1% of the frame vs the 0.1% threshold). B-08.4 in 06-PARITY.md now reads 'no behaviour in MFC' with the grep evidence (EffectFrm.cpp:34, 395 only ON_UPDATE_COMMAND_UI); eff/golden/README.md updated.

## Verification

All three verify commands exit 0; GOLDEN eff stays pending (win-home only). Full resource sweep left to the maintainer. Only Linux was run.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model -Dtest-mode=run && zig build test-resource-model-comparator -Dtest-mode=run` | 0 | pass | 0ms |

## Deviations

None.

## Known Issues

None.

## Files Created/Modified

None.
