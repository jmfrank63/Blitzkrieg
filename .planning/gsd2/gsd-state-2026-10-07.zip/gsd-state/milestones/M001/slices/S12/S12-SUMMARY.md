---
id: S12
parent: M001
milestone: M001
provides:
  - (none)
requires:
  []
affects:
  []
key_files:
  - Sources/src/ResourceModel/items/particle/particle_export.cpp
  - Sources/src/ResourceModel/items/effect/effect_export.cpp
  - Sources/editor/resource_app/keyframe_logic.zig
  - Sources/editor/resource_app/docks.zig
  - Sources/editor/resource_app/scenario.zig
  - Sources/src/EditorBridge/resource_bridge.h
key_decisions: []
patterns_established:
  - (none)
observability_surfaces:
  - none
drill_down_paths:
  []
duration: ""
verification_result: passed
completed_at: 2026-10-05T21:56:05.841Z
blocker_discovered: false
---

# S12: S12

**Particle (.pcp) and Effect (.eff) sub-editors: real exporters, key-frame curve editor with undoable add/move/delete/reset/zoom, Run/Stop and Camera preview, and an auto scenario.**

## What Happened

T01 added the .pcp exporter and importer (simple and complex sources); all 291 shipped Data/Effects/Particles sources round-trip with 0 differences. T02 added the .eff exporter. .eff import is refused with a reason naming MFC's missing reverse path, and 06-PARITY B-08.4 is recorded as 'no behaviour in MFC'. T03 extended the bridge ABI with BkResGetKeyframeKnobs and BkResPreviewCameraMode, mirrored in resource_core and the app's c_bridge. T04 added keyframe_logic.zig, which ports CKeyFrameEditor with one geometry command per gesture; 17 tests cover undo/redo. T05 put the curve widget in the Function window and added a Camera toggle to the preview menu. T06 added BK_EDITOR_AUTO verbs and a pcp+eff scenario with measured Run/Stop/Camera shots, and updated PARITY and spec D026. A final fix changed the import-refusal check in docks_check to expect '.eff import refused'.

## Verification

All run on Linux x64. resource-editor-auto PASS (697 actions over 551 frames) when re-run in this unit with XDG_RUNTIME_DIR and display env set. gsd_exec's default env has no XDG_RUNTIME_DIR, so the first run failed with SdlInitFailed; that was an environment problem, not a code one. Earlier in the slice: install-resource-editor, resource-editor-smoke, resource-editor-host-check, test-resource-app-logic, test-resource-core, test-resource-bridge, test-resource-model, test-resource-model-comparator, test-editor-core and map-editor-smoke all exit 0. The MFC goldens for pcp and eff are pending on win-home. The full resource sweep is left to the maintainer. No macOS or Windows result was seen.

## Requirements Advanced

None.

## Requirements Validated

None.

## New Requirements Surfaced

None.

## Requirements Invalidated or Re-scoped

None.

## Operational Readiness

None.

## Deviations

None.

## Known Limitations

Get particle info, the simple/complex source toggle and effect angle/position editing (direction arrow) were not implemented. Zoom is view-only; MFC's zoom handlers are commented out. MFC golden parity for pcp and eff is pending on win-home. Only Linux was run.

## Follow-ups

Implement Get particle info, the simple/complex toggle and the effect direction arrow, or mark them 'no behaviour in MFC' in PARITY. Produce the pcp and eff MFC goldens on win-home.

## Files Created/Modified

None.
