---
id: T04
parent: S12
milestone: M001
key_files:
  - Sources/editor/resource_app/keyframe_logic.zig
  - Sources/editor/resource_app/panels_logic.zig
key_decisions:
  - Deviation for PARITY: MFC's zoom handlers (OnKeyframeZoomin/outx/y) are fully commented out, so MFC zoom is a no-op. This port implements view-only zoom stepping pixels per step through {5,10,20,25,50,100} (MFC's SIZES list with the default 25 added); zoom is not an undo step.
  - Deviation: resize mode with an empty x range keeps the old scale instead of dividing by zero as MFC does.
  - Deviation: a release that changes no key adds no undo step, whereas MFC posts WM_KEY_FRAME_UPDATE unconditionally.
  - Faithful quirks kept: x-only hit test, Delete removes the last-touched index which does not move after deletion, and a stale index after Reset all removes nothing.
duration: 
verification_result: passed
completed_at: 2026-10-05T21:32:02.080Z
blocker_discovered: false
---

# T04: Pure keyframe curve logic (keyframe_logic.zig) porting CKeyFrameEditor's mapping, scroll model, press/move/release gesture, delete, reset all and zoom, with one geometry command per gesture; 17 tests green against the fake bridge.

**Pure keyframe curve logic (keyframe_logic.zig) porting CKeyFrameEditor's mapping, scroll model, press/move/release gesture, delete, reset all and zoom, with one geometry command per gesture; 17 tests green against the fake bridge.**

## What Happened

Added Sources/editor/resource_app/keyframe_logic.zig, wired into the test-resource-app-logic tier through panels_logic.zig's test block (the same way grid_logic.zig is wired), so build.zig needed no change. It ports KeyFrame.cpp: GetScreenByValue/GetValueByScreen with scroll offsets, SetDimentions/SetHDimention/SetVDimention from BkResKeyframeKnobs (resize mode, scroll bar visibility, Windows pos clamp), OnLButtonDown (hit test on screen x only within SELECT_SIZE; a hit takes the click y clamped to [MinY,MaxY]; a miss inside both ranges inserts sorted), OnMouseMove (NODE_SPACE neighbour clamp, key 0 x fixed, x clamped to MaxX, y only capped above, edge scrolling), DeleteActiveNode (key 0 protected, last-touched index that persists), ResetNodes (keeps first key). The editor works on a local copy during a drag, as MFC does, and the release, delete and reset each commit exactly one .particle_keyframes geometry command through sub_editor_tools.commit, so a whole drag is one undo step; z stays 0. Releases that change nothing add no undo step. Zoom X/Y is view-only and not an undo step.

## Verification

Ran both verify commands; each exits 0. The 17 new tests cover: mapping hand values and round trip, scroll bar visibility and resize mode, x-only hit test with y clamp, sorted insert and out-of-range press, neighbour/key 0/MaxX clamps, y clamps and edge scroll, one undo step per multi-move drag, no-op releases, undo/redo exact for add, move, delete and reset (checked against the fake bridge's stored keys), no two keys sharing x, delete refusal and stale-index quirks, zoom ranges, hover and a non-curve node being refused.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-app-logic -Dtest-mode=run` | 0 | pass | 30000ms |
| 2 | `zig build test-resource-core -Dtest-mode=run` | 0 | pass | 5000ms |

## Deviations

The plan listed build.zig as expected output; no change was needed because keyframe_logic.zig is imported from panels_logic.zig's test block, the existing wiring for grid_logic.zig. Zoom is an invention over MFC's commented-out handlers (recorded as a deviation).

## Known Issues

None.

## Files Created/Modified

- `Sources/editor/resource_app/keyframe_logic.zig`
- `Sources/editor/resource_app/panels_logic.zig`
