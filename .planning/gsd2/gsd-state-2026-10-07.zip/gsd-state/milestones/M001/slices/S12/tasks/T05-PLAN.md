---
estimated_steps: 3
estimated_files: 4
skills_used: []
---

# T05: Function window curve widget, Particle and Effect toolbars

Why: A-15, B-06.1..B-06.4, B-08.1..B-08.3: users edit curves and drive the preview in the app.
Do: (1) In Sources/editor/resource_app/docks.zig replace the function_window_note placeholder (docks_logic.zig:356, docks.zig:426) with the curve widget for the selected CKeyFrameTreeItem node: ImDrawList grid, keys and polyline; left click add/move and drag through keyframe_logic; Delete key; right-click menu with Zoom in/out X/Y (IDR_KEYFRAME_ZOOM_MENU) and Reset all; one command per gesture; empty-state text when the selection has no keyframes. (2) Particle toolbar (panels.zig/main.zig as other kinds are wired): Run, Stop (existing PreviewSync in docks_logic.zig), Camera via BkResPreviewCameraMode, Get particle info (ParticleFrm.cpp:129, show what MFC showed), simple/complex source switch (ParticleFrm.cpp:649-700 UpdateSourceType; frame state, not project data, unless T01 found otherwise). (3) Effect: Run, Stop, Camera; direction dock drives the effect angle (EffectFrm.cpp UpdateEffectAngle 113); child X/Y/Z positions edited as whole numbers through the effect_keyframes channel with BAD_ARGUMENT surfaced, one command per edit. App-logic tests for any new pure logic in docks_logic.zig.
Done when: verify exits 0 and opening the pcp and eff fixtures in resource-editor-smoke does not regress.

## Inputs

- `Sources/editor/resource_app/keyframe_logic.zig`
- `Sources/editor/resource_app/c_bridge.zig`
- `Sources/editor/resource_app/docks.zig`
- `Sources/editor/resource_app/docks_logic.zig`
- `Sources/editor/resource_app/panels.zig`
- `Sources/editor/resource_app/main.zig`
- `Sources/src/editor/ParticleFrm.cpp`
- `Sources/src/editor/EffectFrm.cpp`
- `Sources/src/editor/KeyFrameDock.cpp`

## Expected Output

- `Sources/editor/resource_app/docks.zig`
- `Sources/editor/resource_app/docks_logic.zig`
- `Sources/editor/resource_app/panels.zig`
- `Sources/editor/resource_app/main.zig`

## Verification

zig build test-resource-app-logic -Dtest-mode=run && zig build test-resource-core -Dtest-mode=run && zig build install-resource-editor && zig build resource-editor-smoke
