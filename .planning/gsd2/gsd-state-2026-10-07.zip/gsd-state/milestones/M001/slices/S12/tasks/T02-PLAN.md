---
estimated_steps: 3
estimated_files: 11
skills_used: []
---

# T02: Effect (.eff) exporter, effect import refusal, Interpolate evidence

Why: B-08.5/B-08.6 and B-08.4. FindExporter("eff") is null; MFC EffectFrm.cpp has no GetRPGStats/LoadRPGStats, so there is no reverse path (D026).
Do: (1) Add Sources/src/ResourceModel/items/effect/effect_export.{h,cpp} with ExportEffect ported from CEffectFrame::SaveRPGStats (EffectFrm.cpp:170): Common sound; Animations -> SSpriteEffectDesc (path Effects\\sprites\\<name>, start, repeat, pos); Func Particles -> open Effects\\particles\\<name>.xml from the export context's data root (case-insensitive FoldedFile), read SSourceType to choose SSmokinParticleEffectDesc vs SParticleEffectDesc (start, duration, pos, scale). Meshes, Maya particles and lights are not exported, as in MFC; say so in a comment. Write SEffectDesc through the engine's operator& via NStatsExport::WriteStats. A referenced particle that is missing is a refusal naming the file (check what MFC did and match it; record any deviation). Register {"eff", &ExportEffect} in exporter.cpp, declare in stats_export.h, add effect_export.cpp to build.zig next to particle_export.cpp. (2) In resource_bridge.cpp make importing kind 12 answer REFUSED with 'importing .eff is refused: MFC's effect editor has no reverse path (EffectFrm.cpp has no GetRPGStats/LoadRPGStats)', like spt. (3) Tests in resource_bridge_test.cpp: eff fixture (tools/zig/fixtures/resource_editor/eff/project.eff; extend it and resource_editor_fixtures.zig only as needed so it has one sprite and one func particle child referencing tracked data copied to zig-out/local-test) exports; a second forced export byte-identical; read back SEffectDesc and compare sprites/particles fields to the tree; import refusal message; 'GOLDEN eff pending'; replace the EffectExporter stand-in (~2407) with the real exporter in the preview capture. (4) Record B-08.4 evidence: grep -rn -i interpolate Sources/src/editor/*.cpp shows only ON_UPDATE_COMMAND_UI (EffectFrm.cpp:34, 395); write it into .planning/phases/06-resource-editor-portable-port/06-PARITY.md B-08.4 as 'no behaviour in MFC'. Update eff/golden/README.md. Keep new files CRLF.
Done when: verify exits 0.

## Inputs

- `Sources/src/editor/EffectFrm.cpp`
- `Sources/src/ResourceModel/items/effect/effect.h`
- `Sources/src/ResourceModel/items/effect/effect.cpp`
- `Sources/src/ResourceModel/items/particle/particle_export.cpp`
- `Sources/src/ResourceModel/items/stats_export.h`
- `Sources/src/ResourceModel/exporter.cpp`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `tools/zig/fixtures/resource_editor/eff/project.eff`

## Expected Output

- `Sources/src/ResourceModel/items/effect/effect_export.h`
- `Sources/src/ResourceModel/items/effect/effect_export.cpp`
- `Sources/src/ResourceModel/exporter.cpp`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `build.zig`
- `tools/zig/fixtures/resource_editor/eff/project.eff`
- `tools/zig/fixtures/resource_editor/eff/golden/README.md`
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`

## Verification

zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model -Dtest-mode=run && zig build test-resource-model-comparator -Dtest-mode=run

## Observability Impact

Missing referenced particle names the file; import refusal names the MFC reason; GOLDEN eff pending line.
