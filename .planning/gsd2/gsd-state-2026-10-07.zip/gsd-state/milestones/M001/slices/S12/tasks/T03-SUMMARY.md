---
id: T03
parent: S12
milestone: M001
key_files:
  - Sources/src/EditorBridge/resource_bridge.h
  - Sources/src/EditorBridge/resource_bridge.cpp
  - Sources/src/EditorBridge/resource_bridge_test.cpp
  - Sources/editor/resource_core/bridge.zig
  - Sources/editor/resource_core/fake_bridge.zig
  - Sources/editor/resource_core/root.zig
  - Sources/editor/resource_app/c_bridge.zig
key_decisions:
  - Camera-mode pixel difference is asserted for mesh and particle, only logged for sprite, because a sprite billboard draws the same in both modes.
duration: 
verification_result: passed
completed_at: 2026-10-05T21:28:21.529Z
blocker_discovered: false
---

# T03: Bridge ABI gains BkResGetKeyframeKnobs (range/step/resize mode per key-frame node) and BkResPreviewCameraMode (MFC's horizontal vs default camera), mirrored in resource_core (bridge, fake, root) and the app's c_bridge.

**Bridge ABI gains BkResGetKeyframeKnobs (range/step/resize mode per key-frame node) and BkResPreviewCameraMode (MFC's horizontal vs default camera), mirrored in resource_core (bridge, fake, root) and the app's c_bridge.**

## What Happened

Added BkResKeyframeKnobs and BkResGetKeyframeKnobs (BAD_ARGUMENT for a node that is not a key-frame node) plus BkResPreviewCameraMode(session, horizontal) to resource_bridge.h/.cpp. Horizontal applies SetHorizontalCamera's angles over the preview camera's anchor; default restores the session camera; both are refused with no preview. Mirrored in resource_core/bridge.zig (vtable and wrappers), fake_bridge.zig (knobs per node, camera flag), root.zig and resource_app/c_bridge.zig. Bridge tests check pcp track knobs against the InitDefaultValues defaults, refusal of non-keyframe nodes, and measured pixel differences between camera modes. On resume the bridge tier failed because the sprite frame is identical in both camera modes (changed=0.000000, a screen-aligned billboard); mesh (1.8%) and particle (1.0%) differ well above the 0.1% threshold. The camera-mode assertion now applies to every kind except sprite, and the sprite result is still logged.

## Verification

All four verify commands re-run fresh in this session and exit 0 after the test fix.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass (after sprite camera assertion fix; first run failed 2 sprite checks) | 58000ms |
| 2 | `zig build test-resource-core -Dtest-mode=run` | 0 | pass | 1000ms |
| 3 | `zig build test-resource-app-logic -Dtest-mode=run` | 0 | pass | 1000ms |
| 4 | `zig build test-editor-core -Dtest-mode=run` | 0 | pass | 1000ms |

## Deviations

None.

## Known Issues

None.

## Files Created/Modified

- `Sources/src/EditorBridge/resource_bridge.h`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `Sources/editor/resource_core/bridge.zig`
- `Sources/editor/resource_core/fake_bridge.zig`
- `Sources/editor/resource_core/root.zig`
- `Sources/editor/resource_app/c_bridge.zig`
