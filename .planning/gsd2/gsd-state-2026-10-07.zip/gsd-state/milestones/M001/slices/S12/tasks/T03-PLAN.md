---
estimated_steps: 3
estimated_files: 7
skills_used: []
---

# T03: Bridge ABI: keyframe knobs getter and preview camera mode, mirrored in resource_core and app

Why: the curve widget needs each key-frame node's range/step (CKeyFrameEditor::SetDimentions), which the bridge does not expose; MFC's Camera button (ParticleFrm.cpp:144, EffectFrm.cpp OnButtonCamera) swaps SetHorizontalCamera/SetDefaultCamera, which BkResPreviewCamera(wx,wy,zoom) cannot express (D026).
Do: (1) In Sources/src/EditorBridge/resource_bridge.h add a BkResKeyframeKnobs struct {min_x,max_x,min_y,max_y,step_x,step_y,resize_mode} and BkResGetKeyframeKnobs(session,node,out) (BAD_ARGUMENT for a node that is not a CKeyFrameTreeItem), and BkResPreviewCameraMode(session,horizontal) applying the scene's horizontal or default camera as MFC does; keep CRLF and document both. Implement in resource_bridge.cpp. (2) Tests in resource_bridge_test.cpp: knobs of several pcp tracks equal ParticleTreeItem.cpp InitDefaultValues; a non-keyframe node is BAD_ARGUMENT; camera mode toggles in a preview session and a captured frame differs between modes (measured by code). (3) Mirror in Sources/editor/resource_core/bridge.zig (vtable/interface), fake_bridge.zig (store knobs per node and the camera flag) and Sources/editor/resource_app/c_bridge.zig; core tests that the fake returns the knobs and refuses non-keyframe nodes.
Done when: verify exits 0.

## Inputs

- `Sources/src/editor/KeyFrame.cpp`
- `Sources/src/editor/ParticleFrm.cpp`
- `Sources/src/ResourceModel/key_frame_tree_item.h`
- `Sources/src/EditorBridge/resource_bridge.h`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/editor/resource_core/bridge.zig`
- `Sources/editor/resource_core/fake_bridge.zig`
- `Sources/editor/resource_app/c_bridge.zig`

## Expected Output

- `Sources/src/EditorBridge/resource_bridge.h`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `Sources/editor/resource_core/bridge.zig`
- `Sources/editor/resource_core/fake_bridge.zig`
- `Sources/editor/resource_core/root.zig`
- `Sources/editor/resource_app/c_bridge.zig`

## Verification

zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-core -Dtest-mode=run && zig build test-resource-app-logic -Dtest-mode=run && zig build test-editor-core -Dtest-mode=run
