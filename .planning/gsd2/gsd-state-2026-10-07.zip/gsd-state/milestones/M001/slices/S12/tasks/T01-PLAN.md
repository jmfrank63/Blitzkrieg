---
estimated_steps: 3
estimated_files: 11
skills_used: []
---

# T01: Particle (.pcp) exporter and importer with shipped-particle round trip

Why: B-06.5/B-06.6/B-06.7 and the real preview need a real pcp exporter; FindExporter("pcp") is null today (Sources/src/ResourceModel/exporter.cpp Exporters() lists wpn..bdg only) and BkResImportFromGame refuses kind 11 (resource_bridge.cpp bPorted ~5741). Highest risk, first proof (D026).
Do: (1) Add Sources/src/ResourceModel/items/particle/particle_export.{h,cpp} with ExportParticle, ParticleStatsToTree, ported line for line from Sources/src/editor/ParticleFrm.cpp: FillRPGStats 274 (simple, 17 tracks via CopyFramesListToKeyTrack), FillRPGStats2 338 (smokin), SaveRPGStats 386 (one (0,0) key per track for a just-created project), GetRPGStats/GetRPGStats2 441/452 and LoadRPGStats 477 (SSourceType.ComplexParticleSource chooses the struct). Use the engine's SParticleSourceData / SSmokinParticleSourceData (Sources/src/Scene/ParticleSourceData.h) operator& through NStatsExport::WriteStats and the stats_export.h helpers (PreparedCopy, ChildItem, Value*); never hand-write XML. Find out from the model (Sources/src/ResourceModel/items/particle/particle.{h,cpp}) how simple vs complex is stored and document it. Check that key_frame_tree_item.{h,cpp} knobs (fMinValX..fStepY, bResizeMode) match ParticleTreeItem.cpp InitDefaultValues per track; fix any drift. (2) Register {"pcp", &ExportParticle} in exporter.cpp and declare it in stats_export.h; add particle_export.cpp to build.zig's ResourceModel source list next to bridge_export.cpp (~4135). (3) In resource_bridge.cpp add kind 11 to bPorted and the import switch (read the particle xml with the engine reader, fill the tree), keeping the existing preview kind 11 (WrapParticleSource). (4) Tests in Sources/src/EditorBridge/resource_bridge_test.cpp: fixture tools/zig/fixtures/resource_editor/pcp/project.pcp exports (simple and, via a fixture variant or a test-time tree edit, complex), second forced export byte-identical, read back through operator& and compare keys per track to the model; import->export->import field-equal; 'GOLDEN pcp pending' line; update the batch test (~1962) and import-refusal test (~2051) that today expect pcp not ported; replace the ParticleSourceExporter stand-in (~2405) with the real exporter and keep a captured preview frame check. Shipped scan: copy every Data/Effects/Particles/*.xml read-only to zig-out/local-test, import each holding particle KeyData, export field-equal through the comparator (extend comparator.{h,cpp} for the particle structs if it lacks them; unknown fields fail), print 'PARTICLES checked=N files=N unimportable=U'; non-particle xml files are counted and named as skipped with the reason, never silently dropped (D022 strictness); a listed unimportable file that imports fails the test. Resolve Data paths case-insensitively (DataFile helper). Update tools/zig/fixtures/resource_editor/pcp/golden/README.md with the win-home step (export-goldens.ps1 -Extensions pcp). Keep new files CRLF.
Done when: the verify tiers exit 0 and the summary records the real PARTICLES counts.

## Inputs

- `Sources/src/editor/ParticleFrm.cpp`
- `Sources/src/editor/ParticleTreeItem.cpp`
- `Sources/src/Scene/ParticleSourceData.h`
- `Sources/src/ResourceModel/items/particle/particle.h`
- `Sources/src/ResourceModel/items/particle/particle.cpp`
- `Sources/src/ResourceModel/key_frame_tree_item.h`
- `Sources/src/ResourceModel/items/stats_export.h`
- `Sources/src/ResourceModel/exporter.cpp`
- `Sources/src/ResourceModel/items/bridge/bridge_export.cpp`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `tools/zig/fixtures/resource_editor/pcp/project.pcp`

## Expected Output

- `Sources/src/ResourceModel/items/particle/particle_export.h`
- `Sources/src/ResourceModel/items/particle/particle_export.cpp`
- `Sources/src/ResourceModel/exporter.cpp`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `build.zig`
- `tools/zig/fixtures/resource_editor/pcp/golden/README.md`

## Verification

zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model -Dtest-mode=run && zig build test-resource-model-comparator -Dtest-mode=run && zig build test-resource-core -Dtest-mode=run

## Observability Impact

Export failures name the track; the shipped scan prints PARTICLES checked/files/unimportable with offender paths; GOLDEN pcp pending line.
