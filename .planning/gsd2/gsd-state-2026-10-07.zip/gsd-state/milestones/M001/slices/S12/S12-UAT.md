# S12: S12 — UAT

**Milestone:** M001
**Written:** 2026-10-05T21:56:05.843Z

# S12 UAT

**UAT Type:** automated on Linux x64, plus a manual check of the curve widget.

## Preconditions
- `zig build install-resource-editor` has succeeded.
- A display is available. XDG_RUNTIME_DIR and WAYLAND_DISPLAY are set.

## Steps
1. Run `zig build resource-editor-auto`. Expected: PASS, with the pcp and eff blocks run: keyframe add/move/delete/reset each undone and redone, zoom steps, export written, Run/Stop/Camera shots differing.
2. Open `tools/zig/fixtures/pcp/project.pcp` in ResourceEditor and select a key-frame node. In the Function window, click to add a key, drag it, press Delete, then Reset all. Expected: each gesture is one undo step, and Ctrl+Z / Ctrl+Y restore exact values.
3. Toggle Camera in the preview menu. Expected: the mesh and particle views change.
4. Try importing an .eff from game data. Expected: refused, naming MFC's missing reverse path.
5. Run `zig build test-resource-bridge -Dtest-mode=run`. Expected: the shipped particle scan reports differences=0.

## Edge cases
- Esc cancels a drag with no undo step.
- A release that changes nothing adds no undo step.
- A preview with a missing particle source is refused with a message naming the file.

## Not Proven By This UAT
- macOS and Windows results.
- MFC golden parity for pcp and eff (needs win-home).
- Get particle info, the simple/complex toggle and the effect direction arrow (not implemented).
- The full resource sweep, which is left to the maintainer.
