---
id: T05
parent: S12
milestone: M001
key_files: []
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-05T21:36:19.328Z
blocker_discovered: false
---

# T05: Function window now hosts the key-frame curve widget (grid, polyline, keys, add/move/delete, zoom and Reset all menu, one command per gesture) and the preview menu gains a Camera toggle; Particle info, source switch and effect angle and position editing were not done.

**Function window now hosts the key-frame curve widget (grid, polyline, keys, add/move/delete, zoom and Reset all menu, one command per gesture) and the preview menu gains a Camera toggle; Particle info, source switch and effect angle and position editing were not done.**

## What Happened

Replaced the Function window placeholder in docks.zig with a curve widget driven by keyframe_logic.Editor. The widget draws a step grid, the key polyline and key handles. Left press adds or grabs a key, the drag moves it, and the release commits one command. Esc cancels a drag, and Delete removes the active key. The right-click menu offers Zoom in/out X/Y and Reset all. The editor reloads when the selection or history revision changes (for example after undo). It shows the empty-state note when the selected node has no key-frame knobs. Failures are shown in the window, naming the error and the bridge's last message. The Preview menu gained a Horizontal camera toggle backed by dl.toggledCamera, which calls BkResPreviewCameraMode, next to the existing Run and Stop. build.zig links the data-only comparator library into the ResourceEditor so the exporters' Scene structs resolve. NOT done: the Particle toolbar's Get particle info and simple/complex source switch, and the Effect direction-dock angle and child X/Y/Z whole-number editing through effect_keyframes. These are left for a follow-up task. No panels.zig or main.zig changes were made.

## Verification

All four plan verify commands exit 0: test-resource-app-logic, test-resource-core, install-resource-editor, resource-editor-smoke (smoke-edit PASS on .unt). The smoke run did not open the pcp or eff fixtures specifically. The curve widget's interactive drawing was not exercised by an automated shot. Linux only; macOS and Windows not run.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-app-logic -Dtest-mode=run` | 0 | pass | 1000ms |
| 2 | `zig build test-resource-core -Dtest-mode=run` | 0 | pass | 4000ms |
| 3 | `zig build install-resource-editor` | 0 | pass | 4000ms |
| 4 | `zig build resource-editor-smoke` | 0 | pass | 5600ms |

## Deviations

None.

## Known Issues

None.

## Files Created/Modified

None.
