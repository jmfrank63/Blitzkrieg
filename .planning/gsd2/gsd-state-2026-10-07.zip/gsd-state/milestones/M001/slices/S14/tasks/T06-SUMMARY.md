---
id: T06
parent: S14
milestone: M001
key_files: []
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-06T03:18:04.030Z
blocker_discovered: false
---

# T06: Added resource-editor-auto-mip/-chc/-cgc/-mdc with measured marker pixels (click, undo, redo, save, export), wired them into CI and the sweep, and updated AGENTS.md, PARITY and the spec.

**Added resource-editor-auto-mip/-chc/-cgc/-mdc with measured marker pixels (click, undo, redo, save, export), wired them into CI and the sweep, and updated AGENTS.md, PARITY and the spec.**

## What Happened

scenario.zig has a block per kind. Each copies its fixture, opens it, clicks the image with real pointer events and measures the marker pixel by code. Each then undoes (marker gone), redoes (marker back), saves and exports (expect=exported). mip uses the final-map fixture, checks the generated map image and expects road3d.bzm and map_h.dds in the export root. chc and cgc toggle Show crosses and drag a cross. mdc measures its picture as non-background. build.zig's resource_auto_steps has the four new entries with schedules, and the concatenation compile check is kept. The steps are also in cross-platform.yml (Windows and macOS), in run-resource-sweep.sh TIERS and in AGENTS.md's Resource Editor list. 06-PARITY.md marks B-14.1-4, B-14.6, B-15.1-4, B-16.1-4 and B-17.1-4 done with evidence; B-14.5 and the mip/chc/cgc/mdc goldens stay pending on win-home. The spec records the bzm/minimap location deviation and one undo step per gesture (D030). The full sweep is left to the maintainer.

## Verification

Ran install-resource-editor and the auto steps for mip, chc, cgc, mdc and core on Linux x64. All passed. The mip log prints the measured marker pixel before and after undo (R177 G203 B68, 0 of 9 cross pixels) and after redo (R255 G255 B0, 9 of 9). macOS and Windows were not run; CI covers them.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build install-resource-editor && zig build resource-editor-auto-mip` | 0 | pass | 11500ms |
| 2 | `zig build resource-editor-auto-chc` | 0 | pass | 0ms |
| 3 | `zig build resource-editor-auto-cgc` | 0 | pass | 0ms |
| 4 | `zig build resource-editor-auto-mdc` | 0 | pass | 0ms |
| 5 | `zig build resource-editor-auto-core` | 0 | pass | 0ms |

## Deviations

None.

## Known Issues

None.

## Files Created/Modified

None.
