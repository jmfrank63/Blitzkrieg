---
estimated_steps: 3
estimated_files: 7
skills_used: []
---

# T06: resource-editor-auto-mip, -chc, -cgc, -mdc with measured frames; CI, sweep, PARITY and spec

Why: the slice demo needs auto scenarios and the parity evidence (D028 per-editor steps).
Do: (1) Scenario blocks in Sources/editor/resource_app/scenario.zig and build.zig's resource_auto_steps (four new entries with their schedules, keeping the concatenation compile check): per kind copy the fixture into {dir}, open, select the item, click the image with real pointer events at a known image point, capture and measure the marker pixel there by code, undo (marker back), redo, save, export (expect=exported); mip uses the final-map fixture and checks the generated map image is shown; chc/cgc toggle Show crosses and drag a cross; mdc shows its picture measured non-background. Each step well under 3 minutes. (2) Add the steps to .github/workflows/cross-platform.yml where the other resource-editor-auto-* run, to tools/zig/run-resource-sweep.sh TIERS, and to AGENTS.md's Resource Editor list. (3) .planning/phases/06-resource-editor-portable-port/06-PARITY.md: B-14.1-4, B-14.6, B-15.1-4, B-16.1-4, B-17.1-4 done with evidence (test names, auto steps, measured values); B-14.5 and the mip/chc/cgc/mdc goldens 'pending win-home'; note the ported MFC validation quirks. (4) docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md: the bzm/minimap location deviation and one-undo-per-gesture (D030). Full sweep left to the maintainer; record the tiers run.
Done when: verify exits 0 and git status shows nothing the task touched uncommitted.

## Inputs

- `Sources/editor/resource_app/scenario.zig`
- `Sources/editor/resource_app/docks_check.zig`
- `Sources/editor/resource_app/image_logic.zig`
- `build.zig`
- `.github/workflows/cross-platform.yml`
- `tools/zig/run-resource-sweep.sh`
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`

## Expected Output

- `Sources/editor/resource_app/scenario.zig`
- `build.zig`
- `.github/workflows/cross-platform.yml`
- `tools/zig/run-resource-sweep.sh`
- `AGENTS.md`
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`

## Verification

zig build install-resource-editor && zig build resource-editor-auto-mip && zig build resource-editor-auto-chc && zig build resource-editor-auto-cgc && zig build resource-editor-auto-mdc && zig build resource-editor-auto-core

## Observability Impact

Each auto step prints the measured marker pixel before and after undo and fails naming the frame and position.
