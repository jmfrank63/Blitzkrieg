---
estimated_steps: 3
estimated_files: 10
skills_used: []
---

# T02: Campaign and Chapter exporters and importers

Why: B-15.3/B-15.4 and B-16.3/B-16.4. CampaignFrm.cpp (FillRPGStats ~L60-100, ExportFrameData ~L250-290) and ChapterFrm.cpp (~L70-110, ~L300-340) share a shape: texts with szPrefix (the szAddDir + szPrevExportFileName export-relative rule), the map image via ComposeImageToTexture, mapImageRect = GetImageSize, crosses (chapters; missions then place holders) with their positions, chapter .lua copies.
Do: (1) items/campaign/campaign_export.{h,cpp} and items/chapter/chapter_export.{h,cpp}, line-for-line ports using T01's NImageExport::ComposeImageToTexture/GetImageSize; cross positions come from the tree values the cross channels write (resource_bridge.cpp WriteCrossesToRpg ~L1233 keeps RPG copies; read what MFC's FillRPGStats read, MEM030); register cgc and chc in exporter.cpp; add sources to build.zig. (2) Import for cgc and chc in BkResImportFromGame from shipped Data/Scenarios/Campaigns/... and Data/Scenarios/Chapters/... 1.xml (MFC GetRPGStats/LoadRPGStats). (3) Tests in resource_bridge_test.cpp: export of each fixture readable through GetGameStats<SCampaignStats>/<SChapterStats> with expected fields (prefixed texts, positions, mapImageRect, image DDS, .txt and .lua copies); moving a cross through BkResSetChapterCrosses then exporting changes vPosOnMap; import a shipped campaign and chapter then export field-equal via the comparator; missing map image fails naming it. Record in the test names which shipped samples are used.
Done when: verify exits 0 and git status is clean for touched files.

## Inputs

- `Sources/src/editor/CampaignFrm.cpp`
- `Sources/src/editor/CampaignTreeItem.cpp`
- `Sources/src/editor/ChapterFrm.cpp`
- `Sources/src/editor/ChapterTreeItem.cpp`
- `Sources/src/ResourceModel/items/campaign/campaign.h`
- `Sources/src/ResourceModel/items/chapter/chapter.h`
- `Sources/src/ResourceModel/image_export.h`
- `tools/zig/fixtures/resource_editor/cgc/project.cgc`
- `tools/zig/fixtures/resource_editor/chc/project.chc`

## Expected Output

- `Sources/src/ResourceModel/items/campaign/campaign_export.h`
- `Sources/src/ResourceModel/items/campaign/campaign_export.cpp`
- `Sources/src/ResourceModel/items/chapter/chapter_export.h`
- `Sources/src/ResourceModel/items/chapter/chapter_export.cpp`
- `Sources/src/ResourceModel/items/stats_export.h`
- `Sources/src/ResourceModel/exporter.cpp`
- `Sources/src/EditorBridge/resource_bridge.h`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `build.zig`

## Verification

zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model -Dtest-mode=run

## Observability Impact

Export failures name the missing image, text or .lua source; import names the stats file it could not read.
