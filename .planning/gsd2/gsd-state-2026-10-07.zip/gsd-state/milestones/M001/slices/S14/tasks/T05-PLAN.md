---
estimated_steps: 3
estimated_files: 6
skills_used: []
---

# T05: Image frame view: image dock, click-to-place and Show crosses drag, undoable

Why: B-14.3, B-15.2, B-16.2, B-17.2; ImageFrm.cpp/ImageView.cpp, ChapterFrm (bEditCrosses, zeroSizeX/Y hit box around pos - zeroShift, vCrossShift pick offset), CampaignFrm, MissionTreeItem SetActiveObjective/UpdateItemValue ~L251-288.
Do: (1) Sources/editor/resource_app/image_logic.zig, no ImGui (squad_logic.zig shape): View (scroll offset, image size in real pixels, screen<->image), clamp to the image rect, MFC's hit box, modes (place active item vs Show crosses drag), Overlay press/move/release/cancel committing one geometry command per gesture on release via resource_core sub_editor_tools over channels mission_objectives/chapter_crosses/campaign_crosses; which item is active comes from the tree selection (objective for mip, mission or place holder for chc, chapter for cgc). Register in test-resource-app-logic with tests against the fake bridge: click places the active objective, clamp at edges, hit test picks the right cross with the offset kept, drag then undo restores and redo reapplies, Escape cancels with no history entry. (2) Image loading keeping the real size: request BkEditorMinimapImage with max_side 2048 and record the decoded size (or add a size query if scaling happens; refuse images larger than 2048 with a message). Mission shows <projdir>/map_h.dds, calling BkResMissionMinimap (T03) on select when absent; chapter/campaign show their map image; medal shows its picture with no placement. (3) Draw in panels.zig/docks.zig as the squad overlay does: invisible button canvas, image, cross markers (active one highlighted), Show crosses toggle in the toolbar (tools_ui.zig) for chc/cgc. CRLF.
Done when: verify exits 0 and git status clean for touched files.

## Inputs

- `Sources/editor/resource_app/squad_logic.zig`
- `Sources/editor/resource_app/panels.zig`
- `Sources/editor/resource_app/docks.zig`
- `Sources/editor/resource_app/c_bridge.zig`
- `Sources/editor/resource_core/bridge.zig`
- `Sources/editor/resource_core/fake_bridge.zig`
- `Sources/src/editor/ImageFrm.cpp`
- `Sources/src/editor/ChapterFrm.cpp`
- `Sources/src/editor/CampaignFrm.cpp`
- `Sources/src/editor/MissionTreeItem.cpp`

## Expected Output

- `Sources/editor/resource_app/image_logic.zig`
- `Sources/editor/resource_app/panels.zig`
- `Sources/editor/resource_app/docks.zig`
- `Sources/editor/resource_app/tools_ui.zig`
- `Sources/editor/resource_core/sub_editor_tools.zig`
- `build.zig`

## Verification

zig build test-resource-app-logic -Dtest-mode=run && zig build test-resource-core -Dtest-mode=run && zig build install-resource-editor && zig build resource-editor-host-check && zig build resource-editor-smoke

## Observability Impact

Image load failures and minimap refusals show the bridge message in the status bar; the overlay reports gesture errors through the panel's report().
