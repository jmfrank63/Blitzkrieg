---
estimated_steps: 3
estimated_files: 9
skills_used: []
---

# T04: Mission exporter with validation, and Mission import

Why: B-14.4 and B-14.6; MissionFrm.cpp FillRPGStats (~L73-130), SaveRPGStats, ExportFrameData (~L300-400) with its validation list.
Do: (1) items/mission/mission_export.{h,cpp}: port FillRPGStats line for line (szPrefix texts, map image name, combat/exploration musics, mapImageRect = GetImageSize(<projdir>/map.tga) via T01, template/final map, setting, MOD name/version from the context, objectives with vPosOnMap, bSecret, nAnchorScriptID); the validation list with MFC's messages and its quirks (szErrorMsg overwritten, both music checks inspect the same E_MISSION_MUSICS_ITEM list) ported as behaviour and listed for PARITY; copy map_{h,c,l}.dds (via T03's createMinimap when absent), the header/subheader/desc .txt and each objective header/text .txt creating subdirs from the reference path; call convertMapToBzm when the final map's .bzm is missing; fail naming the missing callback when it is empty. Register mip in exporter.cpp; build.zig sources. (2) Import mip in BkResImportFromGame from Data/Scenarios/ScenarioMissions/... 1.xml (GetRPGStats). (3) A second tracked mip fixture (generator row in resource_editor_fixtures.zig, e.g. tools/zig/fixtures/resource_editor/mip/final-map/project.mip) with final map, texts, one combat and one exploration music and two objectives so validation passes; regenerate EXTENSIONS.md. (4) A named GOG test 'S14Mission::GogArdennen40' that reports 'pending: win-home only' when INTEX2 ardennen40/current.mip is absent (S10 brandenburgertor pattern), never a pass. (5) Tests: the validation-passing fixture exports SMissionStats readable via GetGameStats<SMissionStats> with expected fields, the DDS and .txt copies and maps/<name>.bzm; each validation failure (no header, no objective, objective without text) reports MFC's message; moving an objective via BkResSetMissionObjectives changes vPosOnMap; shipped mission import then export is field-equal (tolerated RPG/BGImage drift only).
Done when: verify exits 0 and git status clean for touched files.

## Inputs

- `Sources/src/editor/MissionFrm.cpp`
- `Sources/src/editor/MissionTreeItem.cpp`
- `Sources/src/ResourceModel/items/mission/mission.h`
- `Sources/src/ResourceModel/exporter.h`
- `Sources/src/ResourceModel/image_export.h`
- `tools/zig/fixtures/resource_editor/mip/project.mip`
- `Data/Maps/road3d.xml`

## Expected Output

- `Sources/src/ResourceModel/items/mission/mission_export.h`
- `Sources/src/ResourceModel/items/mission/mission_export.cpp`
- `Sources/src/ResourceModel/items/stats_export.h`
- `Sources/src/ResourceModel/exporter.cpp`
- `Sources/src/EditorBridge/resource_bridge.h`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `tools/zig/resource_editor_fixtures.zig`
- `tools/zig/fixtures/resource_editor/EXTENSIONS.md`
- `tools/zig/fixtures/resource_editor/mip/final-map/project.mip`
- `build.zig`

## Verification

zig build make-resource-fixtures && zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model -Dtest-mode=run

## Observability Impact

Validation failures carry MFC's message text in BkEditorLastMessage; the GOG row prints 'pending: win-home only'.
