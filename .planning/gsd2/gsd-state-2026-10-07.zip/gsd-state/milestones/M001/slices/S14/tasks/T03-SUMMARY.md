---
id: T03
parent: S14
milestone: M001
key_files:
  - Sources/src/EditorBridge/bridge.cpp
  - Sources/src/EditorBridge/map_tools.h
  - Sources/src/EditorBridge/resource_bridge.cpp
  - Sources/src/EditorBridge/resource_bridge.h
  - Sources/src/EditorBridge/resource_bridge_test.cpp
  - Sources/src/ResourceModel/exporter.h
  - Sources/editor/resource_core/bridge.zig
  - Sources/editor/resource_core/fake_bridge.zig
  - Sources/editor/resource_app/c_bridge.zig
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-06T02:52:17.174Z
blocker_discovered: false
---

# T03: Added Mission minimap creation (BkResMissionMinimap, shared CreateMissionMinimap) and map .xml-to-.bzm conversion, exposed as SExportContext callbacks createMinimap/convertMapToBzm and mirrored in the Zig bridges.

**Added Mission minimap creation (BkResMissionMinimap, shared CreateMissionMinimap) and map .xml-to-.bzm conversion, exposed as SExportContext callbacks createMinimap/convertMapToBzm and mirrored in the Zig bridges.**

## What Happened

Factored the minimap body out of BkEditorCreateMiniMapImage into a helper in the new map_tools.h/bridge.cpp (NMapTools::CreateMissionMinimap, ConvertMapToBzm) so the Map Editor keeps its own params while the Resource Editor uses MinimapCreation's single 0x200 parameter. ConvertMapToBzm reads the map xml and writes the bzm through NMapFile::Write (chunk 1 + SQuickLoadMapInfo chunk). Added BkResMissionMinimap, which writes map_{h,c,l}.dds beside the open .mip, refusing with a named reason for shipped-Data projects, no path or no final map. Added createMinimap/convertMapToBzm to SExportContext, filled for every export (bzm lands in the staging root's maps\<FinalMap>.bzm). Mirrored the call in resource_core/bridge.zig, fake_bridge.zig and resource_app/c_bridge.zig. Tests cover 512x512 DDS headers, bzm round trip with sizes equal in chunk 1 and the quick-load chunk, shipped-Data refusal and missing map. After the resume, the one failing check was a test bug: NMapFile::Read needs engine backslash paths, so the test now converts them and prints the read error on failure.

## Verification

Re-ran the full verify line after the fix; all exit 0. Map Editor smoke also passes, and test-editor-bridge covers BkEditorCreateMiniMapImage.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 65000ms |
| 2 | `zig build test-resource-core -Dtest-mode=run` | 0 | pass | 2000ms |
| 3 | `zig build test-editor-bridge -Dtest-mode=run` | 0 | pass | 539000ms |
| 4 | `zig build test-editor-core -Dtest-mode=run` | 0 | pass | 2000ms |
| 5 | `zig build map-editor-smoke` | 0 | pass | 15000ms |

## Deviations

None.

## Known Issues

None.

## Files Created/Modified

- `Sources/src/EditorBridge/bridge.cpp`
- `Sources/src/EditorBridge/map_tools.h`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge.h`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `Sources/src/ResourceModel/exporter.h`
- `Sources/editor/resource_core/bridge.zig`
- `Sources/editor/resource_core/fake_bridge.zig`
- `Sources/editor/resource_app/c_bridge.zig`
