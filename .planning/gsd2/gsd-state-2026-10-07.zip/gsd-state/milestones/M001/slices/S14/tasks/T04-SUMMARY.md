---
id: T04
parent: S14
milestone: M001
key_files:
  - Sources/src/ResourceModel/items/mission/mission_export.cpp
  - Sources/src/ResourceModel/items/mission/mission_export.h
  - Sources/src/EditorBridge/resource_bridge.cpp
  - Sources/src/EditorBridge/resource_bridge_test.cpp
  - tools/zig/resource_editor_fixtures.zig
  - tools/zig/resource_model_comparator_test.cpp
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-06T03:02:25.246Z
blocker_discovered: false
---

# T04: Added the Mission (mip) exporter with MFC's validation list, a shipped-Data Mission importer, a second passing mip fixture, and bridge tests including a field-equal shipped round trip.

**Added the Mission (mip) exporter with MFC's validation list, a shipped-Data Mission importer, a second passing mip fixture, and bridge tests including a field-equal shipped round trip.**

## What Happened

Ported CMissionFrame::FillRPGStats and ExportFrameData into items/mission/mission_export.{h,cpp}: the stats carry the prefixed texts, map image, combat/exploration musics, template/final map, setting, MOD name/version and the objectives (vPosOnMap, bSecret, nAnchorScriptID); mapImageRect comes from map.tga via NImageExport. The validation list keeps MFC's quirks (last failing message wins; both music checks read the combat list, so the exploration message is the one shown). The export copies map_{h,c,l}.dds (made through createMinimap when map_h.dds is absent), header/subheader/desc and objective .txt files (subfolders created), and calls convertMapToBzm when no maps folder has the .bzm; missing callbacks fail naming the callback. Registered mip in exporter.cpp and build.zig. BkResImportFromGame now imports mip from shipped ScenarioMissions 1.xml (MissionStatsToTree; MFC left objective headers empty, the port fills the header slot). Added the mip/final-map fixture (generator row, texts, picture) and regenerated EXTENSIONS.md; the chc context.xml and script.lua fixtures T02 left untracked are now present for the commit. Tests: S14MissionExport covers the passing fixture (stats read by the engine, DDS, txt, .bzm), a moved objective changing vPosOnMap, four validation refusals with MFC messages, the plain fixture refused, and ussr/finland import then export field-equal (MODName/MODVersion/ImageRect drift tolerated). S14Mission::GogArdennen40 prints 'pending: win-home only'. Updated two older expectations that said mip was unported (bridge export loop and comparator test).

## Verification

make-resource-fixtures, test-resource-bridge and test-resource-model all exit 0 on Linux x64. No macOS/Windows result was seen. Goldens and the GOG ardennen40 row stay pending on win-home. Full sweep left to the maintainer.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build make-resource-fixtures` | 0 | pass | 20000ms |
| 2 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 120000ms |
| 3 | `zig build test-resource-model -Dtest-mode=run` | 0 | pass | 21000ms |

## Deviations

None.

## Known Issues

None.

## Files Created/Modified

- `Sources/src/ResourceModel/items/mission/mission_export.cpp`
- `Sources/src/ResourceModel/items/mission/mission_export.h`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `tools/zig/resource_editor_fixtures.zig`
- `tools/zig/resource_model_comparator_test.cpp`
