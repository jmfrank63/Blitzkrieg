# S14 Research: Mission, Chapter, Campaign, Medal sub-editors (image-frame)

Scouted from the repo only; nothing was built or run. Linux x64 is the local target; macOS and Windows are CI. GOG files are never committed (test name only).

## What already exists (do not rebuild)

Model (`Sources/src/ResourceModel/items/{mission,chapter,campaign,medal}/*.{h,cpp}`):
- All four item families are ported at S03 level: tree item classes, properties, `InitDefaultValues`, factory, XML load and save. They are built into the bridge (`build.zig` ~L4098-4104). Mission has Root, CommonProps, Musics, MusicProps, Objectives, ObjectiveProps.
- The model stops at the tree. There is NO exporter for any kind: `NResourceModel::RegisterExporter` (`exporter.h`) is only called by tests (`resource_bridge_test.cpp` ~L1727 with a fake "mdc" exporter). `BkResExport` answers "not ported" for kinds without one. S14 must write 4 exporters (mip, chc, cgc, mdc) and register them. Check whether S06 (also unstarted) lands a first real exporter and shared helper first; if not, S14 owns the registration pattern for itself.
- MFC `SaveRPGStats`/`FillRPGStats`/`LoadRPGStats` per frame (project RPG copy) is only partially modelled in the bridge (see geometry below).

Bridge (`Sources/src/EditorBridge/resource_bridge.{h,cpp}`):
- Geometry channels for exactly this slice exist and are tested: `BkResGet/SetMissionObjectives` (channel 11), `BkResGet/SetChapterCrosses` (12), `BkResGet/SetCampaignCrosses` (13), one `BkResPoint2` per child, in child order. They write the child position values; save also writes `RPG/Objectives/item[i]/PosOnMap` etc. (`WriteCrossesToRpg`, resource_bridge.cpp ~L1233). Tested by `CrossesInMfcLayout` in `resource_bridge_test.cpp` ~L1215-1255.
- Bridge preview (`kPreviewKinds`, resource_bridge.cpp ~L3538) has only spt, unt, msh, pcp, eff. The spec says 2D editors use no engine scene: images shown as ImGui textures, markers as overlays. So S14 needs NO new preview kind, only an image-load path.
- Image decoding for a texture already exists: `BkEditorMinimapImage` (bridge.h ~L673, used by `docks.zig` `textureFor`...: reads `<base>.tga` / `_h.dds` through the engine decoders, RGBA8, scaled to max_side 8..2048). Fine for display; BUT marker coordinates are in image pixels of the unscaled image (MFC clamps to `vImageSize` and adds scroll pos), so the app must keep the real image size (out_width/out_height are the scaled size; either request max_side 2048 or add a size-only call).
- Map minimap: `BkEditorCreateMiniMapImage` (bridge.h ~L688, bridge.cpp ~L2215) already wraps `CMapInfo::CreateMiniMapImage` but with the Map Editor's fixed params (512 large + 256 normal, refuses paths inside the installation's Data). MFC `CMinimapCreation::Create1Minimap` (`Sources/src/editor/MinimapCreation.cpp`, 71 lines) is different: it picks .xml vs .bzm by mtime, skips if the `_h.dds` is newer, reads either (xml via `CreateDataTreeSaver`+`AddTypedSuper`; bzm via `CreateStructureSaver` chunk 1), `UnpackFrameIndices`, then one `SRMImageCreateParameter(name, 0x200x0x200, true, false, INTERMISSION_IMAGE_BRIGHTNESS/CONSTRAST/GAMMA)` and `CreateMiniMapImage`. Reuse the body of bridge.cpp ~L2215-2290; add a `BkResMinimapCreate` (or generalise) rather than copying.
- `.xml` to `.bzm`: MFC `CMissionFrame::ExportFrameData` (MissionFrm.cpp ~L350-380) reads `Data/maps/<FinalMap>.xml` through `CreateDataTreeSaver`/`AddTypedSuper(&mapInfo)` when `<map>.bzm` is missing, then writes `.bzm` with `CreateStructureSaver(WRITE)`: chunk 1 = mapInfo, chunk `RMGC_QUICK_LOAD_MAP_INFO_CHUNK_NUMBER` = `SQuickLoadMapInfo::FillFromMapInfo`. The Map Editor bridge (`session_rmg.cpp` ~L1589-1610) already writes that same pair of chunks for templates; reuse or factor out of there. Note MFC writes the bzm next to the source in the editor data dir (the Data tree), not the export dir; decide where the port writes it (staging root like other exports, with the shipped-Data rule from AGENTS.md: never write into shipped `Data/`). This is a deliberate deviation to record in the spec and PARITY B-14.4.

Zig:
- `Sources/editor/resource_core/{bridge,document,root,history,fake_bridge}.zig` already know the three channels (`GeometryChannel.mission_objectives/.chapter_crosses/.campaign_crosses`, points2 family, `root.zig` ~L562 geometry-delete handling). `Sources/editor/resource_app/c_bridge.zig` ~L437 maps them to the C calls.
- NOT present in the app: any geometry/click-to-place UI at all, and any image/overlay viewport. `grep` shows no consumer of geometry channels in `tools_ui.zig`/`panels.zig`/`docks.zig`. S09 (grid tools), S10 (building), S11 (bridge marks) and S06 (squad formation) each also need an overlay canvas. Biggest planning decision: the shared canvas (image view with pan, scroll, hit test, drag, marker drawing, clamp to image) should be a small shared module in `resource_app` that S14 creates and others reuse, and its pure logic (hit test, clamp, coordinate transform, drag state machine) must live in a `*_logic.zig` so it is covered by `test-resource-app-logic`. If S06 lands first, consume its overlay seam instead.
- `panels_logic.zig` already lists the 4 kinds in the Editors menu; `tools_logic.zig` has default folders (`scenarios/`, `scenarios/campaigns/`, `medals/`).

## MFC behaviour to port (sources)

Common: `ImageFrm.cpp` (181 lines: `LoadImageTexture` calls `ComposeImageToTexture` into the editor temp dir, falls back to `pTM->GetTexture`; scroll bars when image larger than the 800x600 game window; `bShowKrest` cross texture; `GFXDraw`), `ImageView.cpp`.
- `ComposeImageToTexture` and `GetImageSize` are in `Sources/src/editor/BuildCompose.cpp` (not in ResourceModel/EditorBridge yet). It pads to next pow2 (white, alpha 0 fill), applies picture options (gamma.cfg, `bCorrect`), writes DXT3 (chapter/campaign/medal: `m_nCompressedFormat = GFXPF_DXT3`, `m_nLowFormat = ARGB4444`). It is needed by all four exporters (image output) and by `SChapterStats.mapImageRect = GetImageSize(...)`. Port it once into ResourceModel (check S06/S07 for an existing port first; picture export is shared by Weapon etc.). `dxt_gate.h` and `spike/legacy_dxt.*` already hold the legacy encoder and measured tolerance, so the DXT golden comparison path exists.

Mission (`MissionFrm.cpp` 15 KB, `MissionTreeItem.cpp` 368 lines):
- Selecting a mission with a Final map generates `map_h.dds` beside the project (if absent) via `Create1Minimap("Maps\\<FinalMap>", <projdir>/map)` and shows it. Click on the image sets the active objective's position (`SetActiveObjective`, `UpdateItemValue` ~L251-288 in MissionTreeItem).
- `ExportFrameData`: validation list (header, subheader, description text; final map OR template map plus setting; at least one combat and one exploration music; at least one objective, each with header and text) with message box, then `SaveRPGStats` (`SMissionStats` under `RPG`), copy `map_h.dds`, `map_c.dds`, `map_l.dds`, copy the three `.txt` files (header/subheader/desc) plus each objective header/text `.txt` (creating subdirs from the reference path), and the xml-to-bzm conversion above. Note MFC validation code overwrites `szErrorMsg` and the combat/exploration music checks both inspect the same `E_MISSION_MUSICS_ITEM` list (a MFC bug); port as behaviour, record in PARITY.
- `FillRPGStats` ~L73-190 and `GetRPGStats`: objective strings are prefixed by `szPrefix` (export-relative dir, the `szAddDir + szPrevExportFileName` rule), `vPosOnMap`, `bSecret`, `nAnchorScriptID`.
- GOG test project path: `INTEX2\data\scenarios\Custom\Missions\ardennen40\current.mip` (Data/Editor/TestProjects/16_Mission/README.md says external-project-reference).

Chapter (`ChapterFrm.cpp`): Show crosses mode (`bEditCrosses`): when on, pressing near a cross (hit box `zeroSizeX/Y` around `pos - zeroShift`) picks it and dragging moves it with the pick offset `vCrossShift`; when off, a click puts the active mission or placeholder at the click point. Positions clamp to the image rectangle, scroll offset added. Export: texts, map image via `ComposeImageToTexture`, `.lua` copies, `SChapterStats` with `mapImageRect`. Mission list and place holders are two separate cross lists (channel 12 carries both: missions then places).
Campaign (`CampaignFrm.cpp`, `CampaignTreeItem.cpp`): same pattern for chapters; export copies texts, image, `SCampaignStats`.
Medal (`MedalFrm.cpp` 255 lines): no placement; Picture, Texture, Name, Desc; export: `SaveRPGStats`, `ComposeImageToTexture(<Texture>.tga)` into the result dir, copy name and description `.txt`, plus a small preview. Simplest of the four, good first exporter.

## Fixtures and goldens

- Repo fixtures exist: `tools/zig/fixtures/resource_editor/{mip,chc,cgc,mdc}/project.*` with `art-16x16.tga`, and `golden/README.md` only: goldens are pending on win-home (`tools/zig/win-home/export-goldens.ps1 -Extensions mip,chc,cgc,mdc`; MFC editor batch mode). `test-resource-model-comparator` reports "GOLDEN <ext> pending". The comparator already handles `EExportKind::MISSION/CHAPTER/CAMPAIGN/MEDAL` (`SMissionStats`, etc. via `GetGameStats<>`; one tolerated drift: `RPG/BGImage` for 2002 missions).
- Gap: `mip/project.mip` has an empty "Final map" and empty "Settings file", so the fixture cannot exercise MinimapCreation or xml-to-bzm. `chc` and `cgc` use Map image `map` but the fixture folder has only `art-16x16.tga`, not `map.tga`; check the fixture generator (`tools/zig/resource_editor_fixtures.zig`) and `EXTENSIONS.md` (generated, do not edit by hand, run `zig build make-resource-fixtures`). S14 likely needs a second mip fixture (or a generator change) with a tiny tracked map `.xml` (plus a minimal reference lists root) and the texts the validation demands; the generator rows must be regenerated and the win-home goldens re-made by the maintainer ("golden left to win-home" is an acceptable task completion, never claimed done).
- The task can prove parity locally without MFC output by (a) running the new exporter and reading the result back through the comparator readers (self-consistency, field-equal against hand-derived expected stats) and (b) the game reading it: `resource-editor-game-reads-it` is S16, but a `test-resource-bridge` check that reads the mission through `GetGameStats<SMissionStats>` is feasible.
- Round trip import: `BkResImportFromGame(kind, path)` exists (resource_bridge.h ~L452); each kind needs its importer (MFC `LoadRPGStats` from `RPG`): verify which kinds are wired. Shipped sample sources: `Data/scenarios/...` (shipped Data is read only). `Data/Editor/TestProjects/{16..18,21}_*` are README-only references, no local project files.
- GOG row: `INTEX2 ardennen40/current.mip` exports equal to golden on win-home. Register as a named test that reports "pending: win-home only" when the path is absent (same pattern as S10 `brandenburgertor`); never claim it passed.

## Natural seams for tasks

1. ResourceModel: port `ComposeImageToTexture`/`GetImageSize` (or consume S06's) with unit tests (pow2 pad, DXT3 output, dds size, gamma.cfg correct flag), reusing `dxt_gate`/`legacy_dxt`.
2. ResourceModel exporters, one per kind, each with `FillRPGStats` port, validation, copies; medal first (no map code), then campaign, chapter, mission. Register in the bridge init; extend `test-resource-bridge` (BkResExport per fixture, read back with comparator readers).
3. Minimap + bzm: a bridge function wrapping Create1Minimap semantics and xml-to-bzm (factor from bridge.cpp ~L2215 and session_rmg.cpp ~L1589); test-resource-bridge asserts the produced `.bzm` loads through `CreateStructureSaver` and has the `QuickLoadMapInfo` chunk, and that the minimap files exist with the expected size (512x512 `_h/_c/_l`), measured by code.
4. Core/app: image view + marker overlay + drag/place tool as undoable geometry commands (existing channel commands; one history entry per drag, not per mouse move: coalesce or commit on mouse up, MFC set the position on every move; record the choice). Pure logic in `*_logic.zig` (hit test with zero-shift box, clamp, scroll offsets, tool state, objective activation) + tests; ImGui drawing in `docks.zig`/`tools_ui.zig` style.
5. Scenario + CI: extend `scenario.zig` (BK_EDITOR_AUTO) with open mip fixture, place objective by click, undo, save, export; check capture frame measured (marker pixel at the expected screen position) like `docks_check.zig` does; tiers `resource-editor-auto` and test-resource-app-logic.
6. Docs: update 06-PARITY.md rows B-14..B-17 (statuses and evidence), spec note for bzm output location.

## Risks (highest first)

1. Exporters are net-new C++ with MFC semantics that were never captured: float/int formatting of `PosOnMap`, `mapImageRect` from `GetImageSize` (it returns a rect of used/padded sizes; see `BuildCompose.cpp`), the `szPrefix`/`szAddDir` path logic and subdir creation, and DXT3 encoder equality. Goldens cannot be produced here, so correctness rests on the comparator reading both sides; keep exporter code a line-for-line port of the MFC as S03 did for items.
2. The bzm/minimap path needs a real map: the repo fixtures lack one; the minimap uses engine terrain/textures, so the test needs the staged game data (like `BkEditorCreateMiniMapImage`'s test in the map bridge test). Pick a tracked small map from `Data/maps` or `tools/zig/fixtures`, copy into `zig-out/local-test`.
3. No overlay/click-canvas exists in the app; if S06/S09 are developed in parallel (they are independent of S05 only), there is a merge-risk and divergence risk. Land the shared canvas module first or coordinate by file ownership.
4. Coordinates: marker positions are image pixels, but `BkEditorMinimapImage` may scale down (max_side). Keep image size explicit.
5. Without an RPG copy MFC keeps only whole parts of crosses across reopen (documented in resource_bridge.h); the app UI must not assume sub-pixel fidelity.
6. Linux GUI tiers need a video device; under the gsd_exec sandbox `SdlInitFailed: No available video device` (S05 summary), so run `resource-editor-*` steps in the foreground shell.

## First proof

Medal exporter end to end on `tools/zig/fixtures/resource_editor/mdc/project.mdc`: BkResExport -> staging dir with `SMedalStats` XML, `<texture>` DDS (DXT3 padded) and copied `.txt`, read back through `NResourceModel::Compare` with the medal kind, and the same exporter output equal to itself. That retires ComposeImageToTexture and the exporter registration pattern before the heavier mission work. Second proof: click-to-place a mission objective via the existing channel through `test-resource-core`/fake bridge undo/redo, then the real overlay.

## Verification commands (all foreground, each well under 10 min)

- `zig build test-resource-core`
- `zig build test-resource-app-logic`
- `zig build test-resource-bridge`
- `zig build test-resource-model -Dtest-mode=run` (comparator: golden pending lines are expected until win-home goldens exist; do not count pending as pass)
- `zig build make-resource-fixtures` then check the generated `EXTENSIONS.md` diff is only the intended rows
- `zig build install-resource-editor resource-editor-host-check`, then `resource-editor-smoke`, `resource-editor-auto` (one step at a time)
- Map Editor tiers if shared kit or bridge code (bridge.cpp) is touched: `test-editor-bridge`, `test-editor-core`, `map-editor-smoke`.
- Full sweep (`tools/zig/run-resource-sweep.sh`, about 27 minutes) left to the maintainer; record that plus the tiers run. Win-home only: MFC golden regeneration for mip, chc, cgc, mdc and the GOG `ardennen40` row.

## Notes for the planner

- CRLF line endings on all new files; conventional commits `feat(resource-editor): ...`; no push.
- Tests may use only tracked data; copy into `zig-out/local-test/...`; resolve Data paths case-insensitively with the `DataFile` helper.
- PARITY rows to move from `todo`: B-14.1-6, B-15.1-4, B-16.1-4, B-17.1-4 (06-PARITY.md ~L239-270). B-14.5 stays "pending win-home".
