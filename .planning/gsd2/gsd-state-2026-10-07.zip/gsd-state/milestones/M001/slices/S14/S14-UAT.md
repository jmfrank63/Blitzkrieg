# S14: S14 — UAT

**Milestone:** M001
**Written:** 2026-10-06T03:20:20.647Z

# S14 UAT

**UAT Type:** automated tiers plus optional hand try on Linux

## Preconditions
- Linux x64 build: `zig build install-resource-editor`.

## Steps
1. Run `zig build resource-editor-auto-mip`. Expected: `auto PASS`, with measured frames under zig-out/local-test/resource_editor/auto-mip.
2. Run `-chc`, `-cgc`, `-mdc` in turn. Expected: each ends in `auto PASS`.
3. Open a Mission fixture and click the image to place an objective and a cross, then undo and redo. Expected: one undo step per gesture.
4. Use minimap creation and the .xml to .bzm conversion on a Mission. Expected: minimap image produced and the .bzm is written.

## Edge cases
- Undoing a placement removes it fully; the export validation list rejects invalid missions.

## Not Proven By This UAT
- B-14.5 and the mip/chc/cgc/mdc goldens, including the GOG `INTEX2 ardennen40/current.mip`, stay pending on win-home.
- macOS and Windows results (CI after push).
- The full resource sweep (left to the maintainer).
