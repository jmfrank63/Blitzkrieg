---
id: T05
parent: S14
milestone: M001
key_files: []
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-06T03:07:15.753Z
blocker_discovered: false
---

# T05: Added the image frame: image_logic.zig (click-to-place and Show crosses drag over mission/chapter/campaign position channels, one undo step per gesture) and an Image window in docks.zig that shows the picture at real size with crosses and a Show crosses toggle.

**Added the image frame: image_logic.zig (click-to-place and Show crosses drag over mission/chapter/campaign position channels, one undo step per gesture) and an Image window in docks.zig that shows the picture at real size with crosses and a Show crosses toggle.**

## What Happened

Added Sources/editor/resource_app/image_logic.zig, ImGui-free in the squad_logic shape. It holds the Kind classification, the picture source path (Mission map.xml, which BkEditorMinimapImage resolves to map_h.dds; Chapter prop 3, Campaign and Medal prop 2, as <name>.tga in the project folder), the active-item resolution from the tree selection, MFC's hit box (32 wide starting 15.4 before the position), the View with clamping to the picture, and an Overlay with press/move/release/cancel. Place mode puts the active objective, mission, place holder or chapter at the clamped click. Show crosses picks the first cross under the cursor (missions before place holders, as FindActiveCross does), keeps the grab offset, and drags it. Each gesture commits one geometry command via sub_editor_tools.commit on release, and Escape or a mode switch restores the position with no history entry. To reuse the existing live-write/undo machinery, FormationDrag in sub_editor_tools.zig gained a channel field and beginChannel, and item_type gained the mission, chapter, campaign and medal common-props, list and props classes. pictures_cache.upload and releaseTexture were made public. docks.zig gained an ImageFrame state and a drawImageFrame window: it decodes the picture once per path through BkEditorMinimapImage at max_side 2048, refuses a picture whose side reaches 2048 (it may have been scaled, so positions would not be real pixels), and calls BkResMissionMinimap once for a Mission whose map_h.dds is missing. It draws a scrolling invisible-button canvas with the image as a GPU texture and crosses with the active one highlighted, a Show crosses checkbox for chc and cgc, and a Reload button, with load failures, minimap refusals and gesture errors shown in the window note. Twelve new logic tests run against the fake bridge: active item, click places and undo/redo, edge clamp and live follow, no active item, hit box edges and offset, cross drag as one step with undo/redo, empty ground and mission-before-place order, no-op drag, Escape, mode switch, medal, real-size rule, source path.

## Verification

test-resource-app-logic and test-resource-core run green, install-resource-editor builds, and resource-editor-host-check and resource-editor-smoke pass on Linux. The Image window itself was not driven in the real app here; the per-kind resource-editor-auto steps with measured frames belong to the slice's later task. Only Linux was verified; macOS and Windows are left to CI.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-app-logic -Dtest-mode=run` | 0 | pass | 3000ms |
| 2 | `zig build test-resource-core -Dtest-mode=run` | 0 | pass | 3000ms |
| 3 | `zig build install-resource-editor` | 0 | pass | 60000ms |
| 4 | `zig build resource-editor-host-check` | 0 | pass | 6000ms |
| 5 | `zig build resource-editor-smoke` | 0 | pass | 5000ms |

## Deviations

None.

## Known Issues

None.

## Files Created/Modified

None.
