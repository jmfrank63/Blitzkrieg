---
id: T02
parent: S14
milestone: M001
key_files: []
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-06T02:34:03.516Z
blocker_discovered: false
---

# T02: Added Chapter (chc) and Campaign (cgc) exporters and shipped-Data importers, ported from ChapterFrm/CampaignFrm, with bridge tests including field-equal round trips of shipped samples.

**Added Chapter (chc) and Campaign (cgc) exporters and shipped-Data importers, ported from ChapterFrm/CampaignFrm, with bridge tests including field-equal round trips of shipped samples.**

## What Happened

Added items/chapter/chapter_export.{h,cpp} and items/campaign/campaign_export.{h,cpp} as line-for-line ports of the MFC frames' ExportFrameData: export-prefixed texts, picture, script and music, mapImageRect via NImageExport::GetImageSize, the mission, place-holder and chapter crosses read from the tree values the cross channels write, plus the .txt/.lua copies and map DDS packs. Both are registered in exporter.cpp and added to build.zig. BkResImportFromGame now imports kinds 17 (chc) and 18 (cgc) from shipped Data/Scenarios/Chapters/.../1.xml and Data/Scenarios/Campaigns/.../german.xml, stripping the export prefix so a re-export writes it once. Fixtures cgc/chc were extended with texts and a map picture. Resumed after an interruption: the earlier session had not completed. Fixed GetChildren() compile errors in both exporters, replaced the two stale 'not ported yet' assertions for chc/cgc, and added the S14ChapterCampaign tests: fixture export read back by the engine reader (prefixed texts, ImageRect, DDS packs, copied texts), a moved cross changing the exported vPosOnMap, a missing picture failing the export and naming it, and shipped German/Kharkov42 chapter and German campaign imports exported stats-only and compared field-equal through the comparator with Data untouched.

## Verification

zig build test-resource-bridge -Dtest-mode=run and zig build test-resource-model -Dtest-mode=run both exit 0 in this session. Shipped round trips: chc German/Kharkov42 46 fields, 0 differences; cgc German 134 fields, 0 differences (ImageRect excluded for chapter because the shipped DDS has no source picture). New files are CRLF. macOS and Windows were not run.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 75000ms |
| 2 | `zig build test-resource-model -Dtest-mode=run` | 0 | pass | 21000ms |

## Deviations

None.

## Known Issues

None.

## Files Created/Modified

None.
