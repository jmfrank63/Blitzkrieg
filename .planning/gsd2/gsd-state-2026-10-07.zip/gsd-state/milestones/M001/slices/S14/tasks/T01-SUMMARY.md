---
id: T01
parent: S14
milestone: M001
key_files:
  - Sources/src/ResourceModel/image_export.cpp
  - Sources/src/ResourceModel/items/medal/medal_export.cpp
  - Sources/src/EditorBridge/resource_bridge.cpp
  - Sources/src/EditorBridge/resource_bridge_test.cpp
  - tools/zig/resource_editor_fixtures.zig
  - tools/zig/resource_model_comparator_test.cpp
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-06T02:21:45.383Z
blocker_discovered: false
---

# T01: Ported ComposeImageToTexture/GetImageSize into NImageExport, added the Medal (mdc) exporter and shipped-Data importer, extended the mdc/chc/cgc/mip fixtures with a 20x12 picture and texts, and covered it with bridge tests.

**Ported ComposeImageToTexture/GetImageSize into NImageExport, added the Medal (mdc) exporter and shipped-Data importer, extended the mdc/chc/cgc/mip fixtures with a 20x12 picture and texts, and covered it with bridge tests.**

## What Happened

NImageExport gained PadToPowerOfTwo, ComposeImageToTexture (padding white, alpha 0, optional gamma/compress, formats per frame) and GetImageSize (size over padded size, (size+0.5)/pow2). items/medal/medal_export.{h,cpp} ports CMedalFrame FillRPGStats/SaveRPGStats/ExportFrameData: SMedalStats under RPG, medal picture packed to _c(DXT5)/_l(ARGB1555)/_h.dds, name/description .txt copied. Picture is checked before anything is written; a missing texture fails naming the file, a missing .txt is a warning, stats-only keeps a zero ImageRect with a warning if the picture is absent. ExportMedal is registered in exporter.cpp and in build.zig. BkResImportFromGame handles kind mdc (MFC's GetRPGStats is commented out, so the port reads name/description/texture back and keeps the path below medals\ as export_file_name). Fixture generator writes medal.tga/map.tga (20x12) and the referenced .txt files for mdc/chc/cgc/mip. Tests: new S14Medal in resource_bridge_test.cpp (export, ImageRect, DDS size and alpha/white padding, stats-only, missing picture failure, shipped German/as1 import round trip field-equal via CompareStats MEDAL with a 256x256 4.tga supplied because shipped Data keeps only DDS). The comparator test's 'mdc has no exporter' assertion now checks mip instead and asserts mdc is registered.

## Verification

make-resource-fixtures, test-resource-bridge and test-resource-model all exit 0 on Linux x64. Round trip printed 'ROUNDTRIP mdc German/as1: 14 fields compared, 0 differences'. macOS/Windows not run.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build make-resource-fixtures` | 0 | pass | 60000ms |
| 2 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 240000ms |
| 3 | `zig build test-resource-model -Dtest-mode=run` | 0 | pass | 120000ms |

## Deviations

EXTENSIONS.md needed no regeneration (unchanged). Shipped medal round trip tolerates the 6-digit ImageRect x2/y2 via NearFloat and needs a supplied 4.tga since Data holds only DDS. Tests re-register the real mdc exporter in S14Medal because earlier tiers unregister the slot.

## Known Issues

None.

## Files Created/Modified

- `Sources/src/ResourceModel/image_export.cpp`
- `Sources/src/ResourceModel/items/medal/medal_export.cpp`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `tools/zig/resource_editor_fixtures.zig`
- `tools/zig/resource_model_comparator_test.cpp`
