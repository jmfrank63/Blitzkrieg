---
estimated_steps: 3
estimated_files: 11
skills_used: []
---

# T01: ComposeImageToTexture/GetImageSize port and the Medal exporter and importer

Why: all four image-frame exporters need MFC's ComposeImageToTexture (Sources/src/editor/BuildCompose.cpp:235-301) and GetImageSize (:302-323); Medal (MedalFrm.cpp, 255 lines) is the simplest kind and the first end-to-end proof (D030).
Do: (1) Port both functions line for line into NImageExport (Sources/src/ResourceModel/image_export.{h,cpp}): next-pow2 padding with white alpha-0 fill, picture options via ReadGammaConfig with MFC's bCorrect flag, DXT3 compressed + ARGB4444 low format (reuse SaveCompressedTexture's overloads), GetImageSize's rect of used size over padded size; outputs relative to the staging root. (2) Add items/medal/medal_export.{h,cpp}: port CMedalFrame FillRPGStats/SaveRPGStats/ExportFrameData (SMedalStats under RPG through the engine serializer as stats_export does, ComposeImageToTexture of <Texture>.tga, copy name and description .txt, the small preview MFC writes); declare ExportMedal in items/stats_export.h and add {"mdc", &ExportMedal} to exporter.cpp's table; add the new .cpp to build.zig's bridge sources. (3) Import: port CMedalFrame::GetRPGStats into BkResImportFromGame for kind mdc (resource_bridge.cpp ~L6601, the bPorted list and the switch) reading a shipped Data/Medals/<side>/<name>/1.xml; update the header comment listing ported kinds. (4) Fixture: the mdc/chc/cgc/mip projects reference 'medal'/'map' pictures the folder lacks; extend tools/zig/resource_editor_fixtures.zig so each of those folders gets the tga its project names (small, non-pow2 e.g. 20x12, so padding is exercised) and the .txt files they reference, run `zig build make-resource-fixtures`, commit the regenerated EXTENSIONS.md (only the intended rows change). (5) Tests in Sources/src/EditorBridge/resource_bridge_test.cpp: compose pads 20x12 to 32x16 with alpha 0 outside, rect equals (0,0,20/32,12/16) or what the MFC code computes; BkResExport on a copy of mdc/project.mdc writes the stats readable by GetGameStats<SMedalStats> with the expected fields, the DDS files and the .txt copies; import Data/Medals/German/as1 then export is field-equal through NResourceModel's comparator; a missing texture fails naming the file. CRLF on new files.
Done when: verify exits 0 and git status shows nothing the task touched uncommitted.

## Inputs

- `Sources/src/editor/BuildCompose.cpp`
- `Sources/src/editor/MedalFrm.cpp`
- `Sources/src/editor/MedalTreeItem.cpp`
- `Sources/src/ResourceModel/items/medal/medal.h`
- `Sources/src/ResourceModel/image_export.h`
- `Sources/src/ResourceModel/exporter.h`
- `Sources/src/ResourceModel/comparator.h`
- `tools/zig/fixtures/resource_editor/mdc/project.mdc`
- `Data/Medals/German/as1/1.xml`

## Expected Output

- `Sources/src/ResourceModel/image_export.h`
- `Sources/src/ResourceModel/image_export.cpp`
- `Sources/src/ResourceModel/items/medal/medal_export.h`
- `Sources/src/ResourceModel/items/medal/medal_export.cpp`
- `Sources/src/ResourceModel/items/stats_export.h`
- `Sources/src/ResourceModel/exporter.cpp`
- `Sources/src/EditorBridge/resource_bridge.h`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `tools/zig/resource_editor_fixtures.zig`
- `tools/zig/fixtures/resource_editor/EXTENSIONS.md`
- `build.zig`

## Verification

zig build make-resource-fixtures && zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model -Dtest-mode=run

## Observability Impact

Medal export failures name the missing texture or text file; import refusal names the unreadable 1.xml.
