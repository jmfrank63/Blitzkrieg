---
id: S14
parent: M001
milestone: M001
provides:
  - (none)
requires:
  []
affects:
  []
key_files: []
key_decisions: []
patterns_established:
  - (none)
observability_surfaces:
  - none
drill_down_paths:
  []
duration: ""
verification_result: passed
completed_at: 2026-10-06T03:20:20.645Z
blocker_discovered: false
---

# S14: S14

**Mission, Chapter, Campaign and Medal editors: click-to-place objectives and crosses, minimap creation, .xml to .bzm conversion, exporters, and measured auto scenarios, with CI, sweep, parity and spec wiring.**

## What Happened

S14 added the four mission-side sub-editors (mip, chc, cgc, mdc) to the portable Resource Editor. The Mission editor gained an image frame (image_logic.zig) for click-to-place objectives and crosses, Mission minimap creation (BkResMissionMinimap, shared CreateMinimap), and .xml to .bzm map conversion. Exporters for Mission (with MFC's validation list), Chapter and Campaign were added with golden/shipped-Data checks. T06 added resource-editor-auto-mip/-chc/-cgc/-mdc with measured frames and wired the steps into build.zig, the Windows and macOS CI jobs, tools/zig/run-resource-sweep.sh and AGENTS.md. 06-PARITY.md marks B-14.1-4, B-14.6, B-15.1-4, B-16.1-4 and B-17.1-4 done with evidence; the spec records the bzm/minimap location deviation and one undo step per gesture (D030).

## Verification

Re-checked at close: all six task summaries (T01-T06) exist, git status is clean, and the logs of the T06 runs of resource-editor-auto-chc (49 actions), -cgc (46), -mdc (15) and -core (38) all end in 'auto PASS'; resource-editor-auto-mip was run in T06 after install-resource-editor. The full sweep (run-resource-sweep.sh) is left to the maintainer. No macOS or Windows result was observed.

## Requirements Advanced

None.

## Requirements Validated

None.

## New Requirements Surfaced

None.

## Requirements Invalidated or Re-scoped

None.

## Operational Readiness

None.

## Deviations

None.

## Known Limitations

B-14.5 and the mip/chc/cgc/mdc MFC goldens are pending on win-home. macOS and Windows not verified locally.

## Follow-ups

None.

## Files Created/Modified

None.
