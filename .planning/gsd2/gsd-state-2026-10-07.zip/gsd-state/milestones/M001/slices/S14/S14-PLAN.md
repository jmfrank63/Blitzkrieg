# S14: Mission, Chapter, Campaign, Medal sub-editors (image-frame)

**Goal:** The Mission (.mip), Chapter (.chc), Campaign (.cgc) and Medal (.mdc) sub-editors work end to end, ported from MissionFrm/ChapterFrm/CampaignFrm/MedalFrm, ImageFrm, BuildCompose and MinimapCreation (D030): real exporters write SMissionStats/SChapterStats/SCampaignStats/SMedalStats with copied .txt/.lua, the ComposeImageToTexture image and the map DDS; Mission generates its map image through the engine minimap and converts the final map .xml to .bzm into the export root (never into shipped Data); each kind imports from shipped Data and round-trips field-equal; the app shows each image as an ImGui texture with objectives and crosses placed by click and dragged in Show crosses mode, one undo step per gesture; one resource-editor-auto step per kind with measured frames. Goldens and the GOG ardennen40 row stay pending on win-home.
**Demo:** Place objectives and crosses by clicking the image; MinimapCreation reproduces a map image for Mission; .xml to .bzm map conversion for Mission; GOG `INTEX2 ardennen40/current.mip` exports equal to golden on win-home. Repo fixture golden parity for each; import round trip; auto scenario.

## Must-Haves

- NImageExport::ComposeImageToTexture and GetImageSize ported line for line, tested (pow2 padding with white alpha-0 fill, DXT3 + ARGB4444, rect of used/padded size).
- Exporters for mdc, cgc, chc, mip registered in exporter.cpp; BkResExport on each repo fixture writes the stats readable by the comparator's GetGameStats<> reader, field-equal to hand-derived expectations, plus image and text copies; Mission's validation list reports the MFC messages.
- Mission: the bridge creates map_{h,c,l}.dds from a final map (Data/Maps/road3d.xml copied under zig-out/local-test) and the export writes maps/<name>.bzm holding chunk 1 and the QuickLoadMapInfo chunk, both measured by code; refused inside shipped Data.
- Import from game data for all four kinds (Data/Medals, Data/Scenarios/Campaigns, Chapters, ScenarioMissions): import then export field-equal.
- App: image view + overlay for the four kinds; place objective/cross by click, drag in Show crosses mode, undo/redo; pure logic covered by test-resource-app-logic.
- resource-editor-auto-mip, -chc, -cgc, -mdc green locally with captured frames measured (marker pixel at the expected place before and after undo); wired into the aggregate, cross-platform.yml, run-resource-sweep.sh TIERS and AGENTS.md.
- 06-PARITY B-14.1-4, B-14.6, B-15.1-4, B-16.1-4, B-17.1-4 done with evidence; B-14.5 and the goldens recorded pending win-home; spec records the bzm/minimap location deviation.
- Map Editor tiers touched by the bridge.cpp factoring (test-editor-bridge, test-editor-core, map-editor-smoke) stay green.

## Proof Level

- This slice proves: integration: real exporters run through the bridge and the engine's own readers on Linux x64; GUI tiers run locally with a video device; macOS/Windows by CI after push; MFC goldens and GOG row on win-home only (pending, never claimed).

## Integration Closure

Consumes NImageExport (S06), the exporter table and SExportContext callbacks (S06-S13), the cross geometry channels 11-13 (S04), BkEditorMinimapImage/BkEditorCreateMiniMapImage (Map Editor bridge), the squad overlay gesture pattern (squad_logic.zig) and per-editor auto steps (D028). New wiring: four exporters and importers, minimap/bzm context callbacks, image_logic.zig and the image dock, four auto steps. Remaining for the milestone: S15 GUI editor and S16 sweep/deletion.

## Verification

- Export failures name the missing source file, the failed validation item (MFC's message text) or the missing engine callback; minimap/bzm refusals name the path and why (shipped Data, missing map); importers name the unreadable stats file; auto steps print measured pixel values for each checked marker.

## Tasks

- [x] **T01: ComposeImageToTexture/GetImageSize port and the Medal exporter and importer** `est:3h`
  Why: all four image-frame exporters need MFC's ComposeImageToTexture (Sources/src/editor/BuildCompose.cpp:235-301) and GetImageSize (:302-323); Medal (MedalFrm.cpp, 255 lines) is the simplest kind and the first end-to-end proof (D030).
  Do: (1) Port both functions line for line into NImageExport (Sources/src/ResourceModel/image_export.{h,cpp}): next-pow2 padding with white alpha-0 fill, picture options via ReadGammaConfig with MFC's bCorrect flag, DXT3 compressed + ARGB4444 low format (reuse SaveCompressedTexture's overloads), GetImageSize's rect of used size over padded size; outputs relative to the staging root. (2) Add items/medal/medal_export.{h,cpp}: port CMedalFrame FillRPGStats/SaveRPGStats/ExportFrameData (SMedalStats under RPG through the engine serializer as stats_export does, ComposeImageToTexture of <Texture>.tga, copy name and description .txt, the small preview MFC writes); declare ExportMedal in items/stats_export.h and add {"mdc", &ExportMedal} to exporter.cpp's table; add the new .cpp to build.zig's bridge sources. (3) Import: port CMedalFrame::GetRPGStats into BkResImportFromGame for kind mdc (resource_bridge.cpp ~L6601, the bPorted list and the switch) reading a shipped Data/Medals/<side>/<name>/1.xml; update the header comment listing ported kinds. (4) Fixture: the mdc/chc/cgc/mip projects reference 'medal'/'map' pictures the folder lacks; extend tools/zig/resource_editor_fixtures.zig so each of those folders gets the tga its project names (small, non-pow2 e.g. 20x12, so padding is exercised) and the .txt files they reference, run `zig build make-resource-fixtures`, commit the regenerated EXTENSIONS.md (only the intended rows change). (5) Tests in Sources/src/EditorBridge/resource_bridge_test.cpp: compose pads 20x12 to 32x16 with alpha 0 outside, rect equals (0,0,20/32,12/16) or what the MFC code computes; BkResExport on a copy of mdc/project.mdc writes the stats readable by GetGameStats<SMedalStats> with the expected fields, the DDS files and the .txt copies; import Data/Medals/German/as1 then export is field-equal through NResourceModel's comparator; a missing texture fails naming the file. CRLF on new files.
  Done when: verify exits 0 and git status shows nothing the task touched uncommitted.
  - Files: `Sources/src/ResourceModel/image_export.h`, `Sources/src/ResourceModel/image_export.cpp`, `Sources/src/ResourceModel/items/medal/medal_export.h`, `Sources/src/ResourceModel/items/medal/medal_export.cpp`, `Sources/src/ResourceModel/items/stats_export.h`, `Sources/src/ResourceModel/exporter.cpp`, `Sources/src/EditorBridge/resource_bridge.h`, `Sources/src/EditorBridge/resource_bridge.cpp`, `Sources/src/EditorBridge/resource_bridge_test.cpp`, `tools/zig/resource_editor_fixtures.zig`, `build.zig`
  - Verify: zig build make-resource-fixtures && zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model -Dtest-mode=run

- [x] **T02: Campaign and Chapter exporters and importers** `est:3h`
  Why: B-15.3/B-15.4 and B-16.3/B-16.4. CampaignFrm.cpp (FillRPGStats ~L60-100, ExportFrameData ~L250-290) and ChapterFrm.cpp (~L70-110, ~L300-340) share a shape: texts with szPrefix (the szAddDir + szPrevExportFileName export-relative rule), the map image via ComposeImageToTexture, mapImageRect = GetImageSize, crosses (chapters; missions then place holders) with their positions, chapter .lua copies.
  Do: (1) items/campaign/campaign_export.{h,cpp} and items/chapter/chapter_export.{h,cpp}, line-for-line ports using T01's NImageExport::ComposeImageToTexture/GetImageSize; cross positions come from the tree values the cross channels write (resource_bridge.cpp WriteCrossesToRpg ~L1233 keeps RPG copies; read what MFC's FillRPGStats read, MEM030); register cgc and chc in exporter.cpp; add sources to build.zig. (2) Import for cgc and chc in BkResImportFromGame from shipped Data/Scenarios/Campaigns/... and Data/Scenarios/Chapters/... 1.xml (MFC GetRPGStats/LoadRPGStats). (3) Tests in resource_bridge_test.cpp: export of each fixture readable through GetGameStats<SCampaignStats>/<SChapterStats> with expected fields (prefixed texts, positions, mapImageRect, image DDS, .txt and .lua copies); moving a cross through BkResSetChapterCrosses then exporting changes vPosOnMap; import a shipped campaign and chapter then export field-equal via the comparator; missing map image fails naming it. Record in the test names which shipped samples are used.
  Done when: verify exits 0 and git status is clean for touched files.
  - Files: `Sources/src/ResourceModel/items/campaign/campaign_export.h`, `Sources/src/ResourceModel/items/campaign/campaign_export.cpp`, `Sources/src/ResourceModel/items/chapter/chapter_export.h`, `Sources/src/ResourceModel/items/chapter/chapter_export.cpp`, `Sources/src/ResourceModel/items/stats_export.h`, `Sources/src/ResourceModel/exporter.cpp`, `Sources/src/EditorBridge/resource_bridge.h`, `Sources/src/EditorBridge/resource_bridge.cpp`, `Sources/src/EditorBridge/resource_bridge_test.cpp`, `build.zig`
  - Verify: zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model -Dtest-mode=run

- [x] **T03: Mission minimap creation and map .xml-to-.bzm conversion in the bridge** `est:3h`
  Why: B-14.2 and the bzm half of B-14.4 need the engine's map and terrain code, which only the bridge has (D030).
  Do: (1) Factor the CreateMiniMapImage body out of BkEditorCreateMiniMapImage (Sources/src/EditorBridge/bridge.cpp ~L2215-2290) into a helper taking the SRMImageCreateParameter list, so the Map Editor keeps its 512+256 params and the ResourceEditor uses MinimapCreation.cpp's Create1Minimap: pick .xml vs .bzm by mtime, skip when the _h.dds is newer, read xml via CreateDataTreeSaver+AddTypedSuper or bzm via CreateStructureSaver chunk 1, UnpackFrameIndices, one 0x200 x 0x200 parameter with INTERMISSION_IMAGE_BRIGHTNESS/CONSTRAST/GAMMA. (2) A helper writing <map>.bzm from a map .xml as CMissionFrame::ExportFrameData (MissionFrm.cpp ~L350-380): chunk 1 = mapInfo, chunk RMGC_QUICK_LOAD_MAP_INFO_CHUNK_NUMBER = SQuickLoadMapInfo::FillFromMapInfo (reuse the Map Editor's .bzm save code if it writes the same pair). (3) Expose both: BkResMissionMinimap(session) writes map_{h,c,l}.dds beside the open .mip from its Final map (resolved case-insensitively in the installation Data), refused when the project lies inside the shipped Data, has no path, or has no final map, each naming why; and new SExportContext callbacks (createMinimap, convertMapToBzm) in exporter.h that the bridge fills for every export, the bzm target being the staging root's maps\<FinalMap>.bzm. Document in resource_bridge.h; mirror BkResMissionMinimap in resource_core/bridge.zig, fake_bridge.zig and resource_app/c_bridge.zig. (4) Tests in resource_bridge_test.cpp using Data/Maps/road3d.xml copied under zig-out/local-test (a mip fixture copy whose Final map names it): minimap writes three DDS of 512x512 measured by reading the headers; bzm loads through CreateStructureSaver READ with chunk 1 and the QuickLoadMapInfo chunk present and its map size equal to the xml's; shipped-Data project refused; Map Editor's BkEditorCreateMiniMapImage still passes its own test.
  Done when: verify exits 0, Map Editor tiers green, git status clean for touched files.
  - Files: `Sources/src/EditorBridge/bridge.cpp`, `Sources/src/EditorBridge/resource_bridge.h`, `Sources/src/EditorBridge/resource_bridge.cpp`, `Sources/src/EditorBridge/resource_bridge_test.cpp`, `Sources/src/ResourceModel/exporter.h`, `Sources/editor/resource_core/bridge.zig`, `Sources/editor/resource_core/fake_bridge.zig`, `Sources/editor/resource_app/c_bridge.zig`
  - Verify: zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-core -Dtest-mode=run && zig build test-editor-bridge -Dtest-mode=run && zig build test-editor-core -Dtest-mode=run && zig build map-editor-smoke

- [x] **T04: Mission exporter with validation, and Mission import** `est:3h`
  Why: B-14.4 and B-14.6; MissionFrm.cpp FillRPGStats (~L73-130), SaveRPGStats, ExportFrameData (~L300-400) with its validation list.
  Do: (1) items/mission/mission_export.{h,cpp}: port FillRPGStats line for line (szPrefix texts, map image name, combat/exploration musics, mapImageRect = GetImageSize(<projdir>/map.tga) via T01, template/final map, setting, MOD name/version from the context, objectives with vPosOnMap, bSecret, nAnchorScriptID); the validation list with MFC's messages and its quirks (szErrorMsg overwritten, both music checks inspect the same E_MISSION_MUSICS_ITEM list) ported as behaviour and listed for PARITY; copy map_{h,c,l}.dds (via T03's createMinimap when absent), the header/subheader/desc .txt and each objective header/text .txt creating subdirs from the reference path; call convertMapToBzm when the final map's .bzm is missing; fail naming the missing callback when it is empty. Register mip in exporter.cpp; build.zig sources. (2) Import mip in BkResImportFromGame from Data/Scenarios/ScenarioMissions/... 1.xml (GetRPGStats). (3) A second tracked mip fixture (generator row in resource_editor_fixtures.zig, e.g. tools/zig/fixtures/resource_editor/mip/final-map/project.mip) with final map, texts, one combat and one exploration music and two objectives so validation passes; regenerate EXTENSIONS.md. (4) A named GOG test 'S14Mission::GogArdennen40' that reports 'pending: win-home only' when INTEX2 ardennen40/current.mip is absent (S10 brandenburgertor pattern), never a pass. (5) Tests: the validation-passing fixture exports SMissionStats readable via GetGameStats<SMissionStats> with expected fields, the DDS and .txt copies and maps/<name>.bzm; each validation failure (no header, no objective, objective without text) reports MFC's message; moving an objective via BkResSetMissionObjectives changes vPosOnMap; shipped mission import then export is field-equal (tolerated RPG/BGImage drift only).
  Done when: verify exits 0 and git status clean for touched files.
  - Files: `Sources/src/ResourceModel/items/mission/mission_export.h`, `Sources/src/ResourceModel/items/mission/mission_export.cpp`, `Sources/src/ResourceModel/items/stats_export.h`, `Sources/src/ResourceModel/exporter.cpp`, `Sources/src/EditorBridge/resource_bridge.h`, `Sources/src/EditorBridge/resource_bridge.cpp`, `Sources/src/EditorBridge/resource_bridge_test.cpp`, `tools/zig/resource_editor_fixtures.zig`, `build.zig`
  - Verify: zig build make-resource-fixtures && zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model -Dtest-mode=run

- [x] **T05: Image frame view: image dock, click-to-place and Show crosses drag, undoable** `est:3h`
  Why: B-14.3, B-15.2, B-16.2, B-17.2; ImageFrm.cpp/ImageView.cpp, ChapterFrm (bEditCrosses, zeroSizeX/Y hit box around pos - zeroShift, vCrossShift pick offset), CampaignFrm, MissionTreeItem SetActiveObjective/UpdateItemValue ~L251-288.
  Do: (1) Sources/editor/resource_app/image_logic.zig, no ImGui (squad_logic.zig shape): View (scroll offset, image size in real pixels, screen<->image), clamp to the image rect, MFC's hit box, modes (place active item vs Show crosses drag), Overlay press/move/release/cancel committing one geometry command per gesture on release via resource_core sub_editor_tools over channels mission_objectives/chapter_crosses/campaign_crosses; which item is active comes from the tree selection (objective for mip, mission or place holder for chc, chapter for cgc). Register in test-resource-app-logic with tests against the fake bridge: click places the active objective, clamp at edges, hit test picks the right cross with the offset kept, drag then undo restores and redo reapplies, Escape cancels with no history entry. (2) Image loading keeping the real size: request BkEditorMinimapImage with max_side 2048 and record the decoded size (or add a size query if scaling happens; refuse images larger than 2048 with a message). Mission shows <projdir>/map_h.dds, calling BkResMissionMinimap (T03) on select when absent; chapter/campaign show their map image; medal shows its picture with no placement. (3) Draw in panels.zig/docks.zig as the squad overlay does: invisible button canvas, image, cross markers (active one highlighted), Show crosses toggle in the toolbar (tools_ui.zig) for chc/cgc. CRLF.
  Done when: verify exits 0 and git status clean for touched files.
  - Files: `Sources/editor/resource_app/image_logic.zig`, `Sources/editor/resource_app/panels.zig`, `Sources/editor/resource_app/docks.zig`, `Sources/editor/resource_app/tools_ui.zig`, `Sources/editor/resource_core/sub_editor_tools.zig`, `build.zig`
  - Verify: zig build test-resource-app-logic -Dtest-mode=run && zig build test-resource-core -Dtest-mode=run && zig build install-resource-editor && zig build resource-editor-host-check && zig build resource-editor-smoke

- [x] **T06: resource-editor-auto-mip, -chc, -cgc, -mdc with measured frames; CI, sweep, PARITY and spec** `est:3h`
  Why: the slice demo needs auto scenarios and the parity evidence (D028 per-editor steps).
  Do: (1) Scenario blocks in Sources/editor/resource_app/scenario.zig and build.zig's resource_auto_steps (four new entries with their schedules, keeping the concatenation compile check): per kind copy the fixture into {dir}, open, select the item, click the image with real pointer events at a known image point, capture and measure the marker pixel there by code, undo (marker back), redo, save, export (expect=exported); mip uses the final-map fixture and checks the generated map image is shown; chc/cgc toggle Show crosses and drag a cross; mdc shows its picture measured non-background. Each step well under 3 minutes. (2) Add the steps to .github/workflows/cross-platform.yml where the other resource-editor-auto-* run, to tools/zig/run-resource-sweep.sh TIERS, and to AGENTS.md's Resource Editor list. (3) .planning/phases/06-resource-editor-portable-port/06-PARITY.md: B-14.1-4, B-14.6, B-15.1-4, B-16.1-4, B-17.1-4 done with evidence (test names, auto steps, measured values); B-14.5 and the mip/chc/cgc/mdc goldens 'pending win-home'; note the ported MFC validation quirks. (4) docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md: the bzm/minimap location deviation and one-undo-per-gesture (D030). Full sweep left to the maintainer; record the tiers run.
  Done when: verify exits 0 and git status shows nothing the task touched uncommitted.
  - Files: `Sources/editor/resource_app/scenario.zig`, `build.zig`, `.github/workflows/cross-platform.yml`, `tools/zig/run-resource-sweep.sh`, `AGENTS.md`, `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`, `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`
  - Verify: zig build install-resource-editor && zig build resource-editor-auto-mip && zig build resource-editor-auto-chc && zig build resource-editor-auto-cgc && zig build resource-editor-auto-mdc && zig build resource-editor-auto-core

## Files Likely Touched

- Sources/src/ResourceModel/image_export.h
- Sources/src/ResourceModel/image_export.cpp
- Sources/src/ResourceModel/items/medal/medal_export.h
- Sources/src/ResourceModel/items/medal/medal_export.cpp
- Sources/src/ResourceModel/items/stats_export.h
- Sources/src/ResourceModel/exporter.cpp
- Sources/src/EditorBridge/resource_bridge.h
- Sources/src/EditorBridge/resource_bridge.cpp
- Sources/src/EditorBridge/resource_bridge_test.cpp
- tools/zig/resource_editor_fixtures.zig
- build.zig
- Sources/src/ResourceModel/items/campaign/campaign_export.h
- Sources/src/ResourceModel/items/campaign/campaign_export.cpp
- Sources/src/ResourceModel/items/chapter/chapter_export.h
- Sources/src/ResourceModel/items/chapter/chapter_export.cpp
- Sources/src/EditorBridge/bridge.cpp
- Sources/src/ResourceModel/exporter.h
- Sources/editor/resource_core/bridge.zig
- Sources/editor/resource_core/fake_bridge.zig
- Sources/editor/resource_app/c_bridge.zig
- Sources/src/ResourceModel/items/mission/mission_export.h
- Sources/src/ResourceModel/items/mission/mission_export.cpp
- Sources/editor/resource_app/image_logic.zig
- Sources/editor/resource_app/panels.zig
- Sources/editor/resource_app/docks.zig
- Sources/editor/resource_app/tools_ui.zig
- Sources/editor/resource_core/sub_editor_tools.zig
- Sources/editor/resource_app/scenario.zig
- .github/workflows/cross-platform.yml
- tools/zig/run-resource-sweep.sh
- AGENTS.md
- .planning/phases/06-resource-editor-portable-port/06-PARITY.md
- docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md
