---
estimated_steps: 3
estimated_files: 8
skills_used: []
---

# T03: Mission minimap creation and map .xml-to-.bzm conversion in the bridge

Why: B-14.2 and the bzm half of B-14.4 need the engine's map and terrain code, which only the bridge has (D030).
Do: (1) Factor the CreateMiniMapImage body out of BkEditorCreateMiniMapImage (Sources/src/EditorBridge/bridge.cpp ~L2215-2290) into a helper taking the SRMImageCreateParameter list, so the Map Editor keeps its 512+256 params and the ResourceEditor uses MinimapCreation.cpp's Create1Minimap: pick .xml vs .bzm by mtime, skip when the _h.dds is newer, read xml via CreateDataTreeSaver+AddTypedSuper or bzm via CreateStructureSaver chunk 1, UnpackFrameIndices, one 0x200 x 0x200 parameter with INTERMISSION_IMAGE_BRIGHTNESS/CONSTRAST/GAMMA. (2) A helper writing <map>.bzm from a map .xml as CMissionFrame::ExportFrameData (MissionFrm.cpp ~L350-380): chunk 1 = mapInfo, chunk RMGC_QUICK_LOAD_MAP_INFO_CHUNK_NUMBER = SQuickLoadMapInfo::FillFromMapInfo (reuse the Map Editor's .bzm save code if it writes the same pair). (3) Expose both: BkResMissionMinimap(session) writes map_{h,c,l}.dds beside the open .mip from its Final map (resolved case-insensitively in the installation Data), refused when the project lies inside the shipped Data, has no path, or has no final map, each naming why; and new SExportContext callbacks (createMinimap, convertMapToBzm) in exporter.h that the bridge fills for every export, the bzm target being the staging root's maps\<FinalMap>.bzm. Document in resource_bridge.h; mirror BkResMissionMinimap in resource_core/bridge.zig, fake_bridge.zig and resource_app/c_bridge.zig. (4) Tests in resource_bridge_test.cpp using Data/Maps/road3d.xml copied under zig-out/local-test (a mip fixture copy whose Final map names it): minimap writes three DDS of 512x512 measured by reading the headers; bzm loads through CreateStructureSaver READ with chunk 1 and the QuickLoadMapInfo chunk present and its map size equal to the xml's; shipped-Data project refused; Map Editor's BkEditorCreateMiniMapImage still passes its own test.
Done when: verify exits 0, Map Editor tiers green, git status clean for touched files.

## Inputs

- `Sources/src/editor/MinimapCreation.cpp`
- `Sources/src/editor/MissionFrm.cpp`
- `Sources/src/EditorBridge/bridge.cpp`
- `Sources/src/EditorBridge/bridge.h`
- `Sources/src/EditorBridge/session_rmg.cpp`
- `Sources/src/ResourceModel/exporter.h`
- `Data/Maps/road3d.xml`
- `tools/zig/editor_bridge_test.cpp`

## Expected Output

- `Sources/src/EditorBridge/bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge.h`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `Sources/src/ResourceModel/exporter.h`
- `Sources/editor/resource_core/bridge.zig`
- `Sources/editor/resource_core/fake_bridge.zig`
- `Sources/editor/resource_app/c_bridge.zig`

## Verification

zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-core -Dtest-mode=run && zig build test-editor-bridge -Dtest-mode=run && zig build test-editor-core -Dtest-mode=run && zig build map-editor-smoke

## Observability Impact

BkResMissionMinimap and the bzm callback refuse with messages naming the path and the reason (shipped Data, no final map, unreadable map).
