---
id: T05
parent: S10
milestone: M001
key_files: []
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-05T17:48:32.905Z
blocker_discovered: false
---

# T05: Registered the Building grid editor with entrance, shoot, fire, smoke, directed-explosion, move-point, horizontal and angle/cone modes (undoable through point_tools), plus Generate points and the point overlay with angle and cone handles.

**Registered the Building grid editor with entrance, shoot, fire, smoke, directed-explosion, move-point, horizontal and angle/cone modes (undoable through point_tools), plus Generate points and the point overlay with angle and cone handles.**

## What Happened

grid_logic.zig: new Tool entries (entrance, shoot, fire, smoke, dir_explosion, move_point, horizontal, angle), registrationFor(.build) with passability_cells/transparency_cells, and targetNode for the building root. Pure helpers: aimDirection/aimTip (MFC's (-sin a, cos a) with EDGE_LENGTH 200), handlesOf, hitPoint, hitHandle, angleToward, coneToward, plus colours (yellow cone lines, red arrow, per-family point tints, alpha 120 inactive). GridEditor gained family, active point and a PointDrag. Press, move and release route to point_tools: a click on free ground places a point (copying the active direction), a click on a point selects it, the directed explosions only select; move point and horizontal drag with grab offset; the angle mode drags the direction or cone handle; entrance and set zero commit on release; right click or the Delete point button deletes a point with its tree child; Escape cancels a drag with no history. canGenerate mirrors OnUpdateGeneratePoints (smoke and dir-explosion modes only) and generate commits generateSmokePoints or generateDirExpPoints. panels.zig: second toolbar row for the point modes, Generate points and Delete point buttons, zero cross for the building, and drawBuildingPoints (entrance, all four families, active point's cone edges, direction line and arrow head). Preview kind 9 needed no app change, since syncPreview is kind-driven and T03 gave the bridge its preview. 11 new app-logic tests run against fake_bridge covering registration, hit-testing, every point mode with undo/redo state, cancel, and generate.

## Verification

Ran in the foreground on Linux x64: test-resource-app-logic, test-resource-core, install-resource-editor and resource-editor-smoke, all exit 0. No macOS or Windows result is claimed. The overlay drawing is compiled and smoke-launched but not yet measured by a captured shot; that is the T06 auto scenario.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-app-logic -Dtest-mode=run` | 0 | pass | 60000ms |
| 2 | `zig build test-resource-core -Dtest-mode=run` | 0 | pass | 60000ms |
| 3 | `zig build install-resource-editor` | 0 | pass | 120000ms |
| 4 | `zig build resource-editor-smoke` | 0 | pass | 60000ms |

## Deviations

None.

## Known Issues

None.

## Files Created/Modified

None.
