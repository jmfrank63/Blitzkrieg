---
id: S10
parent: M001
milestone: M001
provides:
  - (none)
requires:
  []
affects:
  []
key_files: []
key_decisions: []
patterns_established:
  - (none)
observability_surfaces:
  - none
drill_down_paths:
  []
duration: ""
verification_result: passed
completed_at: 2026-10-05T18:26:53.249Z
blocker_discovered: false
---

# S10: Building sub-editor

**Portable Building (.bld) sub-editor: point modes with angle/cone handles, passability and transparency grid, exporter and importer, preview shot and BK_EDITOR_AUTO bld scenario; GOG golden pending win-home.**

## What Happened

S10 ported the MFC Building editor (CBuildingFrame, .bld). Delivered: ResourceModel tree and BuildingStatsToTree, ExportBuilding (desc SBuildingRPGStats, sprite and shadow packs with passability, icon.tga) and importer; bridge tree of the repo fixture; Zig grid editor registered with entrance, shoot, fire, smoke and directed-explosion point tools, all undoable with angle and cone handles; Move tool, passability and transparency cells; preview shot and a BK_EDITOR_AUTO bld block with measured colour shots (locked red 12 to 397 pixels and back to 12 after undo; transparency colour 0 to 183 and back to 0). Import round trip covers every shipped Data/Buildings folder field-equal, with a D021 negative-tile guard (182 checked, 0 negative). 06-PARITY.md B-09 rows updated with evidence. The GOG INTEX2 brandenburgertor golden is wired as S10Building::GogBrandenburgertor and prints GOLDEN pending without BK_GOG_ROOT and BK_GOG_GOLDEN; the GOG files are never committed.

## Verification

Re-run in this unit: zig build test-resource-core exit 0; zig build test-resource-bridge exit 0 (Project+Tree OK, building origin check, GOG golden reported pending). Working tree clean. Earlier in the session (before interruption) resource-editor-smoke and resource-editor-auto with the bld block were run and passed. Full resource sweep left to the maintainer.

## Requirements Advanced

None.

## Requirements Validated

None.

## New Requirements Surfaced

None.

## Requirements Invalidated or Re-scoped

None.

## Operational Readiness

None.

## Deviations

None.

## Known Limitations

B-09.14 GOG golden comparison and MFC golden parity for bld are pending win-home (export-goldens.ps1 -Extensions bld). macOS and Windows results come from CI only, not seen here.

## Follow-ups

Run export-goldens.ps1 -Extensions bld and the GOG comparison with BK_GOG_ROOT/BK_GOG_GOLDEN on win-home; maintainer runs tools/zig/run-resource-sweep.sh.

## Files Created/Modified

None.
