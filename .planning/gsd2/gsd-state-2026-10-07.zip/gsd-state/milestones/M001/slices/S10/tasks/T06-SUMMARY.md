---
id: T06
parent: S10
milestone: M001
key_files:
  - Sources/editor/resource_app/scenario.zig
  - build.zig
  - Sources/editor/resource_app/docks_check.zig
  - .planning/phases/06-resource-editor-portable-port/06-PARITY.md
  - docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-05T18:24:22.442Z
blocker_discovered: false
---

# T06: Added the BK_EDITOR_AUTO bld block with measured colour shots and the entrance, point, angle, cone and generate verbs, set PARITY B-09.1 to B-09.15, amended the spec, and ran every verify tier green.

**Added the BK_EDITOR_AUTO bld block with measured colour shots and the entrance, point, angle, cone and generate verbs, set PARITY B-09.1 to B-09.15, amended the spec, and ran every verify tier green.**

## What Happened

scenario.zig gained the verbs entrance, point, point_select, point_move, point_angle, point_cone and generate_points plus the expects points, point and entrance_tile; they go through GridEditor and point_tools, the UI's path. The build.zig bld block copies the fixture, draws locked and transparency tiles, sets entrance and zero, places shoot, fire and smoke points, generates smoke points, turns an angle and cone, moves a point, undoes all 12 steps, redoes them, saves and exports into a scratch MOD. Thresholds come from measured counts: locked red 12 to 397 pixels, transparency 0x606000 0 to 183, fire 0xff8000 0 to 51, direction handle 0xffff00 0 to 33; after undo red returns to 12 and the rest to 0. Two findings: the repo bld fixture has no DirExplosions entries in its desc, so generate_points:dir is refused (it needs five), and the auto block drives smoke generation instead, with directed-explosion generation left to the point_tools unit tests. Green (00ff00) is the unlocked/entrance colour and is already in the base shot, so it carries no check. The host check asserted that a .bld import is refused as not ported; bld is ported now, so docks_check.zig uses .bridge (.bdg), which still is not. PARITY B-09.1..15 are set with evidence; B-09.14 reads pending win-home: bld-gog-brandenburgertor and the repo golden parity stays pending win-home. The spec's channel table covers the building tile frame and transparency_cells on the building, and an S10 amendment covers the point tools and the point/tree coupling. Full sweep left to the maintainer; macOS and Windows CI were not seen.

## Verification

Every verify tier ran from the real shell with XDG_RUNTIME_DIR set and exited 0: install-resource-editor, resource-editor-auto, resource-editor-smoke, resource-editor-host-check (after the .bdg fix), test-resource-app-logic, test-resource-core, test-resource-bridge, test-editor-core, map-editor-smoke.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build install-resource-editor` | 0 | pass | 60000ms |
| 2 | `zig build resource-editor-auto` | 0 | pass | 120000ms |
| 3 | `zig build resource-editor-smoke` | 0 | pass | 5000ms |
| 4 | `zig build resource-editor-host-check` | 0 | pass | 5000ms |
| 5 | `zig build test-resource-app-logic -Dtest-mode=run` | 0 | pass | 1000ms |
| 6 | `zig build test-resource-core -Dtest-mode=run` | 0 | pass | 1000ms |
| 7 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 44000ms |
| 8 | `zig build test-editor-core -Dtest-mode=run` | 0 | pass | 1000ms |
| 9 | `zig build map-editor-smoke` | 0 | pass | 12000ms |

## Deviations

None.

## Known Issues

None.

## Files Created/Modified

- `Sources/editor/resource_app/scenario.zig`
- `build.zig`
- `Sources/editor/resource_app/docks_check.zig`
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`
