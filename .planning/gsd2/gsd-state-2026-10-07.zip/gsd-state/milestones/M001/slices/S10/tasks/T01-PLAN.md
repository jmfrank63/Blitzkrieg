---
estimated_steps: 7
estimated_files: 2
skills_used: []
---

# T01: D021: measure shipped objects for tiles left of or above (0,0)

Why: D021 (hard steer 2026-10-05T17:05). TilesToGrid (Sources/src/EditorBridge/resource_bridge.cpp, ~line 1219) refuses a tile with negative X or Y, and object passability_cells/transparency_cells (ReadObjectTileGrid -> ObjectTiles, ~line 1267) go through it. That refusal is only safe if no shipped object needs negative tiles, so the test measures it.

Do:
1. In Sources/src/EditorBridge/resource_bridge_test.cpp, add a case (named e.g. 'objects-negative-tiles') next to the S09 object Shipped() case (~line 4255; reuse T11::FoldedPath and the existing scratch root). Enumerate every folder under Data/Objects (case-insensitive, read-only) that holds a 1.xml; there are about 590. Copy each folder's 1.xml, plus whatever BkResImportFromGame(kind 7) needs to read, into zig-out/local-test/<scratch>/objects-negtiles/<rel>. Import each copy with BkResImportFromGame(pSession, 7, ...). Then read passability_cells and transparency_cells on the root node through the public getters. A BK_EDITOR_REFUSED whose message contains 'left of or above' counts as negative. Better still, compute the tiles directly through the same ObjectTiles path if the test can reach it, so the count does not depend on the message text. Print 'NEGTILES objects checked=<N> negative=<M>' and one line per offender with its path. Check N > 500, and check that nothing was written into Data/ (the ListingOf helper is the precedent). Imports that fail for unrelated reasons are counted and printed separately, not silently skipped.
2. If M > 0: let the channels carry a grid origin so the object stays editable. Extend the passability_cells/transparency_cells blob in resource_bridge.h/.cpp and on the Zig side (Sources/editor/resource_core/bridge.zig, fake_bridge.zig, Sources/editor/resource_app/c_bridge.zig) with an append-only origin (first tile X/Y), following D020's append-only ABI rule and never renumbering channels. Add a round-trip test on one offender: get, set, save, reopen, get; the stored desc is unchanged. Record the change in the spec.
3. If M == 0: record N, M and the date in docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md under Amendments (a D021 bullet). Keep the refusal. The test stays as the guard and fails if M becomes > 0.
Do not write into Data/. Run only the tiers below (AGENTS.md).

Done when: the case prints the NEGTILES line, the spec or ABI is updated per the branch taken, and the verify tiers exit 0.

## Inputs

- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge.h`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `Sources/src/ResourceModel/items/object/object_export.h`
- `Sources/src/ResourceModel/grid_projection.h`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`

## Expected Output

- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`

## Verification

zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-core -Dtest-mode=run

## Observability Impact

Prints 'NEGTILES objects checked=N negative=M', one line per offender, and the count of failed imports.
