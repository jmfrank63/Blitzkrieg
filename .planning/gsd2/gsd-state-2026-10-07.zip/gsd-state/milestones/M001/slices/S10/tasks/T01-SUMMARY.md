---
id: T01
parent: S10
milestone: M001
key_files: []
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-05T17:14:39.847Z
blocker_discovered: false
---

# T01: Measured all 590 shipped objects: none has a negative tile, so the grid refusal stays and a guard test enforces it.

**Measured all 590 shipped objects: none has a negative tile, so the grid refusal stays and a guard test enforces it.**

## What Happened

Added S09Object::NegativeTiles to resource_bridge_test.cpp. It imports every Data/Objects folder with a 1.xml in place (read-only) through BkResImportFromGame kind 7, reads passability_cells and transparency_cells on the object root, and counts a 'left of or above' refusal as negative. Result: NEGTILES objects checked=590 negative=0 import_failed=0. The case checks N>500, M==0 and that no folder listing in Data changed. Branch M==0 taken: D021 recorded in the spec Amendments, ABI unchanged. The test stays as a guard.

## Verification

Both verify tiers exit 0; the NEGTILES line printed as above.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 0ms |
| 2 | `zig build test-resource-core -Dtest-mode=run` | 0 | pass | 0ms |

## Deviations

None.

## Known Issues

None.

## Files Created/Modified

None.
