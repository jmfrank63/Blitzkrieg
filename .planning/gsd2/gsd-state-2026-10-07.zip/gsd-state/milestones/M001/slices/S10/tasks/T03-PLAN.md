---
estimated_steps: 8
estimated_files: 7
skills_used: []
---

# T03: Building exporter and importer, fixture art, preview kind

Why: B-09.13 and B-09.15. The exporter and importer come with the sub-editor, and kind 9 currently answers 'not ported yet' (resource_bridge.cpp ~3379, 3446, 4377, 4546, 5641).

Do:
1. Fixture art: project.bld references 1.tga, 1s.tga, 1w.tga, 1ws.tga, 2.tga, 2s.tga, 2g.tga, 2w.tga, 2ws.tga, 2wg.tga and others (grep the project). Generate them in tools/zig/resource_editor_fixtures.zig, as obt's art is generated, and commit the generated TGAs into tools/zig/fixtures/resource_editor/bld/. Keep the art small and alpha-bearing.
2. Add Sources/src/ResourceModel/items/building/building_export.cpp/.h. Port CBuildingFrame::ExportFrameData (BuildFrm.cpp:454-556), SaveRPGStats (558-~920) and CBuildingTreeRootItem::ComposeAnimations (BuildTreeItem.cpp / BuildCompose.cpp). Reuse NResourceModel's ComposeSingleObjectPack, BuildAnimations, Origin2DPosition and SaveIconFile (Sources/src/ResourceModel/compose.h) and GridProjection; use ARGB1555 as the low format. Port LoadRPGStats (922-~1275) as the importer, the inverse of export. Follow object_export.cpp's shape and error style. Add the new .cpp to both source lists in build.zig (next to object_export.cpp, ~line 4132 and the second list ~line 9068).
3. Dispatch kind 9 in resource_bridge.cpp for export (normal, forced, stats-only) and BkResImportFromGame. Add a preview kind entry for 9 in kPreviewKinds (~line 4022; the composed building sprite, as obt does) and a BkResPreview capture check.
4. resource_bridge_test.cpp: export the bld fixture. A second forced export is byte-identical. A deleted picture warns and leaves no DDS. Export -> import -> stats-only export is field-equal through the comparator. The import refusal test at ~line 1971 that uses kind 9 as the 'not ported yet' example must move to a kind that is still unported.
5. Make sure test-resource-model and test-resource-model-comparator still print 'GOLDEN bld pending' (golden folder empty) and stay green.

Done when: the verify tiers exit 0.

## Inputs

- `Sources/src/editor/BuildFrm.cpp`
- `Sources/src/editor/BuildTreeItem.cpp`
- `Sources/src/editor/BuildCompose.cpp`
- `Sources/src/ResourceModel/items/building/building.h`
- `Sources/src/ResourceModel/items/building/building.cpp`
- `Sources/src/ResourceModel/items/object/object_export.cpp`
- `Sources/src/ResourceModel/items/object/object_export.h`
- `Sources/src/ResourceModel/compose.h`
- `Sources/src/ResourceModel/grid_projection.h`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `tools/zig/resource_editor_fixtures.zig`
- `tools/zig/fixtures/resource_editor/bld/project.bld`
- `build.zig`

## Expected Output

- `Sources/src/ResourceModel/items/building/building_export.cpp`
- `Sources/src/ResourceModel/items/building/building_export.h`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `tools/zig/resource_editor_fixtures.zig`
- `build.zig`

## Verification

zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model -Dtest-mode=run && zig build test-resource-model-comparator -Dtest-mode=run && zig build test-resource-core -Dtest-mode=run

## Observability Impact

Export and import failures name the file and the field. A missing picture is a warning that names it.
