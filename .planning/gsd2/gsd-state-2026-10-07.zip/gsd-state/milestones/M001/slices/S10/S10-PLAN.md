# S10: Building sub-editor

**Goal:** The Building (.bld) sub-editor works end to end. First, D021 is settled by measuring every shipped object for negative tiles. Then: building grids are held in the tile frame like the object's, and every point mode (entrance, zero, shoot, fire, smoke, directed explosion, move point, horizontal position, angle and cone handles, generate points) is an undoable command. The ported exporter and importer match MFC: repo fixture golden parity (pending until win-home), a shipped import round trip that is field-equal, and a named GOG brandenburgertor golden test that runs only on win-home. A measured preview shot shows the building, its passability and its points, and a BK_EDITOR_AUTO bld scenario passes.
**Demo:** All point modes undoable with angle and cone handles. GOG `INTEX2 brandenburgertor/current.bld` exports equal to its MFC golden on win-home (committed as test name only; actual GOG files never committed). Repo fixture golden parity; import round trip; preview shot showing building + passability + points; auto scenario.

## Must-Haves

- T01 test reports N shipped objects checked (N > 500, from Data/Objects copied read-only to zig-out/local-test) and the count with a negative tile. If that count is > 0, the tile channels carry a grid origin (appended ABI, D020) and a round-trip test on such an object passes. If it is 0, the spec records N and the result, and the refusal stays, guarded by the test.
- passability_cells and transparency_cells on the building root are tile-frame channels cropped with the zero-point origin on save, exactly as CBuildingFrame::SaveRPGStats does. The get/set/save/reopen/export round trip passes in test-resource-bridge.
- Each building point tool emits one undo step and keeps the desc list and tree children in sync. resource_core tests assert geometry before, after, after undo and after redo for entrance, zero, place shoot/fire/smoke/dir-explosion point, move point, horizontal position, angle handle, cone handle, delete point and generate points.
- bld export of the repo fixture succeeds, a second forced export is byte-identical, import->export->import is field-equal, and a shipped Data/Buildings sample imports and exports stats-only field-equal with nothing written into Data/. The golden lines print 'GOLDEN bld pending'. The test 'bld-gog-brandenburgertor' prints pending when BK_GOG_ROOT and BK_GOG_GOLDEN are unset. export-goldens.ps1 can export the GOG project to an uncommitted folder.
- The shipped buildings are scanned for negative tiles too, and the count is recorded.
- resource-editor-auto has a bld block: code measures the locked red, the transparency colour and the point/handle colours in the captured shot, and undo removes them in a second shot.
- 06-PARITY.md B-09.1..B-09.15 carry evidence. B-09.14 stays 'pending win-home' with the test name.
- Tiers green on Linux: test-resource-model, test-resource-model-comparator, test-resource-bridge, test-resource-core, test-resource-app-logic, test-editor-core, install-resource-editor, resource-editor-host-check, resource-editor-smoke, resource-editor-auto, map-editor-smoke. The full sweep is left to the maintainer. macOS and Windows are CI only.

## Proof Level

- This slice proves: Contract and integration. The engine's own readers (comparator, LoadRPGStats inverse) prove the exported and imported data. Code measures the captured TGA for the overlay. MFC golden equality stays pending until win-home and is never claimed.

## Integration Closure

Bridge kind 9 (bld) gains its exporter, importer, preview kind and tile-frame channels. resource_core gains kind-agnostic point tools that S11 (bridge fire/smoke points) reuses. The app registers bld in grid_logic with grid and point tools. BK_EDITOR_AUTO gains point verbs. S11 consumes the point tools and the tile-frame pattern.

## Verification

- The T01/T04 scans print 'NEGTILES objects checked=N negative=M' and 'NEGTILES buildings checked=N negative=M', listing each offender's path. Export and import failures name the file and the field. Auto shots print measured colour counts against their thresholds. GOLDEN lines say pending with the reason.

## Tasks

- [x] **T01: D021: measure shipped objects for tiles left of or above (0,0)** `est:1h`
  Why: D021 (hard steer 2026-10-05T17:05). TilesToGrid (Sources/src/EditorBridge/resource_bridge.cpp, ~line 1219) refuses a tile with negative X or Y, and object passability_cells/transparency_cells (ReadObjectTileGrid -> ObjectTiles, ~line 1267) go through it. That refusal is only safe if no shipped object needs negative tiles, so the test measures it.
  - Files: `Sources/src/EditorBridge/resource_bridge_test.cpp`, `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`
  - Verify: zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-core -Dtest-mode=run

- [x] **T02: Building tile-frame grids, building channels, and undoable point tools in resource_core** `est:3h`
  Why: the slice demo needs every point mode undoable with angle and cone handles. Building passability today is HOME_FRAME raw desc (resource_bridge.cpp HomeOf ~line 785), but CBuildingFrame keeps lockedTiles and transeparences as tile lists and SaveRPGStats crops them with the zero-point origin exactly as the object does (Sources/src/editor/BuildFrm.cpp:558-760). transparency_cells is object-only today.
  - Files: `Sources/src/EditorBridge/resource_bridge.h`, `Sources/src/EditorBridge/resource_bridge.cpp`, `Sources/src/EditorBridge/resource_bridge_test.cpp`, `Sources/editor/resource_core/bridge.zig`, `Sources/editor/resource_core/fake_bridge.zig`, `Sources/editor/resource_core/point_tools.zig`, `Sources/editor/resource_core/root.zig`, `Sources/editor/resource_app/c_bridge.zig`
  - Verify: zig build test-resource-core -Dtest-mode=run && zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-app-logic -Dtest-mode=run && zig build test-editor-core -Dtest-mode=run

- [x] **T03: Building exporter and importer, fixture art, preview kind** `est:3h`
  Why: B-09.13 and B-09.15. The exporter and importer come with the sub-editor, and kind 9 currently answers 'not ported yet' (resource_bridge.cpp ~3379, 3446, 4377, 4546, 5641).
  - Files: `tools/zig/resource_editor_fixtures.zig`, `tools/zig/fixtures/resource_editor/bld/`, `Sources/src/ResourceModel/items/building/building_export.cpp`, `Sources/src/ResourceModel/items/building/building_export.h`, `Sources/src/EditorBridge/resource_bridge.cpp`, `Sources/src/EditorBridge/resource_bridge_test.cpp`, `build.zig`
  - Verify: zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model -Dtest-mode=run && zig build test-resource-model-comparator -Dtest-mode=run && zig build test-resource-core -Dtest-mode=run

- [x] **T04: Shipped building round trip, building negative-tile scan, GOG brandenburgertor named test** `est:2h`
  Why: the slice demo needs an import round trip on shipped data and the GOG INTEX2 brandenburgertor/current.bld golden comparison on win-home, committed as a test name only. Building grids are now tile-frame channels (T02) that use the same negative-tile refusal, so the D021 measurement must cover buildings too.
  - Files: `Sources/src/EditorBridge/resource_bridge_test.cpp`, `tools/zig/win-home/export-goldens.ps1`, `tools/zig/fixtures/resource_editor/bld/golden/README.md`, `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`
  - Verify: zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model-comparator -Dtest-mode=run

- [x] **T05: App: bld grid and point modes, overlay with angle and cone handles, preview wiring** `est:3h`
  Why: users edit buildings in the app. MFC's CBuildingFrame toolbar (BuildFrm.cpp SetActiveMode 1796, mode handlers 1895-2336) has move object, draw grid, transparency dropdown, entrance, zero, shoot/fire/dir-explosion/smoke point modes, move point, horizontal position, angle, and generate points.
  - Files: `Sources/editor/resource_app/grid_logic.zig`, `Sources/editor/resource_app/panels.zig`, `Sources/editor/resource_app/main.zig`
  - Verify: zig build test-resource-app-logic -Dtest-mode=run && zig build test-resource-core -Dtest-mode=run && zig build install-resource-editor && zig build resource-editor-smoke

- [x] **T06: BK_EDITOR_AUTO bld block with measured shot, PARITY B-09 rows, spec, tier run** `est:2h`
  Why: the slice demo asks for a preview shot of the building with its passability and points, measured by code, and an auto scenario. Parity and spec must record the evidence.
  - Files: `Sources/editor/resource_app/scenario.zig`, `build.zig`, `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`, `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`
  - Verify: zig build install-resource-editor && zig build resource-editor-auto && zig build resource-editor-smoke && zig build resource-editor-host-check && zig build test-resource-app-logic -Dtest-mode=run && zig build test-resource-core -Dtest-mode=run && zig build test-resource-bridge -Dtest-mode=run && zig build test-editor-core -Dtest-mode=run && zig build map-editor-smoke

## Files Likely Touched

- Sources/src/EditorBridge/resource_bridge_test.cpp
- docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md
- Sources/src/EditorBridge/resource_bridge.h
- Sources/src/EditorBridge/resource_bridge.cpp
- Sources/editor/resource_core/bridge.zig
- Sources/editor/resource_core/fake_bridge.zig
- Sources/editor/resource_core/point_tools.zig
- Sources/editor/resource_core/root.zig
- Sources/editor/resource_app/c_bridge.zig
- tools/zig/resource_editor_fixtures.zig
- tools/zig/fixtures/resource_editor/bld/
- Sources/src/ResourceModel/items/building/building_export.cpp
- Sources/src/ResourceModel/items/building/building_export.h
- build.zig
- tools/zig/win-home/export-goldens.ps1
- tools/zig/fixtures/resource_editor/bld/golden/README.md
- Sources/editor/resource_app/grid_logic.zig
- Sources/editor/resource_app/panels.zig
- Sources/editor/resource_app/main.zig
- Sources/editor/resource_app/scenario.zig
- .planning/phases/06-resource-editor-portable-port/06-PARITY.md
