---
id: T03
parent: S10
milestone: M001
key_files:
  - Sources/src/ResourceModel/items/building/building_export.cpp
  - Sources/src/ResourceModel/items/building/building_export.h
  - Sources/src/EditorBridge/resource_bridge.cpp
  - Sources/src/EditorBridge/resource_bridge_test.cpp
  - tools/zig/resource_editor_fixtures.zig
  - build.zig
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-05T17:39:53.428Z
blocker_discovered: false
---

# T03: Ported the Building exporter and importer (ExportBuilding, BuildingStatsToTree, WriteBuildingFrameData), kind-9 bridge dispatch and preview, 16 generated fixture TGAs, and bld export/determinism/missing-picture/round-trip tests.

**Ported the Building exporter and importer (ExportBuilding, BuildingStatsToTree, WriteBuildingFrameData), kind-9 bridge dispatch and preview, 16 generated fixture TGAs, and bld export/determinism/missing-picture/round-trip tests.**

## What Happened

building_export.cpp/.h port CBuildingFrame::ExportFrameData, SaveRPGStats and ComposeAnimations (reusing ComposeSingleObjectPack, BuildAnimations, Origin2DPosition, SaveIconFile, GridProjection, ARGB1555 low format) and LoadRPGStats as the importer (tree half plus desc frame half). Both are in both build.zig source lists. resource_bridge.cpp dispatches kind 9 for export (normal, forced, stats-only) and BkResImportFromGame, and has a kPreviewKinds entry for bld. tools/zig/resource_editor_fixtures.zig generates the 16 bld source TGAs (committed under tools/zig/fixtures/resource_editor/bld/) and documents them in EXTENSIONS.md. After the interrupted session, the resumed run found gsd_task_complete had not been recorded and the tiers failing: a wrong include path in building_export.h (../tree_item.h -> ../../tree_item.h), missing generated art, and two old tests using bld as the 'not ported yet' example. Fixed those (import refusal example moved to bdg, kind 10; export loop gained a bld branch) and added the S10Building test namespace: fixture export writes 1.xml, season DDS and icon; second forced export byte-identical; deleted 1w.tga warns and leaves no 1w DDS; export -> import -> stats-only export field-equal (99 fields, 0 differences).

## Verification

All four verify tiers exit 0 on Linux x64; GOLDEN bld stays pending (golden folder empty) in all three model/bridge tiers. Full resource sweep left to the maintainer. No preview capture test for bld was added beyond the preview-kind entry; the measured preview shot is slice-level work.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 36100ms |
| 2 | `zig build test-resource-model -Dtest-mode=run` | 0 | pass | 20250ms |
| 3 | `zig build test-resource-model-comparator -Dtest-mode=run` | 0 | pass | 19450ms |
| 4 | `zig build test-resource-core -Dtest-mode=run` | 0 | pass | 570ms |

## Deviations

The plan's BkResPreview capture check for bld was not added in this task; only the preview kind entry exists.

## Known Issues

No bld preview capture test yet. Golden parity for bld is pending until win-home.

## Files Created/Modified

- `Sources/src/ResourceModel/items/building/building_export.cpp`
- `Sources/src/ResourceModel/items/building/building_export.h`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `tools/zig/resource_editor_fixtures.zig`
- `build.zig`
