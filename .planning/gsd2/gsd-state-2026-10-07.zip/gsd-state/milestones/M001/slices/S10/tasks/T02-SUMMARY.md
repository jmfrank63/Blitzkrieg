---
id: T02
parent: S10
milestone: M001
key_files:
  - Sources/src/EditorBridge/resource_bridge.cpp
  - Sources/src/EditorBridge/resource_bridge.h
  - Sources/src/EditorBridge/resource_bridge_test.cpp
  - Sources/src/ResourceModel/items/object/object_export.cpp
  - Sources/editor/resource_core/point_tools.zig
  - Sources/editor/resource_core/fake_bridge.zig
  - Sources/editor/resource_core/sub_editor_tools.zig
  - Sources/editor/resource_core/root.zig
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-05T17:25:36.592Z
blocker_discovered: false
---

# T02: Building root gets tile-frame passability/transparency channels, a sprite_pos home and point-child sync in the bridge; point_tools.zig adds undoable place/move/delete/angle/cone/entrance/generate tools.

**Building root gets tile-frame passability/transparency channels, a sprite_pos home and point-child sync in the bridge; point_tools.zig adds undoable place/move/delete/angle/cone/entrance/generate tools.**

## What Happened

Bridge: IsObjectTileChannel/ReadObjectTileGrid/RewriteObjectGrids were generalised to IsTileFrameChannel/ReadFrameTileGrid/RewriteFrameGrids, serving the object and building roots. A building save writes only the desc grids (new NResourceModel::WriteObjectGrids) so no TransLines appear in own_data. HomeOf accepts the building root for transparency_cells and sprite_pos (Move object changes sprite_pos with the zero point). Aimed-point writes on a building sync direction and cone to the same-index tree child (SyncAimedChildren); inserting and removing children stays with the editor. resource_bridge_test.cpp has a Building case: get/set/get/save/reopen/get for grids, sprite, zero, entrance and shoot/fire/smoke/explosion points, plus MFC's reader checking origins and desc grids. Zig: new resource_core/point_tools.zig (kind-agnostic Target{node,channel,container,child_class}) with placePoint and deletePoint (child insert/delete and list write in one composite), PointDrag (move, horizontal, direction, cone, aim; one command at release, cancel leaves no history), editPoint, setEntrance, and pure ports of GenerateSmokePoints/GenerateDirExpPoints with a Frame conversion. fake_bridge.zig seeds Direction/cone props on building point items and syncs them on aimed writes. item_type gained the building classes; root.zig exports point_tools. Each tool is tested before/after/undo/redo. The D021 measurement (no negative tiles) was recorded earlier. c_bridge.zig needed no change: the channels already existed.

## Verification

All four verify tiers exit 0 in the foreground: test-resource-core (70 pass), test-resource-bridge, test-resource-app-logic, test-editor-core. Linux only; no macOS/Windows results claimed.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-core -Dtest-mode=run` | 0 | pass | 60000ms |
| 2 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 120000ms |
| 3 | `zig build test-resource-app-logic -Dtest-mode=run` | 0 | pass | 60000ms |
| 4 | `zig build test-editor-core -Dtest-mode=run` | 0 | pass | 60000ms |

## Deviations

c_bridge.zig and bridge.zig unchanged (channels already existed). Generate-point functions return AI-grid screen positions converted by a caller-supplied Frame, since the channel's own frame depends on the app's camera.

## Known Issues

Generated dir-explosion/smoke positions are unit-tested against MFC's formulas, not against an MFC-produced golden. Durations in evidence are approximate.

## Files Created/Modified

- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge.h`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `Sources/src/ResourceModel/items/object/object_export.cpp`
- `Sources/editor/resource_core/point_tools.zig`
- `Sources/editor/resource_core/fake_bridge.zig`
- `Sources/editor/resource_core/sub_editor_tools.zig`
- `Sources/editor/resource_core/root.zig`
