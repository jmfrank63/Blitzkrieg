---
id: T04
parent: S10
milestone: M001
key_files: []
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-05T17:43:40.558Z
blocker_discovered: false
---

# T04: Added the shipped-building import round trip, the building negative-tile scan (182 checked, 0 negative), the win-home-only bld-gog-brandenburgertor named test and the export-goldens.ps1 -GogProject mode.

**Added the shipped-building import round trip, the building negative-tile scan (182 checked, 0 negative), the win-home-only bld-gog-brandenburgertor named test and the export-goldens.ps1 -GogProject mode.**

## What Happened

resource_bridge_test.cpp gained a 'building shipped' case (copy a Data/Buildings folder, import with kind 9, stats-only export, compare with the shipped 1.xml through the comparator, ListingOf unchanged) and a 'buildings-negative-tiles' scan that prints 'NEGTILES buildings checked=182 negative=0 import_failed=12' plus offenders. No building has a negative tile, so no grid origin was added; the count is recorded in the spec's D021 bullet. The named test bld-gog-brandenburgertor reads BK_GOG_ROOT and BK_GOG_GOLDEN, finds INTEX2/brandenburgertor/current.bld case-insensitively, exports into zig-out/local-test and compares with the golden via the comparator and dxt-tolerance.json. Unset, it prints 'GOLDEN bld-gog-brandenburgertor pending: BK_GOG_ROOT/BK_GOG_GOLDEN not set (win-home only)' and does not count as a pass. No GOG files are copied or committed. tools/zig/win-home/export-goldens.ps1 has an optional -GogProject/-GogOut mode that batch-exports one project into an uncommitted folder and prints the BK_GOG_* values; the bld golden README documents it. The GOG comparison itself was not run: win-home only.

## Verification

Both verify commands re-run in this session on Linux x64 and exited 0; the bridge log shows the NEGTILES buildings line, the bld pending golden line and the GOG pending line, with no FAIL lines. Full resource sweep left to the maintainer.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 0ms |
| 2 | `zig build test-resource-model-comparator -Dtest-mode=run` | 0 | pass | 0ms |

## Deviations

None.

## Known Issues

None.

## Files Created/Modified

None.
