---
estimated_steps: 8
estimated_files: 8
skills_used: []
---

# T02: Building tile-frame grids, building channels, and undoable point tools in resource_core

Why: the slice demo needs every point mode undoable with angle and cone handles. Building passability today is HOME_FRAME raw desc (resource_bridge.cpp HomeOf ~line 785), but CBuildingFrame keeps lockedTiles and transeparences as tile lists and SaveRPGStats crops them with the zero-point origin exactly as the object does (Sources/src/editor/BuildFrm.cpp:558-760). transparency_cells is object-only today.

Do:
1. Bridge (Sources/src/EditorBridge/resource_bridge.cpp/.h): on the building root, make passability_cells and transparency_cells tile-frame channels as for the object (IsObjectTileChannel / ObjectTiles / RewriteObjectGrids). Generalise those helpers to building root + object root rather than copying them; building desc is SBuildingRPGStats, so read and write its passability/vOrigin/visibility/vVisOrigin with the same LoadRPGStats inverse. Extend HomeOf so CHANNEL_TRANSPARENCY_CELLS also accepts the building root. Check BuildFrm OnMoveObject (1895) and zeroShiftX/Y: if 'Move object' changes a stored value, give it a home (reuse sprite_pos=19 if the stored field matches; otherwise append a new channel after the current last one, never renumbering). If it does not, record that it is view-only. Keep HasNoPrivateGeometry true.
2. Point coupling: read BuildShoot.cpp, BuildFire.cpp, BuildSmoke.cpp, BuildDirExp.cpp and BuildFrm.cpp OnLButtonDown/Up (1331-1795) to see whether placing or deleting a point also adds or removes a tree child (CBuildingSlotPropsItem, CBuildingFirePointPropsItem, CBuildingSmokePropsItem, CBuildingDirExplosionPropsItem in Sources/src/ResourceModel/items/building/building.h). Mirror that, so desc lists and tree children stay in sync after set, save and reopen.
3. resource_bridge_test.cpp: on the bld fixture (tools/zig/fixtures/resource_editor/bld/project.bld) run get -> set -> get -> save -> reopen -> get for passability_cells, transparency_cells, zero, entrance and each aimed channel. Then read desc back as MFC would (ReadAsMfc) and check that the origin matches the zero point, as the obt-geometry case does. A transparency value > 7 is refused.
4. Add Sources/editor/resource_core/point_tools.zig, kind-agnostic (node + channel parameters, so S11 reuses it for bridge fire/smoke points): place point (MFC's default angle/cone per mode), move point (drag press/move/release gives one composite), set horizontal position, angle handle drag, cone handle drag, delete point, set entrance, generate points (OnGeneratePoints 2327 -> GenerateDirExpPoints / GenerateSmokePoints; port the generation as a pure function from the passability tiles). Each tool emits geometry/composite commands with before/after snapshots, including the tree insert/remove from step 2 in the same undo step. Wire it into Sources/editor/resource_core/root.zig and teach fake_bridge.zig the building channels and coupling. Grid tools from grid_tools.zig apply to the building root unchanged.
5. resource_core tests: for each tool, assert readGeometry (and the child count where coupled) before the edit, after it, after undo and after redo. A drag is one undo step, and a cancelled drag leaves no history entry.

Done when: the verify tiers exit 0.

## Inputs

- `Sources/src/EditorBridge/resource_bridge.h`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `Sources/editor/resource_core/bridge.zig`
- `Sources/editor/resource_core/fake_bridge.zig`
- `Sources/editor/resource_core/grid_tools.zig`
- `Sources/editor/resource_core/root.zig`
- `Sources/editor/resource_app/c_bridge.zig`
- `Sources/src/ResourceModel/items/building/building.h`
- `Sources/src/ResourceModel/items/object/object_export.h`
- `Sources/src/ResourceModel/grid_projection.h`
- `Sources/src/editor/BuildFrm.cpp`
- `Sources/src/editor/BuildShoot.cpp`
- `Sources/src/editor/BuildFire.cpp`
- `Sources/src/editor/BuildSmoke.cpp`
- `Sources/src/editor/BuildDirExp.cpp`
- `tools/zig/fixtures/resource_editor/bld/project.bld`

## Expected Output

- `Sources/src/EditorBridge/resource_bridge.h`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `Sources/editor/resource_core/bridge.zig`
- `Sources/editor/resource_core/fake_bridge.zig`
- `Sources/editor/resource_core/point_tools.zig`
- `Sources/editor/resource_core/root.zig`
- `Sources/editor/resource_app/c_bridge.zig`

## Verification

zig build test-resource-core -Dtest-mode=run && zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-app-logic -Dtest-mode=run && zig build test-editor-core -Dtest-mode=run

## Observability Impact

A channel or point op that is refused names the channel, the kind and the reason. An out-of-range point index is BK_EDITOR_BAD_ARGUMENT, with the index in the message.
