---
estimated_steps: 7
estimated_files: 4
skills_used: []
---

# T04: Shipped building round trip, building negative-tile scan, GOG brandenburgertor named test

Why: the slice demo needs an import round trip on shipped data and the GOG INTEX2 brandenburgertor/current.bld golden comparison on win-home, committed as a test name only. Building grids are now tile-frame channels (T02) that use the same negative-tile refusal, so the D021 measurement must cover buildings too.

Do:
1. resource_bridge_test.cpp: add a 'building shipped' case like the object Shipped() (~line 4255). Pick a small building under Data/Buildings (FoldedPath, read-only), copy it to zig-out/local-test, import it with kind 9, export it stats-only, and compare it with the shipped 1.xml through the comparator: nFieldsCompared > 5 and 0 differences. ListingOf(shipped) must be unchanged.
2. Add a 'buildings-negative-tiles' scan, like T01's: every Data/Buildings folder with a 1.xml (about 194), copied, imported, passability/transparency read. Print 'NEGTILES buildings checked=N negative=M' and the offenders. If M > 0 and T01 did not add the origin, apply T01's step 2 (grid origin, append-only) for buildings. Otherwise record the count in the spec's D021 bullet.
3. Add a test named 'bld-gog-brandenburgertor'. It reads BK_GOG_ROOT (the GOG install holding the INTEX2 mod projects) and BK_GOG_GOLDEN (the MFC export of that project made on win-home). If either is unset or missing, it prints 'GOLDEN bld-gog-brandenburgertor pending: BK_GOG_ROOT/BK_GOG_GOLDEN not set (win-home only)' and does not count as a pass. Otherwise it opens <BK_GOG_ROOT>/.../INTEX2/brandenburgertor/current.bld (case-folded), exports it into zig-out/local-test, and compares it with BK_GOG_GOLDEN through the comparator (stats field-equal, _h.dds byte-identical, DDS within dxt-tolerance.json). Never copy or commit GOG files.
4. tools/zig/win-home/export-goldens.ps1: add an optional -GogProject <path> -GogOut <folder> mode. It batch-exports one GOG project into an uncommitted folder and prints the BK_GOG_ROOT/BK_GOG_GOLDEN values to use. Document it in tools/zig/fixtures/resource_editor/bld/golden/README.md.

Done when: the verify tiers exit 0 and the pending line prints.

## Inputs

- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `Sources/src/ResourceModel/items/building/building_export.cpp`
- `Sources/src/ResourceModel/comparator.h`
- `tools/zig/win-home/export-goldens.ps1`
- `tools/zig/fixtures/resource_editor/bld/golden/README.md`
- `tools/zig/fixtures/resource_editor/dxt-tolerance.json`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`

## Expected Output

- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `tools/zig/win-home/export-goldens.ps1`
- `tools/zig/fixtures/resource_editor/bld/golden/README.md`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`

## Verification

zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model-comparator -Dtest-mode=run

## Observability Impact

Prints 'NEGTILES buildings checked=N negative=M' and the GOG pending line with its reason. The comparator lists each differing field.
