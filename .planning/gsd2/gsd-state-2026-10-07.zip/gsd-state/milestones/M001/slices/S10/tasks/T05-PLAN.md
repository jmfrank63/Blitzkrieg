---
estimated_steps: 6
estimated_files: 3
skills_used: []
---

# T05: App: bld grid and point modes, overlay with angle and cone handles, preview wiring

Why: users edit buildings in the app. MFC's CBuildingFrame toolbar (BuildFrm.cpp SetActiveMode 1796, mode handlers 1895-2336) has move object, draw grid, transparency dropdown, entrance, zero, shoot/fire/dir-explosion/smoke point modes, move point, horizontal position, angle, and generate points.

Do:
1. Sources/editor/resource_app/grid_logic.zig: register bld (registrationFor) with the grid tools (passability brush, transparency brush, set zero, move object if T02 gave it a home) and new point Tool entries: entrance, shoot, fire, smoke, dir_explosion, move_point, horizontal, angle, generate. Route press/move/release to resource_core point_tools (T02) through the GridEditor state machine. Add hit-testing for a point, its angle handle and its cone handle in grid coordinates as pure functions, and colours per mode that match MFC's drawing in BuildShoot/BuildFire/BuildSmoke/BuildDirExp.cpp.
2. Sources/editor/resource_app/panels.zig: the toolbar with the bld modes (generate is enabled only in the smoke and dir-explosion modes, as OnUpdateGeneratePoints does) and the overlay: the building sprite preview (preview kind 9), grid, passability and transparency, the entrance, the zero cross, and each point with its direction line and cone arc.
3. App-logic tests (test-resource-app-logic) for registration, hit-testing of points and handles, and a press/drag/release through GridEditor against fake_bridge per point mode, with undo/redo state checked.

Done when: the verify tiers exit 0.

## Inputs

- `Sources/editor/resource_app/grid_logic.zig`
- `Sources/editor/resource_app/panels.zig`
- `Sources/editor/resource_app/main.zig`
- `Sources/editor/resource_core/point_tools.zig`
- `Sources/editor/resource_core/grid_tools.zig`
- `Sources/src/editor/BuildFrm.cpp`
- `Sources/src/editor/BuildShoot.cpp`
- `Sources/src/editor/BuildFire.cpp`
- `Sources/src/editor/BuildSmoke.cpp`
- `Sources/src/editor/BuildDirExp.cpp`

## Expected Output

- `Sources/editor/resource_app/grid_logic.zig`
- `Sources/editor/resource_app/panels.zig`

## Verification

zig build test-resource-app-logic -Dtest-mode=run && zig build test-resource-core -Dtest-mode=run && zig build install-resource-editor && zig build resource-editor-smoke

## Observability Impact

A tool refused by the bridge shows the bridge message in the status line.
