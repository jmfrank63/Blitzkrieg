# S10 Research: Building sub-editor

## 0. Required early task (hard steer 2026-10-05T17:05, D021)

The planner must make this **T01**, before the building tasks. It is a check, not a new slice. Run only the tiers it touches (AGENTS.md).

**T01: Do shipped objects have tiles left of or above (0,0)?** The object tile channels (`passability_cells`, `transparency_cells`) are held in the tile frame, and `TilesToGrid` in `Sources/src/EditorBridge/resource_bridge.cpp` (around line 1219) refuses any tile with a negative X or Y. Fence and bridge lists go through the same function.
1. Write a test that copies the shipped object projects' data from `Data/` (read-only) into `zig-out/local-test/...`. For every shipped object, read the desc grids through `ObjectTiles` (resource_bridge.cpp, around line 1267), which is `LoadRPGStats`' inverse, and report how many objects were checked and whether any yields a tile with a negative X or Y. Never write into `Data/`.
2. If any object does: carry a grid origin in the channel so that object stays editable (extend the channel's ABI blob and the Zig side, append only, per D020), and add a round-trip test on that object (get, set, save, reopen, get; the stored desc is unchanged).
3. If none does: record the count and the result in `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`, keep the refusal, and keep the test as the guard.
Verify: `zig build test-resource-bridge && zig build test-resource-core`.
