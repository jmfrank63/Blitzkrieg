---
estimated_steps: 7
estimated_files: 4
skills_used: []
---

# T06: BK_EDITOR_AUTO bld block with measured shot, PARITY B-09 rows, spec, tier run

Why: the slice demo asks for a preview shot of the building with its passability and points, measured by code, and an auto scenario. Parity and spec must record the evidence.

Do:
1. Sources/editor/resource_app/scenario.zig: add verbs and document them in its header: do=entrance:<x>/<y>, do=point:<mode>/<x>/<y>, do=point_move:<i>/<x>/<y>, do=point_angle:<i>/<deg>, do=point_cone:<i>/<deg>, do=generate_points:<mode>. Each goes through grid_logic and point_tools, the same path as the UI. Reuse S09's grid_cell/grid_trans/grid_zero verbs.
2. build.zig: add a bld block to the resource-editor-auto scenario, copying the obt block's form (~line 8542). Copy the fixture to scratch, open it, draw locked tiles and transparency, set the entrance and zero, place one shoot, fire, smoke and dir-explosion point, turn one angle and cone, undo, redo, save, export into the scratch MOD and capture a shot. Code measures the TGA with kit.auto_schedule.Tga: the locked red, a transparency yellow and the point colours each go above a threshold, and undo of the points removes their colour in a second shot.
3. .planning/phases/06-resource-editor-portable-port/06-PARITY.md: set B-09.1..B-09.15 with evidence (test names, tiers). B-09.14 says 'pending win-home: bld-gog-brandenburgertor'. Repo goldens stay 'pending win-home'. In docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md, update the channel table rows (building tile frame, transparency_cells on the building, any new channel) and add an S10 amendment for the point tools and the point/tree coupling.
4. Run the tiers one at a time from the real shell with XDG_RUNTIME_DIR=/run/user/$UID set; GUI tiers fail inside gsd_exec with SdlInitFailed. In the summary, record that the full sweep is left to the maintainer and that macOS and Windows CI was not seen.

Done when: every verify tier exits 0 and the parity rows and spec are updated.

## Inputs

- `Sources/editor/resource_app/scenario.zig`
- `Sources/editor/resource_app/grid_logic.zig`
- `Sources/editor/resource_core/point_tools.zig`
- `build.zig`
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`

## Expected Output

- `Sources/editor/resource_app/scenario.zig`
- `build.zig`
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`

## Verification

zig build install-resource-editor && zig build resource-editor-auto && zig build resource-editor-smoke && zig build resource-editor-host-check && zig build test-resource-app-logic -Dtest-mode=run && zig build test-resource-core -Dtest-mode=run && zig build test-resource-bridge -Dtest-mode=run && zig build test-editor-core -Dtest-mode=run && zig build map-editor-smoke

## Observability Impact

The auto log prints each shot's measured colour counts and thresholds. A failure names the colour and the shot.
