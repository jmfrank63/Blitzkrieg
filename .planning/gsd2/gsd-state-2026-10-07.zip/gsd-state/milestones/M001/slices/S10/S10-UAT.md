# S10: Building sub-editor — UAT

**Milestone:** M001
**Written:** 2026-10-05T18:26:53.250Z

# S10 UAT

**UAT Type:** automated, Linux x64 headless

## Preconditions
- Linux build environment, XDG_RUNTIME_DIR set, tracked fixtures only.

## Steps
1. Run `zig build test-resource-core`. Expected: exit 0.
2. Run `zig build test-resource-bridge`. Expected: exit 0, S10Building fixture, export, determinism, round-trip and shipped-import checks pass; GOG line prints pending.
3. Run `zig build resource-editor-auto`. Expected: bld block frames 340-399 pass: locked red pixels rise from 12 to 397 and return to 12 after undo; transparency colour 0x606000 rises from 0 to 183 and returns to 0.
4. Run `zig build resource-editor-smoke`. Expected: pass.

## Edge cases
- Missing picture on export reports an error; shipped buildings contain no negative tiles.

## Not Proven By This UAT
- GOG brandenburgertor golden equality and MFC golden parity (win-home only).
- macOS and Windows behaviour (CI only).
- Full resource sweep (maintainer).
