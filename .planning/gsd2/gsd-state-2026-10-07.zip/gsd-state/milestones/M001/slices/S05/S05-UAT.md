# S05: ResourceEditor app shell: all shared features, packaging, CI, BK_EDITOR_AUTO extensions — UAT

**Milestone:** M001
**Written:** 2026-10-05T11:53:30.928Z

# S05 UAT

**UAT Type:** Integration, run on Linux x64 with a display.

## Preconditions
- Linux x64 with a Wayland or X display and the repo at the S05 commit.
- No video device means the GUI tiers cannot run. A skip is logged and is not counted as a pass.

## Steps
1. Run `zig build install-game install-resource-editor install-map-editor`. Expected: exit 0, and `ResourceEditor` is staged beside `Game` and `MapEditor`.
2. Run `zig build resource-editor-host-check -Dtest-mode=run`. Expected: exit 0.
3. Run `zig build resource-editor-smoke -Dtest-mode=run`. Expected: exit 0, with "smoke-edit PASS" and a measured frame.
4. Run `zig build resource-editor-auto -Dtest-mode=run`. Expected: exit 0, with every scenario step passing.
5. Run `zig build test-resource-app-logic test-resource-core test-resource-bridge test-editor-core -Dtest-mode=run`. Expected: exit 0.
6. Run `zig build map-editor-smoke map-editor-auto -Dtest-mode=run`. Expected: exit 0, Map Editor unchanged.
7. Launch ResourceEditor and use New for any kind. Expected: an empty project opens.

## Edge cases
- Run the GUI tiers one at a time. Running several together can race on zig-out.
- A host with no GPU or no video device logs a skip.

## Not Proven By This UAT
- macOS and Windows runs, which CI covers after a push.
- View toggles (A-13), background colour (A-16) and expand/collapse all (A-17), which are not implemented.
- Export for any kind, because no kind has an exporter yet. The auto schedule asserts a refusal.
- The full resource sweep, which is left to the maintainer.
