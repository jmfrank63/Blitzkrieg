---
id: T01
parent: S05
milestone: M001
key_files:
  - Sources/src/EditorBridge/resource_bridge.cpp
  - Sources/src/EditorBridge/resource_bridge_test.cpp
  - docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md
key_decisions:
  - Backups are copies, not moves, so live data/ stays complete until each file is replaced, and a failed backup aborts before anything is touched
  - The backup folder is the sibling .bk-export-backup beside data/ (and beside .bk-export-staging); it is kept only when a restore itself fails, and the message names where it is
  - The failure is forced with a directory in the way at the target, which fails on Linux and Windows alike
duration: 
verification_result: passed
completed_at: 2026-10-05T09:19:13.924Z
blocker_discovered: false
---

# T01: Export promotion from staging into data/ is now all-or-nothing: live files are backed up, and any failed move rolls back every promoted file, new folder and backup, with a message naming the failing file.

**Export promotion from staging into data/ is now all-or-nothing: live files are backed up, and any failed move rolls back every promoted file, new folder and backup, with a message naming the failing file.**

## What Happened

Tests first. I added namespace ExportRollback to Sources/src/EditorBridge/resource_bridge_test.cpp. It runs after T10::Run and writes only under <scratch>/export_rollback. A stand-in mdc exporter stages a configurable file list. In data/ the test pre-populates two replaced files and one unrelated file, and puts a directory (with a file inside) at the second staged file's target. Case 1: the first file replaces a live file, then the second fails. Case 2: the first file is new, in folders that did not exist, then the second fails. For each case the test takes a snapshot of the whole mod folder (relative names plus bytes, folders included) before and after. It asserts the export is FAILED, the message names medals/rb/2-blocked.xml and says "rolled back", the tree is byte-identical, and no .bk-export-staging or .bk-export-backup folder is left. Then it removes the blocking folder and asserts the same export succeeds whole, with no backup left. Before the fix the test failed as expected: 1-replaced.xml had changed, and a-new/deep/0-new.xml and its folders were left behind.

Fix: in Sources/src/EditorBridge/resource_bridge.cpp, the new PromoteStaged replaces the one-by-one rename loop in ExportOne. (1) It copies every live regular file that a staged file will replace into the sibling <exportRoot>/.bk-export-backup. If a backup copy fails, nothing has been touched yet: the backup is removed and the error says nothing was exported. (2) It renames the staged files in sorted order and records the folders it creates. (3) If a move fails, it walks the promoted files in reverse: a file with a backup is restored by renaming the backup over it, and a new file is removed. It then removes the folders it created (deepest first; std::filesystem::remove only deletes empty ones) and the backup folder. The message is "cannot move <file> into <data>: <reason>; the export was rolled back, <data> is as it was". If a restore itself fails, the backup folder is kept and the message names the file and where the originals are. ExportOne always removes staging afterwards. Batch export uses ExportOne too, so it gets the same guarantee.

I recorded the change in the spec (docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md, Export bullet, CRLF). All edits are CRLF, and I made them with exact-string Edits next to T02's concurrent work in the same test file.

## Verification

Before the fix, test-resource-bridge failed on the new export-rollback checks (partial export left in data/). After the fix it passes, including the whole-success follow-up. test-resource-model and test-editor-bridge are also green. The scratch tree after the run shows the final successful export and no staging or backup folders.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 20700ms |
| 2 | `zig build test-resource-model -Dtest-mode=run` | 0 | pass | 20329ms |
| 3 | `zig build test-editor-bridge -Dtest-mode=run` | 0 | pass | 543682ms |

## Deviations

The scratch output is <scratch-root>/export_rollback (zig-out/local-test/resource_editor/t02/export_rollback), next to the tier's other scratch folders, rather than zig-out/local-test/resource_bridge/export_rollback.

## Known Issues

On Windows, restoring a backup relies on std::filesystem::rename replacing an existing file; T04 (save-over-existing) proves that on Windows CI. I did not see Windows or macOS results.

## Files Created/Modified

- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`
