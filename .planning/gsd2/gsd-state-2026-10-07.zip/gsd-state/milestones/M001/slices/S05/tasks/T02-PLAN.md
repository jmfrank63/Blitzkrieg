---
estimated_steps: 1
estimated_files: 2
skills_used: []
---

# T02: Review fix: save over an existing project in test-resource-bridge (D014 item 4)

Source: .gsd/OVERRIDES.md override 2026-10-05T08:37 item 4. Add a case to Sources/src/EditorBridge/resource_bridge_test.cpp where the destination project file already exists (with different content) before BkResSave; assert BkResSave returns OK, the file now holds the new bytes (read back and compare to the expected serialisation), no temp file is left, and the `.bak` behaviour matches what resource_bridge.cpp documents. Also cover saving onto the project's own open path. This makes the Windows CI run prove std::filesystem::rename replaces an existing file; if the safe-save path relies on POSIX rename semantics, make it replace explicitly on Windows (guarded by the backup) and note it. Do not claim the Windows result unless CI is seen. Run only test-resource-bridge and test-resource-model.

## Inputs

- `.gsd/OVERRIDES.md`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`

## Expected Output

- `Save-over-existing test case in test-resource-bridge`

## Verification

zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model -Dtest-mode=run

## Observability Impact

Test log line names the save-over-existing sub-step.
