---
id: T11
parent: S05
milestone: M001
key_files:
  - Sources/editor/resource_app/tools_logic.zig
  - Sources/editor/resource_app/tools_ui.zig
  - Sources/editor/resource_app/batch_cli.zig
  - Sources/editor/resource_app/main.zig
  - Sources/editor/resource_app/settings.zig
  - Sources/editor/resource_app/lifecycle_ui.zig
  - Sources/editor/resource_app/panels_logic.zig
  - Sources/editor/kit/testlaunch.zig
  - build.zig
  - .planning/phases/06-resource-editor-portable-port/06-PARITY.md
  - docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md
key_decisions:
  - kit/testlaunch generalised with Options.profile / Options.map_name (defaults keep the Map Editor's argv); Run Blitzkrieg uses -editor-test, profile ResourceEditorTest, no map, -mod=<export folder name>, and is refused when the export folder is not directly in <BaseRoot>mods/
  - Export is gated by the app's own path (untitled, or a recovery copy) before the bridge is called
  - gamma.cfg is app-side Zig in the engine's tree layout, searched upward like ReadConfigFile; picture values are stored and reported but not yet applied by any exporter
  - Set Directories persists source_folder, game_folder and game_parameters; the export folder stays MOD Settings' own and is not persisted, because re-applying it would rewrite mod.xml
  - --batch runs on a hidden window because BkEditorStart needs a window and a device; exit 0/1/2, and 3 when there is no GPU; unknown flags are refused (MFC ignored them)
  - A batch project counts as failed when BkResBatch names it in a warning, as MFC's errorFiles list did
  - A-23 SaveMapObjects is recorded as 'no behaviour in MFC' (no menu or message-map entry)
duration: 
verification_result: passed
completed_at: 2026-10-05T11:30:31.492Z
blocker_discovered: false
---

# T11: ResourceEditor Tools: MOD Settings, Export / Export Stats Only with report, Compress to PAK, Set Directories, Picture Options + gamma.cfg, Batch Mode dialog and `--batch` CLI (with a resource-editor-batch tier), Run Blitzkrieg F7 through a parameterised kit/testlaunch, and the Editors menu and combo with the last active sub-editor remembered

**ResourceEditor Tools: MOD Settings, Export / Export Stats Only with report, Compress to PAK, Set Directories, Picture Options + gamma.cfg, Batch Mode dialog and `--batch` CLI (with a resource-editor-batch tier), Run Blitzkrieg F7 through a parameterised kit/testlaunch, and the Editors menu and combo with the last active sub-editor remembered**

## What Happened

New files in Sources/editor/resource_app/:
- tools_logic.zig: the pure logic, 12 tests.
  - kindFolder: MFC's szAddDir for each kind.
  - PictureOptions and correctChannel: the engine's CImageProcessor::CreateGammaCorrection ported.
  - gamma.cfg parse and format in the engine's tree layout; findGammaCfg searches upward, as ReadConfigFile did; gammaTarget decides where it is written.
  - exportBlock and runExport: refused by the app's own path (no project, untitled, or a recovery copy, per T09's caveat). formatExportReport lists written, skipped, the warnings and a missing gamma.cfg.
  - withPakExtension.
  - KindMask, parseBatchArgs, listProjects (BkResBatch's order), runBatch and BatchSummary: exported, failed with reasons, other warnings, missing gamma.cfg; exitCode.
  - modFolderForGame: only for a folder directly in <base>mods/. Also gamePath and runGameOptions (profile ResourceEditorTest, no map).
  - rememberActive and shortcutFor.
- batch_cli.zig: --batch and --batch-check.
- tools_ui.zig: ImGui menus, modals, the report window, SDL folder and PAK dialogs, the F7 launch with a non-blocking poll, the Editors menu and the menu-bar combo.

Small targeted edits:
- kit/testlaunch.zig: Options.profile and Options.map_name. Their defaults keep the Map Editor's argv unchanged. ArgvStorage.profile_arg added, plus a new test.
- settings.zig: source_folder and game_folder keys, plus a test.
- lifecycle_ui.zig: a FileMenuHook drawn before Exit.
- main.zig: imports; --batch and --batch-check dispatch through batchMode (hidden host, -mod= applied, args validated before the engine starts); Tools and Editors menus, combo, shortcuts, modals and afterFrame wired in; usage text.
- panels_logic.zig: its test block imports tools_logic.
- build.zig: new resource-editor-batch step.
- 06-PARITY.md: A-08, 09, 10, 12, 18..24 updated. A-23 SaveMapObjects is marked "no behaviour in MFC": it had no menu or message-map entry; its intent (copy the data folders of objects the maps reference) is recorded.
- The spec gets a T11 amendment.

All new and edited files are CRLF and zig-fmt clean. The concurrent T12 edits (docks, Import, Help) were left untouched.

## Verification

Run on Linux x64 only, in the foreground.

Plan verification, all exit 0:
- test-resource-app-logic: 73/73.
- test-map-editor-testlaunch: 24/24.
- install-resource-editor.

Also run:
- resource-editor-batch (new): the 21 fixtures are re-saved byte-identical by -os and reopened as their kind by BkResOpen. The wpn export batch reports "not ported yet" and the missing gamma.cfg. A gamma.cfg at the source root is then found. A shipped Data destination is refused.
- test-editor-kit and test-map-editor-panels, because the kit's testlaunch changed: pass.
- resource-editor-host-check: PASS, docks PASS too.
- Manual CLI runs: `--batch *.unt ... -f` exits 1 with the failure listed; a bad command line exits 2 before the engine starts.
- `--hidden` interactive run with XDG_DATA_HOME and BK_RESOURCE_EDITOR_SETTINGS redirected: PASS, 30 frames.

macOS and Windows were not verified. The full sweep is left to the maintainer.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-app-logic -Dtest-mode=run` | 0 | pass (73/73) | 487ms |
| 2 | `zig build test-map-editor-testlaunch -Dtest-mode=run` | 0 | pass (24/24) | 916ms |
| 3 | `zig build install-resource-editor` | 0 | pass | 3861ms |
| 4 | `zig build resource-editor-batch -Dtest-mode=run` | 0 | pass (21 fixtures re-saved byte-identical and reopened; export report, gamma.cfg, shipped refusal) | 15000ms |
| 5 | `zig build test-editor-kit -Dtest-mode=run` | 0 | pass | 1224ms |
| 6 | `zig build test-map-editor-panels -Dtest-mode=run` | 0 | pass | 4674ms |
| 7 | `zig build resource-editor-host-check -Dtest-mode=run` | 0 | pass | 4706ms |

## Deviations

The batch command line is not fully headless: it opens a hidden, never focused window, because BkEditorStart requires a window and a GPU device. Batch Mode runs inside one frame with no live progress, since BkResBatch has no progress callback. The export folder is session-only rather than saved in the settings file. lifecycle_ui.zig got a small hook (FileMenuHook) so the File menu items sit before Exit. A resource-editor-batch build step was added beyond the plan's verification list.

## Known Issues

No real exporter is registered yet, so the end-to-end proof of exported files covers the -os re-save, and the export batch proves the reporting path only. The batch-check accepts an exporter appearing later. Exporter warnings would also be listed under failed, because BkResBatch's text does not tell them apart. The interactive dialogs (MOD, Set Directories, Picture Options, Batch, PAK, F7) were not driven by scripted input; T13's auto scenarios should cover them. macOS and Windows were not verified.

## Files Created/Modified

- `Sources/editor/resource_app/tools_logic.zig`
- `Sources/editor/resource_app/tools_ui.zig`
- `Sources/editor/resource_app/batch_cli.zig`
- `Sources/editor/resource_app/main.zig`
- `Sources/editor/resource_app/settings.zig`
- `Sources/editor/resource_app/lifecycle_ui.zig`
- `Sources/editor/resource_app/panels_logic.zig`
- `Sources/editor/kit/testlaunch.zig`
- `build.zig`
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`
