---
id: T13
parent: S05
milestone: M001
key_files:
  - Sources/editor/resource_app/scenario.zig
  - Sources/editor/resource_app/main.zig
  - build.zig
  - .github/workflows/cross-platform.yml
  - .planning/phases/06-resource-editor-portable-port/06-PARITY.md
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-05T11:41:12.990Z
blocker_discovered: false
---

# T13: ResourceEditor now has resource-editor-smoke and resource-editor-auto tiers (new, open, set_prop, undo, save, pack, import, run_game, with captured frames measured by code), CI steps on Windows MSVC and macOS arm64, and 13 parity rows updated.

**ResourceEditor now has resource-editor-smoke and resource-editor-auto tiers (new, open, set_prop, undo, save, pack, import, run_game, with captured frames measured by code), CI steps on Windows MSVC and macOS arm64, and 13 parity rows updated.**

## What Happened

The previous session had already written scenario.zig, the --smoke-edit and --auto modes in main.zig, and the build.zig steps. I verified they build and pass on Linux. resource-editor-smoke runs the kind-level new/save/reopen, then --smoke-edit, which opens a copy of the tracked .unt, edits Armor 4 to 5, saves, undoes and saves, and compares the original 54385 bytes. resource-editor-auto runs a 37-entry BK_EDITOR_AUTO schedule over the resource command registry: new:wpn, open, set_prop, save, undo, pack (read back by the engine's PAK reader), import:unt and run_game (the real Game with -mod). Shots are measured by code (39.8% drawn; 0.13% differ between new and opened). Export is asserted as refused by name, because no kind has an exporter yet; a tracked .obj stands in as mod content for pack and run. I added install-resource-editor, host-check, smoke and auto steps to cross-platform.yml for Windows MSVC and macOS arm64 beside the map-editor steps (CRLF kept, YAML parses). In 06-PARITY.md, A-01..07, A-11, A-37 and A-39 are now done with evidence. A-13, A-16 and A-17 stay todo with a reason (View toggles, background colour, expand/collapse all were in no S05 task). Only Linux x64 was run; macOS and Windows are left to CI, and the full resource sweep is left to the maintainer.

## Verification

Ran resource-editor-host-check, resource-editor-smoke and resource-editor-auto with -Dtest-mode=run, then map-editor-smoke, map-editor-auto, test-resource-app-logic and test-editor-core. All passed on Linux x64. Logs and TGAs are under zig-out/local-test/resource_editor/.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build resource-editor-host-check resource-editor-smoke resource-editor-auto -Dtest-mode=run` | 0 | pass | 19900ms |
| 2 | `zig build map-editor-smoke map-editor-auto test-resource-app-logic -Dtest-mode=run` | 0 | pass | 34000ms |
| 3 | `zig build test-editor-core -Dtest-mode=run` | 0 | pass | 2000ms |

## Deviations

None.

## Known Issues

A-13 (View toggles), A-16 (background colour) and A-17 (expand/collapse all) are not implemented. The Export step in the auto schedule asserts a refusal until the first kind gets an exporter. macOS and Windows CI steps were not run here.

## Files Created/Modified

- `Sources/editor/resource_app/scenario.zig`
- `Sources/editor/resource_app/main.zig`
- `build.zig`
- `.github/workflows/cross-platform.yml`
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`
