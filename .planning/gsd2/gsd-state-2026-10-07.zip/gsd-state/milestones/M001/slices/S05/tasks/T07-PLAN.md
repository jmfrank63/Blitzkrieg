---
estimated_steps: 1
estimated_files: 3
skills_used: []
---

# T07: App skeleton: build, stage, host-check on Linux

See S05-RESEARCH.md (Build wiring, Packaging). Create Sources/editor/resource_app/ (main.zig with --check/--smoke/--hidden modes, crt main export) and add addResourceEditor in build.zig modelled on addMapEditor (rdynamic + $ORIGIN rpath on Linux, @executable_path on macOS, Windows mainCRTStartup/.windows/linkMsvcRuntime, same platform gate as the map editor), a target-specific resource_core module importing editor_kit, steps install-resource-editor and resource-editor-host-check (hidden window SDL_WINDOW_HIDDEN|SDL_WINDOW_NOT_FOCUSABLE, BkResNew(kind), ImGui over the engine frame, TGA measured by code). Add --resource-editor to tools/zig/stage.zig (copyResourceEditor + requireStagedFile) and wire it into the package steps; add a staging test. Run install-game install-resource-editor install-map-editor, resource-editor-host-check, map-editor-host-check.

## Inputs

- `.gsd/milestones/M001/slices/S05/S05-RESEARCH.md`
- `build.zig`

## Expected Output

- `ResourceEditor builds and stages beside Game and MapEditor`
- `resource-editor-host-check green on Linux`

## Verification

zig build install-game install-resource-editor install-map-editor && zig build resource-editor-host-check -Dtest-mode=run && zig build map-editor-host-check -Dtest-mode=run

## Observability Impact

host-check captured TGA under zig-out/local-test/resource_editor/
