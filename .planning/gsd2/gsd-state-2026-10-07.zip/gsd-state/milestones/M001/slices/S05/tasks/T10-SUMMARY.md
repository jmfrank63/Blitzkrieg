---
id: T10
parent: S05
milestone: M001
key_files:
  - Sources/editor/resource_app/edit_logic.zig
  - Sources/editor/resource_app/panels.zig
  - Sources/editor/resource_app/main.zig
  - Sources/editor/resource_app/panels_logic.zig
  - Sources/editor/resource_app/c_bridge.zig
  - Sources/editor/resource_core/bridge.zig
  - Sources/editor/resource_core/fake_bridge.zig
  - Sources/editor/resource_core/history.zig
  - Sources/editor/resource_core/document.zig
  - Sources/src/EditorBridge/resource_bridge.h
  - Sources/src/EditorBridge/resource_bridge.cpp
  - Sources/src/EditorBridge/resource_bridge_test.cpp
  - docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md
  - .planning/phases/06-resource-editor-portable-port/06-PARITY.md
key_decisions:
  - Added BkResSetNodeName, BkResSetNodeExpand and BkResPropStrings to the C ABI. Without them the bridge could not rename, persist the expand state, or read combo/bool/browse strings.
  - BkResRefList type 5 answers actions.ini with action-id tokens (CMultySelDialog's list), because MFC's reference dialog never filled that list.
  - Expand is view state: persisted, but not an undo step and not dirtying, as in MFC.
  - Insert offers the class the container already holds. An empty container offers nothing until its sub-editor slice (S06..S15) provides the class.
  - A multi-select inspector edit writes every selected node of the primary's class that has the property, as one composite step.
  - Edit logic lives in a new edit_logic.zig rather than panels_logic.zig, to avoid colliding with T09's concurrent edits. Its tests are included through panels_logic's test block.
duration: 
verification_result: passed
completed_at: 2026-10-05T11:11:43.797Z
blocker_discovered: false
---

# T10: Project tree, object inspector and the reference, multi-select and browse pickers in the ResourceEditor. Every edit is an undoable ResourceCommand, and one gesture collapses to one undo step that respects the save mark. Three new bridge entries back these features (rename, expand, a property's strings), and the actions list now comes from actions.ini.

**Project tree, object inspector and the reference, multi-select and browse pickers in the ResourceEditor. Every edit is an undoable ResourceCommand, and one gesture collapses to one undo step that respects the save mark. Three new bridge entries back these features (rename, expand, a property's strings), and the actions list now comes from actions.ini.**

## What Happened

The plan named only panels.zig and panels_logic.zig, but the bridge was missing three things this task needed. It had no way to rename a node, no way to save the expand state, and no way to read combo, bool or browse strings (it only reported their count). MFC's actions list for CMultySelDialog was also never filled. So the C ABI was extended:
- BkResSetNodeName: ChangeItemName. It sets display_name only, and a name too long for the 64-byte record is refused, not cut.
- BkResSetNodeExpand: sets the item's expand attribute. BkResNodes now reports it; before, it always answered 0.
- BkResPropStrings: two-pass read of SProp::szStrings.
- BkResRefList type 5 (E_ACTIONS_REF) now answers Data/Editor/actions.ini through LoadActionCommands, with each action's id as the token (the bit of the mask).

These are implemented in resource_bridge.cpp and tested in resource_bridge_test.cpp: rename, expand and strings with save+reopen and refusals, and the actions list compared with BkEditorActionCommands.

On the Zig side:
- ResBridge has three new vtable entries (setNodeName, setNodeExpand, propStrings), implemented in fake_bridge.zig and c_bridge.zig. The fake can now store prop strings through setPropStrings.
- ResourceCommand has a new rename_node variant, handled in document.zig's apply, undo and redo.

New Sources/editor/resource_app/edit_logic.zig (pure, 15 tests through FakeResBridge):
- Domain/ValueKind/RefType enums. refTypeFor follows MFC's ConvertFromDomenTypeToRef for all 20 lists, including the two swapped pairs. widgetFor gives every DT_* domain its widget.
- Typed values are checked before BkResSetProp (dec, hex, float, int64). Combo, bool and colour values are written in the form each value kind is stored in (COLORREF, with the high byte kept). Action masks are read and written in the variant's text.
- browseValue makes the chosen path relative to the property's source folder, else to the project folder, lower case with backslashes.
- Tree helpers: placeOf, childAt, insertClassFor, dropPlace.
- Selection: Ctrl toggles, Shift selects a range, prune removes nodes that no longer exist.
- editTargets: a multi-select edit applies to every selected node of the primary's class that has the property.
- Edits through a Target (allocator, bridge, document, history, read_only):
  - setProp: merges within one gesture. When the value comes back to where the step began, the step is dropped, and so is the unsaved mark if that was the saved state. Several nodes are written as one composite step.
  - rename, insert, deleteNodes (one composite; skips the root and nodes under another deleted node; rolls back on a refusal part-way), move/moveBy, undo/redo.
  - setExpand is view state: kept and saved, but no undo step and no unsaved change, as in MFC.
- shortcutFor maps Ctrl+Z, Ctrl+Y, Ctrl+Shift+Z, Delete, Insert and F2.
- RefLists caches the lists and is cleared on a mod switch. filterEntries filters case-insensitively.

New Sources/editor/resource_app/panels.zig (ImGui):
- Tree window: expand state drives SetNextItemOpen. Ctrl/Shift multi-select, drag and drop, and a context menu with Insert item, Delete item, Rename item, Move up and Move down. Rename is a modal.
- Properties window: one widget per domain (edit boxes commit when they lose the keyboard; the colour drag is one gesture).
- A searchable reference picker modal, the actions multi-select with checkboxes, and SDL file/folder dialogs for browse.
- Edit menu items and shortcuts.

Small targeted edits elsewhere:
- main.zig (T09's interactive loop): adds the Edit menu, calls panels.handleShortcuts and panels.draw, and drops the skeleton's tree window in interactive mode. check and smoke still use their own drawTree.
- panels_logic.zig: its test block now imports edit_logic.zig.

Docs: an amendment was appended to the phase 6 spec, and parity rows A-27..A-34 and A-38 were updated with evidence.

## Verification

Run on Linux x64 only:
- zig build test-resource-app-logic -Dtest-mode=run: 48/48 pass (15 new edit_logic tests).
- zig build install-resource-editor: exit 0.
- test-resource-bridge: Project+Tree OK; the new tree, actions and strings checks pass.
- test-resource-core, test-resource-model and test-editor-bridge: PASS. libEditorBridge is shared with the Map Editor, so test-editor-bridge was run too.
- resource-editor-host-check: PASS.
- A --hidden interactive run on a wpn fixture copy drew the new panels against the real bridge for 30 frames: PASS.
- macOS and Windows were not verified. The full sweep is left to the maintainer.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-app-logic -Dtest-mode=run` | 0 | pass (48/48) | 463ms |
| 2 | `zig build install-resource-editor` | 0 | pass | 3879ms |
| 3 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 19480ms |
| 4 | `zig build test-resource-core -Dtest-mode=run` | 0 | pass | 430ms |
| 5 | `zig build test-resource-model -Dtest-mode=run` | 0 | pass | 20327ms |
| 6 | `zig build test-editor-bridge -Dtest-mode=run` | 0 | pass | 545415ms |
| 7 | `zig build resource-editor-host-check -Dtest-mode=run` | 0 | pass | 4703ms |
| 8 | `ResourceEditor --hidden <copy of wpn fixture>` | 0 | pass (30 frames) | 10000ms |

## Deviations

The plan listed only panels.zig and panels_logic.zig. Bridge gaps meant the C ABI, the resource_core bridge, the fake and c_bridge also had to change, and a ResourceCommand variant (rename_node) was added. The pure logic is in a new edit_logic.zig instead of panels_logic.zig.

## Known Issues

- The UI interactions (click, drag, pickers) are exercised only by the logic tests and a hidden-frame run, not by scripted UI input; T13's auto scenarios cover that.
- Per-container insert classes for empty containers are left to the sub-editor slices.
- The browse dialog passes no file filter (MFC's szStrings[1] filter is not mapped to SDL filters yet).
- The fake's moveNode does not reorder siblings, so the order after a move is only checked against the real bridge.

## Files Created/Modified

- `Sources/editor/resource_app/edit_logic.zig`
- `Sources/editor/resource_app/panels.zig`
- `Sources/editor/resource_app/main.zig`
- `Sources/editor/resource_app/panels_logic.zig`
- `Sources/editor/resource_app/c_bridge.zig`
- `Sources/editor/resource_core/bridge.zig`
- `Sources/editor/resource_core/fake_bridge.zig`
- `Sources/editor/resource_core/history.zig`
- `Sources/editor/resource_core/document.zig`
- `Sources/src/EditorBridge/resource_bridge.h`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`
