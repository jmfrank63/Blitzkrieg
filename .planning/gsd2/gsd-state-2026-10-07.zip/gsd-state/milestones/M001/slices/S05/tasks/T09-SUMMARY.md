---
id: T09
parent: S05
milestone: M001
key_files:
  - Sources/editor/resource_app/lifecycle.zig
  - Sources/editor/resource_app/lifecycle_ui.zig
  - Sources/editor/resource_app/settings.zig
  - Sources/editor/resource_app/main.zig
  - Sources/editor/resource_app/panels_logic.zig
  - Sources/editor/kit/settings.zig
  - build.zig
  - docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md
key_decisions:
  - The kit settings were split into shared helpers (applySharedKey, writeSharedHeadKeys/TailKeys) rather than copied; mapeditor.cfg's bytes are asserted unchanged
  - resourceeditor.cfg leaves out default_format and maps_folder and adds last_editor and projects_folder; the other section-5 settings come with T11/T12
  - The one-.bak-per-session rule is enforced app-side around BkResSave via kit Files, because BkResSave rewrites .bak on every save
  - Recovery copies are written with BkResSave into <UserRoot>resourceeditor/recovery, with a .txt sidecar; a reopened copy stays on Save As
  - --hidden runs never read or write settings, layout, the recovery folder or autosave
  - The lifecycle tests are pulled into test-resource-app-logic by a test block in panels_logic.zig, keeping the build.zig edit minimal
duration: 
verification_result: passed
completed_at: 2026-10-05T10:59:16.887Z
blocker_discovered: false
---

# T09: ResourceEditor File menu lifecycle: New (all 21 kinds), Open, Open Recent, Close, Save and Save As, with safe save and one .bak per session, shipped paths forced to Save As, the locked_<user> prompt with take-over, the unsaved-changes prompt on close and exit, and autosave with recovery under <UserRoot>resourceeditor/. resourceeditor.cfg shares the kit's generic keys, the BK_RESOURCE_EDITOR_SETTINGS seam is in the spec, and layout.ini sits beside the settings file.

**ResourceEditor File menu lifecycle: New (all 21 kinds), Open, Open Recent, Close, Save and Save As, with safe save and one .bak per session, shipped paths forced to Save As, the locked_<user> prompt with take-over, the unsaved-changes prompt on close and exit, and autosave with recovery under <UserRoot>resourceeditor/. resourceeditor.cfg shares the kit's generic keys, the BK_RESOURCE_EDITOR_SETTINGS seam is in the spec, and layout.ini sits beside the settings file.**

## What Happened

New files in Sources/editor/resource_app/:
- settings.zig: resourceeditor.cfg. It shares the kit's editor-neutral keys and adds last_editor and projects_folder. It also resolves the settings path (BK_RESOURCE_EDITOR_SETTINGS, else <user_root>resourceeditor/resourceeditor.cfg) and the layout.ini path.
- lifecycle.zig: a pure Session state machine over ResBridge plus kit Files. It covers request/guard/perform for New/Open/Close/Quit/switch-editor, Save routing (Save As when there is no path, the project is read-only, the path is shipped, or the project is a reopened recovery copy), and refusal of Save As into shipped data. Save As adds the kind's extension when it is missing. It also keeps the recent list (a recent entry that fails to open is dropped), the lock prompt with take-over, and SessionBackups: BkResSave copies to .bak on every save, so the app moves the session's .bak aside and back to keep MFC/phase-3's one .bak per file per session. Autosave uses kit autosave: into the project's own file when it is writable, otherwise a recovery copy under <user_root>resourceeditor/recovery/<stem>.<ext> plus a .txt sidecar. Recovery offers are parsed here too.
- lifecycle_ui.zig: the ImGui/SDL glue. It draws the File menu and Ctrl/Cmd+O/S/Shift+S, shows the SDL file dialogs (filters for all kinds, or the current kind on Save As), and draws the unsaved, lock and recovery modals, a status line and a window title with the dirty mark. It also reads and writes the settings file (temp file plus rename), enables layout.ini persistence, scans recovery at start-up and writes sidecars.

main.zig changes:
- The interactive mode now runs on lifecycle_ui over c_bridge.RealResBridge, so c_bridge is now linked into ResourceEditor.
- It accepts <kind> or <project> on the command line. With neither, it starts a new project of the remembered sub-editor (default Infantry).
- Window close goes through the unsaved-changes prompt.
- --hidden never touches the user's settings, layout, recovery folder or autosave.

kit/settings.zig: applyGenericKey, writeGenericKeys and writeGenericTailKeys are now built from the new applySharedKey, writeSharedHeadKeys and writeSharedTailKeys. A new kit test asserts the mapeditor.cfg bytes and order are unchanged.

build.zig: test-resource-app-logic now also imports editor_kit. panels_logic.zig gained a test block that pulls in the lifecycle.zig and settings.zig tests.

Spec amendment added recording the settings file, the seam, layout.ini, the recovery folder and sidecar, the .bak rule, and the caveat that a recovery write moves the bridge's own path. Because of that caveat, T11's Export must check the app's path.

All new and edited files are CRLF. T10's files were not touched.

## Verification

Ran in the foreground on Linux x64.

Plan verification, all exit 0:
- test-resource-app-logic (now 33 tests, including 16 new lifecycle tests and 4 new settings tests)
- test-editor-core
- test-map-editor-panels

Because kit/settings.zig changed, also ran (all exit 0):
- test-editor-kit
- test-map-editor-view, test-map-editor-testlaunch, test-map-editor-auto, test-map-editor-engine
- map-editor-host-check
- resource-editor-host-check (PASS, vulkan 1280x800)

install-resource-editor builds. ResourceEditor --hidden passed in three cases, with XDG_DATA_HOME and BK_RESOURCE_EDITOR_SETTINGS redirected under zig-out/local-test: no argument (it started on the unt default), scp, and a copied wpn fixture opened by path. No locked_ file was left behind and nothing was written under resourceeditor/.

The visible interactive mode (dialogs, persistence on disk) was not driven by a person or a script. Its logic is proved through FakeResBridge and FakeFiles; T13's smoke/auto will drive the real UI.

Full sweep left to the maintainer.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-app-logic -Dtest-mode=run` | 0 | pass | 1247ms |
| 2 | `zig build test-editor-core -Dtest-mode=run` | 0 | pass | 1142ms |
| 3 | `zig build test-map-editor-panels -Dtest-mode=run` | 0 | pass | 4694ms |
| 4 | `zig build test-editor-kit -Dtest-mode=run` | 0 | pass | 455ms |
| 5 | `zig build test-map-editor-view -Dtest-mode=run` | 0 | pass | 1495ms |
| 6 | `zig build test-map-editor-testlaunch -Dtest-mode=run` | 0 | pass | 293ms |
| 7 | `zig build test-map-editor-auto -Dtest-mode=run` | 0 | pass | 307ms |
| 8 | `zig build test-map-editor-engine -Dtest-mode=run` | 0 | pass | 31203ms |
| 9 | `zig build map-editor-host-check -Dtest-mode=run` | 0 | pass | 21682ms |
| 10 | `zig build resource-editor-host-check -Dtest-mode=run` | 0 | pass | 6844ms |

## Deviations

The plan named settings.zig and panels_logic.zig as the edit points. The lifecycle logic went into a new lifecycle.zig and the UI into lifecycle_ui.zig instead, to avoid conflicts with T10, which was editing panels_logic.zig and panels.zig at the same time. In the fake bridge test for a reopened recovery copy, the kind is checked through the offer: the fake's files carry no kind and reopen as weapons.

## Known Issues

A recovery-copy write goes through BkResSave, which moves the bridge's internal path to the copy. The app's path stays authoritative, but T11's Export must refuse an untitled project by the app's path. Persistent interactive I/O (real dialogs, settings on disk) has not been run with a visible window; T13's smoke/auto should cover it.

## Files Created/Modified

- `Sources/editor/resource_app/lifecycle.zig`
- `Sources/editor/resource_app/lifecycle_ui.zig`
- `Sources/editor/resource_app/settings.zig`
- `Sources/editor/resource_app/main.zig`
- `Sources/editor/resource_app/panels_logic.zig`
- `Sources/editor/kit/settings.zig`
- `build.zig`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`
