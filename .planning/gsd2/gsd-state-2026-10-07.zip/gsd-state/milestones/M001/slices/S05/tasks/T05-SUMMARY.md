---
id: T05
parent: S05
milestone: M001
key_files:
  - Sources/src/EditorBridge/resource_bridge.cpp
  - Sources/src/EditorBridge/resource_bridge_test.cpp
  - tools/zig/fixtures/resource_editor/preview-scene/particle.tga
  - tools/zig/fixtures/resource_editor/preview-scene/effect.tga
  - tools/zig/fixtures/resource_editor/preview-scene/preview-scene.md
key_decisions:
  - The particle-source preview wraps the exported source in a one-item effect, as MFC's CParticleFrame did, because IVisObjBuilder has no particle vis type
  - The wrapper XML is written by hand in SEffectDesc's layout because EditorBridge does not link Formats
  - No Zig change: BkResKind already covers pcp and the fake bridge is kind-agnostic
  - The stand-in source is flame.xml; smokeofflame.xml drew no measurable pixels
duration: 
verification_result: passed
completed_at: 2026-10-05T10:19:22.853Z
blocker_discovered: false
---

# T05: BkResPreviewBegin/Show now preview a .pcp particle source (wrapped in a one-item effect as CParticleFrame did); test-resource-bridge captures it against pcp/project.pcp with the 1% gate, committed as particle.tga, with the .eff capture kept as effect.tga

**BkResPreviewBegin/Show now preview a .pcp particle source (wrapped in a one-item effect as CParticleFrame did); test-resource-bridge captures it against pcp/project.pcp with the 1% gate, committed as particle.tga, with the .eff capture kept as effect.tga**

## What Happened

Added a particle-source preview kind (pcp, kind 11) to kPreviewKinds in resource_bridge.cpp with a bParticleSource flag. IVisObjBuilder has no particle vis type, so ShowPreview does what CParticleFrame::OnRunButton/CreateEffectDescriptionFile did: after the exporter writes the source, WrapParticleSource writes editor\preview\particle_source_effect.xml in SEffectDesc's layout (start 0, duration 2x the project's Life time, position and scale from the ETIT_PARTICLE_COMMON_PROPS_ITEM slots 1,2,4..6) and builds it as SGVOT_EFFECT. The XML is written by hand because the EditorBridge archive does not link Formats; the format matches shipped Effects\Effects\*.xml, including the scale attribute, and the engine's own builder reading it proves it. MFC's complex-source (smokin) toggle is frame state, not project data, so the plain key-based source is used. The Zig side needed no change: BkResKind is the shared int kind and pcp already exists; fake_bridge ignores the kind. In resource_bridge_test.cpp T11, a ParticleSourceExporter stand-in copies the shipped Effects/Particles/flame.xml. The captures are now particle (pcp/project.pcp) and effect (eff/project.eff, the extra). Both use the same >=1% non-black-non-magenta gate and the >=0.1% changed-vs-empty gate, measured in code and logged per kind in preview.log. The old preview-scene/particle.tga (from the .eff) was moved to effect.tga, and the new pcp capture was committed as particle.tga. preview-scene.md gained an S05 section with the measured shares and the fixture behind each capture. A trial with smokeofflame.xml changed 0 pixels and failed the drew gate, so flame.xml was kept; this also shows the gate catches a source that draws nothing visible.

## Verification

All three tiers named in the plan pass on Linux x64. test-resource-bridge logged particle (pcp) non-black-non-magenta=0.250 changed-vs-empty=0.0019 and effect (eff) 0.291 / 0.030, with mesh 0.265 and sprite 0.307 unchanged. test-resource-core and test-editor-bridge are green. The full sweep is left to the maintainer.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 30000ms |
| 2 | `zig build test-resource-core -Dtest-mode=run` | 0 | pass | 443ms |
| 3 | `zig build test-editor-bridge -Dtest-mode=run` | 0 | pass | 551393ms |

## Deviations

No Zig mirror was needed because the kind enum already includes pcp. The fixture rename was staged with git mv, an index-only rename with no commit.

## Known Issues

The particle capture's changed-vs-empty share (0.0019) is about 2x the 0.1% gate, because the flame source is small after one second. Another GPU could draw it closer to the gate.

## Files Created/Modified

- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `tools/zig/fixtures/resource_editor/preview-scene/particle.tga`
- `tools/zig/fixtures/resource_editor/preview-scene/effect.tga`
- `tools/zig/fixtures/resource_editor/preview-scene/preview-scene.md`
