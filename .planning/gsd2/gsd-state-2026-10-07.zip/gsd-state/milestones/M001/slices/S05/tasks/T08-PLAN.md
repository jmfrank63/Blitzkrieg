---
estimated_steps: 1
estimated_files: 3
skills_used: []
---

# T08: Real bridge adapter and headless app-logic tier

Add Sources/editor/resource_app/c_bridge.zig implementing resource_core.bridge.ResBridge over @cImport(resource_bridge.h) (Project, Tree, Props, Refs, Export, MOD, Preview, Import, geometry get/set). Add panels_logic.zig (pure: document lifecycle state, menu enablement, unsaved-changes prompts, editors list in MFC order) tested through FakeResBridge as a new test-resource-app-logic step that builds on every target like test-resource-core. Run test-resource-app-logic, test-resource-core, install-resource-editor.

## Inputs

- `Sources/editor/resource_core/bridge.zig`
- `Sources/src/EditorBridge/resource_bridge.h`

## Expected Output

- `c_bridge.zig`
- `panels_logic.zig + test-resource-app-logic tier`

## Verification

zig build test-resource-app-logic -Dtest-mode=run && zig build test-resource-core -Dtest-mode=run && zig build install-resource-editor
