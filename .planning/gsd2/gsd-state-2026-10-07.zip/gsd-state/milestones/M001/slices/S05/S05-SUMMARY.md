---
id: S05
parent: M001
milestone: M001
provides:
  - (none)
requires:
  []
affects:
  []
key_files:
  - Sources/editor/resource_app/main.zig
  - Sources/editor/resource_app/scenario.zig
  - build.zig
  - .github/workflows/cross-platform.yml
  - .planning/phases/06-resource-editor-portable-port/06-PARITY.md
key_decisions: []
patterns_established:
  - (none)
observability_surfaces:
  - none
drill_down_paths:
  []
duration: ""
verification_result: passed
completed_at: 2026-10-05T11:53:30.916Z
blocker_discovered: false
---

# S05: ResourceEditor app shell: all shared features, packaging, CI, BK_EDITOR_AUTO extensions

**The ResourceEditor app shell builds, stages and passes host-check/smoke/auto on Linux x64, with the S04 review findings fixed first and CI steps added for Windows MSVC and macOS arm64.**

## What Happened

T01-T06 closed the four S04 review findings (D014): export promotion is all-or-nothing, geometry is written in MFC's own layout with no _bk_geometry anywhere, a particle-source preview kind is captured against the .pcp fixture, and test-resource-bridge saves over an existing project. T07-T12 built Sources/editor/resource_app/ over the kit, resource_core and the BkRes* bridge: the app skeleton with install and staging, the real bridge adapter with the headless app-logic tier, document lifecycle (safe save, .bak, autosave, recovery, locking), project tree, inspector and reference pickers, tools (MOD settings, Export, PAK, directories, picture options, batch CLI, Run Blitzkrieg, Editors menu) and the docks, preview background, Import, Help and About. T13 added the resource-editor-smoke and resource-editor-auto tiers (new, open, set_prop, undo, save, pack, import, run_game, with captured frames measured by code), the CI steps for Windows MSVC and macOS arm64, and 13 updated 06-PARITY.md rows.

## Verification

Fresh run on Linux x64: install-game, install-resource-editor and install-map-editor build. resource-editor-host-check, -smoke and -auto, map-editor-smoke and map-editor-auto exit 0, run one step at a time from the shell. test-resource-app-logic, test-resource-core, test-resource-bridge and test-editor-core exit 0. No _bk_geometry remains in Sources/src/EditorBridge. The CI workflow contains the resource-editor install, host-check, smoke and auto steps. Under the gsd_exec sandbox the GUI tiers fail with "SdlInitFailed: No available video device", and the untouched Map Editor tiers fail the same way, so this is an environment limit and not a regression. macOS and Windows CI results were not seen. The full resource sweep is left to the maintainer.

## Requirements Advanced

None.

## Requirements Validated

None.

## New Requirements Surfaced

None.

## Requirements Invalidated or Re-scoped

None.

## Operational Readiness

None.

## Deviations

None.

## Known Limitations

A-13 View toggles, A-16 background colour and A-17 expand/collapse all are not implemented. Export is only asserted as a refusal until the first sub-editor kind gets an exporter. macOS and Windows CI were not run here.

## Follow-ups

None.

## Files Created/Modified

None.
