---
estimated_steps: 1
estimated_files: 2
skills_used: []
---

# T01: Review fix: all-or-nothing export promotion (D-09, D014 item 1)

Source: .gsd/OVERRIDES.md override 2026-10-05T08:37 item 1, decision D014, spec D-09. Tests first in resource_bridge_test.cpp. In Sources/src/EditorBridge/resource_bridge.cpp (export promotion loop ~line 2318, the FilesBelow(staging) rename loop) make promotion all-or-nothing: before moving anything, back up every live file that will be replaced (e.g. into a sibling `.bk-export-backup` folder), then move all staged files; on any failure move every already-promoted file back out (delete files that did not exist before), restore every backup, remove staging/backup, and return an error naming the failing file and that the export was rolled back. Test: register a test exporter (the existing `mdc` GoodExporter pattern) producing >= 3 files, pre-populate the export root under zig-out/local-test with known content for some of them, force the second file to fail (a directory in the way at its target path, or a read-only parent; prefer directory-in-the-way since it fails on Linux and Windows alike), then assert the export root is byte-identical to before (walk the tree, compare names + bytes) and no staging/backup folder is left. Keep the existing success-path tests green. Run only: test-resource-bridge, test-resource-model, test-editor-bridge.

## Inputs

- `.gsd/OVERRIDES.md`
- `.gsd/DECISIONS.md`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`

## Expected Output

- `Atomic promotion with backup+rollback in resource_bridge.cpp`
- `Forced second-file failure test proving byte-identical export root`

## Verification

zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model -Dtest-mode=run && zig build test-editor-bridge -Dtest-mode=run

## Observability Impact

BkEditorLastMessage names the failing file and states the rollback.
