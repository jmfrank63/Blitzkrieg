# S05 Research: ResourceEditor app shell

**Depth: targeted.** The technology is known (Zig 0.16, ImGui, the BkRes* C ABI). The work is new to this app, but the map editor is a complete template. Nothing in `Sources/editor/resource_app/` exists yet.

## Summary

S05 is the Zig+ImGui app `ResourceEditor` over what S02-S04 delivered. The inputs are:
- `Sources/editor/kit/` (host, files, shipped, autosave, history, settings, auto_schedule, testlaunch, pictures_cache, crt, imgui)
- `Sources/editor/resource_core/` (`bridge.zig` ResBridge, `document.zig`, `history.zig` ResourceCommand, `fake_bridge.zig`)
- `Sources/src/EditorBridge/resource_bridge.{h,cpp}` (`BkRes*`, `BkResSession == BkEditorSession`)

Mirror `Sources/editor/app` (MapEditor, about 41k lines in total, `main.zig` 1297, `panels.zig` 4605, `smoke.zig` 2159) in structure, but keep the app small. Sub-editor-specific tools belong to S06-S15; S05 only builds the shared shell.

The main risk is the size of the UI surface: A-01..A-39 in `06-PARITY.md`. The second risk is that a few shell features have no bridge function yet (see Gaps).

## Implementation Landscape

### Build wiring (build.zig, ~8000+ lines)

- `addMapEditor` (build.zig:6348) is the template. It builds sdl_module (translate-c of SDL, no libc), kit_module, core_module, then the exe via `mapEditorModule(...)` (:8002) and `configureMapEditorExecutable` (:8065).
  - Linux/macOS: `rdynamic` and an `$ORIGIN` / `@executable_path` rpath. Windows: `mainCRTStartup` entry, `.windows` subsystem, `linkMsvcRuntime`, plus the COM/winmm/etc. system libs.
  - It installs beside Game into `stage_suffix`, with `install_exe.step.dependOn(install_game_step)`.
  - It creates the steps `install-map-editor`, `map-editor-host-check`, `-smoke`, `-auto`, ... (`--check`, `--smoke`, `--hidden` modes, `BK_EDITOR_AUTO_DIR`, `BK_EDITOR_AUTO`, `BK_EDITOR_AUTO_GAME`).
- Plan: add `addResourceEditor` next to it (or factor `addMapEditor`'s shared engine and imports into a helper that both call; `MapEditorEngine` already carries engine libs). It produces `install-resource-editor`, `resource-editor-host-check`, `-smoke` and `-auto`.
- `mapEditorModule` hard-codes a `m2_script_lua` anonymous import and `editor_core` (map core). The resource app imports `editor_kit` and a `resource_core` module instead. resource_core is currently only built as a test module (build.zig:2960). It needs a target-specific module with the `editor_kit` import.
- The map platform gate (build.zig:2337, `map_editor_platform`) decides which targets get an editor. The resource editor must use the same gate (macOS arm64/x64, Windows MSVC, Linux x64).
- The `-Dtest-mode=run` pattern gates execution of run steps, as in the existing `if (test_mode == .run)` blocks.

### Packaging (tools/zig/stage.zig)

- `--map-editor <path>` is parsed at stage.zig:96, copied by `copyMapEditor` (:217), and required afterwards via `requireStagedFile` (:186).
- Add `--resource-editor <path>` with `copyResourceEditor` and an analogous `requireStagedFile` call. Wire it into `stage_package_game_cmd` and `stage_package_game_editors_cmd` (build.zig:2521 and :2549, guarded by `if (map_editor_exe)`).
- The staged `ResourceEditor` must sit beside `Game` and `MapEditor`. Add a test of the staging (see how MapEditor's is tested).

### CI (.github/workflows/cross-platform.yml)

- Resource tiers `test-resource-core` / `-model` / `-bridge` already run on linux x64/arm64, windows msvc/gnu and macos arm64/x64 (lines ~116-128, 339-362, 766-841, 973-984, 1221-1233). `resource-editor-host-check`, `-smoke`, `-auto` and `install-resource-editor` must be added on the same jobs, next to where the `map-editor-*` steps run (windows 421-467, macos 789-820, linux).
- Windows steps take the `-Dmsvc-include/-Dwindows-sdk-include/-Dmsvc-lib/-Dwindows-sdk-lib` args. The macOS ones take `--sysroot "$MACOS_SYSROOT"`.
- macOS and Windows will only be verified when the branch is pushed; AGENTS.md forbids claiming those results.

### Zig app layout to create (`Sources/editor/resource_app/`)

Suggested files, by analogy to the map app:
- `main.zig`: modes `--check`, `--smoke`, `--hidden`, `--batch`, interactive, `-mod=`. The CRT main export from `kit/crt.zig`. Settings path resolution (see `resolveSettingsPath`, main.zig:446).
- `c_bridge.zig`: the real `ResBridge` implementation over `@cImport` of `resource_bridge.h`, behind the same interface as `resource_core.bridge.ResBridge`. The map app's `c_bridge.zig` is 2252 lines for a much larger ABI; the resource one is smaller (about 55 functions) but needs the geometry getters and setters too. S05 needs only Project, Tree, Props, Refs, Export, MOD, Preview and Import.
- `panels.zig` and a `panels_logic.zig` (pure, testable): menus, project tree, inspector, dialogs.
- `smoke.zig` and `auto.zig`: the scripted runs.
- `settings.zig`: `resourceeditor.cfg`.
- Reuse the kit's `host.zig` (`Host.start`, hidden windows use `SDL_WINDOW_HIDDEN | SDL_WINDOW_NOT_FOCUSABLE`), `autosave.recoveryName(buffer, doc_path, extension)` (the extension is a run-time argument, so pass the project's own `.wpn` etc.), `files`/`shipped` (safe save, `.bak`, `isShipped` makes Save become Save As), and `history.History(Command)`.
- `kit/settings.zig` is "not yet fully map-neutral" (`Format` is `bzm`/`xml`, folder key `maps_folder`). Generalise it, or compose a resource-specific settings file that shares `applyGenericKey` / `writeGenericKeys` and keeps `mapeditor.cfg`'s byte order unchanged. Do not break `core/settings.zig`.
- The kit README says `settings` is where a second editor generalises. Expect a small kit change, which means every map tier (`test-editor-core`, `test-map-editor-*`) must stay green. Run the touched ones in the foreground.

### The bridge ABI the app consumes (resource_bridge.h)

- Project: `BkResNew(kind)`, `Open`, `Save`, `Close`, `KindOf`, `Lock`, `LockOwner`, `LockTakeOver`. The lock is MFC's `locked_<user>`.
- Tree: `Nodes` (two-pass, a short buffer is REFUSED), `Props`, `SetProp`, `InsertNode`, `DeleteNode` (blob out), `RestoreNode`, `MoveNode`. Records use fixed buffers: display_name 64, value_text 128.
- `RefList(type)` serves the 20 reference types.
- `Export`/`ExportStatsOnly`/`Batch` take flags `BK_RES_EXPORT_FORCE=1` and `OPEN_SAVE=2`, and fill a `BkResExportReport` (written, skipped, warnings).
- `ModSettingsGet`/`Set` (`BkResModSettings`: export_dir 260, name 64, version 32, desc 256). `PackMod(out_zip_path)` is the native zip and satisfies A-10.
- Preview: `PreviewBegin(kind)`, `Show`, `Stop`, `Playback(run)`, `Camera`. These return `BK_EDITOR_NO_DEVICE` without a GPU.
- `ImportFromGame(kind, path)`: **only infantry (unt) is ported**. Every other kind answers `BK_EDITOR_REFUSED` naming the kind. The Import UI must show that message rather than hide the menu, and the UI test uses the infantry fixture.
- Export is refused when the kind's exporter is not ported yet, per S06+. The Export flow in S05 can therefore only be proven end to end for kinds whose exporter already exists. Check `NResourceModel::RegisterExporter` call sites to see which kinds those are, and pick the fixture for the S05 tests accordingly.

### Gaps: needing new bridge or app code in S05 (A-rows)

- **A-12 Picture Options + `gamma.cfg`:** there is no `BkRes*` for gamma or picture options. The kit has `pictures_cache.zig` (a PictureQueue decoder), and the map app has `app/pictures.zig` (90 lines) that decodes through the engine. The search upward for `gamma.cfg` and the brightness/contrast/gamma state are app-side, with a new small bridge call or a pure Zig implementation, so plan a decision here. The batch report also lists missing `gamma.cfg` files, so its source of truth is needed in the bridge's `BkResBatch` warnings or in the app.
- **A-18 Set Directories** (source, export, game exe, game args): there is no bridge. This is settings-file state in the app, with the export dir passed through `BkResModSettingsSet`. The game path and args feed `kit/testlaunch` (`buildArgv`, `gamePath`).
- **A-22 Run Blitzkrieg (F7):** `kit/testlaunch.zig` already has `Options`, `buildArgv`, `splitParameters`, `describe(exit)`; the constant `profile_name = "MapEditorTest"` and `map_file_name` are map-specific. Generalise the profile name (`ResourceEditorTest`) via a parameter rather than a copy. Launch with `-mod=<exportMod>`.
- **A-23 SaveMapObjects:** `OnSaveObjects` has no message-map entry. Recover the intent from MFC `ParentFrame.cpp`; port if clear, otherwise record "no behaviour in MFC" in 06-PARITY.md.
- **A-26 Help (F1):** `reshelp.chm` is not in the repo. Help shows the shortcut list and a link to the spec.
- **A-14/A-35 Direction Button and thumbnail list docks:** pure ImGui widgets, no bridge needed. Thumbnails need a picture source. Reuse `pictures_cache`.
- **A-15 Function Window dock** is listed in S05 boundary output but `06-PARITY.md` assigns it to 06-12 (the keyframe editor). Treat it in S05 as the dock frame only; the editing is S12.
- **A-29 Inspector:** every `DT_*` domain type (DEC/STR/BOOL/FLOAT/COMBO/BROWSE/COLOR). The PropRecord carries `domain_type`, `value_kind`, `combo_count`, value as text, so all editing goes through `BkResSetProp(value_text)`. Combo options: check how the bridge returns them (`combo_count`, probably via a separate call or `RefList`) before designing the widget.
- **A-30..A-34:** pickers use `BkResRefList(type)` for 20 types; the AI-class and player-sides combos and localisation items were done in S03.
- **A-38 undo/redo:** `resource_core` has `ResourceCommand` with every variant round-tripped against FakeResBridge. The app wires Ctrl+Z/Y, tracks gestures (a drag is one undo) and the save mark (`clean_depth`).
- **A-39 Autosave and recovery:** `kit/autosave.zig` (`Autosave.due`, `target(needs_save_as)`, `recoveryName`). Recovery on start-up must find the file in the user-data root, not beside shipped data.
- **A-27 Tree expand state:** `BkResNodeRecord.expand`, but is it persisted? Check whether the save writes it back into the project XML (round-trip tests already say unedited saves are byte-identical). If so, the UI only needs `SetProp`-like call or a dedicated one. Verify in `resource_bridge.cpp`.

### Settings and user-data root

- The spec (`docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`, ~line 460) requires per-platform user-data root like the game's `<UserRoot>` (XDG on Linux). Tests must never touch the user's profile: redirect with `XDG_DATA_HOME` or a `BK_*_SETTINGS` override. The map editor's `BK_EDITOR_SETTINGS` precedent is at main.zig:283. Add `BK_RESOURCE_EDITOR_SETTINGS` or reuse and document the choice in the spec.
- ImGui layout: `layout.ini` beside the settings file (`enableLayoutPersistence`, main.zig:370).

### BK_EDITOR_AUTO extensions

- `kit/auto_schedule.zig` (710 lines) parses the schedule (`tool=<label>`, `do=<named_cmd>`, shot/compare/differ/exit actions with TGA comparison). The map app's `auto.zig` is only a re-export shim; the actual dispatch is in `smoke.zig`'s AutoRunner and `commands.zig`'s named command registry.
- S05 needs a resource command registry (`do=new:wpn`, `do=open:<fixture>`, `do=set_prop:...`, `do=save`, `do=export`, `do=undo`, `do=import:unt`, `do=pack`, `do=run_game`) and an auto scenario on an in-repo fixture, producing a captured frame measured by code (AGENTS.md: graphics claims are proved by TGA measurement, not source reading).
- The auto step needs the hidden window path and a GPU. The preview tiers already "skip when there is no GPU"; keep that policy but note that a skip is not a pass.

### Fixtures

- `tools/zig/fixtures/resource_editor/<ext>/` holds all 21 kinds; `preview-scene/` holds the captured TGAs; `references_root` serves reference tests. Use these and `Data/Editor/TestProjects`, copied to `zig-out/local-test/resource_editor/...`. Never write into shipped `Data/`.
- Which fixture the host-check/smoke/auto use: choose a kind with exporter and import (unt/infantry is the only one with Import). The New-project test must cover every one of the 21 kinds, since "opens an empty project of any sub-editor kind" is part of the slice's demo.

## Natural seams (for the planner)

1. **Build + stage + CI skeleton, first proof.** A `resource_app` that starts the host on a hidden window, calls `BkResNew(kind)` and exits. `install-resource-editor` and `resource-editor-host-check` (window opens, ImGui draws over the engine frame, TGA check) working on Linux. This de-risks the engine/linking and stays small.
2. **Real bridge adapter** (`c_bridge.zig`) implementing `resource_core.bridge.ResBridge`, plus the app-side pure logic (`panels_logic.zig`) tested through `FakeResBridge` as a headless tier (add a `test-resource-app-logic` step; it must build on every target like `test-resource-core`).
3. **Document lifecycle UI:** New/Open/Close/Save/Save As, safe save + `.bak`, shipped-path Save As, recent files, lock prompt (take-over), unsaved-changes prompt on exit/close, autosave + recovery.
4. **Tree + inspector + pickers:** tree with rename, expand state, insert/delete, all `DT_*` editors, 20 reference pickers, multi-select, browse, multi-select of nodes.
5. **Tools:** MOD Settings, Export, Export Stats Only, PAK, Set Directories, Picture Options, Batch dialog and CLI (`ResourceEditor --batch <kind|all> <src> <dst> [-f] [-os]`, headless: no window, no GPU; the report lists exported, skipped and failed files plus missing `gamma.cfg`), Run Blitzkrieg (F7), Editors menu and combo (20 kinds in MFC order, last active remembered).
6. **Docks and preview:** thumbnail list, direction button, function-window frame, preview as window background (`BkResPreview*`), Import UI, Help, About.
7. **Smoke and auto scenarios, CI steps, parity rows.** Update `06-PARITY.md` A-rows to `done (<evidence>)`. Record the new env seam and user-data decisions in the spec.

The batch CLI (item 5) is independent of the window, so it can be built and tested early on the bridge alone; `BkResBatch` already exists.

## Verification (foreground, each under 10 minutes; full sweep is the maintainer's)

- `zig build install-game install-resource-editor`
- `zig build test-resource-core test-resource-model test-resource-bridge -Dtest-mode=run` (regression)
- New: the app logic tier, `resource-editor-host-check`, `resource-editor-smoke`, `resource-editor-auto` with `-Dtest-mode=run`
- If the kit is touched: `test-editor-kit`, `test-editor-core`, `test-map-editor-view`, `-panels`, `-testlaunch`, `-auto`, `map-editor-host-check`, `map-editor-smoke`, `map-editor-auto` and the rest of the Map Editor tier list in AGENTS.md. The M2/M3 tiers are longer, so run each on its own.
- Record "full sweep left to the maintainer" plus the tiers actually run. Say nothing about macOS/Windows results.
- Batch: run `ResourceEditor --batch` on a fixture folder under `zig-out/local-test`, then read the exported files with the engine's readers (the comparator from S03), not by eye.

## Pitfalls and constraints (already known, reuse)

- Linux: executables that load engine modules need `rdynamic` plus `$ORIGIN`; worker threads need the default 16 MiB stack; hidden windows use `SDL_WINDOW_HIDDEN | SDL_WINDOW_NOT_FOCUSABLE`; stop `ISFX` before modules unload; resolve Data paths case-insensitively.
- Windows: no `link_libc` on app modules (CRT collision, see the comment at build.zig:6384); `.windows` subsystem needs `crt.attachParentConsole` so `--batch` and the automated modes still print.
- `BK_DEBUG_LOG=1` for `DebugTrace` in release.
- CRLF for all new text files; match comment density; Zig doc comments say why.
- Zig 0.16: `std.ArrayList(u8)` has no `.writer()`; use `appendSlice(allocator, ...)` and `bufPrint` (MEM006).
- Do not push. Commit with `feat(resource-editor): ...` and the Co-Authored-By attribution line.
- No GPU on a runner means the preview/auto tiers skip; make that visible in the log.

## Open questions for the planner

1. Picture Options / gamma.cfg: bridge call or app-side? Recommend app-side Zig for the settings and a thin bridge for the batch's missing-gamma list, since `BkResBatch` already reports warnings.
2. Which fixture kind proves Export end to end (needs a registered exporter; check `RegisterExporter` call sites)? If none exists yet, Export in S05 is proven by the REFUSED path and an exporter test double, and the per-kind proof moves to S06+.
3. Whether to generalise `kit/settings.zig` and `kit/testlaunch.zig` in place (touches Map Editor tiers) or add resource-specific wrappers. Recommend small parameterisation, then rerun the map tiers.
4. Whether the resource tiers' `-smoke` needs a real project round trip (open, edit prop, undo, save, byte-compare) in the window. Recommended: yes, using the unt fixture.

## Skills

No installed skill is a direct fit (Zig and ImGui). `tdd` fits for the pure panels logic; `verify-before-complete` should gate each task. No `npx skills find` search was run.
