---
id: T03
parent: S05
milestone: M001
key_files:
  - Sources/src/EditorBridge/resource_bridge.cpp
  - Sources/src/EditorBridge/resource_bridge.h
  - Sources/src/EditorBridge/resource_bridge_test.cpp
  - docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md
key_decisions:
  - The bridge session plays the MFC frame for own_data/desc: edits are held in the session map and patched into the rendered XML on save, and unedited channels are read on demand from the as-read document. No ResourceModel item was changed.
  - A channel on a node with no MFC home is BK_EDITOR_REFUSED for both get and set. Before this, any node was accepted.
  - locked_tiles on a building or object is refused because MFC saves that list as desc/passability; use passability_cells there.
  - ABI values are MFC's stored values with no transform, written with %g (6 significant digits). Aimed angle maps to Direction; cone maps to Angle (slots) or VerticalAngle (fire/smoke/explosion), rounded on read.
  - The ABI entrance is desc Entrances[0]; any further entrances are kept as read.
  - An older port's _bk_geometry copies of channels 0..8 are dropped on read.
duration: 
verification_result: passed
completed_at: 2026-10-05T09:40:47.058Z
blocker_discovered: false
---

# T03: The cells, point and aimed geometry channels (0..8) are now saved where MFC keeps them (own_data/desc frame chunks, squad formation ZeroPos, fence/bridge LockedTiles) instead of _bk_geometry. Tests read the saved files back with the engine's own CDataTreeXML + SBuildingRPGStats/SObjectRPGStats and with the S03 items. The channel -> MFC home table is in the phase 6 spec.

**The cells, point and aimed geometry channels (0..8) are now saved where MFC keeps them (own_data/desc frame chunks, squad formation ZeroPos, fence/bridge LockedTiles) instead of _bk_geometry. Tests read the saved files back with the engine's own CDataTreeXML + SBuildingRPGStats/SObjectRPGStats and with the S03 items. The channel -> MFC home table is in the phase 6 spec.**

## What Happened

Research: MFC does not store building/object geometry in tree items. CBuildingFrame/CObjectFrame keep it in the frame, and OnFileSave writes it beside the tree. SaveFrameOwnData writes own_data/krest_pos and, for objects, own_data/TransLines. SaveRPGStats writes desc (SBuildingRPGStats/SObjectRPGStats: passability CArray2D as size item plus upper-case hex rows, Entrances, FireSlots, FirePoints, SmokePoints, DirExplosions). Squad zero point is CSquadFormationPropsItem::ZeroPos, and fence/bridge locked tiles are the item's LockedTiles list; S03 already ports both.

Tests first: in resource_bridge_test.cpp, the wpn GeometryOnChildNodes test and the inline T05/T06 _bk_geometry blocks were replaced by three functions:
- BuildingGeometryInMfcLayout: bld root, every channel.
- ObjectGeometryInMfcLayout: obt root, passability, zero point and transparency lines.
- ItemGeometryInMfcLayout: scp formation node and fnc fence props node, both below the root, plus wpn refusals.
Each test does set -> save. It then checks there is no _bk_geometry and reads the file back the way MFC does: ReadAsMfc uses CreateDataTreeSaver plus tree.Add("desc") and own_data, and LoadItemOfType uses NResourceModel::Load. Then reopen -> equal, a byte-identical resave, list shorten/clear, refusals, and delete->restore byte-identical.

Implementation in resource_bridge.cpp:
- HomeOf maps (node type, channel) to HOME_FRAME, HOME_SQUAD_ZERO, HOME_TILE_LIST, HOME_PRIVATE (T04 channels) or HOME_NONE (refused).
- ReadFrameGeometry and WriteFrameGeometry patch only the edited sub-elements of own_data/desc and keep everything else as read. New entries get the struct constructor defaults, and a new own_data/desc chunk is inserted in MFC's order.
- LoadGeometry and StoreGeometry route every Get/Set helper. Frame channels: an edit is held in the session map, and an unedited channel is read from the document as loaded. Item homes go straight to the S03 item.
- RenderForSave writes the frame entries. InjectGeometry and ParseGeometryChild skip channels 0..8, and the bytes_grid, point2 and aimed _bk_geometry codec branches were removed.
- HexEncode is now upper case (NStr::BinToString).
- Transparency lines need an even point count.

resource_bridge.h documents units, homes and refusals. The spec gained a "Where geometry is stored (D014 item 2)" subsection in section 3: a table (T04 appends rows), the no-home cases with reasons, the MFC-reader limits, and an amendment entry.

## Verification

Ran the three tiers in the foreground on Linux x64, and all passed. test-resource-bridge printed "Project+Tree OK (21 fixtures)" with the new MFC-reader checks included. test-resource-model printed VERDICT=PASS (goldens pending, as before). test-resource-core passed. I inspected the saved bld output: own_data/krest_pos and desc/passability/Entrances/FireSlots are in MFC shape. macOS and Windows were not run (CI). The full sweep is left to the maintainer.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 25661ms |
| 2 | `zig build test-resource-model -Dtest-mode=run` | 0 | pass | 20432ms |
| 3 | `zig build test-resource-core -Dtest-mode=run` | 0 | pass | 451ms |

## Deviations

The fnc fence-props locked-tiles case was added beyond the bld/obt/scp fixtures because that is locked_tiles' only MFC home. The obt fixture stands in for the plan's "obj".

## Known Issues

MFC's LoadRPGStats indexes desc lists by the tree's props children, so the tool must keep aimed list lengths equal to the matching props child count. This is recorded in the spec and not enforced. Building/object Basic Info fields in desc are left to the export slice. Opening a port-written file in the real MFC editor.exe is only possible on win-home and has not been done.

## Files Created/Modified

- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge.h`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`
