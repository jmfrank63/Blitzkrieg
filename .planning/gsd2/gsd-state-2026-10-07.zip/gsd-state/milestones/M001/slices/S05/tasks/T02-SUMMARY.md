---
id: T02
parent: S05
milestone: M001
key_files:
  - Sources/src/EditorBridge/resource_bridge_test.cpp
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-05T09:08:15.031Z
blocker_discovered: false
---

# T02: test-resource-bridge now saves over an existing project file and over the project's own open path, asserting bytes, .bak and no .tmp.

**test-resource-bridge now saves over an existing project file and over the project's own open path, asserting bytes, .bak and no .tmp.**

## What Happened

Added SaveOverExisting to resource_bridge_test.cpp, called after the fixture round-trip loop. It plants a stale file at the destination, opens the wpn fixture, and calls BkResSave. It asserts OK, destination bytes equal the fixture (the byte-identical serialisation), .bak holds the stale bytes, and no .tmp remains. It then saves again onto the session's own open path (now the destination), asserting OK, the bytes are unchanged, .bak holds the previous save, no .tmp remains, and the file re-opens. The output goes to zig-out/local-test/resource_editor/t02/save_over_existing and the log lines are prefixed "save-over-existing:". The test passed on first run, so no change to resource_bridge.cpp was needed. BkResSave renames .tmp over the destination with std::filesystem::rename. On Linux this replaces the file. MSVC's implementation also replaces an existing file, so I added no explicit Windows handling. The new test lets Windows CI confirm that.

## Verification

test-resource-bridge and test-resource-model both exit 0 on Linux. The new sub-step prints start and done lines with no FAIL. The file keeps CRLF line endings.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 19349ms |
| 2 | `zig build test-resource-model -Dtest-mode=run` | 0 | pass (goldens pending) | 20389ms |

## Deviations

No change to the safe-save code was needed. The Windows result is left to CI and not claimed.

## Known Issues

None. The model tier's goldens are still pending (missing win-home goldens), as before.

## Files Created/Modified

- `Sources/src/EditorBridge/resource_bridge_test.cpp`
