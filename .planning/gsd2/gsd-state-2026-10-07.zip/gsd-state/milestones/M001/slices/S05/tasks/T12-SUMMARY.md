---
id: T12
parent: S05
milestone: M001
key_files:
  - Sources/editor/resource_app/docks.zig
  - Sources/editor/resource_app/docks_logic.zig
  - Sources/editor/resource_app/docks_check.zig
  - Sources/editor/resource_app/main.zig
  - Sources/editor/resource_app/lifecycle.zig
  - Sources/editor/resource_app/panels_logic.zig
  - build.zig
  - docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md
  - .planning/phases/06-resource-editor-portable-port/06-PARITY.md
key_decisions:
  - Thumbnails are decoded by the engine's own image decoders through the existing BkEditorMinimapImage (it reads <base>.tga for a <base>.xml path), so no new C ABI entry was needed. Only the lower-case .tga extension decodes on case-sensitive file systems.
  - Thumbnail cells are 64px, not MFC's 100, because the kit's pictures_cache decodes at most 64 on a side. Recorded in the spec.
  - The preview is begun per open-project kind, and the bridge decides which kinds have a preview (no duplicated table). Until S06+ registers exporters, Show refuses and the reason is shown.
  - Import is a guarded Pending action (ImportRequest {kind, folder}), placed at the top of the File menu because lifecycle_ui owns the rest of that menu.
  - View/Preview/Help are separate ImGui menu blocks, so T11's View/Tools items merge without edit conflicts.
  - The host check's docks half lives in a new docks_check.zig and uses the tracked spt/sprite-1frame.tga, passed by build.zig as an optional 4th --check argument.
duration: 
verification_result: passed
completed_at: 2026-10-05T11:27:44.226Z
blocker_discovered: false
---

# T12: ResourceEditor now has a thumbnail list, direction button and function-window frame docked around the preview scene in the background, plus Import (Ctrl+I), Help (F1) with the shortcut list and spec link, and About. resource-editor-host-check measures a second capture: the engine-decoded thumbnail has the fixture's colour, and the preview's middle is uncovered.

**ResourceEditor now has a thumbnail list, direction button and function-window frame docked around the preview scene in the background, plus Import (Ctrl+I), Help (F1) with the shortcut list and spec link, and About. resource-editor-host-check measures a second capture: the engine-decoded thumbnail has the fixture's colour, and the preview's middle is uncovered.**

## What Happened

New files in Sources/editor/resource_app/:
- docks_logic.zig (pure, 11 tests):
  - CDirectionButton ported: angle from a click via atan2, the needle squashed 2:1 with int truncation, the degrees text, and GetQuadrant as MFC wrote it.
  - CThumbList's *.tga filter, case-insensitive sort and fit-on-black.
  - thumbnailDecodePath.
  - PreviewSync: Begin for the open project's kind, once per kind; Stop when no project is open and at exit; Run = Show; the bridge's refusal is kept as the message.
  - ImportForm, which produces the guarded Pending action.
  - The Help shortcut table with Ctrl->Cmd on macOS, the spec path/URL, and the About lines (IDD_ABOUTBOX text plus the port's).
- docks.zig (ImGui):
  - Thumbnails window: folder field, folder dialog, rescan. Thumbnails are decoded by the engine through BkEditorMinimapImage (<base>.xml -> <base>.tga) into kit pictures_cache and drawn in 64px cells with selection and double-click.
  - Direction window (Ctrl+D) and Function window frame (Ctrl+F).
  - A background-less preview status line.
  - Import window: kind combo, folder plus browse; requests through ui.session.
  - Help (F1) with the shortcut table and Open/Copy spec link; About.
  - F5 runs the preview (Show + playback).
- docks_check.zig: the host check's second half (see Verification).

Edits to shared files:
- panels_logic.zig: Pending.import_from_game now carries an ImportRequest {kind, folder}, and its test block imports docks_logic.
- lifecycle.zig: perform runs the import. It reports the bridge's refusal and keeps the open project. Added a test for the guarded import with dont_save and the refused-kind case.
- main.zig: Docks is wired into the interactive loop (syncPreview each frame; File gets Import at the top; new View/Preview/Help menus; shortcuts; drawDocks/drawDialogs). The probe, Tga, Rgb and clear_colour are now pub for docks_check. --check accepts an optional 4th arg <picture.tga>.
- build.zig: resource-editor-host-check passes tools/zig/fixtures/resource_editor/spt/sprite-1frame.tga.

Documentation:
- Spec amendment appended.
- 06-PARITY rows A-14, A-15, A-25, A-26, A-35 and A-36 updated with evidence.

All files are CRLF.

## Verification

All checks ran in the foreground on Linux x64 with a Vulkan GPU, so no tier was skipped for lack of a GPU.

- test-resource-app-logic: 73/73 tests pass.
- install-resource-editor: OK.
- resource-editor-host-check: the T07 half still passes (centre = clear colour, because no preview has been begun for wpn). Its comment now says so.
- The new docks half (docks_check.zig) works on the same session and captures resource-editor-check-docks.tga. It proves, by code:
  - a .wpn preview is refused, and the message names the kind;
  - Lifecycle.importFromGame(.msh) is refused with "not ported yet .msh";
  - .unt from the shipped Data/Units/Humans/German/Gunner opens as an untitled, unsaved project with more than one node;
  - the .unt preview scene is begun;
  - Run reports why it was not shown;
  - the thumbnail of a copy of the tracked spt/sprite-1frame.tga, decoded by the engine, measures (209,75,183) in the capture, equal to the fixture's own pixel;
  - all 1581 samples of the central 400x240 preview region are the scene's clear colour, so no dock covers the preview;
  - the probe is still orange.

The capture was also viewed as a PNG. ResourceEditor --hidden unt and --hidden wpn both pass with settings redirected under zig-out/local-test. macOS and Windows were not verified. The full sweep is left to the maintainer.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-app-logic -Dtest-mode=run` | 0 | pass (73/73) | 481ms |
| 2 | `zig build install-resource-editor` | 0 | pass | 6154ms |
| 3 | `zig build resource-editor-host-check -Dtest-mode=run` | 0 | pass (host check PASS + docks PASS, thumbnail (209,75,183), 1581 preview samples clear) | 4727ms |

## Deviations

The plan named only panels.zig and main.zig. The work went into new files instead (docks.zig, docks_logic.zig, docks_check.zig) to avoid colliding with T11, plus small edits to main.zig, lifecycle.zig, panels_logic.zig and build.zig (one argument). The Import UI and parity row A-36 were also covered.

## Known Issues

The shortcuts T11 adds (Ctrl+M/E/T/R/B, F7) should be appended to docks_logic.shortcuts. T11's MOD switch should call Docks.modChanged() to drop thumbnail textures. The preview can only show the empty scene until a sub-editor registers an exporter. The thumbnail decode shares the session's last-message buffer.

## Files Created/Modified

- `Sources/editor/resource_app/docks.zig`
- `Sources/editor/resource_app/docks_logic.zig`
- `Sources/editor/resource_app/docks_check.zig`
- `Sources/editor/resource_app/main.zig`
- `Sources/editor/resource_app/lifecycle.zig`
- `Sources/editor/resource_app/panels_logic.zig`
- `build.zig`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`
