---
estimated_steps: 1
estimated_files: 4
skills_used: []
---

# T03: Review fix: geometry in MFC layout, cells and point families (D014 item 2, part 1)

Source: .gsd/OVERRIDES.md override 2026-10-05T08:37 item 2; decisions D006, D008, D014. Tests first. For channels passability_cells, locked_tiles, transparency_lines, zero_point, entrance, shoot_points, fire_points, smoke_points, directed_explosion_points: find where MFC stores each (the owning tree item's fields and its operator&(IDataTree&) in Sources/src/editor, the S03 ports in Sources/src/ResourceModel, or a separate file next to the project) and write a table (channel -> MFC item/field/element or file) into the phase 6 spec docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md (geometry section). Change resource_bridge.cpp (EmitGeometryChild ~line 345 and the load path) so these channels are read from and written to exactly that place, through the ResourceModel items where they already exist, not `_bk_geometry`. Where a channel truly has no MFC home, record it in the spec with the reason. Tests in resource_bridge_test.cpp: set -> save -> reopen through the MFC-layout reader (NResourceModel::Load / the S03 items) -> equal, on bld/obj/scp fixtures including non-root nodes; delete->restore still byte-identical; the saved XML contains no `_bk_geometry` for these channels. Keep test-resource-core green. Run only test-resource-bridge, test-resource-model, test-resource-core.

## Inputs

- `.gsd/OVERRIDES.md`
- `.gsd/DECISIONS.md`
- `Sources/src/editor`
- `Sources/src/EditorBridge/resource_bridge.cpp`

## Expected Output

- `Channel->MFC home table in the phase 6 spec`
- `Cells/point/aimed channels serialised in MFC layout`
- `Round-trip tests through the MFC-layout reader`

## Verification

zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model -Dtest-mode=run && zig build test-resource-core -Dtest-mode=run

## Observability Impact

Spec table documents where each channel lives.
