---
id: T07
parent: S05
milestone: M001
key_files:
  - Sources/editor/resource_app/main.zig
  - build.zig
  - tools/zig/stage.zig
  - tools/zig/stage_test.zig
key_decisions:
  - main.zig calls the BkRes* C ABI directly through @cImport(resource_bridge.h) and casts kit.host's session pointer, so T07 does not depend on T08's c_bridge.zig; T08/T09 can move the calls behind ResBridge.
  - The host check measures the screen centre as the engine's clear colour, because there is no preview scene until T12; it also requires the tree window's middle to be non-clear and the probe to be orange.
  - Factored editorAppKit and linkEditorEngine out of addMapEditor/mapEditorModule rather than duplicating them; map-editor-host-check stays green.
  - No resource-editor-smoke/-auto build steps yet: the --smoke mode exists, and T13 wires the steps and CI.
duration: 
verification_result: passed
completed_at: 2026-10-05T10:39:58.036Z
blocker_discovered: false
---

# T07: The ResourceEditor app skeleton is in place: it builds, installs beside Game and MapEditor, and is staged by the package steps (--resource-editor). resource-editor-host-check passes on Linux, measuring a hidden-window capture by code.

**The ResourceEditor app skeleton is in place: it builds, installs beside Game and MapEditor, and is staged by the package steps (--resource-editor). resource-editor-host-check passes on Linux, measuring a hidden-window capture by code.**

## What Happened

Created Sources/editor/resource_app/main.zig. It has these modes:
- interactive (with --hidden, which quits after 30 frames)
- --check [kind] [out.tga]
- --smoke [kind] [out.<ext>]
- -mod= handling through BkEditorSetMod

It also exports the CRT main for mainCRTStartup on Windows. The app uses kit.host (a hidden window has SDL_WINDOW_HIDDEN|SDL_WINDOW_NOT_FOCUSABLE) and @cImports resource_bridge.h itself, so it does not depend on T08's c_bridge.zig.

The check calls BkResNew(kind), BkResKindOf and the two-pass BkResNodes, then draws the project tree window and an orange probe over the engine frame. It captures the frame through BkEditorCaptureFrame and measures the TGA in code:
- the capture size equals the screen size
- the probe's centre is orange
- the screen's centre is still the engine's clear colour (there is no preview scene yet; T12 adds the preview background)
- the tree window's middle is ImGui's, neither the clear colour nor orange

build.zig changes:
- New addResourceEditor, with the same platform gate as MapEditor (map_editor_platform) and the same configureMapEditorExecutable (rdynamic + $ORIGIN on Linux, @executable_path on macOS, Windows mainCRTStartup/.windows).
- A target-specific resource_core module that imports the target editor_kit.
- Steps install-resource-editor and resource-editor-host-check. The host-check run only executes with -Dtest-mode=run and writes zig-out/local-test/resource_editor/resource-editor-check.tga.
- package-game and package-game-editors pass --resource-editor with the exact emitted binary.
- Refactored the shared SDL/kit setup into editorAppKit, and the shared engine link list into linkEditorEngine; addMapEditor and mapEditorModule now call these helpers.

tools/zig/stage.zig gained the resource_editor option, --resource-editor parsing, copyResourceEditor (error MissingResourceEditor) and a requireStagedFile check in verifyStagedPayload. tools/zig/stage_test.zig gained two tests: ResourceEditor staged beside Game and MapEditor, and a missing binary failing the stage.

All new and edited files are CRLF. T08's build.zig area was not touched.

## Verification

Linux x64 only. Build: zig build install-game install-resource-editor install-map-editor exit 0, and ResourceEditor is staged in zig-out/game/linux/x86_64/debug/ beside Game and MapEditor. zig build resource-editor-host-check -Dtest-mode=run exit 0, printing "resource-editor: host check PASS (vulkan, 1280x800, wpn, 1 nodes)". zig build map-editor-host-check -Dtest-mode=run exit 0 (all three runs, the panel smoke and the mod switch passed), so the build.zig refactor did not regress MapEditor. zig build test-stage -Dtest-mode=run exit 0, including the new staging tests. Also ran these by hand: --smoke wpn (save, reopen, kind and node count PASS), --hidden bld (30 frames PASS) and --check pcp (PASS). macOS and Windows not verified; CI will show them. Full sweep left to the maintainer.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build install-game install-resource-editor install-map-editor` | 0 | pass | 3929ms |
| 2 | `zig build resource-editor-host-check -Dtest-mode=run` | 0 | pass | 4898ms |
| 3 | `zig build map-editor-host-check -Dtest-mode=run` | 0 | pass | 19420ms |
| 4 | `zig build test-stage -Dtest-mode=run` | 0 | pass | 30000ms |

## Deviations

The test-stage duration is approximate. No CI workflow edits (T13 does them). Interactive mode has File > New <kind> / Quit only; the real lifecycle UI is T09+.

## Known Issues

kit/host.zig's engine-start failure message still says "map-editor:" (it belongs to the kit, so it was left unchanged).

## Files Created/Modified

- `Sources/editor/resource_app/main.zig`
- `build.zig`
- `tools/zig/stage.zig`
- `tools/zig/stage_test.zig`
