---
estimated_steps: 1
estimated_files: 2
skills_used: []
---

# T12: Docks, preview background, Import, Help, About

Parity rows A-14, A-15, A-25, A-26, A-35. Thumbnail list (pictures_cache), direction button, function-window dock frame only (editing is S12), preview as window background through BkResPreview*, Import UI (unt works; other kinds show the REFUSED message), Help with shortcuts + spec link, About.

## Inputs

- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`

## Expected Output

- `Docks, preview, import, help, about`

## Verification

zig build test-resource-app-logic -Dtest-mode=run && zig build install-resource-editor && zig build resource-editor-host-check -Dtest-mode=run
