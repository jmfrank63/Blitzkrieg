---
estimated_steps: 1
estimated_files: 2
skills_used: []
---

# T10: Project tree, inspector and reference pickers

Parity rows A-27..A-34, A-38. Tree panel (rename, expand state, insert/delete/move with undo via ResourceCommand, multi-select), inspector for every DT_* domain type through BkResSetProp, combo options, 20 reference pickers via BkResRefList, browse. Ctrl+Z/Y with gestures collapsing to one undo step and the save mark. Logic tests in test-resource-app-logic.

## Inputs

- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`

## Expected Output

- `Tree + inspector + pickers`

## Verification

zig build test-resource-app-logic -Dtest-mode=run && zig build install-resource-editor
