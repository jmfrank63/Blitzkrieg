---
estimated_steps: 1
estimated_files: 7
skills_used: []
---

# T05: Review fix: particle-source preview kind against the .pcp fixture (D014 item 3)

Source: .gsd/OVERRIDES.md override 2026-10-05T08:37 item 3. The S04 'particle' capture uses the .eff effect project. Add a particle-source preview kind to BkResPreviewBegin/Show (resource_bridge.h/.cpp; mirror in resource_core bridge.zig + fake_bridge.zig if the kind enum is shared) that shows a particle source from tools/zig/fixtures/resource_editor/pcp/project.pcp. Add the capture to the Preview sub-step of test-resource-bridge with the same >= 1% non-black-non-magenta gate, measured in code; a GPU-less host logs 'skipped: no GPU device' (a skip is not a pass). Commit the capture as tools/zig/fixtures/resource_editor/preview-scene/particle.tga (from pcp) and keep the effect capture as an extra (e.g. effect.tga); update preview-scene.md with both measured shares and which fixture each came from. Run only test-resource-bridge, test-resource-core, test-editor-bridge.

## Inputs

- `.gsd/OVERRIDES.md`
- `tools/zig/fixtures/resource_editor/pcp/project.pcp`
- `tools/zig/fixtures/resource_editor/preview-scene/preview-scene.md`

## Expected Output

- `Particle-source preview kind`
- `Committed pcp particle capture + effect capture as extra`
- `Updated preview-scene.md with measured shares`

## Verification

zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-core -Dtest-mode=run && zig build test-editor-bridge -Dtest-mode=run

## Observability Impact

Captured TGAs and measured share logged per kind.
