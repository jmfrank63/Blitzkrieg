---
estimated_steps: 1
estimated_files: 5
skills_used: []
---

# T11: Tools: MOD settings, Export, PAK, directories, picture options, batch CLI, Run Blitzkrieg, editors menu

Parity rows A-08..A-24 (see S05-RESEARCH.md Gaps). MOD Settings, Export / Export Stats Only (report: written/skipped/warnings), PAK via BkResPackMod, Set Directories, Picture Options + gamma.cfg (app-side Zig), Batch dialog and headless CLI `ResourceEditor --batch <kind|all> <src> <dst> [-f] [-os]` (exported files read back with the engine's readers / S03 comparator), Run Blitzkrieg F7 via kit/testlaunch with a parameterised profile name (ResourceEditorTest) and -mod=, Editors menu/combo in MFC order with last active remembered. A-23 SaveMapObjects: port or mark 'no behaviour in MFC'. If kit/testlaunch.zig changes, run test-map-editor-testlaunch.

## Inputs

- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`
- `.gsd/milestones/M001/slices/S05/S05-RESEARCH.md`

## Expected Output

- `Tools menus and batch CLI with tests`

## Verification

zig build test-resource-app-logic -Dtest-mode=run && zig build test-map-editor-testlaunch -Dtest-mode=run && zig build install-resource-editor

## Observability Impact

Batch report lists exported/skipped/failed and missing gamma.cfg.
