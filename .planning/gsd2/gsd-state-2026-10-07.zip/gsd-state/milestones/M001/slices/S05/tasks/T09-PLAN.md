---
estimated_steps: 1
estimated_files: 5
skills_used: []
---

# T09: Document lifecycle UI, settings, autosave and recovery

New (all 21 kinds) / Open / Close / Save / Save As with kit safe save + .bak, shipped-path forces Save As, recent files, locked_<user> prompt with take-over, unsaved-changes prompt on close/exit, autosave + recovery from the user-data root (D002). resourceeditor.cfg via a resource-specific settings file sharing the kit's generic keys (keep mapeditor.cfg byte order); BK_RESOURCE_EDITOR_SETTINGS seam recorded in the spec; layout.ini beside settings. Uses Sources/editor/kit autosave.zig, files.zig, shipped.zig. Tests in test-resource-app-logic; if kit/settings.zig changes, run test-editor-core and the test-map-editor-* tiers.

## Inputs

- `.gsd/milestones/M001/slices/S05/S05-RESEARCH.md`
- `Sources/editor/kit/autosave.zig`
- `Sources/editor/kit/files.zig`
- `Sources/editor/kit/shipped.zig`

## Expected Output

- `Lifecycle UI and tests`
- `Settings file + env seam documented`

## Verification

zig build test-resource-app-logic -Dtest-mode=run && zig build test-editor-core -Dtest-mode=run && zig build test-map-editor-panels -Dtest-mode=run
