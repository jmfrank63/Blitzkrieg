# S05: ResourceEditor app shell: all shared features, packaging, CI, BK_EDITOR_AUTO extensions

**Goal:** First close the four S04 review findings (D014: atomic export promotion, geometry in MFC's own layout with no `_bk_geometry`, a particle-source preview capture, save over an existing project), then build the ResourceEditor app shell (`Sources/editor/resource_app/`) over the kit, resource_core and the BkRes* bridge: install-resource-editor on Linux x64 (macOS/Windows via CI), resource-editor-host-check/-smoke/-auto, staging beside Game and MapEditor, and every shared section-A feature on an in-repo fixture.
**Demo:** `install-resource-editor` builds on macOS arm64, Windows MSVC, Linux x64. `resource-editor-host-check`, `-smoke`, `-auto` pass. The staged `ResourceEditor` sits beside `Game` and `MapEditor` in packages. Running it opens an empty project of any sub-editor kind; section A features (New/Open/Save with safe save + `.bak` + autosave + recovery + locking, MOD Settings, Export, PAK via native zip, Picture Options with `gamma.cfg`, Set Directories, Batch panel + CLI, Run Blitzkrieg via F7, Editors menu, inspector + reference pickers + multi-select + browse, thumbnail list + direction button + function-window docks, Import UI, Help showing shortcuts + spec link, About) all work on an in-repo fixture.

## Must-Haves

- T01-T06 (review fixes, D014, override 2026-10-05T08:37) are done before any app-shell task starts: export promotion is all-or-nothing with a forced-second-file-failure test proving the export root is byte-identical; no `_bk_geometry` is written anywhere and every geometry channel round-trips set->save->reopen through the MFC-layout reader (channels without an MFC home are listed in the phase 6 spec with the reason); a particle-source preview kind captured against the .pcp fixture passes the >= 1% non-black-non-magenta gate and is committed, with the .eff capture kept as an extra; test-resource-bridge saves over an existing project.
- `zig build install-resource-editor` builds on Linux x64; CI steps exist for macOS arm64/x64 and Windows MSVC (results claimed only when seen).
- `resource-editor-host-check`, `-smoke`, `-auto` pass on this Linux machine; a GPU-less host logs a skip, which is not counted as a pass.
- The staged ResourceEditor sits beside Game and MapEditor in packages.
- New opens an empty project for each of the 21 kinds; section A features (A-01..A-39 in 06-PARITY.md) are done or marked with evidence/reason.
- Every Map Editor tier listed in AGENTS.md that a task touches stays green; the full sweep is left to the maintainer at slice end.

## Proof Level

- This slice proves: Integration: review fixes proved by tests in test-resource-bridge / test-resource-model / test-resource-core (byte comparisons, MFC-layout reader, captured TGA measured by code). App shell proved by headless logic tests through FakeResBridge plus host-check/smoke/auto runs with captured frames measured by code.

## Integration Closure

Closes the S04->S05 seam: the bridge writes only MFC-readable project XML and atomic exports before any UI depends on it; the app consumes resource_core + resource_bridge.h and is the host S06..S15 sub-editors register into.

## Verification

- Export failures name the file and report the rollback outcome via BkEditorLastMessage; preview captures and smoke/auto logs under zig-out/local-test/resource_editor/; tier skips (no GPU) are logged explicitly.

## Tasks

- [x] **T01: Review fix: all-or-nothing export promotion (D-09, D014 item 1)** `est:2-3h`
  Source: .gsd/OVERRIDES.md override 2026-10-05T08:37 item 1, decision D014, spec D-09. Tests first in resource_bridge_test.cpp. In Sources/src/EditorBridge/resource_bridge.cpp (export promotion loop ~line 2318, the FilesBelow(staging) rename loop) make promotion all-or-nothing: before moving anything, back up every live file that will be replaced (e.g. into a sibling `.bk-export-backup` folder), then move all staged files; on any failure move every already-promoted file back out (delete files that did not exist before), restore every backup, remove staging/backup, and return an error naming the failing file and that the export was rolled back. Test: register a test exporter (the existing `mdc` GoodExporter pattern) producing >= 3 files, pre-populate the export root under zig-out/local-test with known content for some of them, force the second file to fail (a directory in the way at its target path, or a read-only parent; prefer directory-in-the-way since it fails on Linux and Windows alike), then assert the export root is byte-identical to before (walk the tree, compare names + bytes) and no staging/backup folder is left. Keep the existing success-path tests green. Run only: test-resource-bridge, test-resource-model, test-editor-bridge.
  - Files: `Sources/src/EditorBridge/resource_bridge.cpp`, `Sources/src/EditorBridge/resource_bridge_test.cpp`
  - Verify: zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model -Dtest-mode=run && zig build test-editor-bridge -Dtest-mode=run

- [x] **T02: Review fix: save over an existing project in test-resource-bridge (D014 item 4)** `est:1h`
  Source: .gsd/OVERRIDES.md override 2026-10-05T08:37 item 4. Add a case to Sources/src/EditorBridge/resource_bridge_test.cpp where the destination project file already exists (with different content) before BkResSave; assert BkResSave returns OK, the file now holds the new bytes (read back and compare to the expected serialisation), no temp file is left, and the `.bak` behaviour matches what resource_bridge.cpp documents. Also cover saving onto the project's own open path. This makes the Windows CI run prove std::filesystem::rename replaces an existing file; if the safe-save path relies on POSIX rename semantics, make it replace explicitly on Windows (guarded by the backup) and note it. Do not claim the Windows result unless CI is seen. Run only test-resource-bridge and test-resource-model.
  - Files: `Sources/src/EditorBridge/resource_bridge_test.cpp`, `Sources/src/EditorBridge/resource_bridge.cpp`
  - Verify: zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model -Dtest-mode=run

- [x] **T03: Review fix: geometry in MFC layout, cells and point families (D014 item 2, part 1)** `est:4-5h`
  Source: .gsd/OVERRIDES.md override 2026-10-05T08:37 item 2; decisions D006, D008, D014. Tests first. For channels passability_cells, locked_tiles, transparency_lines, zero_point, entrance, shoot_points, fire_points, smoke_points, directed_explosion_points: find where MFC stores each (the owning tree item's fields and its operator&(IDataTree&) in Sources/src/editor, the S03 ports in Sources/src/ResourceModel, or a separate file next to the project) and write a table (channel -> MFC item/field/element or file) into the phase 6 spec docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md (geometry section). Change resource_bridge.cpp (EmitGeometryChild ~line 345 and the load path) so these channels are read from and written to exactly that place, through the ResourceModel items where they already exist, not `_bk_geometry`. Where a channel truly has no MFC home, record it in the spec with the reason. Tests in resource_bridge_test.cpp: set -> save -> reopen through the MFC-layout reader (NResourceModel::Load / the S03 items) -> equal, on bld/obj/scp fixtures including non-root nodes; delete->restore still byte-identical; the saved XML contains no `_bk_geometry` for these channels. Keep test-resource-core green. Run only test-resource-bridge, test-resource-model, test-resource-core.
  - Files: `Sources/src/EditorBridge/resource_bridge.cpp`, `Sources/src/EditorBridge/resource_bridge_test.cpp`, `Sources/src/ResourceModel`, `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`
  - Verify: zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model -Dtest-mode=run && zig build test-resource-core -Dtest-mode=run

- [x] **T04: Review fix: geometry in MFC layout, point lists and keyframes; remove _bk_geometry (D014 item 2, part 2)** `est:4-5h`
  Same method as T03 for formation_positions, bridge_span_marks, mission_objectives, chapter_crosses, campaign_crosses, particle_keyframes, effect_keyframes: extend the spec table, serialise each exactly where MFC stores it (SquadFrm/BridgeFrm/MissionFrm/ChapterFrm/CampaignFrm items, particle/effect keyframe items in Sources/src/editor), then delete the `_bk_geometry` emit/parse code (kGeometryTag, EmitGeometryChild and its parser) and every comment describing it. Tests: set -> save -> reopen through the MFC-layout reader -> equal on scp/bdg/mip/chp/cmp/pcp/eff fixtures incl. non-root nodes; a test that saves every fixture after setting every channel the kind supports and asserts the written XML contains no `_bk_geometry`; all 21 fixtures still save byte-identical unedited. Run only test-resource-bridge, test-resource-model, test-resource-core.
  - Files: `Sources/src/EditorBridge/resource_bridge.cpp`, `Sources/src/EditorBridge/resource_bridge_test.cpp`, `Sources/src/ResourceModel`, `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`
  - Verify: zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model -Dtest-mode=run && zig build test-resource-core -Dtest-mode=run && ! grep -rn '_bk_geometry' Sources/src/EditorBridge Sources/src/ResourceModel

- [x] **T05: Review fix: particle-source preview kind against the .pcp fixture (D014 item 3)** `est:2-3h`
  Source: .gsd/OVERRIDES.md override 2026-10-05T08:37 item 3. The S04 'particle' capture uses the .eff effect project. Add a particle-source preview kind to BkResPreviewBegin/Show (resource_bridge.h/.cpp; mirror in resource_core bridge.zig + fake_bridge.zig if the kind enum is shared) that shows a particle source from tools/zig/fixtures/resource_editor/pcp/project.pcp. Add the capture to the Preview sub-step of test-resource-bridge with the same >= 1% non-black-non-magenta gate, measured in code; a GPU-less host logs 'skipped: no GPU device' (a skip is not a pass). Commit the capture as tools/zig/fixtures/resource_editor/preview-scene/particle.tga (from pcp) and keep the effect capture as an extra (e.g. effect.tga); update preview-scene.md with both measured shares and which fixture each came from. Run only test-resource-bridge, test-resource-core, test-editor-bridge.
  - Files: `Sources/src/EditorBridge/resource_bridge.h`, `Sources/src/EditorBridge/resource_bridge.cpp`, `Sources/src/EditorBridge/resource_bridge_test.cpp`, `Sources/editor/resource_core/bridge.zig`, `Sources/editor/resource_core/fake_bridge.zig`, `tools/zig/fixtures/resource_editor/preview-scene/preview-scene.md`, `tools/zig/fixtures/resource_editor/preview-scene/particle.tga`
  - Verify: zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-core -Dtest-mode=run && zig build test-editor-bridge -Dtest-mode=run

- [x] **T06: Review fixes wrap-up: tiers touched, evidence, close override** `est:1h`
  Run in the foreground the tiers the review fixes touched: test-resource-bridge, test-resource-model, test-resource-core, test-editor-bridge, test-editor-core. Confirm the four items of the 2026-10-05T08:37 override are met with the commands and logs from this task (cite only commands run here). Mark the override's Scope resolved and Applied-at in .gsd/OVERRIDES.md. Record 'full sweep left to the maintainer'. Commit with fix(resource-bridge)/test(...) scopes as appropriate.
  - Files: `.gsd/OVERRIDES.md`
  - Verify: zig build test-resource-bridge test-resource-model test-resource-core test-editor-bridge test-editor-core -Dtest-mode=run

- [x] **T07: App skeleton: build, stage, host-check on Linux** `est:5-6h`
  See S05-RESEARCH.md (Build wiring, Packaging). Create Sources/editor/resource_app/ (main.zig with --check/--smoke/--hidden modes, crt main export) and add addResourceEditor in build.zig modelled on addMapEditor (rdynamic + $ORIGIN rpath on Linux, @executable_path on macOS, Windows mainCRTStartup/.windows/linkMsvcRuntime, same platform gate as the map editor), a target-specific resource_core module importing editor_kit, steps install-resource-editor and resource-editor-host-check (hidden window SDL_WINDOW_HIDDEN|SDL_WINDOW_NOT_FOCUSABLE, BkResNew(kind), ImGui over the engine frame, TGA measured by code). Add --resource-editor to tools/zig/stage.zig (copyResourceEditor + requireStagedFile) and wire it into the package steps; add a staging test. Run install-game install-resource-editor install-map-editor, resource-editor-host-check, map-editor-host-check.
  - Files: `Sources/editor/resource_app/main.zig`, `build.zig`, `tools/zig/stage.zig`
  - Verify: zig build install-game install-resource-editor install-map-editor && zig build resource-editor-host-check -Dtest-mode=run && zig build map-editor-host-check -Dtest-mode=run

- [x] **T08: Real bridge adapter and headless app-logic tier** `est:5-6h`
  Add Sources/editor/resource_app/c_bridge.zig implementing resource_core.bridge.ResBridge over @cImport(resource_bridge.h) (Project, Tree, Props, Refs, Export, MOD, Preview, Import, geometry get/set). Add panels_logic.zig (pure: document lifecycle state, menu enablement, unsaved-changes prompts, editors list in MFC order) tested through FakeResBridge as a new test-resource-app-logic step that builds on every target like test-resource-core. Run test-resource-app-logic, test-resource-core, install-resource-editor.
  - Files: `Sources/editor/resource_app/c_bridge.zig`, `Sources/editor/resource_app/panels_logic.zig`, `build.zig`
  - Verify: zig build test-resource-app-logic -Dtest-mode=run && zig build test-resource-core -Dtest-mode=run && zig build install-resource-editor

- [x] **T09: Document lifecycle UI, settings, autosave and recovery** `est:5-6h`
  New (all 21 kinds) / Open / Close / Save / Save As with kit safe save + .bak, shipped-path forces Save As, recent files, locked_<user> prompt with take-over, unsaved-changes prompt on close/exit, autosave + recovery from the user-data root (D002). resourceeditor.cfg via a resource-specific settings file sharing the kit's generic keys (keep mapeditor.cfg byte order); BK_RESOURCE_EDITOR_SETTINGS seam recorded in the spec; layout.ini beside settings. Uses Sources/editor/kit autosave.zig, files.zig, shipped.zig. Tests in test-resource-app-logic; if kit/settings.zig changes, run test-editor-core and the test-map-editor-* tiers.
  - Files: `Sources/editor/resource_app/main.zig`, `Sources/editor/resource_app/settings.zig`, `Sources/editor/resource_app/panels_logic.zig`, `Sources/editor/kit/settings.zig`, `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`
  - Verify: zig build test-resource-app-logic -Dtest-mode=run && zig build test-editor-core -Dtest-mode=run && zig build test-map-editor-panels -Dtest-mode=run

- [x] **T10: Project tree, inspector and reference pickers** `est:6h`
  Parity rows A-27..A-34, A-38. Tree panel (rename, expand state, insert/delete/move with undo via ResourceCommand, multi-select), inspector for every DT_* domain type through BkResSetProp, combo options, 20 reference pickers via BkResRefList, browse. Ctrl+Z/Y with gestures collapsing to one undo step and the save mark. Logic tests in test-resource-app-logic.
  - Files: `Sources/editor/resource_app/panels.zig`, `Sources/editor/resource_app/panels_logic.zig`
  - Verify: zig build test-resource-app-logic -Dtest-mode=run && zig build install-resource-editor

- [x] **T11: Tools: MOD settings, Export, PAK, directories, picture options, batch CLI, Run Blitzkrieg, editors menu** `est:6h`
  Parity rows A-08..A-24 (see S05-RESEARCH.md Gaps). MOD Settings, Export / Export Stats Only (report: written/skipped/warnings), PAK via BkResPackMod, Set Directories, Picture Options + gamma.cfg (app-side Zig), Batch dialog and headless CLI `ResourceEditor --batch <kind|all> <src> <dst> [-f] [-os]` (exported files read back with the engine's readers / S03 comparator), Run Blitzkrieg F7 via kit/testlaunch with a parameterised profile name (ResourceEditorTest) and -mod=, Editors menu/combo in MFC order with last active remembered. A-23 SaveMapObjects: port or mark 'no behaviour in MFC'. If kit/testlaunch.zig changes, run test-map-editor-testlaunch.
  - Files: `Sources/editor/resource_app/panels.zig`, `Sources/editor/resource_app/batch.zig`, `Sources/editor/resource_app/main.zig`, `Sources/editor/kit/testlaunch.zig`, `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`
  - Verify: zig build test-resource-app-logic -Dtest-mode=run && zig build test-map-editor-testlaunch -Dtest-mode=run && zig build install-resource-editor

- [x] **T12: Docks, preview background, Import, Help, About** `est:4-5h`
  Parity rows A-14, A-15, A-25, A-26, A-35. Thumbnail list (pictures_cache), direction button, function-window dock frame only (editing is S12), preview as window background through BkResPreview*, Import UI (unt works; other kinds show the REFUSED message), Help with shortcuts + spec link, About.
  - Files: `Sources/editor/resource_app/panels.zig`, `Sources/editor/resource_app/main.zig`
  - Verify: zig build test-resource-app-logic -Dtest-mode=run && zig build install-resource-editor && zig build resource-editor-host-check -Dtest-mode=run

- [x] **T13: Smoke and auto scenarios, CI steps, parity rows** `est:5-6h`
  resource-editor-smoke (open unt fixture copy, edit prop, undo, save, byte-compare) and resource-editor-auto with a resource command registry over Sources/editor/kit/auto_schedule.zig (do=new:<kind>, open, set_prop, save, export, undo, import:unt, pack, run_game) producing captured frames measured by code. Add install-resource-editor, resource-editor-host-check/-smoke/-auto to .github/workflows/cross-platform.yml beside the map-editor steps. Update 06-PARITY.md A-rows to done(<evidence>) or reason. Run the resource tiers and map-editor-smoke/auto in the foreground; full sweep left to the maintainer.
  - Files: `Sources/editor/resource_app/smoke.zig`, `Sources/editor/resource_app/auto.zig`, `build.zig`, `.github/workflows/cross-platform.yml`, `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`
  - Verify: zig build resource-editor-host-check resource-editor-smoke resource-editor-auto -Dtest-mode=run && zig build map-editor-smoke map-editor-auto -Dtest-mode=run

## Files Likely Touched

- Sources/src/EditorBridge/resource_bridge.cpp
- Sources/src/EditorBridge/resource_bridge_test.cpp
- Sources/src/ResourceModel
- docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md
- Sources/src/EditorBridge/resource_bridge.h
- Sources/editor/resource_core/bridge.zig
- Sources/editor/resource_core/fake_bridge.zig
- tools/zig/fixtures/resource_editor/preview-scene/preview-scene.md
- tools/zig/fixtures/resource_editor/preview-scene/particle.tga
- .gsd/OVERRIDES.md
- Sources/editor/resource_app/main.zig
- build.zig
- tools/zig/stage.zig
- Sources/editor/resource_app/c_bridge.zig
- Sources/editor/resource_app/panels_logic.zig
- Sources/editor/resource_app/settings.zig
- Sources/editor/kit/settings.zig
- Sources/editor/resource_app/panels.zig
- Sources/editor/resource_app/batch.zig
- Sources/editor/kit/testlaunch.zig
- .planning/phases/06-resource-editor-portable-port/06-PARITY.md
- Sources/editor/resource_app/smoke.zig
- Sources/editor/resource_app/auto.zig
- .github/workflows/cross-platform.yml
