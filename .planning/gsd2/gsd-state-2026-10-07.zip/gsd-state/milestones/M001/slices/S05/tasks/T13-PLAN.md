---
estimated_steps: 1
estimated_files: 5
skills_used: []
---

# T13: Smoke and auto scenarios, CI steps, parity rows

resource-editor-smoke (open unt fixture copy, edit prop, undo, save, byte-compare) and resource-editor-auto with a resource command registry over Sources/editor/kit/auto_schedule.zig (do=new:<kind>, open, set_prop, save, export, undo, import:unt, pack, run_game) producing captured frames measured by code. Add install-resource-editor, resource-editor-host-check/-smoke/-auto to .github/workflows/cross-platform.yml beside the map-editor steps. Update 06-PARITY.md A-rows to done(<evidence>) or reason. Run the resource tiers and map-editor-smoke/auto in the foreground; full sweep left to the maintainer.

## Inputs

- `Sources/editor/kit/auto_schedule.zig`
- `Sources/editor/app/smoke.zig`

## Expected Output

- `Smoke and auto tiers green on Linux`
- `CI steps`
- `Parity rows updated`

## Verification

zig build resource-editor-host-check resource-editor-smoke resource-editor-auto -Dtest-mode=run && zig build map-editor-smoke map-editor-auto -Dtest-mode=run

## Observability Impact

Smoke/auto logs and TGAs under zig-out/local-test/resource_editor/
