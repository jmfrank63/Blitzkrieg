---
estimated_steps: 1
estimated_files: 4
skills_used: []
---

# T04: Review fix: geometry in MFC layout, point lists and keyframes; remove _bk_geometry (D014 item 2, part 2)

Same method as T03 for formation_positions, bridge_span_marks, mission_objectives, chapter_crosses, campaign_crosses, particle_keyframes, effect_keyframes: extend the spec table, serialise each exactly where MFC stores it (SquadFrm/BridgeFrm/MissionFrm/ChapterFrm/CampaignFrm items, particle/effect keyframe items in Sources/src/editor), then delete the `_bk_geometry` emit/parse code (kGeometryTag, EmitGeometryChild and its parser) and every comment describing it. Tests: set -> save -> reopen through the MFC-layout reader -> equal on scp/bdg/mip/chp/cmp/pcp/eff fixtures incl. non-root nodes; a test that saves every fixture after setting every channel the kind supports and asserts the written XML contains no `_bk_geometry`; all 21 fixtures still save byte-identical unedited. Run only test-resource-bridge, test-resource-model, test-resource-core.

## Inputs

- `.gsd/OVERRIDES.md`
- `Sources/src/editor`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`

## Expected Output

- `All 16 channels in MFC layout or recorded as no MFC home in the spec`
- `No `_bk_geometry` in code or written XML`
- `No-_bk_geometry test over all fixtures`

## Verification

zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model -Dtest-mode=run && zig build test-resource-core -Dtest-mode=run && ! grep -rn '_bk_geometry' Sources/src/EditorBridge Sources/src/ResourceModel

## Observability Impact

none beyond test log lines
