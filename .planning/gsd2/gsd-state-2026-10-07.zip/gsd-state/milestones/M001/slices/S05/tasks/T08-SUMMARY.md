---
id: T08
parent: S05
milestone: M001
key_files:
  - Sources/editor/resource_app/c_bridge.zig
  - Sources/editor/resource_app/panels_logic.zig
  - build.zig
  - docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md
key_decisions:
  - Node class integer carried as decimal text in NodeRecord.class_name
  - Empty-slice two-pass reads mapped to REFUSED when total>0 to match the core/fake contract
  - Editors menu = 20 MFC entries without GUI; default Infantry
  - One bridge session holds one project: switching sub-editors parks it by path and reopens it with a fresh history (recorded in the spec)
  - c_bridge compile-checked as a host object in test-resource-app-logic because T07's main.zig does not import it
duration: 
verification_result: passed
completed_at: 2026-10-05T10:42:35.726Z
blocker_discovered: false
---

# T08: Real ResBridge adapter (c_bridge.zig) over resource_bridge.h plus pure panels_logic.zig (Editors menu in MFC order, menu enablement, unsaved prompt, document lifecycle) and a new test-resource-app-logic tier

**Real ResBridge adapter (c_bridge.zig) over resource_bridge.h plus pure panels_logic.zig (Editors menu in MFC order, menu enablement, unsaved prompt, document lifecycle) and a new test-resource-app-logic tier**

## What Happened

Added Sources/editor/resource_app/c_bridge.zig: RealResBridge implements every resource_core.bridge.ResBridge vtable entry over @cImport(resource_bridge.h): Project (new/open/save/close/kindOf/lock/lockOwner), Tree (nodes/props/setProp/insert/delete/restore/move), refList, all 16 geometry channels through their BkResGet*/Set* pairs (grid, point2 lists, aimed, vec3, single point; layouts asserted at comptime), export/stats-only/batch with report and warnings copy, MOD get/set, packMod, importFromGame, preview begin/show/stop. Extra adapter-only methods: lockTakeOver, previewPlayback, previewCamera. How the C ABI and the core differ is documented: class_type int <-> decimal class_name, a C sizing call answering OK becomes REFUSED when the total is >0, lock owner comes from the login. The host session is taken as *anyopaque because the kit's @cImport gives a different opaque type. Added panels_logic.zig: editors_menu (20 entries, labels and separators from editor.rc; GUI left out because MFC commented out CreateGUIFrame), default Infantry (LoadLastActiveModuleID), kindFromExtension/kindFromPath (all 21), restoreEditor, isEnabled following MFC's OnUpdate handlers (Save/SaveAs/Close/Export need an open project; undo/redo also need a project that is not read-only), saveRoute (no path, read-only or shipped -> Save As), UnsavedPrompt with resource actions, and Lifecycle (new/open with lock and a read-only fallback naming the owner, import counts as unsaved, save refuses a read-only project's own path, close, switchEditor that parks a project by path and reopens it). 13 tests run through FakeResBridge. build.zig: test-resource-app-logic (host target, built on every target like test-resource-core, run when test_mode==.run) plus a host addObject of c_bridge.zig so the adapter is semantically checked. A deliberately bad symbol was shown to fail that step. T07's executable does not import c_bridge yet and main.zig is T07's file, so c_bridge is not linked into ResourceEditor in this task. Spec updated with the 20-entry menu and the parking decision.

## Verification

zig build test-resource-app-logic -Dtest-mode=run: 13/13 pass and the c_bridge object compiles. zig build test-resource-core -Dtest-mode=run: 30/30 pass. zig build install-resource-editor: exit 0 (step added by T07). Checked that the object step really analyses vtable bodies by temporarily renaming a C call, which failed the build as expected, then restoring it.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-app-logic -Dtest-mode=run` | 0 | pass (13/13 tests, c_bridge object compiled) | 1102ms |
| 2 | `zig build test-resource-core -Dtest-mode=run` | 0 | pass (30/30) | 433ms |
| 3 | `zig build install-resource-editor` | 0 | pass | 3837ms |

## Deviations

c_bridge.zig is not yet linked into the ResourceEditor executable. That needs main.zig (owned by T07) to import it, expected in T09. Its own small helper tests are compiled but not run, because a test binary would need the engine symbols.

## Known Issues

The real adapter has not been run against the engine yet. The first run will come when main.zig wires it in (T09/T13 smoke).

## Files Created/Modified

- `Sources/editor/resource_app/c_bridge.zig`
- `Sources/editor/resource_app/panels_logic.zig`
- `build.zig`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`
