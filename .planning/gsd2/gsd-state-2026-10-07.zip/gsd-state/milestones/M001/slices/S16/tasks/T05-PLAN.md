---
estimated_steps: 15
estimated_files: 2
skills_used: []
---

# T05: Linux foreground tier run and test-resources-all

Depends on: T08 (D039, D040, hard steer 2026-10-06T05:58) and T09 (D042, hard steer 2026-10-06T06:34, MFC-form save and re-saved fixtures) must be complete first; T08 aligns the MFC golden layout in the comparator. Also run test-resource-model-comparator and report its GOLDEN lines.

Golden follow-up (hard steer 2026-10-06T06:23, D041; folded into this task, not a new slice):
- The 'struct defaults' class (wpn, trc, msh, obt, bld) is a fixture artefact. export-goldens.ps1 now lets MFC open and save each scratch fixture (-os) before exporting; the maintainer regenerates and commits the goldens on win-home. In comparator.cpp, test-resource-model-comparator, 06-PARITY.md and the spec, remove the BK_NO_PROJECT_STATS entries from the accepted set and report wpn/trc/msh/obt/bld as 'pending regeneration'.
- Camera-dependent values (fnc origins, bld explosion noise, obt grids and packs) are not proven: report them as 'pending' with that reason, not 'accepted' (drop the BK_SCENE_CAMERA entries from the accepted set).
- 'Accepted' stays only for differences proven from MFC source and the golden bytes: the %lg six-digit floats and the trc DXT5 solid-block encoding. Each accepted line keeps its source reference.
- GOLDEN_SUMMARY and the PARITY table must show the new pass/accepted/pending counts; run test-resource-model-comparator and report the GOLDEN lines.

Why: the roadmap demo requires test-resources-all green with 0 FAIL and a full resource sweep. Per AGENTS.md and D010, the agent cannot run tools/zig/run-resource-sweep.sh (about 27 minutes), so it runs every tier separately in the foreground.
Do:
- Run each of the following one at a time, in the foreground with a timeout of at most 10 minutes, never in parallel, and never left in the background:
  - install-game, install-map-editor, install-resource-editor
  - test-resources-all
  - test-resource-model, test-resource-model-comparator, test-resource-core, test-resource-bridge, test-resource-app-logic, test-editor-core, test-editor-kit, test-editor-bridge (use -Dtest-mode=run where the step needs it)
  - resource-editor-host-check, resource-editor-smoke
  - each resource-editor-auto-<ext> (core wpn unt spt msh obt fnc bld bdg pcp eff til 3rd 3rv mip chc cgc mdc gui)
  - resource-editor-game-reads-it
  - map-editor-smoke, map-editor-auto, map-editor-game-reads-it-m3
- GUI tiers need XDG_RUNTIME_DIR=/run/user/$UID plus the session WAYLAND_DISPLAY, or SDL_VIDEODRIVER=offscreen. If the env is missing, the failure is SdlInitFailed; that is an environment problem, so fix the env and rerun.
- A Map Editor tier failure is a real regression (AGENTS.md, 3e8afc8a7): fix it, do not classify it.
- Record every command and exit code in the task summary. State: 'full sweep left to the maintainer'. List the unproved items: macOS, Windows, MFC goldens, GOG goldens, hand try.
- Commit only if a fix was needed. git status must be clean.
Done when: every listed tier exits 0 here, or a regression was fixed and re-run.

## Inputs

- `tools/zig/run-resource-sweep.sh`
- `AGENTS.md`

## Expected Output

- Update the implementation and proof artifacts needed for this task.

## Verification

zig build test-resources-all && zig build test-resource-core -Dtest-mode=run && zig build test-resource-bridge -Dtest-mode=run && zig build resource-editor-smoke && zig build map-editor-smoke
