---
id: T10
parent: S16
milestone: M001
key_files:
  - Sources/src/ResourceModel/comparator.cpp
  - Sources/src/ResourceModel/grid_projection.cpp
  - Sources/src/ResourceModel/items/object/object_export.cpp
  - Sources/src/ResourceModel/items/bridge/bridge_export.cpp
  - Sources/src/ResourceModel/items/chapter/chapter_export.cpp
  - tools/zig/resource_model_comparator_test.cpp
  - tools/zig/win-home/export-goldens.ps1
  - docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-06T09:35:14.054Z
blocker_discovered: false
---

# T10: The 17 MFC goldens are compared for real (pass=4 accepted=7 fail=0 pending=9); the editor camera is reproduced (MfcEditorCamera), fixtures for mip/chc/cgc/bdg/3rd/3rv are fixed, and the exporters now write MFC's cached-block form.

**The 17 MFC goldens are compared for real (pass=4 accepted=7 fail=0 pending=9); the editor camera is reproduced (MfcEditorCamera), fixtures for mip/chc/cgc/bdg/3rd/3rv are fixed, and the exporters now write MFC's cached-block form.**

## What Happened

Removed the stale pending rules (stats-reload for wpn/trc/msh/obt/bld, and the 'MFC crashed' rule for mip/chc/cgc) and compared the goldens of 3e98ebc19 for real. Per kind: wpn, mcp, unt, mdc pass. msh, pcp (six-digit floats), trc (DXT5 solid blocks), spt (graphics only) accepted. bld accepted: 4 stats are MFC struct defaults because MFC's own save of a building writes no desc block (BuildFrm.cpp:560, mfc-new/buildingtest.bld has none), proven; 15 explosion points are float noise. Camera: added MfcEditorCamera (ortho 800x600, default placement, anchor snapped as CCamera::Update does; translation (-624,300) with anchor 16 cells). It reproduces the fence golden to float noise (anchor 8 fails, negative test) and, with a new opt-in SExportContext::bRequantiseGrids (LoadRPGStats then SaveRPGStats), the object golden's origin from the hand-made (2,1); obt's .san and DDS packs are byte-equal, so obt (26 files), fnc (10) and bld (50) are accepted, with a 1e-3 float-noise bound (measured up to 5.5e-4). Comparison also found real defects: the chc/cgc/mip cached RPG block held prefixed export paths (MFC loads it into the tree and prefixes again) and now holds the tree's own paths; the bridge cache listed no fire/smoke points while the tree had one each, which crashes CBridgeFrame::GetRPGStats, so the exporter writes one entry per child. Fixtures: mip made a valid mission (template, setting, music, objective header); chc/cgc/mip/bdg re-saved through the port; 3rd texture road_asphalt_city; 3rv water\a_bottom; EXTENSIONS.md regenerated. eff/til: export-goldens.ps1 now places the shipped particle (as particle-2key.xml) and tilemask.tga in the editor's data folder and removes them again; the comparator gives the port's export the same folder. scp not changed: USSR_Mosin is in the tracked objects.xml, so win-home's objects DB lacks it; documented. Pending kinds (scp, bdg, eff, til, 3rd, 3rv, mip, chc, cgc) are checked against their golden and compared as soon as it is regenerated. Updated 06-PARITY.md and appended the spec amendment 'S16 T10' with the per-kind table and the maintainer's regeneration command. Adjusted two bridge tests and the bdg auto scenario for the fixtures.

## Verification

All four verify commands exit 0 on Linux in the foreground; comparator GOLDEN_SUMMARY pass=4 accepted=7 fail=0 pending=9. Also green: resource-editor-auto-{bdg,3rd,3rv,mip,chc,cgc,obt,fnc,bld,eff,til,core}, resource-editor-game-reads-it, resource-editor-smoke, resource-editor-host-check. export-goldens.ps1 parses under pwsh but was not run (needs win-home). Full sweep left to the maintainer. No macOS or Windows result claimed.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-model -Dtest-mode=run` | 0 | pass | 23000ms |
| 2 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 77000ms |
| 3 | `zig build test-resource-model-comparator -Dtest-mode=run` | 0 | pass | 22000ms |
| 4 | `zig build test-resources-all` | 0 | pass | 26000ms |
| 5 | `zig build resource-editor-game-reads-it` | 0 | pass | 126000ms |
| 6 | `zig build resource-editor-auto-bdg / mip / chc / cgc / 3rd / 3rv / obt / fnc / bld / eff / til / core, resource-editor-smoke, resource-editor-host-check` | 0 | pass | 200000ms |

## Deviations

scp fixture not changed (the member is already a shipped unit; cause is win-home's objects database). The eff fixture keeps particle-2key (many tests depend on it); the script supplies the source instead.

## Known Issues

Goldens for scp, bdg, eff, til, 3rd, 3rv, mip, chc, cgc need regeneration on win-home; whether bdg/3rd/3rv still crash MFC is unverified.

## Files Created/Modified

- `Sources/src/ResourceModel/comparator.cpp`
- `Sources/src/ResourceModel/grid_projection.cpp`
- `Sources/src/ResourceModel/items/object/object_export.cpp`
- `Sources/src/ResourceModel/items/bridge/bridge_export.cpp`
- `Sources/src/ResourceModel/items/chapter/chapter_export.cpp`
- `tools/zig/resource_model_comparator_test.cpp`
- `tools/zig/win-home/export-goldens.ps1`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`
