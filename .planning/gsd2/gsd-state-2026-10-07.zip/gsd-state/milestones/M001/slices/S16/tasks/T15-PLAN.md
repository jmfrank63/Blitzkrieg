---
estimated_steps: 8
estimated_files: 10
skills_used: []
---

# T15: Batch export for every kind, independent of UI and view state

Order: runs now, after T14 and BEFORE T07. T07 stays on hold (D043); never complete T07 without performing it. Hard steer 2026-10-06T15:09 (D049).
Why: Johannes: 'This will matter for our port, it should work there. I do not care about the original.' Today resource-editor-batch (--batch-check) re-saves all 21 kinds with -os but exports only wpn; test-resource-bridge's BkResBatch case exports only mdc/wpn/pcp; resource-editor-batch is in neither .github/workflows/cross-platform.yml nor tools/zig/run-resource-sweep.sh. MFC's batch export crashes on 3rd/3rv (UpdateRoadView/UpdateRiverView dereference the GUI tree, null in batch). The port must not have that class of bug: export must never depend on UI or view state.
Do:
1. The batch (CLI --batch and BkResBatch, which the in-app Tools > Batch mode uses) exports every kind that has an exporter, including 3rd and 3rv, from a folder of all fixtures with force. Cover two cases: no project open, and a project of the same kind open in the app (session state, selection and view must not change the output or be changed by the batch). Find and remove any dependency of the export path on UI or view state; start by reading BkResBatch (Sources/src/EditorBridge/resource_bridge.cpp, about line 4282) and the 3rd/3rv export code.
2. Each batch output equals the single export (BkResExport) of the same fixture byte for byte, and is read back by the engine's own reader. Add this to test-resource-bridge (all kinds, not only mdc/wpn/pcp) and to the --batch-check tier (extend it beyond wpn).
3. A batch over a mixed folder (valid projects, a corrupt project, a wrong-kind file, an unsupported file) reports per project in the report and continues past a failing project; the exit status and BkResBatch status say that something failed. Test it in test-resource-bridge and --batch-check.
4. Add resource-editor-batch to .github/workflows/cross-platform.yml and to tools/zig/run-resource-sweep.sh, next to the other resource-editor tiers. Keep the tier under the 3-minute budget or split it (for example resource-editor-batch plus a second step per group of kinds) and add every split step to CI and the sweep.
5. Record the decision in the spec (dated S16 amendment, append-only) and in 06-PARITY.md: the port's batch exports every kind and is UI-independent, unlike MFC's 3rd/3rv batch crash. Keep CRLF. Commit as test/fix(resource-editor) with a scope; git status clean (headers, fixtures and docs included). Verify with plain zig build commands only; full sweep left to the maintainer.

## Inputs

- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/editor/resource_app/batch_cli.zig`
- `tools/zig/fixtures/resource_editor`
- `build.zig`
- `.gsd/OVERRIDES.md`

## Expected Output

- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `Sources/editor/resource_app/batch_cli.zig`
- `build.zig`
- `.github/workflows/cross-platform.yml`
- `tools/zig/run-resource-sweep.sh`

## Verification

zig build test-resource-bridge -Dtest-mode=run && zig build resource-editor-batch -Dtest-mode=run && zig build test-resource-model -Dtest-mode=run && zig build resource-editor-smoke

## Observability Impact

The batch tier prints one line per project (kind, status, export equals single export) and a final total; expected after this task: every kind exported, the mixed-folder case reports its failures and the batch continues.
