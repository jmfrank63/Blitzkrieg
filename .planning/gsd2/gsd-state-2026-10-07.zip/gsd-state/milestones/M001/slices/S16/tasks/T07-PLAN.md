---
estimated_steps: 13
estimated_files: 5
skills_used: []
---

# T07: Delete the MFC editor (approved by Johannes 2026-10-06, D-26/D035/D037)

RELEASED (hard steer 2026-10-06T16:12, D050): the D043 hold is lifted; the golden comparison is complete (pass=10 accepted=10 fail=0 pending=0 at b8aa895bb, maintainer's Linux sweep PASS). Dispatch alone and perform the deletion. Former hold text: do not dispatch T07 until a later steer explicitly releases it. The maintainer is regenerating all 20 MFC goldens on win-home from the re-saved fixtures (44094bf22); differences they reveal must be traced against Sources/src/editor before it is deleted. If T05 and T06 finish first, stop and report T07 as waiting for the golden comparison (not blocked for approval; D037 stands).

Depends on: T02, T03, T04, T05, T06, T08, T09, T10, T11, T12, T13, T14 and T15 must all be complete (D038, D040, D042, D044, D045, D046, D047, D048, D049). Never dispatch T07 in a parallel batch with them or with T01; run it alone, after they are done. If an earlier run left a blocker (tasks/T07-SUMMARY.superseded-blocked-run.md, blocker_discovered), it is superseded: clear it and proceed per D037. Nothing was deleted by that run.

Why: Johannes approved the deletion on 2026-10-06 (D037, hard steer 05:03 in .gsd/OVERRIDES.md), before the win-home hand try and the MFC goldens, because the MFC editor stays in git history and upstream. The approval does NOT require the win-home goldens or a hand try first; the goldens are generated later on win-home from PRE_DELETE. Do not block or wait at this task. There is no gate check; do not complete it with blocker_discovered. The hand try (macOS, Windows), the win-home MFC goldens and the GOG goldens stay open and are never claimed done.
Steps:
- Before deleting, note the current HEAD hash (the commit just before the deletion commit). This is PRE_DELETE.
- Run `rg -n 'src/editor|editor\.exe|editor2'` outside .gsd, .planning, zig-out and Sources/src/editor. Fix any build or CI reference. Comment and spec mentions may stay as history. build.zig lines about 1853 and 9955 are comments only. Keep every test and fixture that does not need the MFC sources (tools/zig/fixtures, committed goldens folders, mfc_item_inventory JSON, comparator and export-goldens.ps1).
- git rm -r Sources/src/editor (this includes Sources/src/editor/bin/editor2.exe) and git rm Sources/src/bin/editor.exe.
- In Sources/src/A7.sln, remove the 'editor' project at line 195 (GUID {425EDE25-204A-B5C4-9C5F-C77FD3F123E1}), its configuration, nested-project and ProjectDependencies lines. Keep the file's CRLF.
- In tools/zig/stage.zig, remove only the editor.exe row of copyEditors (line 597). ExcelExporter and ELK stay.
- Note in tools/zig/mfc_item_inventory.py's header that its inputs are deleted and the committed JSON is now the source of truth.
- Record PRE_DELETE in docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md (dated S16 amendment) and in .planning/phases/06-resource-editor-portable-port/06-PARITY.md (header note): the MFC goldens remain pending and are generated on win-home from PRE_DELETE (git worktree or checkout there, build editor.exe from it, run tools/zig/win-home/export-goldens.ps1), so the golden comparison can still run later. Also state that Johannes approved the deletion before the hand try. Update the PARITY header sentence that says the editor is deleted only when every row is done, to say it was deleted early by approval with the golden rows still pending. Update .planning/STATE.md and 06-CONTEXT D-26 with a pointer to the approval.
- Use the Phase 5 MFC map-editor deletion commit as precedent (git log on .planning/STATE.md mentions it).
- Commit as chore(resource-editor): remove the MFC editor, with the attribution line from the session. The PRE_DELETE hash goes in the commit body. git status must be clean afterwards (including the spec and PARITY edits, which go in the same commit or one right after it).
Done when: the commit exists, the three installs, test-resource-model and test-resources-all are green on Linux (foreground, one tier at a time if the aggregate exceeds 10 minutes), stage.zig packaging still runs, PRE_DELETE is named in the spec and PARITY. Full sweep left to the maintainer.

## Inputs

- `Sources/src/A7.sln`
- `tools/zig/stage.zig`
- `tools/zig/mfc_item_inventory.py`
- `.planning/phases/06-resource-editor-portable-port/06-CONTEXT.md`
- `.gsd/OVERRIDES.md`

## Expected Output

- `Sources/src/A7.sln`
- `tools/zig/stage.zig`
- `tools/zig/mfc_item_inventory.py`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`

## Verification

zig build install-game && zig build install-map-editor && zig build install-resource-editor && zig build test-resource-model && zig build test-resources-all

## Observability Impact

None; the deletion commit body names PRE_DELETE.
