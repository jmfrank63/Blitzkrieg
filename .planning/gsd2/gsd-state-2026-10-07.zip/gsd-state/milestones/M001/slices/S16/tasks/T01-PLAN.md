---
estimated_steps: 14
estimated_files: 12
skills_used: []
---

# T01: Paste assigns unique ElementIDs (S15 review fix, override 2026-10-06T04:54)

Why: this is the active override of 2026-10-06T04:54. CUiScreen::Paste (Sources/src/ResourceModel/ui_screen.cpp around line 910) copies each window's ElementID unchanged. A paste into a screen that already uses that id produces two controls that send the same id in UI_NOTIFY_WINDOW_CLICKED. MFC has no GUI copy/paste, so this task defines the port behaviour. Planners have dropped this item before, so it must stay T01 and run before the other S16 tasks.
Do:
- In Paste, collect the ElementIDs already used in the target screen, recursively.
- For each pasted window, including those in nested subtrees: keep its ElementID when it is unused. When it collides with the target screen or with an id already assigned in this paste, assign the next free ElementID. Ids must stay unique among the pasted windows too.
- Return the reassignments (old id to new id, per window) through a new out-parameter or struct. Surface them through the BkResGui* paste entry point in Sources/src/EditorBridge/resource_bridge.cpp, its Zig mirror in Sources/editor/resource_core (bridge.zig, fake_bridge.zig, gui_tools.zig) and the app's c_bridge.zig. gui_logic.zig reports each reassignment in the status line and the log.
- Undo of the paste command restores the screen byte for byte, as the existing gui_tools undo does.
- Tests in Sources/src/ResourceModel/ui_screen_test.cpp (run by test-resource-model):
  (a) Paste the same subtree into the same shipped screen twice. Re-read the saved screen with the engine's UI reader (IDataTree path used by the existing ui_screen checks) and check that all ElementIDs of interactive controls are unique and the originals are unchanged.
  (b) Paste into a screen with no collision and check that the ids are kept.
  (c) Paste a subtree with an internal duplicate and check that the ids become unique.
- Add a resource_core undo/redo test with the fake bridge.
- Add a line to 06-PARITY.md B-21 and a dated line to the spec's Amendments (D031 follow-up).
- Commit as fix(resource-editor): with headers and tests included. git status must be clean.
Done when: the tests above pass, test-resource-core and resource-editor-auto-gui stay green, and the override is answered by evidence.

## Inputs

- `Sources/src/ResourceModel/ui_screen.cpp`
- `Sources/src/ResourceModel/ui_screen.h`
- `Sources/src/ResourceModel/ui_screen_test.cpp`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge.h`
- `Sources/editor/resource_core/gui_tools.zig`
- `Sources/editor/resource_app/gui_logic.zig`

## Expected Output

- `Sources/src/ResourceModel/ui_screen.cpp`
- `Sources/src/ResourceModel/ui_screen.h`
- `Sources/src/ResourceModel/ui_screen_test.cpp`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge.h`
- `Sources/editor/resource_core/bridge.zig`
- `Sources/editor/resource_core/fake_bridge.zig`
- `Sources/editor/resource_core/gui_tools.zig`
- `Sources/editor/resource_app/c_bridge.zig`
- `Sources/editor/resource_app/gui_logic.zig`

## Verification

zig build test-resource-model -Dtest-mode=run && zig build test-resource-core -Dtest-mode=run && zig build test-resource-app-logic -Dtest-mode=run && zig build test-resource-bridge -Dtest-mode=run && zig build install-resource-editor && zig build resource-editor-auto-gui

## Observability Impact

Each ElementID reassignment is printed to the status line and the log as 'paste: ElementID <old> -> <new> (<window name>)'.
