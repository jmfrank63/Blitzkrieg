---
estimated_steps: 9
estimated_files: 5
skills_used: []
---

# T11: Golden round 3: compare 18 MFC goldens, fix spt, art-16x16, 3rd/3rv editor data, mip, scp fixtures

Order: runs now, after T10 and BEFORE T07. T07 stays on hold (D043/D045); the maintainer reopened it because an earlier run marked it complete without deleting anything: never complete T07 without performing it. Hard steer 2026-10-06 (D045). Why: commit ae04873da holds MFC goldens for 18 kinds made from the T10 fixtures. MFC still showed five fixture problems on win-home.
Do:
1. Compare all 18 goldens for real (test-resource-model-comparator) and fix the port or explain each difference by proof from MFC source and golden bytes (D041 rule).
2. spt: MFC reports 'Can not find files total count 1 ...\spt\source\_.sprite-1frame.tga'. CSpriteFrame (SpriteTreeItem.cpp:89, :220) searches '_.'+name. Name and arrange the frame files as MFC's sprite editor does so the golden carries the sprite.
3. art-16x16.tga: 'Some of files can not be opened' (fnc and til reference it). Find which export opens it and why MFC's image loader rejects it (format, bit depth, RLE, size); use art MFC can read.
4. 3rd and 3rv crash MFC on export: it loads maps\road3d.xml and maps\river3d.xml and their terrain from the editor data folder (3dRoadFrm.cpp:243-289, 3dRiverFrm.cpp:204-225), which the GOG install has only inside data.pak. Extend export-goldens.ps1 Place-EditorDataFile to place the tracked Data/Maps/road3d.xml, river3d.xml and every file they reference that the editor needs, remove them afterwards, and list the files in the script comment.
5. mip: open-and-save still crashes MFC (export from the unsaved fixture works). Find the cause in MissionFrm's open path and fix the fixture.
6. scp: replace squad member USSR_Mosin with a unit present in the shipped GOG data (check Data/objects.xml against units in the GOG paks) so the golden carries the squad.
7. Keep the port's tests green; update fixture hashes. Re-save changed fixtures through the port (own_data, RPG). Keep CRLF. Do not regenerate goldens; the maintainer re-runs export-goldens.ps1 once more. Update 06-PARITY.md and the spec (append-only). Commit with fixtures, headers and docs; git status clean. Verify with plain zig build commands only. Report per kind. Full sweep left to the maintainer.

## Inputs

- `tools/zig/fixtures/resource_editor`
- `tools/zig/win-home/export-goldens.ps1`
- `Sources/src/editor`
- `Data/Maps/road3d.xml`
- `Data/Maps/river3d.xml`
- `Data/objects.xml`
- `.gsd/OVERRIDES.md`

## Expected Output

- `tools/zig/fixtures/resource_editor`
- `tools/zig/win-home/export-goldens.ps1`
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`

## Verification

zig build test-resource-model -Dtest-mode=run && zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model-comparator -Dtest-mode=run && zig build test-resources-all

## Observability Impact

The comparator prints one line per kind (pass, accepted, pending, fail with reason) and the GOLDEN_SUMMARY counts.
