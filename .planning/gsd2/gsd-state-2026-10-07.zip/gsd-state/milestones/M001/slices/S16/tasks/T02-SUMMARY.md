---
id: T02
parent: S16
milestone: M001
key_files:
  - Sources/editor/resource_app/view_logic.zig
  - Sources/editor/resource_app/panels.zig
  - Sources/editor/resource_app/settings.zig
  - Sources/editor/resource_app/edit_logic.zig
  - Sources/editor/resource_app/scenario.zig
  - build.zig
  - .planning/phases/06-resource-editor-portable-port/06-PARITY.md
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-06T05:23:06.667Z
blocker_discovered: false
---

# T02: Added View menu toggles (Toolbar, Status Bar, Project Tree, Object Inspector), Set Background Colour and Expand/Collapse all (Ctrl+C), persisted in resourceeditor.cfg and proved by logic tests and the core auto tier.

**Added View menu toggles (Toolbar, Status Bar, Project Tree, Object Inspector), Set Background Colour and Expand/Collapse all (Ctrl+C), persisted in resourceeditor.cfg and proved by logic tests and the core auto tier.**

## What Happened

New view_logic.zig holds the View state (four toggles, background colour, MFC's expand flag) with parse/pack helpers. settings.zig gained view_* and background_colour keys at the tail, written only when not default. panels.zig draws the View menu items, the colour picker, the background fill (skipped while the preview scene shows) and hides the tree, inspector and status line per toggle; main.zig loads and stores the state and hides the toolbar combo. edit_logic.setExpandAll and expandedCount walk the tree via setExpand with no undo step, as in MFC. Help lists Ctrl+C. scenario.zig gained do=view, do=background, do=expand_all/collapse_all/expand_toggle and expect=view/background/expanded/expanded_min; resource-editor-auto-core has a new View block (frames 35-57, exit frame 60). PARITY rows A-13, A-16 and A-17 are now done with evidence. I did not run git, as the task instructed that the system commits; the files are still uncommitted.

## Verification

test-resource-app-logic (189 pass), install-resource-editor, resource-editor-auto-core PASS (background pixels 0 to 809200, open items 5/0/5, panels-off frame differs 20.98%), resource-editor-smoke PASS, resource-editor-host-check PASS. All ran natively on Linux with the Wayland session display. macOS and Windows not run.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-app-logic -Dtest-mode=run` | 0 | pass | 1000ms |
| 2 | `zig build install-resource-editor` | 0 | pass | 60000ms |
| 3 | `zig build resource-editor-auto-core` | 0 | pass | 19580ms |
| 4 | `zig build resource-editor-smoke` | 0 | pass | 30000ms |
| 5 | `zig build resource-editor-host-check` | 0 | pass | 30000ms |

## Deviations

none

## Known Issues

Changes are uncommitted; AGENTS.md wants a clean git status, so the system commit must include view_logic.zig (untracked) and the PARITY file.

## Files Created/Modified

- `Sources/editor/resource_app/view_logic.zig`
- `Sources/editor/resource_app/panels.zig`
- `Sources/editor/resource_app/settings.zig`
- `Sources/editor/resource_app/edit_logic.zig`
- `Sources/editor/resource_app/scenario.zig`
- `build.zig`
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`
