---
id: T04
parent: S16
milestone: M001
key_files:
  - build.zig
  - Sources/editor/resource_app/scenario.zig
  - Sources/editor/resource_app/game_reads_logic.zig
  - tools/zig/fixtures/resource_editor/game-reads-it.auto
  - Sources/src/EditorBridge/resource_bridge.cpp
  - .github/workflows/cross-platform.yml
  - tools/zig/run-resource-sweep.sh
  - AGENTS.md
  - .planning/phases/06-resource-editor-portable-port/06-PARITY.md
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-06T06:00:54.563Z
blocker_discovered: false
---

# T04: resource-editor-game-reads-it now covers all 21 project kinds: 10 proved by the real Game via BK_MOD_TRACE, 11 by the engine's own reader (PROOF=reader with REASON), wired into CI GPU runners, the sweep, AGENTS.md and PARITY.

**resource-editor-game-reads-it now covers all 21 project kinds: 10 proved by the real Game via BK_MOD_TRACE, 11 by the engine's own reader (PROOF=reader with REASON), wired into CI GPU runners, the sweep, AGENTS.md and PARITY.**

## What Happened

Resumed after interruption. The earlier session had already extended the fixture (game-reads-it.auto), scenario.zig, game_reads_logic.zig, the C bridge (BkResReadBack) and build.zig. I rebuilt and ran the step: result.log has 21 KIND lines, all PASS (wpn, unt, msh, obt, fnc, bld, scp, mcp, bdg, gui with PROOF=game; spt, pcp, eff, trc, til, 3rd, 3rv, mip, chc, cgc, mdc with PROOF=reader and a REASON). This session added the step to cross-platform.yml on the Windows and macOS GPU jobs (after the map-editor game-reads-it step), to run-resource-sweep.sh and to AGENTS.md's tier list, and appended section D to 06-PARITY.md with per-kind proof and reason. Files kept CRLF. Per the task's rules no git commands were run; the system commits from this summary. Full sweep left to the maintainer.

## Verification

zig build install-game, install-resource-editor, resource-editor-game-reads-it (21 KIND lines, all PASS) and resource-editor-auto-gui (PASS, 61 actions) run in the foreground on Linux. macOS and Windows not run here; left to CI.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build install-game && zig build install-resource-editor && zig build resource-editor-game-reads-it` | 0 | pass | 300000ms |
| 2 | `zig build resource-editor-auto-gui` | 0 | pass | 120000ms |

## Deviations

none

## Known Issues

Full sweep left to the maintainer. macOS/Windows CI results not seen.

## Files Created/Modified

- `build.zig`
- `Sources/editor/resource_app/scenario.zig`
- `Sources/editor/resource_app/game_reads_logic.zig`
- `tools/zig/fixtures/resource_editor/game-reads-it.auto`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `.github/workflows/cross-platform.yml`
- `tools/zig/run-resource-sweep.sh`
- `AGENTS.md`
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`
