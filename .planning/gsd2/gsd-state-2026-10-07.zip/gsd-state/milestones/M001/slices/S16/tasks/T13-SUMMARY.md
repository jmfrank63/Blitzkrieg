---
id: T13
parent: S16
milestone: M001
key_files: []
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-06T13:56:27.231Z
blocker_discovered: false
---

# T13: The port now writes MFC's value flag (bool = 9 in the road, river, campaign, mission and weapon projects), five fixtures are re-saved, and the goldens compare pass=10 accepted=9 fail=0 pending=1 (3rd, waiting for a re-export).

**The port now writes MFC's value flag (bool = 9 in the road, river, campaign, mission and weapon projects), five fixtures are re-saved, and the goldens compare pass=10 accepted=9 fail=0 pending=1 (3rd, waiting for a re-export).**

## What Happened

Found the cause of the 3rd golden's SoilParams 0: MFC saves a bool as flag 9 (VT_BOOL | VT_INT, because CVariant::operator bool calls OptimizeInt) and reads a flag-8 bool as false in the Road editor; the port wrote 8. Added CTreeItem::BoolsReadAsInt and an EncodeMfcValue parameter so items whose MFC save reads its bools (road, river, campaign, mission, weapon) write flag 9, kept or edited over a stored value too; every other value keeps flag = type, as MFC's own bridge, fence, unit and mesh projects do. Re-saved fixtures 3rd, 3rv, cgc, mip and wpn and updated their size and hash rows in EXTENSIONS.md. Added tests: every value type/flag pair in all fixtures and in mfc-new, plus an encoder test per type. Compared the scp and til goldens for real: scp passes against the batch-safe copy, til is accepted (392 floats at six significant digits, and the tileset XML replaced by MFC's batch History). The 3rd pending reason is corrected to the proven cause. Recorded the T13 amendment in the spec, the 06-PARITY rows (including the corrected T12 3rd row) and the win-home re-export list. T07 stays on hold; nothing was deleted. Per kind: pass for scp, unt, eff, 3rv, mip, chc, cgc, mdc and others (10), accepted 9 (spt, msh, obt, fnc, bld, bdg, pcp, til and one more), pending 1 (3rd, until re-exported), fail 0.

## Verification

test-resource-model, test-resource-bridge, test-resource-model-comparator and test-resources-all all exit 0 with no FAIL; test-resource-model was re-run after the EXTENSIONS.md hash update. Full sweep left to the maintainer.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-model -Dtest-mode=run && zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model-comparator -Dtest-mode=run` | 0 | pass | 0ms |
| 2 | `zig build test-resources-all` | 0 | pass (VERDICT=PASS, 0 FAIL) | 0ms |
| 3 | `zig build test-resource-model -Dtest-mode=run (after EXTENSIONS.md update)` | 0 | pass | 0ms |

## Deviations

None.

## Known Issues

None.

## Files Created/Modified

None.
