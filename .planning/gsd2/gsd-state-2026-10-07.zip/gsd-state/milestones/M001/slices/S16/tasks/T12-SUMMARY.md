---
id: T12
parent: S16
milestone: M001
key_files:
  - Sources/src/ResourceModel/comparator.cpp
  - tools/zig/resource_model_comparator_test.cpp
  - Sources/src/EditorBridge/resource_bridge_test.cpp
  - tools/zig/resource_editor_fixtures.zig
  - tools/zig/fixtures/resource_editor/til/art-16x16.tga
  - tools/zig/fixtures/resource_editor/EXTENSIONS.md
  - tools/zig/win-home/export-goldens.ps1
  - docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md
  - .planning/phases/06-resource-editor-portable-port/06-PARITY.md
key_decisions:
  - 3rd SoilParams stays pending, not accepted: MFC's source gives 16 and the cause of the golden's 0 is not proven; the port is not changed.
  - scp is exported from a scratch copy whose formation lists no units, because MFC's batch path never calls CallMeAfterSerialize; the tracked fixture keeps its unit.
  - til fixture art is 64x32 (the mask's size) and keeps the file name art-16x16.tga.
duration: 
verification_result: passed
completed_at: 2026-10-06T12:42:17.427Z
blocker_discovered: false
---

# T12: Golden comparison is now pass=9 accepted=8 fail=0 pending=3: spt and 3rv compared for real, til and scp causes found in MFC source and fixed in the fixtures and scratch copies, 3rd SoilParams left pending as unproven.

**Golden comparison is now pass=9 accepted=8 fail=0 pending=3: spt and 3rv compared for real, til and scp causes found in MFC source and fixed in the fixtures and scratch copies, 3rd SoilParams left pending as unproven.**

## What Happened

Recorded in the spec (amendment S16 T12) and 06-PARITY that the 3rd and 3rv goldens were exported by hand in MFC's GUI, because MFC's batch export of 3D roads and rivers crashes even for projects MFC made itself. 3rd (pending, unproven): the golden holds SoilParams 0 and the port 16. MFC's source gives 16 (3dRoadFrm.cpp:187 and :231, 3dRoadTreeItem.h:49, 3dRoadTreeItem.cpp:261), CVariant reads a loaded bool correctly, and the river code never touches soil params (3rv passes), so the port is unchanged. I added a pending (not proven) golden difference and asked for a hand re-export that notes both soil items. spt: the stale pending rule is removed; the golden's 1.san and three DDS equal the port's, so it is accepted. til: the stale rule is removed and it is compared. Cause found: the tile art was 16x16 while the tile mask is 64x32, and MFC runs the mask over a mask-sized rectangle of every tile (TileTreeItem.cpp:189-192), so the crosset atlas holds random alpha from reading past the image. The terrain atlas is empty because tile index 0 gives a 16-row atlas that CopyFromAB refuses to put a 32-row tile in. The fixture art is now 64x32 (generator writeSolidTga32, EXTENSIONS.md size and hash updated), with the bridge til test adapted (an atlas too low for a tile must stay empty; the loop no longer reads past the decoded height). The comparator now reads crosset.xml as a crosset, accepts the golden's History-only 1.xml (ComposeTiles' tileset XML is replaced by the batch History stream), and accepts the other rounding of an exact decimal tie in MFC's six-digit floats (MSVC rounds 0.001953125 up, glibc to even). The five DDS differences stay pending until the golden is regenerated. scp: the key-named member was not the cause. MFC's batch export loads the project with pRootItem->operator& (ParentFrame.cpp:1403), so CSquadTreeRootItem::CallMeAfterSerialize (called only from ETreeCtrl.cpp:454) never runs, and each formation unit's pMemberProps stays null at SquadFrm.cpp:275. The fixture is kept (the bridge tests need its unit); export-goldens.ps1 and the comparator test now make a scratch copy with an empty formation units list, and the comparator checks the port exports that copy. Needs a win-home re-run: scp and til via export-goldens.ps1 -Extensions scp,til, and 3rd re-exported by hand in the GUI. 3rv needs nothing. Full sweep left to the maintainer; no macOS or Windows result claimed. T07 untouched.

## Verification

Ran in the foreground on Linux: test-resource-model, test-resource-bridge, test-resource-model-comparator (GOLDEN_SUMMARY extensions=20 pass=9 accepted=8 fail=0 pending=3), test-resources-all, test-resource-editor-fixtures, test-resource-xml-roundtrip and resource-editor-auto-til, all exit 0.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-model -Dtest-mode=run` | 0 | pass | 24000ms |
| 2 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 84000ms |
| 3 | `zig build test-resource-model-comparator -Dtest-mode=run` | 0 | pass (pass=9 accepted=8 fail=0 pending=3) | 22000ms |
| 4 | `zig build test-resources-all` | 0 | pass | 26000ms |
| 5 | `zig build test-resource-editor-fixtures test-resource-xml-roundtrip` | 0 | pass | 20000ms |
| 6 | `zig build resource-editor-auto-til` | 0 | pass | 11000ms |

## Deviations

Plan step 2 expected a port fix for 3rd SoilParams; the MFC source shows the port already matches it, so the difference is recorded as pending instead. Plan step 3 expected til to compare for real: it does, with the DDS differences pending because of the fixture art size.

## Known Issues

Golden regeneration is needed on win-home for scp and til (export-goldens.ps1 -Extensions scp,til) and a hand re-export of 3rd noting the Has dust effect and Units leave tracks items. Full sweep left to the maintainer.

## Files Created/Modified

- `Sources/src/ResourceModel/comparator.cpp`
- `tools/zig/resource_model_comparator_test.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `tools/zig/resource_editor_fixtures.zig`
- `tools/zig/fixtures/resource_editor/til/art-16x16.tga`
- `tools/zig/fixtures/resource_editor/EXTENSIONS.md`
- `tools/zig/win-home/export-goldens.ps1`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`
