---
id: T14
parent: S16
milestone: M001
key_files: []
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-06T15:18:06.060Z
blocker_discovered: false
---

# T14: 3rd SoilParams is accepted as a proven upstream MFC precedence bug, the precedence audit found no other hit, the file-name case is covered by a comparator test, and the goldens now compare pass=10 accepted=10 fail=0 pending=0.

**3rd SoilParams is accepted as a proven upstream MFC precedence bug, the precedence audit found no other hit, the file-name case is covered by a comparator test, and the goldens now compare pass=10 accepted=10 fail=0 pending=0.**

## What Happened

Replaced the pending 3rd VSODescription/SoilParams rule in comparator.cpp with a proven (accepted) one citing C3DRoadCommonPropsItem::SetSoilParams at 7f0f4be5c (`nVal & ESP_DUST != 0x0` parses as nVal & (ESP_DUST != 0), i.e. nVal & 1), Johannes' win-home verification and his decision to keep the stored 16. 3rv has no soil path in its editor. Precedence audit over every file under Sources/src/editor at 7f0f4be5c found a single hit (3dRoadTreeItem.h:51, two expressions on one line), already fixed in aea2ebc4c; the port reads `( cSoilParams & FLAG ) != 0` in road3d_export.cpp:170-171, so no port change. File-name case: the comparator already pairs files case-insensitively and the engine reader folds the case of stored names, so no accepted rule was needed (I tried a case-only accepted rule, found it unreachable, and removed it); added a 'golden negative case' test (cgc: golden file named 1.XML pairs with 1.xml, lowercase Chapter equals the port's mixed-case value, a different value still fails). Recorded the decision, the audit and the final 20-kind table in the spec (S16 T14 amendment) and 06-PARITY.md. Goldens were not regenerated; full sweep left to the maintainer. T07 stays on hold (D043).

## Verification

Ran the four plan commands in the foreground; all exit 0. Comparator prints GOLDEN_SUMMARY extensions=20 pass=10 accepted=10 fail=0 pending=0. No macOS or Windows result claimed.

Final per-kind table: pass: wpn, mcp, scp, unt, eff, 3rv, mip, chc, cgc, mdc. Accepted: trc (DXT5 encoder block, 6), spt (golden 1.xml is only MFC's History, 1), msh (six-digit floats, 38), obt (GetPos3 float rounding, 4), fnc (15), bld (no cached desc block 4 + float rounding 15), bdg (float rounding, 105), pcp (six-digit floats, 2), til (392 six-digit floats + MFC History replaced tileset XML, 393), 3rd (SoilParams upstream MFC bug, 1). Pending: none. Fail: none. gui has no golden (switched off in MFC).

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-model-comparator -Dtest-mode=run` | 0 | pass | 22000ms |
| 2 | `zig build test-resource-model -Dtest-mode=run` | 0 | pass | 23000ms |
| 3 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 77000ms |
| 4 | `zig build test-resources-all` | 0 | pass | 26000ms |

## Deviations

None.

## Known Issues

None.

## Files Created/Modified

None.
