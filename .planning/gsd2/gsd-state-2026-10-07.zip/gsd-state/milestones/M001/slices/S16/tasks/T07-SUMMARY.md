---
id: T07
parent: S16
milestone: M001
key_files:
  - docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-06T16:53:35.152Z
blocker_discovered: false
---

# T07: MFC editor removed in c6b4329c6 (PRE_DELETE b8aa895bb00efb2fdac28096656dcf26984e3f87); spec placeholder filled and stale goldens line corrected.

**MFC editor removed in c6b4329c6 (PRE_DELETE b8aa895bb00efb2fdac28096656dcf26984e3f87); spec placeholder filled and stale goldens line corrected.**

## What Happened

The deletion was performed in the release steer session: commit c6b4329c6 'chore(resource-editor): remove the MFC editor' deletes Sources/src/editor and both MFC editor.exe binaries, edits A7.sln-related references, tools/zig/stage.zig and mfc_item_inventory.py. PRE_DELETE is b8aa895bb00efb2fdac28096656dcf26984e3f87. Under the hard steer of 2026-10-06T16:52 the task is completed from that commit. The spec's placeholder 'PRE_DELETE = <filled by S16/T07>' now holds the full hash, and the stale line claiming bdg/3rd/3rv/mip/chc/cgc goldens are missing now says all 20 exist, with 3rd and 3rv exported by hand in MFC's GUI because MFC's batch export of them crashes. Committed as a docs(resource-editor) commit; git status is clean. Full sweep left to the maintainer, who runs it on c6b4329c6.

## Verification

Foreground: zig build install-game install-map-editor install-resource-editor test-resource-model finished with VERDICT=PASS on Linux. test-resources-all and the full sweep were not run here. No macOS or Windows result is claimed.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build install-game install-map-editor install-resource-editor test-resource-model` | 0 | PASS | 0ms |

## Deviations

None.

## Known Issues

None.

## Files Created/Modified

- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`
