---
estimated_steps: 17
estimated_files: 7
skills_used: []
---

# T10: Golden alignment round 2: real comparison of 17 MFC goldens, fixture fixes, camera reproduction

Order: runs now, after T09 and BEFORE T07 (T07 stays on hold, D043; T07 also depends on T10). Hard steer 2026-10-06T08:50, D044. Do not dispatch T07 in parallel with it.

Why: the maintainer regenerated the MFC goldens from the re-saved fixtures (commit 3e98ebc19: 17 kinds incl. mip chc cgc; bdg 3rd 3rv still crash MFC). test-resource-model-comparator at 3e98ebc19 reports pass=4 accepted=3 fail=0 pending=13, but much of 'pending' is stale or fixable.

Do:
1. Remove stale pending rules in the comparator (kGoldenDifferences, GOLDEN_SUMMARY): mip/chc/cgc now have goldens ('MFC crashed, none exists' is wrong); msh/obt/bld/wpn/trc 'pending regeneration' is wrong (regenerated with MFC's own cached stats via open-and-save). Compare them for real. For each difference either fix the port or fixture, or explain it as accepted only when proven from MFC source and golden bytes (D041 rule). Keep every other kind's result unchanged unless proven.
2. Fix the fixtures so MFC exports their full content. Verify each from MFC source in Sources/src/editor and from the golden:
 - eff: references function particle 'particle-2key' that installed data lacks (EffectFrm.cpp:215). Point it at a shipped particle, or ship the particle in the fixture.
 - scp: golden holds only History because CSquadFrame::SaveRPGStats stops at MakeName (SquadFrm.cpp:198-216) for an unresolvable member. Use a shipped unit.
 - til: needs editor\terrain\tilemask.tga in the editor data folder. Add it to the fixture or scratch, or document exactly which file the maintainer must place where (export-goldens.ps1 and PARITY).
 - 3rd: texture terrain\sets\1\roads3d\road_asphalt01 does not exist in shipped data (GOG paks have road_asphalt_city, road_asphalt_ground, road_asphalt_gravel, rail_road_grass/gravel). Use terrain\sets\1\roads3d\road_asphalt_city.
 - 3rv: water\bottom does not exist (shipped: water\a_bottom, water\water). Use water\a_bottom.
 - bdg: crashes MFC on open. Compare its tree with tools/zig/fixtures/resource_editor/mfc-new/bridgetest.bdg (BridgeFrm.cpp:428-436 SpecificInit, 734-793 span parts back/front/bottom, 783 bottom sprite). Make every span carry its three part items and valid sprite references.
 Keep the port's tests green; update expectations (fixture hashes, byte-identity checks) where a fixture changes. Re-save changed fixtures through the port so they keep own_data and RPG (T09). Keep CRLF.
3. Camera-dependent values (fnc origins, bld explosion noise, obt grids and packs): reproduce MFC's IScene::GetPos2/GetPos3 with the editor's default camera (Scene/Camera.cpp, GraphicsEngine.cpp SetupViewport, as S08 T07 did) and compare. Keep 'pending' only what cannot be proven, with that reason.
4. Update 06-PARITY.md and the spec amendment (append-only) with the per-kind result. Add a note for the maintainer: re-run export-goldens.ps1 on win-home, and which kinds to retry (bdg 3rd 3rv, fixed kinds eff scp til).
5. Do not regenerate MFC goldens. Verify with plain zig build commands only. Commit as fix(resource-editor): / test(resource-editor):, with fixtures, headers and docs included. git status must be clean.
6. Summary reports per kind: pass / accepted (with proof) / pending (with reason) / fixed. Full sweep left to the maintainer.

Done when: no stale pending rule remains, each fixture issue above is fixed or documented, camera values are proven or kept pending with reason, and the verify line is green.

## Inputs

- `tools/zig/fixtures/resource_editor`
- `tools/zig/fixtures/resource_editor/mfc-new`
- `Sources/src/editor`
- `Sources/src/Scene/Camera.cpp`
- `Sources/src/Scene/GraphicsEngine.cpp`
- `.gsd/OVERRIDES.md`
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`

## Expected Output

- `tools/zig/fixtures/resource_editor`
- `tools/zig/resource_model_comparator.cpp`
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`

## Verification

zig build test-resource-model -Dtest-mode=run && zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model-comparator -Dtest-mode=run && zig build test-resources-all

## Observability Impact

The comparator prints one line per kind (pass, accepted, pending, fail with reason) and the GOLDEN_SUMMARY counts.
