# S16 Research: Full sweep, delete MFC, spec amendment, STATE.md update

Depth: targeted. This is a closeout slice. Most of its work is gating and deletion, plus one new test tier. Findings come from build.zig, tools/zig/stage.zig, Sources/src/A7.sln, 06-PARITY.md, 06-CONTEXT.md and .planning/STATE.md.

## 0. Required first task: S15 review fix (D036, hard steer 2026-10-06T04:54)

S16/T01 is already planned (tasks/T01-PLAN.md). Keep it as T01 and run it before every other S16 task. The slice must not complete without it. The task fixes CUiScreen::Paste (Sources/src/ResourceModel/ui_screen.cpp:910), which copies ElementIDs unchanged and so can give two controls the same id in UI_NOTIFY_WINDOW_CLICKED. The rule is port behaviour, because MFC has no GUI paste. A pasted ElementID is kept when it is unused in the target screen. When it collides, it gets the next free ElementID, also inside pasted subtrees, so the pasted windows stay unique among themselves. Each reassignment is reported in the status line and the log, and undo restores. Tests check, through the engine's UI reader, that pasting twice into the same screen gives unique ElementIDs and leaves the originals unchanged, and that a paste with no collision keeps its ids. Number the other S16 tasks from T02.

## Summary

S16 has one real build task (`resource-editor-game-reads-it`) and a small deletion task. Two of its gates cannot be passed by an agent:
- Johannes's hand try on macOS and Windows.
- The MFC goldens, which only win-home can produce.

Decision D-26 in 06-CONTEXT.md allows deletion only after three things: all 06-PARITY.md rows are done, all goldens and `test-resources-all` pass, and Johannes approves the hand try. Do not delete anything until Johannes approves. The plan should put the deletion in a task that is explicitly blocked on that approval, or split it into its own slice.

## Findings

1. **`resource-editor-game-reads-it` does not exist.**
   - `rg` of build.zig finds only the `map-editor-game-reads-it`, `-m2` and `-m3` steps (build.zig around lines 7987-8040).
   - The S15 `resource-editor-auto-gui` step already test-launches the real Game and measures frames, so it is a working pattern.
   - The new step should export one resource per kind into a temp mod and launch `Game -mod=...` with each resource.
   - It should require a clean exit and a clean game log.
   - Model it on `map-editor-game-reads-it-m3`:
     - `XDG_DATA_HOME` and `BK_USER_ROOT` redirected into `zig-out/local-test/`.
     - `BK_DEBUG_LOG=1`.
     - A log file under `zig-out/local-test/`.
   - Fixtures are under `tools/zig/fixtures/resource_editor/<ext>/`. Only kinds that have an exporter can be included.
   - Kinds that refuse export or have no game-side loader need an explicit documented exception in PARITY.
   - Examples are tileset preview/import refusal, eff import refusal and Mission needing a map.
   - Check which of the 21 kinds the engine can load from a mod. `resource-editor-auto-gui` is the proven example for gui, and the others need their own loader check.
   - Add the step to the CI jobs in `.github/workflows/cross-platform.yml` only on the GPU runners, as the map one is.

2. **`test-resources-all` already exists** (build.zig around line 10234).
   - It aggregates only the window-free and GPU-free tiers: test-resource-model, test-resource-xml-roundtrip, test-dxt-tolerance and test-resource-editor-fixtures.
   - It does not include the per-editor autos or the bridge/core tiers.
   - The roadmap's "green locally with 0 FAIL" means run this step plus the sweep.
   - Per AGENTS.md, an agent cannot run `tools/zig/run-resource-sweep.sh` (about 27 minutes, over the 10-minute foreground cap).
   - The plan must say "full sweep left to the maintainer". It should list the individual tiers the agent runs in the foreground.
   - The agent can run these one at a time, each under about 3 minutes:
     - `test-resources-all`
     - `resource-editor-host-check`
     - `resource-editor-smoke`
     - each `resource-editor-auto-<ext>` (core, wpn, unt, spt, msh, obt, fnc, bld, bdg, pcp, eff, til, 3rd, 3rv, mip, chc, cgc, mdc, gui)
     - the new game-reads-it step
     - `test-resource-core`, `test-resource-bridge`, `test-resource-model`, `test-resource-model-comparator`, `test-resource-app-logic`
     - `test-editor-core`
     - the Map Editor `map-editor-smoke`
   - GUI tiers need the user's display env. Set `XDG_RUNTIME_DIR=/run/user/$UID` and the Wayland display, or use `SDL_VIDEODRIVER=offscreen`. The gsd_exec sandbox lacks both. Prior slices recorded `SdlInitFailed` for this reason.
   - Do not run several resource-editor UI tiers in parallel. They race on `zig-out` (S07 note).

3. **06-PARITY.md is not fully done.**
   - Rows still `todo`: A-13 (View toggles), A-16 (Set Background Colour) and A-17 (Expand/Collapse all). S05 listed them as not implemented. The grep was truncated at 40 lines, so the planner must re-grep `todo` and `pending` across the whole file.
   - Rows marked "pending win-home":
     - The MFC golden comparisons for every kind. There are 20 or more rows, each citing `export-goldens.ps1 -Extensions <list>`.
     - B-09.14 (GOG bld brandenburgertor).
     - B-14.5 (GOG mip ardennen40).
   - D-26 and D-29 say every row must be done. The options are:
     - Implement A-13, A-16 and A-17. They are small ImGui features in `Sources/editor/resource_app`: tree and inspector visibility toggles, a background colour setting stored in `resourceeditor.cfg`, and expand/collapse all through the existing `BkResSetNodeExpand`.
     - Or mark them `no behaviour in MFC` with a reason. That is not true here, since MFC has these commands.
   - Recommendation: implement them first. This is the first proof and the largest code change in the slice.
   - Pending-win-home rows cannot be closed on Linux.
   - The plan must record them as a maintainer or win-home follow-up. It must not mark them done. This also means the full D-29 criteria and "every parity row done" cannot be met by an agent.
   - Do not claim macOS or Windows results (AGENTS.md).

4. **Deletion targets** (verified paths):
   - `Sources/src/editor/` is a directory of 239 entries, 306 tracked files per `git ls-files | wc -l`. It includes `Sources/src/editor/bin/editor2.exe`.
   - `Sources/src/bin/editor.exe`.
   - The `editor` project entry in **`Sources/src/A7.sln`** (not at the repo root). Line 195 reads `Project(...) = "editor", "editor\editor.vcxproj", "{425EDE25-204A-B5C4-9C5F-C77FD3F123E1}"`. Also remove its GUID lines in the project configuration and nested-project sections, and any `ProjectDependencies` that reference it.
   - `tools/zig/stage.zig` `copyEditors` (about line 595): remove the `editor.exe` row only. `ExcelExporter.exe` and `ELK.exe` stay, since they belong to later phases.
   - `copyEditors` skips files that are not found, so the function would not fail after deletion. Remove the row anyway.
   - Not stale references:
     - `Sources/src/ResourceModel/*.h` and `.cpp`, `tools/zig/mfc_item_inventory.py` and `tools/zig/resource_editor_fixtures.zig` mention `Sources/src/editor/` in comments or as input paths.
     - `mfc_item_inventory.py` generates the inventory from `Sources/src/editor`. After deletion, it can no longer be re-run, so the committed `mfc-item-inventory.json` becomes the source of truth. `test-resource-model-fidelity` reads the JSON, not the sources. Confirm this by reading the test before deleting.
     - build.zig line 9955 and `tools/zig/resource_model_test.cpp` mention the directory in comments only. Confirm with `rg`.
   - Before deleting, run `rg -n "src/editor|editor\.exe|editor2"` outside `.gsd/`, `zig-out/` and `.planning/`. Fix any build or CI reference found.
   - Phase 5 did the same for the map editor (STATE.md mentions "deleted the MFC editor"). Use that deletion as precedent: `git log --stat` of the 05-11 deletion commit.
   - The deletion must also leave `zig build install-game install-map-editor install-resource-editor` green. Run the three installs and `test-resource-model` after it. Run the packaging step or check `stage.zig`.
   - The `.exe` files are shipped binaries, so confirm the CRLF and `git status` rules: `git status` must be clean after the commit.
   - The goldens stay (D-26).

5. **Spec amendment.**
   - `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md` already has `## Amendments (M001 planning, 2026-10-05)` with Linux-first-class and the user-data-root rule (done in S01 T01). D031 and D032 and other entries were added later.
   - S16 needs only a final dated entry recording:
     - The deletion.
     - The `resource-editor-game-reads-it` design.
     - The remaining win-home items.
     - The `mfc-item-inventory.json` status.
   - Keep CRLF and the append-only style.

6. **STATE.md update** (`.planning/STATE.md`).
   - It still describes Phase 5 (11/11 plans) as current. It has no Phase 6 or M001 progress.
   - Rewrite the current-position block for the milestone end: S01-S16 status, what is verified on Linux, what is left (hand try, win-home goldens, CI results on macOS and Windows after push), and the open items from the sweeps.
   - Also update the ROADMAP and 06-CONTEXT status lines if they track progress.
   - Do not push (AGENTS.md). The maintainer merges and pushes.

## Recommended order and seams

1. **T01** Implement A-13, A-16 and A-17 with tests (app logic) and an auto step, and update the PARITY rows. Files: `Sources/editor/resource_app/*`, `scenario.zig`, `06-PARITY.md`.
2. **T02** Add `resource-editor-game-reads-it` to build.zig, plus a test driver and a CI entry. This is independent of T01.
3. **T03** Run the Linux foreground tiers and record the log. State "full sweep left to the maintainer". List the unproved items: macOS, Windows, goldens, GOG, hand try.
4. **T04** Spec amendment and STATE.md update. These can be written before deletion, saying that deletion is pending approval.
5. **T05** Deletion. Blocked on Johannes's approval. Do not execute it in auto mode unless an approval is on record. If there is none, the plan should leave T05 unexecuted and mark the slice as needing a human gate.

Each Verify line must be only commands joined by `&&`, with no notes, pipes or redirects (AGENTS.md).

## Constraints and pitfalls

- Match CRLF in all new text files. Commit with a conventional scope, for example `feat(resource-editor): ...` and `chore(resource-editor): remove the MFC editor`.
- Before a task completes, `git status` must be clean.
- Tests use only tracked data and copy it into `zig-out/local-test/`. Never write into shipped `Data/`.
- Do not start a long run in the background and end the session.
- Never claim macOS or Windows results.
- Pre-existing note: the S01 and S02 reports of 8 red Map Editor tiers (the AIWarFog::SetZero trap) were fixed in `3e8afc8a7`. A failure in those tiers now is a real regression.

## Skills

No external skills are needed. Applicable installed skills: verify-before-complete (no completion claims without fresh output) and handoff, if the approval gate stops the slice.
