---
id: T11
parent: S16
milestone: M001
key_files:
  - Sources/src/ResourceModel/comparator.cpp
  - Sources/src/ResourceModel/grid_projection.cpp
  - tools/zig/resource_model_comparator_test.cpp
  - Sources/src/EditorBridge/resource_bridge_test.cpp
  - tools/zig/win-home/export-goldens.ps1
  - tools/zig/resource_editor_fixtures.zig
  - tools/zig/fixtures/resource_editor/spt/_.sprite-1frame.tga
  - tools/zig/fixtures/resource_editor/til/art-16x16.tga
  - tools/zig/fixtures/resource_editor/scp/project.scp
  - tools/zig/fixtures/resource_editor/EXTENSIONS.md
  - docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md
  - .planning/phases/06-resource-editor-portable-port/06-PARITY.md
key_decisions:
  - bdg is compared with the camera anchor one ulp below 24 world cells, because the X component sits exactly on the integer 1536 and MFC truncates to 1535
  - scp member is named by key (USSR_Mosin), which MakeName returns unchanged; the path form stays covered by a scratch copy in the comparator tests
  - til tile art becomes a 32-bit targa as a guess at the cause, recorded as unproven; the mip crash fix is a hypothesis (nested final-map project excluded from the scratch copy)
duration: 
verification_result: passed
completed_at: 2026-10-06T10:20:56.305Z
blocker_discovered: false
---

# T11: The 20 MFC goldens compare pass=8 accepted=7 fail=0 pending=5; bdg is compared and accepted, and the spt, til, 3rd, 3rv, mip and scp fixture problems are fixed or mitigated, with til and mip causes recorded as unproven.

**The 20 MFC goldens compare pass=8 accepted=7 fail=0 pending=5; bdg is compared and accepted, and the spt, til, 3rd, 3rv, mip and scp fixture problems are fixed or mitigated, with til and mip causes recorded as unproven.**

## What Happened

Compared the goldens for real. bdg: the golden's camera anchor is 24 world cells with the X component exactly on the integer 1536, which MFC's quaternion axes truncate to 1535. The comparison uses the anchor one ulp below 24 cells, and the remaining float noise on bridge segments, fire points and smoke points is accepted under the existing 1e-3 bound with source-line reasons. eff: MFC batch export roots an effect at base, so the comparator reads that root only when it holds an effect child (a weapon read as an effect is still refused). Stale pending rules for bdg and mip are removed, spt is added as pending, and the reasons for scp, til, 3rd and 3rv are rewritten. Fixtures: (1) spt now carries _.sprite-1frame.tga, which CSpriteFrame wants because "_." is a name prefix. (2) til's tile art is a 32-bit targa with 8 alpha bits (new generator kind picture32). The cause of MFC rejecting the 24-bit art is NOT proven: the til golden's crosset has no tiles, and the loader source accepts both formats. (3) export-goldens.ps1 places the tracked Data/Maps/road3d.xml, river3d.xml and all of Data/Terrain/sets/1 in the editor data folder and removes the files again; the script comment lists them. (4) mip: the cause was not found in the open path. The batch runner is recursive and opens the nested mip/final-map project, so the script's scratch copy leaves it out. This is a hypothesis for the next win-home run. (5) scp: the member is named by key USSR_Mosin, which MakeName returns unchanged, so no objects database is needed. The GOG paks are not on this machine, so no unit could be checked against them, and a unit present in the paks was not chosen as the plan asked. The comparator tests keep the path form covered on a copy. Tests updated: the spt bridge test expects composed files, and the til atlas test handles 32-bit art. The generator, EXTENSIONS.md, the spec amendment S16 T11 and the 06-PARITY rows are updated, all CRLF. Goldens were not regenerated, as the plan says; the maintainer re-runs the script for spt, scp, til, 3rd and 3rv (and mip if it crashes again). Full sweep left to the maintainer. T07 was not touched.

## Verification

Ran in the foreground on Linux: test-resource-model, test-resource-bridge, test-resource-model-comparator, test-resources-all, test-resource-editor-fixtures, test-resource-xml-roundtrip, resource-editor-auto-spt, resource-editor-auto-til and resource-editor-game-reads-it. All exit 0. The comparator reports GOLDEN_SUMMARY extensions=20 pass=8 accepted=7 fail=0 pending=5. The PowerShell script parses with 0 errors. No macOS or Windows result is claimed; the full sweep is left to the maintainer.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-model -Dtest-mode=run` | 0 | pass | 23000ms |
| 2 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 88000ms |
| 3 | `zig build test-resource-model-comparator -Dtest-mode=run` | 0 | pass (pass=8 accepted=7 fail=0 pending=5) | 60000ms |
| 4 | `zig build test-resources-all` | 0 | pass | 26000ms |
| 5 | `zig build test-resource-editor-fixtures test-resource-xml-roundtrip` | 0 | pass | 30000ms |
| 6 | `zig build resource-editor-auto-spt` | 0 | pass | 14500ms |
| 7 | `zig build resource-editor-auto-til` | 0 | pass | 7000ms |
| 8 | `zig build resource-editor-game-reads-it` | 0 | pass | 126000ms |

## Deviations

scp: used a key-named member instead of a unit verified present in the GOG paks, which are not available here. Added a picture32 kind to the fixture generator and regenerated fixtures through make-resource-fixtures so the changes survive regeneration.

## Known Issues

Five goldens (spt, scp, til, 3rd, 3rv) must be regenerated on win-home before they can be compared. The causes of the til art rejection and of the mip open-and-save crash are unproven hypotheses. No GOG paks on this machine, so the scp unit was not checked against them. T07 stays on hold.

## Files Created/Modified

- `Sources/src/ResourceModel/comparator.cpp`
- `Sources/src/ResourceModel/grid_projection.cpp`
- `tools/zig/resource_model_comparator_test.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `tools/zig/win-home/export-goldens.ps1`
- `tools/zig/resource_editor_fixtures.zig`
- `tools/zig/fixtures/resource_editor/spt/_.sprite-1frame.tga`
- `tools/zig/fixtures/resource_editor/til/art-16x16.tga`
- `tools/zig/fixtures/resource_editor/scp/project.scp`
- `tools/zig/fixtures/resource_editor/EXTENSIONS.md`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`
