---
estimated_steps: 8
estimated_files: 5
skills_used: []
---

# T12: Golden round 4: 3rd/3rv SoilParams, real spt and til compare, scp squad export

Order: runs now, after T11 and BEFORE T07. T07 stays on hold (D043); never complete T07 without performing it. Hard steer 2026-10-06T12:06/12:11 (D046).
Why: commit 22a9eba5b holds an MFC golden for all 20 kinds. 3rd and 3rv were exported by hand in MFC's GUI, because MFC's batch export of 3D roads and rivers crashes even for projects MFC made itself. test-resource-model-comparator at 22a9eba5b: pass=9 accepted=7 fail=1 pending=3.
Do:
1. Record in the spec (append-only, dated S16 amendment) and in 06-PARITY.md that the 3rd and 3rv goldens were exported by hand in MFC's GUI, and why: MFC's batch export of 3D roads and rivers crashes even for projects MFC made itself.
2. 3rd FAIL: VSODescription/SoilParams is 16 in the port and 0 in the golden. Find in Sources/src/editor/3dRoadFrm.cpp (FillRPGStats, SaveRPGStats, ExportFrameData) how MFC computes or resets SoilParams on export, and port that. Road and river share the VSO code path, so check 3dRiverFrm.cpp and the 3rv golden too and apply the same fix where it holds.
3. spt and til: their goldens now carry the real export (spt: 1.san plus 1_c/_h/_l.dds; til: 1_*.dds plus crosset.xml and crosset_*.dds). Remove the stale pending rules for both and compare them for real. Fix the port, or explain each remaining difference with proof from MFC source and the golden bytes (D041 rule).
4. scp: the golden still holds only History. The GOG data has USSR_Mosin (data.pak objects.xml lists it and Units/Humans/USSR/Mosin exists), so the member unit is not the cause. Find the cause in CSquadFrame::SaveRPGStats / MakeName (SquadFrm.cpp:198-216) and fix the fixture so the next win-home run exports the squad. If it needs a win-home re-run, state exactly which kind (scp, and 3rd/3rv if their goldens must be re-made by hand) in the task summary, PARITY and the spec.
5. Keep the port's tests green; update fixture hashes; re-save changed fixtures through the port. Keep CRLF. Do not regenerate goldens. Commit with fixtures, headers and docs; git status clean. Verify with plain zig build commands only. Report per kind (pass, accepted, pending, fail and why). Full sweep left to the maintainer.

## Inputs

- `Sources/src/editor/3dRoadFrm.cpp`
- `Sources/src/editor/3dRiverFrm.cpp`
- `Sources/src/editor/SquadFrm.cpp`
- `tools/zig/fixtures/resource_editor`
- `.gsd/OVERRIDES.md`

## Expected Output

- `tools/zig/fixtures/resource_editor`
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`

## Verification

zig build test-resource-model -Dtest-mode=run && zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model-comparator -Dtest-mode=run && zig build test-resources-all

## Observability Impact

The comparator prints one line per kind (pass, accepted, pending, fail with reason) and the GOLDEN_SUMMARY counts.
