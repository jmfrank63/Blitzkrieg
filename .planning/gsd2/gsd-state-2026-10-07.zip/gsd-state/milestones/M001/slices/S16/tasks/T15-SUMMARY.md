---
id: T15
parent: S16
milestone: M001
key_files:
  - Sources/src/EditorBridge/resource_bridge.cpp
  - Sources/src/EditorBridge/resource_bridge_test.cpp
  - Sources/editor/resource_app/batch_cli.zig
  - Sources/editor/resource_app/tools_logic.zig
  - tools/zig/fixtures/resource_editor/bdg/project.bdg
  - .github/workflows/cross-platform.yml
  - tools/zig/run-resource-sweep.sh
  - AGENTS.md
  - docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md
  - .planning/phases/06-resource-editor-portable-port/06-PARITY.md
key_decisions:
  - Exports never use the live scene camera; they always use DefaultEditorCamera so output is independent of view state
  - Exporter warnings use '<path> (warning): ' so only failures are '<path>: reason'
  - bdg fixture cached block re-saved under the fixed camera; other fixtures unchanged
duration: 
verification_result: passed
completed_at: 2026-10-06T15:43:53.171Z
blocker_discovered: false
---

# T15: The batch (BkResBatch, --batch) exports all 21 kinds byte-for-byte like the single export, with and without an open project, without depending on the live scene camera; mixed folders report per project and fail the exit; resource-editor-batch is in CI and the sweep.

**The batch (BkResBatch, --batch) exports all 21 kinds byte-for-byte like the single export, with and without an open project, without depending on the live scene camera; mixed folders report per project and fail the exit; resource-editor-batch is in CI and the sweep.**

## What Happened

BkResBatch now reads each project from its file and exports it with the kind's exporter alone (3rd and 3rv included), wraps each project in a try/catch, names failures as '<path>: <reason>', continues, and answers FAILED when any project failed. Exporter warnings are reported as '<path> (warning): ...' so they no longer count as failed projects. A view-state dependency was found and removed: object/fence/building/bridge exports used the live scene camera (GetPos2); they now always use DefaultEditorCamera. The bdg fixture's cached block was re-saved under it. The -os batch keeps its byte-for-byte contract (no mesh locator rebuild). tools_logic treats FAILED as 'ran'. test-resource-bridge got all-kind batch vs single export cases (nothing open, project of the kind open and edited, mixed folder, engine reader read-back of all 21); the --batch-check tier was extended the same way (full kind folders are now copied so cached stats see the pictures, failure text arena fixed). resource-editor-batch was added to the Windows and macOS CI jobs and tools/zig/run-resource-sweep.sh; AGENTS.md, the spec (dated S16 T15 amendment) and 06-PARITY.md record the decision. The first draft of the re-save loop wrongly rewrote mip/chc/cgc/mdc fixtures; those were reverted and the check fixed instead.

## Verification

Ran the plan's verify commands plus related tiers in the foreground on Linux; all exit 0. Full sweep left to the maintainer. No macOS or Windows result claimed.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 80000ms |
| 2 | `zig build resource-editor-batch -Dtest-mode=run` | 0 | pass | 60000ms |
| 3 | `zig build test-resource-model -Dtest-mode=run` | 0 | pass | 60000ms |
| 4 | `zig build resource-editor-smoke -Dtest-mode=run` | 0 | pass | 6000ms |
| 5 | `zig build test-resource-model-comparator -Dtest-mode=run` | 0 | pass (pass=10 accepted=10 fail=0 pending=0) | 60000ms |
| 6 | `zig build test-resource-app-logic -Dtest-mode=run` | 0 | pass | 30000ms |
| 7 | `zig build resource-editor-auto-core -Dtest-mode=run` | 0 | pass | 120000ms |
| 8 | `zig build resource-editor-auto-bdg -Dtest-mode=run` | 0 | pass | 15000ms |

## Deviations

None to the task plan; the bdg fixture re-save was needed to keep the -os byte-for-byte check green after removing the scene camera.

## Known Issues

None.

## Files Created/Modified

- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `Sources/editor/resource_app/batch_cli.zig`
- `Sources/editor/resource_app/tools_logic.zig`
- `tools/zig/fixtures/resource_editor/bdg/project.bdg`
- `.github/workflows/cross-platform.yml`
- `tools/zig/run-resource-sweep.sh`
- `AGENTS.md`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`
