---
estimated_steps: 7
estimated_files: 3
skills_used: []
---

# T14: Golden round 6: 3rd SoilParams upstream bug accepted, precedence audit, file-name case, final per-kind table

Order: runs now, after T13 and BEFORE T07. T07 stays on hold (D043); never complete T07 without performing it. Hard steer 2026-10-06T15:07 (D048).
Why: all 20 MFC goldens are committed (last 9c6f92f9e; 3rd and 3rv exported by hand in MFC's GUI). Comparator at 9c6f92f9e: pass=10 accepted=9 fail=0 pending=1 (3rd SoilParams).
Do:
1. 3rd SoilParams: record as ACCEPTED, with this reason (proven upstream MFC bug, verified by Johannes on win-home with six test files). Upstream C3DRoadCommonPropsItem::SetSoilParams (Sources/src/editor/3dRoadTreeItem.h at 7f0f4be5c) reads 'values[12].value = ( nVal & SVectorStripeObjectDesc::ESP_DUST != 0x0 )'. C++ parses that as nVal & (ESP_DUST != 0), i.e. nVal & 1. With ESP_DUST=0x10 and ESP_TRACE=0x01 MFC loads dust as false (and both flags true when the trace bit is set) on every project load (LoadRPGStats -> GetRPGStats -> SetSoilParams). A new project shows dust true and saves SoilParams 16; after reopening it shows false and exports 0. This repo fixed the precedence in aea2ebc4c. The port keeps the stored value 16 by decision of Johannes: 'we are not taking over this bug, we are going to fix it'. Remove the 3rd pending entry, add the accepted rule to the comparator (kGoldenDifferences or the accepted rules it uses), and check 3rv for the same path.
2. Precedence audit: search the upstream MFC sources (git show 7f0f4be5c:<path>, every editor under Sources/src/editor) for the same pattern: 'x & FLAG != 0', 'x & FLAG == 0', and similar (| or ^ against a comparison, shifts mixed with comparisons). List each hit with file:line, say whether this repo already fixed it (aea2ebc4c or later) and whether the port behaves like the fixed form (cite the port code or a test). Record the list in the spec (append-only, dated S16 amendment) and in 06-PARITY.md. Fix a port divergence only if one is found; report it.
3. File-name case: record Johannes's decision in the spec: the port keeps names and paths in the case written ('appropriate for modern OS'); MFC lowercases file names and stored paths on save. Make the golden comparator match MFC's lowercased golden file names to the port's names case-insensitively where needed (file pairing, and stored path values only where the difference is the case alone, listed as accepted with this reason). Add a comparator test for a mixed-case port name against a lowercase golden.
4. Final per-kind table (20 kinds: pass, accepted, pending, fail, with reason) in the task summary, 06-PARITY.md and the spec. Do not regenerate goldens. Keep CRLF for repo text files. Commit as docs/test/fix(resource-editor) with a scope; git status clean (headers, fixtures, docs included). Verify with plain zig build commands only; full sweep left to the maintainer.

## Inputs

- `Sources/src/editor/3dRoadTreeItem.h`
- `tools/zig/resource_model_comparator_test.cpp`
- `tools/zig/fixtures/resource_editor`
- `.gsd/OVERRIDES.md`

## Expected Output

- `tools/zig/resource_model_comparator_test.cpp`
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`

## Verification

zig build test-resource-model-comparator -Dtest-mode=run && zig build test-resource-model -Dtest-mode=run && zig build test-resource-bridge -Dtest-mode=run && zig build test-resources-all

## Observability Impact

The comparator prints one line per kind and GOLDEN_SUMMARY; expected after this task: fail=0 pending=0.
