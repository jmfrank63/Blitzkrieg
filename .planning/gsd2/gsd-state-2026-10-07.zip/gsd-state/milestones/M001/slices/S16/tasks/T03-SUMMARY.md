---
id: T03
parent: S16
milestone: M001
key_files:
  - Sources/src/StreamIOZig/streamio.zig
  - Sources/editor/resource_app/scenario.zig
  - Sources/editor/resource_app/game_reads_logic.zig
  - Sources/editor/resource_app/panels_logic.zig
  - tools/zig/fixtures/resource_editor/game-reads-it.auto
  - build.zig
key_decisions:
  - BK_MOD_TRACE lives in the Zig StreamIO overlay lookup, the Game's real data path
  - Per-kind placement is a manifest fixture because schedule arguments are limited to 64 characters
  - Exports are mirrored to the shipped resource's path by copying the exported folder unchanged
duration: 
verification_result: passed
completed_at: 2026-10-06T05:51:47.108Z
blocker_discovered: false
---

# T03: Added resource-editor-game-reads-it: nine object-side kinds (wpn, unt, msh, obt, fnc, bld, scp, mcp, bdg) are exported into one mod, and the real Game, run with the new BK_MOD_TRACE, is shown to open each exported file from the mod; per-kind result.log.

**Added resource-editor-game-reads-it: nine object-side kinds (wpn, unt, msh, obt, fnc, bld, scp, mcp, bdg) are exported into one mod, and the real Game, run with the new BK_MOD_TRACE, is shown to open each exported file from the mod; per-kind result.log.**

## What Happened

Engine trace: StreamIOZig/streamio.zig overlayStream prints `BK_MOD_TRACE: open "<name>" from <overlay>` for each stream the MOD overlay answers, only when BK_MOD_TRACE is set (the Game's data path is the Zig StreamIO, not the C++ CModFileSystem). Scenario (scenario.zig): new actions do=copy_tree, do=gri_copy:<ext> (copy fixture sans golden, open it), do=gri_mirror:<ext> (copy export folder to the shipped resource's path in the mod), do=run_game:<map> (Game on multiplayer\<map>.bzm with BK_MOD_TRACE and BK_DEBUG_LOG, exits at frame 300), and expect=mod_read:<ext>, which checks the Game log, appends a `KIND=<ext> PROOF=game FILE=<path> RESULT=PASS|FAIL` line to result.log and fails the run on FAIL. Because schedule arguments are capped at 64 characters (kit/auto_schedule.zig, untouched), per-kind names live in the manifest tools/zig/fixtures/resource_editor/game-reads-it.auto, parsed by new game_reads_logic.zig (tests in test-resource-app-logic). build.zig has the step resource-editor-game-reads-it, with user data redirected to zig-out/local-test/resource-editor-game-reads-it-user. It plays coldwinter (wpn, unt, msh, obt, fnc), lastchance (bld, scp, mcp) and arnheim (bdg). The weapon proof uses weapon "generic", the one the exported fixture unit names (no shipped file of that name exists). The working-tree edits left by the interrupted T02 run (status-bar toggle in docks.zig/main.zig, Ctrl+C shortcut row, test registration) were verified by the core tier and logic tests and are part of this commit.

## Verification

zig build install-game && zig build install-resource-editor && zig build resource-editor-game-reads-it exits 0 on Linux; result.log has nine KIND lines, all PROOF=game PASS. Negative check: the schedule without do=gri_mirror:fnc exits 1 with KIND=fnc RESULT=FAIL. Regression tiers: test-resource-app-logic (193 pass), resource-editor-auto-core PASS, test-streamio (37 pass). No macOS/Windows result claimed; full sweep left to the maintainer.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build install-game && zig build install-resource-editor && zig build resource-editor-game-reads-it` | 0 | pass (9 KIND lines PASS) | 120000ms |
| 2 | `negative: schedule without gri_mirror:fnc, ResourceEditor --auto` | 1 | pass (fails as intended) | 90000ms |
| 3 | `zig build test-resource-app-logic resource-editor-auto-core` | 0 | pass | 60000ms |
| 4 | `zig build test-streamio` | 0 | pass | 15000ms |

## Deviations

None.

## Known Issues

Not covered here, left for T04 with PROOF=reader and a reason: spt, pcp and eff (no shipped map loads them without a battle) and trc (the fixture trench exports empty Segments/Arcs, and the Game aborts with division by zero in SEntrenchmentRPGStats::GetIndexLocal when a map places it; the Game did open the file from the mod). tools/zig/win-home/export-goldens.ps1 shows as modified but was not touched by this task. The step was run on the debug install (the default); I did not run it on the release install.

## Files Created/Modified

- `Sources/src/StreamIOZig/streamio.zig`
- `Sources/editor/resource_app/scenario.zig`
- `Sources/editor/resource_app/game_reads_logic.zig`
- `Sources/editor/resource_app/panels_logic.zig`
- `tools/zig/fixtures/resource_editor/game-reads-it.auto`
- `build.zig`
