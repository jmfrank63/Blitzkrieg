---
estimated_steps: 10
estimated_files: 7
skills_used: []
---

# T09: Save in MFC form: own_data and cached RPG, mfc-new round trips, re-saved fixtures

Order: runs next, after T08 and BEFORE T05, T06 and T07 (T05, T06 and T07 depend on T09; never dispatch them in parallel with it; T07 also depends on T02-T06 and T08). Hard steer 2026-10-06T06:34, D042.

Why: commit 06a23287d added tools/zig/fixtures/resource_editor/mfc-new/, one empty project per editor made by Johannes with the shipped reseditor.exe (byte-exact). MFC writes and reads <own_data> (export_dir/export_file_name plus frame data such as Front/Back/Begin/End for bridges) and the cached <RPG> stats block before History. It reads them unguarded on open, which is why the port-written bdg/mip/chc/cgc fixtures crash the shipped editor and why MFC's batch export of the other fixtures used struct defaults. D-07 asks for byte-identical output for an unedited save.

Do:
1. Round trip: add a test that opens every mfc-new project in the port, saves it unedited, and compares the saved bytes to the input. Fix the writer until they are equal. Record any unavoidable difference, with its reason, in the spec (docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md) and 06-PARITY.md. No blanket tolerances.
2. Save in MFC form: read CParentFrame::SaveFrame and SaveRPGStats in Sources/src/editor. The port's save writes <own_data> and the cached <RPG>/<desc> block in MFC's form and order for every kind, refreshed from the tree on each save (not copied from the loaded text), so MFC can open every project the port writes. Use the engine readers in ResourceModel, and keep the bridge C ABI additive.
3. Re-save every fixture tools/zig/fixtures/resource_editor/<ext>/project.<ext> through the port so each carries both blocks. Update the byte-identity expectations (fixture hashes and any golden-of-saved-bytes checks) to the new bytes. Do not touch shipped Data. Keep CRLF as the files already have.
4. Tests: each mfc-new project round-trips (step 1); each re-saved fixture contains own_data and RPG (add the check to test-resource-model or the fixture test that already walks the fixtures). Keep the existing resource tiers green.
5. Do not regenerate MFC goldens: the maintainer does that on win-home from the re-saved fixtures. Note in the summary that the 'pending regeneration' kinds of D041 and the 6 crashing kinds (bdg 3rd 3rv mip chc cgc) can be retried there.
6. Verify with plain zig build commands only. Commit as fix(resource-model): or feat(resource-editor): with fixtures, headers and docs included. git status must be clean.

Done when: all mfc-new projects round-trip byte-equal (or each difference is recorded with its reason), every fixture project holds own_data and RPG, and the verify line is green. Full sweep left to the maintainer.

## Inputs

- `tools/zig/fixtures/resource_editor/mfc-new`
- `tools/zig/fixtures/resource_editor`
- `Sources/src/editor`
- `.gsd/OVERRIDES.md`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`

## Expected Output

- `Sources/src/ResourceModel`
- `tools/zig/fixtures/resource_editor`
- `tools/zig/resource_model_test.cpp`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`

## Verification

zig build test-resource-model -Dtest-mode=run && zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model-comparator -Dtest-mode=run && zig build test-resources-all

## Observability Impact

The round-trip test logs one line per mfc-new project (kind, bytes, equal or first differing offset); the fixture check logs own_data and RPG presence per fixture.
