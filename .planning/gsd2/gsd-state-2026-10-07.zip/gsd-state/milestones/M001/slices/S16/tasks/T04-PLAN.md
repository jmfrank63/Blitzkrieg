---
estimated_steps: 12
estimated_files: 7
skills_used: []
---

# T04: resource-editor-game-reads-it: remaining kinds, CI, sweep, PARITY

Why: T03 covers the kinds a map loads at start. The remaining kinds are til, 3rd, 3rv, mip, chc, cgc, mdc and gui, plus pcp and eff if T03 did not cover them. Each of the 21 kinds must be proved, or recorded with a reason.
Do:
- Extend the step. For each kind, prefer the real Game. Examples:
  - gui: the exported Data/UI screen, as resource-editor-auto-gui proves.
  - mip: launch the exported mission (check how the Game starts a mission from the command line or through BK_AUTO_UI).
  - til/3rd/3rv: the season tileset, road and river descriptors a map loads.
  - chc/cgc/mdc: the campaign and chapter screens through BK_AUTO_UI.
- When the Game cannot be driven headless to load a kind, prove it with the engine's own reader, the same one the Game uses (comparator/IDataTree reader on the exported file), and record PROOF=reader and the reason. Never prove by eyeballing.
- Add the step to .github/workflows/cross-platform.yml on the GPU runners only, the same way map-editor-game-reads-it is. Add it to tools/zig/run-resource-sweep.sh and to AGENTS.md's Resource Editor tier list.
- Add a PARITY entry for game-reads-it per kind with its proof and reason.
- Commit as test(resource-editor):. git status must be clean.
Done when: result.log has 21 KIND lines, all PASS, and the step exits 0 on Linux.

## Inputs

- `build.zig`
- `Sources/editor/resource_app/scenario.zig`
- `tools/zig/fixtures/resource_editor/game-reads-it.auto`
- `.github/workflows/cross-platform.yml`
- `tools/zig/run-resource-sweep.sh`

## Expected Output

- `build.zig`
- `Sources/editor/resource_app/scenario.zig`
- `tools/zig/fixtures/resource_editor/game-reads-it.auto`
- `.github/workflows/cross-platform.yml`
- `tools/zig/run-resource-sweep.sh`
- `AGENTS.md`
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`

## Verification

zig build install-resource-editor && zig build resource-editor-game-reads-it && zig build resource-editor-auto-gui

## Observability Impact

result.log gains PROOF=reader lines, each with REASON=... for kinds proved by the engine reader.
