---
estimated_steps: 16
estimated_files: 3
skills_used: []
---

# T06: Spec amendment and .planning/STATE.md at milestone end

Depends on: T08 (D040, hard steer 2026-10-06T05:59) and T09 (D042, hard steer 2026-10-06T06:34) must be complete first; do not dispatch T06 before it. The amendment also records T08's per-kind golden results and verified differences.

Why: the roadmap requires a spec amendment and a STATE.md update. The Linux-first-class and user-data-root entries were done in S01, so S16 adds only its closing entry.
Do:
- In docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md, append a dated entry under the existing '## Amendments' sections. Keep the style append-only and CRLF. Record:
  - the resource-editor-game-reads-it design and its per-kind proof table
  - the paste ElementID rule (T01) and A-13/A-16/A-17
  - mfc-item-inventory.json as the frozen source of truth once Sources/src/editor is deleted (tools/zig/mfc_item_inventory.py can then only run from git history; test-resource-model-fidelity reads the JSON, tools/zig/resource_model_test.cpp line 69)
  - the deletion scope (D-26): approved (D037) but held by D043 until the win-home golden comparison is traced against Sources/src/editor; record it as waiting for the golden comparison, not as waiting on approval
  - the open win-home items: MFC goldens per kind, B-09.14, B-14.5
- Rewrite .planning/STATE.md's current-position block for M001 end:
  - S01-S16 status
  - what is verified on Linux (cite the T05 runs)
  - what is open: Johannes's hand try on macOS and Windows release, the win-home goldens (all 20 regenerated from the re-saved fixtures 44094bf22) and GOG goldens, the MFC deletion (T07, held by D043 until the golden comparison), CI results after the maintainer pushes, the full sweep
- Update .planning/ROADMAP.md's phase 6 status line if it tracks progress.
- Do not claim macOS or Windows results.
- Commit as docs(resource-editor):. git status must be clean.
Done when: both documents are committed with CRLF and git status is clean.

## Inputs

- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`
- `.planning/STATE.md`
- `.planning/ROADMAP.md`
- `.planning/phases/06-resource-editor-portable-port/06-CONTEXT.md`
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`

## Expected Output

- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`
- `.planning/STATE.md`

## Verification

git diff --check HEAD~1
