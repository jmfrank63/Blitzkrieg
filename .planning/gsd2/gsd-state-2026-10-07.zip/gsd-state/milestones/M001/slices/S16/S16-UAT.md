# S16: Full sweep, delete MFC, spec amendment, STATE.md update — UAT

**Milestone:** M001
**Written:** 2026-10-06T16:58:33.622Z

# S16 UAT

Run on Linux x64 unless stated. Steps 1 to 3 repeat evidence already recorded by tasks; they were not re-run in the completion session.

1. `zig build test-resource-model-comparator -Dtest-mode=run`: expect pass=10 accepted=10 fail=0 pending=0 (all 20 MFC goldens).
2. `zig build resource-editor-game-reads-it`: expect exit 0, one line per kind for all 21 kinds, 10 with PROOF=game and 11 with PROOF=reader and a REASON.
3. `zig build resource-editor-auto-core` and `zig build resource-editor-batch`: expect exit 0.
4. Maintainer: `tools/zig/run-resource-sweep.sh` at c6b4329c6. Expect VERDICT=PASS. The run at b8aa895bb was PASS (41 tiers); the run at c6b4329c6 was still in progress when the slice was completed.
5. Check `Sources/src/editor` and both MFC editor.exe binaries are gone, and `git show b8aa895bb` still holds them (PRE_DELETE).
6. Open items left for the maintainer: hand try of the editor, win-home goldens, GOG goldens, macOS and Windows CI after push.
