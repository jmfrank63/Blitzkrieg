---
estimated_steps: 9
estimated_files: 5
skills_used: []
---

# T08: Align MFC golden layout in the comparator, wire msh, fix or explain every difference

Order: runs after T04 and BEFORE T05 (T05 and T07 depend on T08; never parallel with T05 to T07). Why: MFC goldens exist for 14 kinds (commit 734245b31: wpn mcp trc scp spt unt msh obt fnc bld pcp eff til mdc), made on win-home by the shipped reseditor.exe batch mode with <own_data><export_file_name>1.xml injected into a scratch copy of each fixture, so each golden folder holds MFC's files at its top level (1.xml, 1_c.dds, 1.san, ...). test-resource-model-comparator reports every golden file as 'the port did not export this file' only because of layout: the port exports under game-data folders (e.g. units/technics/common/entrenchment/trc/1.xml, objects/obt/1.xml, weapons/wpn.xml).
Do:
- In tools/zig/resource_model_comparator_test.cpp, change CompareGoldenFolder: take the folder holding the port's main stats file as the port root, compare files by their path relative to that root, and map the port's main stats file to the golden's 1.xml where the port names it after the project (weapons/wpn.xml). Keep the negative tests (GoldenNegatives) passing and extend them for the new mapping.
- msh reports 'no exporter' although S08 ported one: set bExporter for msh in kExtensions and wire the exporter so the golden is compared.
- Run the comparator and fix every real difference it reveals, field by field through the engine readers, or record a specific, verified reason per difference in docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md (e.g. the History block, MFC bugs we keep or deliberately do not copy). No blanket tolerances.
- bdg 3rd 3rv mip chc cgc crash the MFC editor (0xC0000005): they stay pending with that reason. Keep them pending in the comparator log with the reason and record the 6 kinds as pending-with-reason in 06-PARITY.md.
- Report per kind: files compared, pass or fail (GOLDEN lines plus a table in the task summary).
- Verify with plain zig build commands only. Commit as test(resource-editor): or fix(resource-model): as fits. git status must be clean.
Done when: GOLDEN_SUMMARY shows every one of the 14 kinds as pass, or fail only for differences with a recorded verified reason that the comparator reports as accepted; the 6 crashing kinds are pending with reason.

## Inputs

- `tools/zig/resource_model_comparator_test.cpp`
- `tools/zig/fixtures/resource_editor`
- `.gsd/OVERRIDES.md`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`

## Expected Output

- `tools/zig/resource_model_comparator_test.cpp`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`

## Verification

zig build test-resource-model-comparator -Dtest-mode=run && zig build test-resource-model && zig build test-resources-all

## Observability Impact

GOLDEN lines in the comparator log report files compared and pass or fail per kind; pending kinds carry the MFC crash reason.
