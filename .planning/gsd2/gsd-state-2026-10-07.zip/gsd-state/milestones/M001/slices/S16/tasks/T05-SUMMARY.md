---
id: T05
parent: S16
milestone: M001
key_files:
  - Sources/src/ResourceModel/comparator.cpp
  - Sources/src/ResourceModel/comparator.h
  - tools/zig/resource_model_comparator_test.cpp
  - docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md
  - .planning/phases/06-resource-editor-portable-port/06-PARITY.md
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-06T08:08:50.057Z
blocker_discovered: false
---

# T05: Every Linux tier exits 0 in the foreground, and the golden comparator now reports stats-reload and camera differences as pending (pass=3 accepted=2 fail=0 pending=15).

**Every Linux tier exits 0 in the foreground, and the golden comparator now reports stats-reload and camera differences as pending (pass=3 accepted=2 fail=0 pending=15).**

## What Happened

Ran each tier one at a time in the foreground, with Wayland env present (no SdlInitFailed). install-game, install-map-editor, install-resource-editor, test-resources-all, the logic tiers, resource-editor-host-check, resource-editor-smoke, all 19 resource-editor-auto-<ext> tiers, resource-editor-game-reads-it, map-editor-smoke, map-editor-auto and map-editor-game-reads-it-m3 exit 0. No tier needed a fix. D041 golden follow-up: comparator.cpp/.h and resource_model_comparator_test.cpp gained a pending list; the BK_NO_PROJECT_STATS and BK_SCENE_CAMERA classes and the obt sprite-pack suffix rule go there instead of accepted. Accepted stays for the %lg six-digit floats, the trc DXT5 solid blocks and the sprite History-only golden. GOLDEN_SUMMARY was accepted=8 pending=9 and is now pass=3 accepted=2 fail=0 pending=15. Spec and 06-PARITY.md updated and everything committed. Full sweep left to the maintainer. Unproved here: macOS, Windows, MFC goldens (pending regeneration on win-home), GOG goldens, Johannes's hand try.

## Verification

All listed tiers exit 0. After the comparator change, test-resource-model-comparator, test-resource-model, test-resources-all and test-resource-bridge were rerun and exit 0. git status is clean.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build install-game / install-map-editor / install-resource-editor` | 0 | pass | 12000ms |
| 2 | `zig build test-resources-all` | 0 | pass | 27000ms |
| 3 | `zig build test-resource-model -Dtest-mode=run` | 0 | pass | 24000ms |
| 4 | `zig build test-resource-model-comparator -Dtest-mode=run` | 0 | pass | 22000ms |
| 5 | `zig build test-resource-core -Dtest-mode=run` | 0 | pass | 1000ms |
| 6 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 92000ms |
| 7 | `zig build test-resource-app-logic -Dtest-mode=run` | 0 | pass | 1000ms |
| 8 | `zig build test-editor-core` | 0 | pass | 1000ms |
| 9 | `zig build test-editor-kit` | 0 | pass | 1000ms |
| 10 | `zig build test-editor-bridge` | 0 | pass | 545000ms |
| 11 | `zig build resource-editor-host-check` | 0 | pass | 6000ms |
| 12 | `zig build resource-editor-smoke` | 0 | pass | 6000ms |
| 13 | `zig build resource-editor-auto-<19 exts>` | 0 | pass | 300000ms |
| 14 | `zig build resource-editor-game-reads-it` | 0 | pass | 126000ms |
| 15 | `zig build map-editor-smoke` | 0 | pass | 12000ms |
| 16 | `zig build map-editor-auto` | 0 | pass | 31000ms |
| 17 | `zig build map-editor-game-reads-it-m3` | 0 | pass | 188000ms |

## Deviations

None.

## Known Issues

None.

## Files Created/Modified

- `Sources/src/ResourceModel/comparator.cpp`
- `Sources/src/ResourceModel/comparator.h`
- `tools/zig/resource_model_comparator_test.cpp`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`
