---
id: S16
parent: M001
milestone: M001
provides:
  - (none)
requires:
  []
affects:
  []
key_files:
  - docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md
  - .planning/STATE.md
  - .planning/phases/06-resource-editor-portable-port/06-PARITY.md
  - Sources/src/ResourceModel/comparator.cpp
  - tools/zig/resource_model_comparator_test.cpp
key_decisions: []
patterns_established:
  - (none)
observability_surfaces:
  - none
drill_down_paths:
  []
duration: ""
verification_result: passed
completed_at: 2026-10-06T16:58:33.621Z
blocker_discovered: false
---

# S16: Full sweep, delete MFC, spec amendment, STATE.md update

**M001 closes on Linux: paste ElementID fix, parity rows A-13/A-16/A-17, resource-editor-game-reads-it for all 21 kinds, 20 MFC goldens compared (pass=10 accepted=10 fail=0 pending=0), and the MFC editor deleted in c6b4329c6 (PRE_DELETE b8aa895bb).**

## What Happened

S16 ran 15 tasks. T01 fixed the S15 paste review finding: a pasted window whose ElementID is taken gets the next free id (also inside pasted subtrees), each change is reported to the status line, and undo/redo restore the exact bytes. T02 added the View toggles (Toolbar, Status Bar, Project Tree, Object Inspector), Set Background Colour and Expand/Collapse all (parity rows A-13, A-16, A-17), persisted in resourceeditor.cfg. T03 and T04 added resource-editor-game-reads-it covering all 21 kinds: 10 proved by the real Game via BK_MOD_TRACE, 11 by the engine's own reader with a recorded reason; wired into CI GPU runners, the sweep script, AGENTS.md and PARITY. T05 ran every Linux tier one at a time in the foreground, all exit 0. T06 appended the S16 closing amendment to the spec and rewrote .planning/STATE.md. T08 to T14 did the golden comparison work: comparator aligned to the MFC golden layout, all exporters wired, saves now write own_data and the cached stats block in MFC's form (D042), the MFC value flag (bool=9) is written, the editor camera is reproduced, fixture problems fixed, and 3rd SoilParams accepted as a proven upstream MFC precedence bug. The comparison went from pass=3 accepted=2 pending=15 to pass=10 accepted=10 fail=0 pending=0 over all 20 goldens (3rd and 3rv were exported by hand in MFC's GUI because MFC's batch export crashes on them). T15 made the batch (BkResBatch, --batch) export all 21 kinds byte-for-byte like the single export. T07, held until the golden comparison was complete and approved by Johannes (D037), deleted Sources/src/editor and both MFC editor binaries in c6b4329c6; PRE_DELETE=b8aa895bb00efb2fdac28096656dcf26984e3f87 is recorded in the spec and PARITY as the commit from which MFC goldens can be regenerated. This completion was done by hand in the hard-steer session because auto-mode's complete-slice unit was repeatedly flagged stuck before starting.

## Verification

Evidence is taken from the task summaries (commands as recorded there). T05: install-game, install-map-editor, install-resource-editor, test-resources-all, test-resource-model, test-resource-model-comparator, test-resource-core, test-resource-bridge, test-resource-app-logic, test-editor-core, test-editor-kit, test-editor-bridge, resource-editor-host-check, resource-editor-smoke, the 19 resource-editor-auto-<ext> tiers, resource-editor-game-reads-it, map-editor-smoke, map-editor-auto and map-editor-game-reads-it-m3 all exited 0 in the foreground. Later tasks reran test-resource-model-comparator (final: pass=10 accepted=10 fail=0 pending=0 at b8aa895bb) and resource-editor-batch. The maintainer's full Linux sweep (tools/zig/run-resource-sweep.sh) at b8aa895bb was VERDICT=PASS with 41 tiers; the sweep at c6b4329c6 (the MFC deletion) is still running and is not claimed here. No tier was run in this completion session. macOS and Windows were not run here; they are verified by CI after the maintainer pushes.

## Requirements Advanced

None.

## Requirements Validated

None.

## New Requirements Surfaced

None.

## Requirements Invalidated or Re-scoped

None.

## Operational Readiness

None.

## Deviations

None.

## Known Limitations

Full sweep at c6b4329c6 not yet seen. macOS and Windows unverified until CI. 11 of 21 kinds are proved by the engine's own reader rather than the real Game (reasons in PARITY). 3rd SoilParams is accepted as an upstream MFC precedence bug; til and mip cause notes were recorded as unproven in T11. Hand try, win-home goldens, GOG goldens remain open (see .planning/STATE.md).

## Follow-ups

None.

## Files Created/Modified

None.
