---
estimated_steps: 11
estimated_files: 3
skills_used: []
---

# T03: resource-editor-game-reads-it: step, engine mod-read trace, object-side kinds

Why: the roadmap's S16 demo requires resource-editor-game-reads-it with one resource per sub-editor kind. It does not exist yet; only map-editor-game-reads-it(-m2/-m3) does, in build.zig around lines 7987-8040. AGENTS.md: 'the game reads it unchanged' is proved by the engine's readers or the real Game, never by eyeballing.
Do:
- Add a build step resource-editor-game-reads-it, modelled on map-editor-game-reads-it-m3 and on the run_game / game_log_clean path of resource-editor-auto-gui in Sources/editor/resource_app/scenario.zig. It uses BK_EDITOR_AUTO with a new --game-reads-it scenario, or a dedicated scenario file under tools/zig/fixtures/resource_editor/.
- Redirect XDG_DATA_HOME / BK_USER_ROOT into zig-out/local-test/resource-editor-game-reads-it/ and set BK_DEBUG_LOG=1. Copy only tracked fixtures and Data there; never write to shipped Data.
- Export one resource per kind into one mod folder, under names that replace shipped resources a shipped multiplayer map uses (for example Data/Maps/Multiplayer/coldwinter.bzm as map-editor-game-reads-it does). The Game then loads them at map start.
- To prove the Game read the mod's file, rather than the shipped one, add a narrow engine trace, for example BK_MOD_TRACE in the engine's file-system/stream layer. It logs each stream opened from the mod folder with the path. Follow the existing BK_*_TRACE pattern, and keep it off unless the env is set.
- Launch the real Game with -mod=<folder> and the map (testlaunch). Assert: clean exit, game_log_clean, and for each kind a trace line showing its exported file opened from the mod.
- This task covers the object-side kinds the map loads: wpn, mcp, trc, scp, spt, unt, msh, obt, fnc, bld, bdg, plus pcp and eff if a unit or weapon on the map references them.
- Write a per-kind result log at zig-out/local-test/resource-editor-game-reads-it/result.log.
- Commit as test(resource-editor): with any engine trace change included. git status must be clean.
Done when: the step exits 0 on Linux with those kinds proved by the Game, and a deliberately broken export (for example a missing file) makes it fail (negative check in the task run).

## Inputs

- `build.zig`
- `Sources/editor/resource_app/scenario.zig`
- `Sources/editor/kit/testlaunch.zig`
- `tools/zig/fixtures/resource_editor/EXTENSIONS.md`

## Expected Output

- `build.zig`
- `Sources/editor/resource_app/scenario.zig`
- `tools/zig/fixtures/resource_editor/game-reads-it.auto`

## Verification

zig build install-game && zig build install-resource-editor && zig build resource-editor-game-reads-it

## Observability Impact

BK_MOD_TRACE (or an equivalent name) logs each stream opened from the mod. result.log has one line per kind: 'KIND=<ext> PROOF=game FILE=<path> RESULT=PASS|FAIL'.
