---
id: T07
parent: S16
milestone: M001
blocker_discovered: true
---

# T07: MFC editor deletion (blocked at the human gate)

blocker_discovered: true

## What happened

The gate check ran first. Nothing was deleted, no file was modified, and no git commit was made.

No explicit approval by Johannes is on record in .gsd/OVERRIDES.md, .gsd/DECISIONS.md or .planning/STATE.md. The only text on the subject is D035, which says T07 deletes nothing and reports a blocker if no approval is on record. The "hand try approved" lines in STATE.md refer to the Phase 03 and earlier milestones, not to the Phase 06 resource editor or the MFC deletion.

Open gates:
1. Johannes's hand try of the macOS and Windows release builds: not approved.
2. Approval of the MFC deletion (06-CONTEXT D-26, D035): not on record.
3. win-home MFC/GOG goldens: not recorded. D015 and D016 still list them as pending.
4. PARITY rows A-13, A-16 and A-17 are open (T02 not done). resource-editor-game-reads-it does not exist yet (T03/T04).
5. The full resource sweep is left to the maintainer.

## Next step

A maintainer steer in .gsd/OVERRIDES.md or .gsd/DECISIONS.md must record the approval and the win-home goldens. After that, rerun T07 to perform the deletion.

## Verification

Gate check only: grep of OVERRIDES.md, DECISIONS.md and STATE.md for an approval found none. `git status` is clean.
