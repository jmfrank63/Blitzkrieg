---
estimated_steps: 10
estimated_files: 9
skills_used: []
---

# T02: A-13 View toggles, A-16 Set Background Colour, A-17 Expand/Collapse all

Why: 06-PARITY.md rows A-13, A-16 and A-17 are still todo. D-26 requires every row to be done before deletion. MFC has these commands (MainFrm.cpp, ParentFrame.cpp, ETreeCtrl), so 'no behaviour in MFC' is not an option.
Do:
- A-13: add View menu toggles for Toolbar, Status Bar, Project Tree and Object Inspector, as pure state in app logic (panels_logic.zig or a new view_logic.zig). Persist them in resourceeditor.cfg through Sources/editor/resource_app/settings.zig, keeping the existing key order and adding new keys at the tail.
- A-16: add View, Set Background Colour, a colour picker that sets the preview background colour (docks_logic.zig preview background, D-16). Persist it in resourceeditor.cfg.
- A-17: add View, Expand/Collapse all with Ctrl+C as in MFC (check the MFC accelerator in Sources/src/editor). It walks the project tree and calls edit_logic.setExpand / BkResSetNodeExpand for every node. Match whatever MFC does for undo; tree expansion is not undone in MFC unless the source says otherwise.
- Tests: app-logic tests for toggle state, settings round trip with a redirected BK_*_SETTINGS / XDG_DATA_HOME, and expand/collapse over a fixture tree with the fake bridge.
- Add BK_EDITOR_AUTO actions (for example do=view:<name>:<on|off>, do=background:<rrggbb>, do=expand_all / collapse_all) with expect predicates. Add a step block in resource-editor-auto-core that measures a captured frame: the background colour pixel count changes, and the tree node count read back changes.
- Update the scenario.zig header doc, PARITY rows A-13/A-16/A-17 with evidence, and the Help shortcuts list.
- Commit as feat(resource-editor):. git status must be clean.
Done when: the rows are done with test and auto evidence and all listed tiers are green. Run GUI tiers with the session display env (XDG_RUNTIME_DIR=/run/user/$UID and WAYLAND_DISPLAY) or SDL_VIDEODRIVER=offscreen, one at a time, never in parallel.

## Inputs

- `Sources/editor/resource_app/panels.zig`
- `Sources/editor/resource_app/panels_logic.zig`
- `Sources/editor/resource_app/settings.zig`
- `Sources/editor/resource_app/docks_logic.zig`
- `Sources/editor/resource_app/edit_logic.zig`
- `Sources/editor/resource_app/scenario.zig`
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`

## Expected Output

- `Sources/editor/resource_app/panels.zig`
- `Sources/editor/resource_app/panels_logic.zig`
- `Sources/editor/resource_app/settings.zig`
- `Sources/editor/resource_app/docks_logic.zig`
- `Sources/editor/resource_app/scenario.zig`
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`

## Verification

zig build test-resource-app-logic -Dtest-mode=run && zig build install-resource-editor && zig build resource-editor-auto-core && zig build resource-editor-smoke && zig build resource-editor-host-check

## Observability Impact

The auto log prints the view toggle state, the background colour and the expanded node count read back.
