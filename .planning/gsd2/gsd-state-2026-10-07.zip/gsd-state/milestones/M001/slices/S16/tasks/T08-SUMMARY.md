---
id: T08
parent: S16
milestone: M001
key_files:
  - tools/zig/resource_model_comparator_test.cpp
  - Sources/src/ResourceModel/comparator.cpp
  - Sources/src/ResourceModel/comparator.h
  - Sources/src/ResourceModel/image_export.cpp
  - Sources/src/ResourceModel/image_export.h
  - Sources/src/ResourceModel/items/mesh/mesh_export.cpp
  - docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md
  - .planning/phases/06-resource-editor-portable-port/06-PARITY.md
key_decisions: []
duration: 
verification_result: passed
completed_at: 2026-10-06T06:22:24.836Z
blocker_discovered: false
---

# T08: Aligned the MFC golden layout in the comparator, wired all 14 exporters, fixed the mesh DDS format choice, and classified every remaining difference as pass, accepted with a source-verified reason, or pending with a reason (3 pass, 8 accepted, 9 pending, 0 FAIL).

**Aligned the MFC golden layout in the comparator, wired all 14 exporters, fixed the mesh DDS format choice, and classified every remaining difference as pass, accepted with a source-verified reason, or pending with a reason (3 pass, 8 accepted, 9 pending, 0 FAIL).**

## What Happened

CompareGoldenFolder now takes the folder holding the port's main stats file as the port root, compares files by path below it, and maps the main stats file (wpn.xml for weapons) to the golden's 1.xml. The scratch copy of each fixture gets <own_data><export_file_name>1.xml like export-goldens.ps1 does, which fixed mdc's medals\name path. Exporters are wired for msh, bld, pcp, eff, til and mdc (all were registered; the comparator flag was false). One real port bug found and fixed: MFC's mesh frame picks DDS formats via ChooseBestFormat (SpriteCompose.cpp:522); the port always wrote DXT5/ARGB1555. Added SaveCompressedTextureBestFormat/ConvertAndSaveImageBestFormat used by the mesh exporter and icon; all msh DDS now match. Remaining differences were each traced to MFC source or the golden's bytes: (1) CParentFrame::ExportSingleFile -> LoadRPGStats reads the project's own <RPG>/<desc> into a default struct, which fixtures lack, so wpn/trc/msh/obt/bld goldens hold struct constructor defaults (weapon golden has RangeMax 30, AimingTime 1); (2) MFC's XML writer uses %lg (DataTreeXML.cpp:326), 6 significant digits - accepted only when the golden equals the port float printed that way; (3) scene-camera dependent values (fnc origins, bld explosion noise, obt grids/packs) - recorded as partial, the engine camera is not available in this tier and this is not proven numerically; (4) trc DXT5 solid-colour blocks encoded differently by the shipped editor (NLegacyDxt also differs), gate 6 for that kind only. New CompareGolden in comparator.cpp with a kGoldenDifferences table (kind, path, reason) plus per-kind file rules in the test; every explained difference is written with its reason to golden/<ext>/accepted.txt. Pending with reason (checked against the golden, so regeneration re-enables the comparison): bdg 3rd 3rv mip chc cgc (MFC crash 0xC0000005), scp and til (golden holds only History), eff (golden made without the particle source). Negative tests extended: layout mapping wpn.xml->1.xml, six-digit rule both sides (100.123 accepted, 100.124 FAIL), stand-ins now in MFC flat layout. Spec amendment and 06-PARITY.md updated with the per-kind table and open items.

## Verification

zig build test-resource-model-comparator -Dtest-mode=run exit 0, VERDICT=PASS, GOLDEN_SUMMARY extensions=20 pass=3 accepted=8 fail=0 pending=9; zig build test-resource-model exit 0; zig build test-resources-all exit 0 VERDICT=PASS; zig build test-resource-bridge -Dtest-mode=run exit 0 (mesh export touched). Editor tiers not run (no shared editor code changed); full sweep left to the maintainer.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-model-comparator -Dtest-mode=run` | 0 | pass | 25000ms |
| 2 | `zig build test-resource-model` | 0 | pass | 23000ms |
| 3 | `zig build test-resources-all` | 0 | pass | 25000ms |
| 4 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 79000ms |

## Deviations

None.

## Known Issues

Open: (a) the port keeps a project's <RPG> unchanged on save, so MFC's LoadRPGStats would read stale stats from a port-edited project (by source reading, not tested against MFC); (b) fnc/bld/obt camera-dependent values need the engine's scene camera in the export (SExportContext::groundCamera never set); (c) goldens for scp, til, eff and the 6 crashing kinds need regenerating on win-home. Fixtures need an <RPG>/<desc> element to compare wpn/trc/msh/obt/bld tree values.

## Files Created/Modified

- `tools/zig/resource_model_comparator_test.cpp`
- `Sources/src/ResourceModel/comparator.cpp`
- `Sources/src/ResourceModel/comparator.h`
- `Sources/src/ResourceModel/image_export.cpp`
- `Sources/src/ResourceModel/image_export.h`
- `Sources/src/ResourceModel/items/mesh/mesh_export.cpp`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`
