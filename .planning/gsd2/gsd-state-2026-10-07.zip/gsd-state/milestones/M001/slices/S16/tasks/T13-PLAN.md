---
estimated_steps: 8
estimated_files: 6
skills_used: []
---

# T13: Golden round 5: MFC value flags (bool flag 9), scp and til compare, win-home re-export list

Order: runs now, after T12 and BEFORE T07. T07 stays on hold (D043); never complete T07 without performing it. Hard steer 2026-10-06T13:29 (D047).
Why: proven on win-home, MFC writes a bool tree value as <value type="8" flag="9" ...> and the port wrote flag="8" (compare mfc-new/roadtest.3rd with 3rd/project.3rd). MFC reads the port's bool as false: Road editor shows Has dust effect off although int_value=1 and the export gives SoilParams 0; MFC's own roadtest.3rd (flag 9) exports 16 (check-roadtest.xml, 20:28). So the 3rd golden's SoilParams 0 is caused by the port's file, not an MFC defect, and T12's "pending, unproven" for 3rd is wrong.
Do:
1. Find in MFC's CVariant and tree serialisation (Sources/src/editor/COI/Variant.cpp, tree item operator&) what flag means for each value type. Compare every <value type= flag=> pair across all mfc-new projects against the port's output for the same kinds. Make the port write exactly MFC's flag for every type, re-save all fixtures through the port, and update byte-identity expectations and fixture hashes (EXTENSIONS.md).
2. Add a test that every bool the port writes carries MFC's flag (and one for the other types' type/flag pairs).
3. Compare the new scp and til goldens (commit 4221882f8) for real; fix the port or explain each difference with proof from MFC source and golden bytes (D041 rule).
4. List exactly which kinds need a new win-home export after the re-save: batch via export-goldens.ps1, and 3rd/3rv by hand in MFC's GUI. Record the list in the task summary, 06-PARITY.md and the spec (append-only dated S16 amendment). Correct T12's 3rd note.
5. Do not regenerate goldens. Keep CRLF. Commit with fixtures, headers and docs; git status clean. Verify with plain zig build commands only. Report per kind (pass, accepted, pending, fail and why). Full sweep left to the maintainer.

## Inputs

- `Sources/src/editor/COI/Variant.cpp`
- `tools/zig/fixtures/resource_editor/mfc-new`
- `tools/zig/fixtures/resource_editor/3rd/project.3rd`
- `Sources/src/ResourceModel/mfc_value.cpp`
- `.gsd/OVERRIDES.md`

## Expected Output

- `tools/zig/fixtures/resource_editor`
- `tools/zig/resource_model_test.cpp`
- `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`

## Verification

zig build test-resource-model -Dtest-mode=run && zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model-comparator -Dtest-mode=run && zig build test-resources-all

## Observability Impact

The comparator prints one line per kind (pass, accepted, pending, fail with reason) and the GOLDEN_SUMMARY counts.
