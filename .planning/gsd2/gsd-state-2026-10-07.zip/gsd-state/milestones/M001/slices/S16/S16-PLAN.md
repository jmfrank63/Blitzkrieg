# S16: Full sweep, delete MFC, spec amendment, STATE.md update

**Goal:** Close M001 on Linux. First fix the S15 paste ElementID review finding. Implement the three open parity rows: A-13 View toggles, A-16 Set Background Colour and A-17 Expand/Collapse all. Add resource-editor-game-reads-it, which proves through the real Game or the engine's own readers that the game reads one exported resource per sub-editor kind. Run every Linux tier in the foreground. Append the closing spec amendment and update .planning/STATE.md. Delete the MFC editor (Sources/src/editor including bin/editor2.exe, Sources/src/bin/editor.exe, the A7.sln entry and the stage.zig copyEditors row) only once Johannes's hand-try approval is on record (D-26, D035). Otherwise stop at that human gate with a blocker. Status 2026-10-06: D050 released T07 (lifting D043); the deletion is done in c6b4329c6 with PRE_DELETE = b8aa895bb00efb2fdac28096656dcf26984e3f87 recorded in the spec and 06-PARITY.md. The maintainer runs the full sweep on c6b4329c6.
**Demo:** `test-resources-all` green locally with 0 FAIL. `resource-editor-game-reads-it` green with one resource per sub-editor kind. Johannes's approval on macOS release and Windows release. Deletion commits for `Sources/src/editor/`, `Sources/src/bin/editor.exe`, `Sources/src/editor/bin/editor2.exe`, `A7.sln` entry, `tools/zig/stage.zig` `copyEditors` entry. `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md` updated with Linux-first-class + user-data-root. `.planning/STATE.md` updated at milestone end.

## Must-Haves

- Pasting into a screen whose ElementIDs collide assigns the next free ElementID, also inside pasted subtrees, and reports each reassignment. A paste with no collision keeps the ids. Undo restores. All of this is checked through the engine's UI reader.
- PARITY rows A-13, A-16 and A-17 are done with evidence: app-logic tests plus steps in resource-editor-auto-core.
- `zig build resource-editor-game-reads-it` exits 0 on Linux. It covers each of the 21 kinds, either by the real Game (log clean, the mod file read) or by the engine's own reader with a reason recorded in PARITY. It is wired into CI (GPU runners), run-resource-sweep.sh and AGENTS.md.
- `zig build test-resources-all` exits 0. Every resource tier and the Map Editor smoke tier are run one at a time in the foreground and exit 0. The full sweep is recorded as "left to the maintainer".
- The spec has a dated S16 amendment. .planning/STATE.md describes M001's end state, including the open items: hand try, win-home goldens, GOG goldens, CI after push.
- MFC deletion: done in one commit, with installs and tiers green afterwards, if approval is on record. Otherwise T07 reports a blocker and nothing is deleted.
- git status is clean after every task.

## Proof Level

- This slice proves: Linux x64 runtime proof: zig build tiers, captured frames and game logs measured by code, and the engine's readers. macOS and Windows are proved only by CI after the maintainer pushes and by Johannes's hand try, and neither is claimed here. Win-home MFC goldens and GOG goldens stay pending.

## Integration Closure

resource-editor-game-reads-it closes the editor-to-Game loop for every kind. Deleting the MFC editor removes the last legacy authoring path. After deletion, mfc-item-inventory.json becomes the frozen source of truth for test-resource-model-fidelity.

## Verification

- Game-reads-it writes a per-kind log under zig-out/local-test/resource-editor-game-reads-it/: one line per kind with a verdict of game or reader, the file read, and a pass or fail. Paste reports reassigned ElementIDs in the status line and the log.

## Tasks

- [x] **T01: Paste assigns unique ElementIDs (S15 review fix, override 2026-10-06T04:54)** `est:2h`
  Why: this is the active override of 2026-10-06T04:54. CUiScreen::Paste (Sources/src/ResourceModel/ui_screen.cpp around line 910) copies each window's ElementID unchanged. A paste into a screen that already uses that id produces two controls that send the same id in UI_NOTIFY_WINDOW_CLICKED. MFC has no GUI copy/paste, so this task defines the port behaviour. Planners have dropped this item before, so it must stay T01 and run before the other S16 tasks.
  Do:
  - In Paste, collect the ElementIDs already used in the target screen, recursively.
  - For each pasted window, including those in nested subtrees: keep its ElementID when it is unused. When it collides with the target screen or with an id already assigned in this paste, assign the next free ElementID. Ids must stay unique among the pasted windows too.
  - Return the reassignments (old id to new id, per window) through a new out-parameter or struct. Surface them through the BkResGui* paste entry point in Sources/src/EditorBridge/resource_bridge.cpp, its Zig mirror in Sources/editor/resource_core (bridge.zig, fake_bridge.zig, gui_tools.zig) and the app's c_bridge.zig. gui_logic.zig reports each reassignment in the status line and the log.
  - Undo of the paste command restores the screen byte for byte, as the existing gui_tools undo does.
  - Tests in Sources/src/ResourceModel/ui_screen_test.cpp (run by test-resource-model):
    (a) Paste the same subtree into the same shipped screen twice. Re-read the saved screen with the engine's UI reader (IDataTree path used by the existing ui_screen checks) and check that all ElementIDs of interactive controls are unique and the originals are unchanged.
    (b) Paste into a screen with no collision and check that the ids are kept.
    (c) Paste a subtree with an internal duplicate and check that the ids become unique.
  - Add a resource_core undo/redo test with the fake bridge.
  - Add a line to 06-PARITY.md B-21 and a dated line to the spec's Amendments (D031 follow-up).
  - Commit as fix(resource-editor): with headers and tests included. git status must be clean.
  Done when: the tests above pass, test-resource-core and resource-editor-auto-gui stay green, and the override is answered by evidence.
  - Files: `Sources/src/ResourceModel/ui_screen.cpp`, `Sources/src/ResourceModel/ui_screen.h`, `Sources/src/ResourceModel/ui_screen_test.cpp`, `Sources/src/EditorBridge/resource_bridge.cpp`, `Sources/src/EditorBridge/resource_bridge.h`, `Sources/editor/resource_core/bridge.zig`, `Sources/editor/resource_core/fake_bridge.zig`, `Sources/editor/resource_core/gui_tools.zig`, `Sources/editor/resource_app/c_bridge.zig`, `Sources/editor/resource_app/gui_logic.zig`, `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`, `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`
  - Verify: zig build test-resource-model -Dtest-mode=run && zig build test-resource-core -Dtest-mode=run && zig build test-resource-app-logic -Dtest-mode=run && zig build test-resource-bridge -Dtest-mode=run && zig build install-resource-editor && zig build resource-editor-auto-gui

- [x] **T02: A-13 View toggles, A-16 Set Background Colour, A-17 Expand/Collapse all** `est:3h`
  Why: 06-PARITY.md rows A-13, A-16 and A-17 are still todo. D-26 requires every row to be done before deletion. MFC has these commands (MainFrm.cpp, ParentFrame.cpp, ETreeCtrl), so 'no behaviour in MFC' is not an option.
  Do:
  - A-13: add View menu toggles for Toolbar, Status Bar, Project Tree and Object Inspector, as pure state in app logic (panels_logic.zig or a new view_logic.zig). Persist them in resourceeditor.cfg through Sources/editor/resource_app/settings.zig, keeping the existing key order and adding new keys at the tail.
  - A-16: add View, Set Background Colour, a colour picker that sets the preview background colour (docks_logic.zig preview background, D-16). Persist it in resourceeditor.cfg.
  - A-17: add View, Expand/Collapse all with Ctrl+C as in MFC (check the MFC accelerator in Sources/src/editor). It walks the project tree and calls edit_logic.setExpand / BkResSetNodeExpand for every node. Match whatever MFC does for undo; tree expansion is not undone in MFC unless the source says otherwise.
  - Tests: app-logic tests for toggle state, settings round trip with a redirected BK_*_SETTINGS / XDG_DATA_HOME, and expand/collapse over a fixture tree with the fake bridge.
  - Add BK_EDITOR_AUTO actions (for example do=view:<name>:<on|off>, do=background:<rrggbb>, do=expand_all / collapse_all) with expect predicates. Add a step block in resource-editor-auto-core that measures a captured frame: the background colour pixel count changes, and the tree node count read back changes.
  - Update the scenario.zig header doc, PARITY rows A-13/A-16/A-17 with evidence, and the Help shortcuts list.
  - Commit as feat(resource-editor):. git status must be clean.
  Done when: the rows are done with test and auto evidence and all listed tiers are green. Run GUI tiers with the session display env (XDG_RUNTIME_DIR=/run/user/$UID and WAYLAND_DISPLAY) or SDL_VIDEODRIVER=offscreen, one at a time, never in parallel.
  - Files: `Sources/editor/resource_app/panels.zig`, `Sources/editor/resource_app/panels_logic.zig`, `Sources/editor/resource_app/settings.zig`, `Sources/editor/resource_app/docks.zig`, `Sources/editor/resource_app/docks_logic.zig`, `Sources/editor/resource_app/edit_logic.zig`, `Sources/editor/resource_app/scenario.zig`, `Sources/editor/resource_app/main.zig`, `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`
  - Verify: zig build test-resource-app-logic -Dtest-mode=run && zig build install-resource-editor && zig build resource-editor-auto-core && zig build resource-editor-smoke && zig build resource-editor-host-check

- [x] **T03: resource-editor-game-reads-it: step, engine mod-read trace, object-side kinds** `est:4h`
  Why: the roadmap's S16 demo requires resource-editor-game-reads-it with one resource per sub-editor kind. It does not exist yet; only map-editor-game-reads-it(-m2/-m3) does, in build.zig around lines 7987-8040. AGENTS.md: 'the game reads it unchanged' is proved by the engine's readers or the real Game, never by eyeballing.
  Do:
  - Add a build step resource-editor-game-reads-it, modelled on map-editor-game-reads-it-m3 and on the run_game / game_log_clean path of resource-editor-auto-gui in Sources/editor/resource_app/scenario.zig. It uses BK_EDITOR_AUTO with a new --game-reads-it scenario, or a dedicated scenario file under tools/zig/fixtures/resource_editor/.
  - Redirect XDG_DATA_HOME / BK_USER_ROOT into zig-out/local-test/resource-editor-game-reads-it/ and set BK_DEBUG_LOG=1. Copy only tracked fixtures and Data there; never write to shipped Data.
  - Export one resource per kind into one mod folder, under names that replace shipped resources a shipped multiplayer map uses (for example Data/Maps/Multiplayer/coldwinter.bzm as map-editor-game-reads-it does). The Game then loads them at map start.
  - To prove the Game read the mod's file, rather than the shipped one, add a narrow engine trace, for example BK_MOD_TRACE in the engine's file-system/stream layer. It logs each stream opened from the mod folder with the path. Follow the existing BK_*_TRACE pattern, and keep it off unless the env is set.
  - Launch the real Game with -mod=<folder> and the map (testlaunch). Assert: clean exit, game_log_clean, and for each kind a trace line showing its exported file opened from the mod.
  - This task covers the object-side kinds the map loads: wpn, mcp, trc, scp, spt, unt, msh, obt, fnc, bld, bdg, plus pcp and eff if a unit or weapon on the map references them.
  - Write a per-kind result log at zig-out/local-test/resource-editor-game-reads-it/result.log.
  - Commit as test(resource-editor): with any engine trace change included. git status must be clean.
  Done when: the step exits 0 on Linux with those kinds proved by the Game, and a deliberately broken export (for example a missing file) makes it fail (negative check in the task run).
  - Files: `build.zig`, `Sources/editor/resource_app/scenario.zig`, `tools/zig/fixtures/resource_editor/game-reads-it.auto`
  - Verify: zig build install-game && zig build install-resource-editor && zig build resource-editor-game-reads-it

- [x] **T04: resource-editor-game-reads-it: remaining kinds, CI, sweep, PARITY** `est:3h`
  Why: T03 covers the kinds a map loads at start. The remaining kinds are til, 3rd, 3rv, mip, chc, cgc, mdc and gui, plus pcp and eff if T03 did not cover them. Each of the 21 kinds must be proved, or recorded with a reason.
  Do:
  - Extend the step. For each kind, prefer the real Game. Examples:
    - gui: the exported Data/UI screen, as resource-editor-auto-gui proves.
    - mip: launch the exported mission (check how the Game starts a mission from the command line or through BK_AUTO_UI).
    - til/3rd/3rv: the season tileset, road and river descriptors a map loads.
    - chc/cgc/mdc: the campaign and chapter screens through BK_AUTO_UI.
  - When the Game cannot be driven headless to load a kind, prove it with the engine's own reader, the same one the Game uses (comparator/IDataTree reader on the exported file), and record PROOF=reader and the reason. Never prove by eyeballing.
  - Add the step to .github/workflows/cross-platform.yml on the GPU runners only, the same way map-editor-game-reads-it is. Add it to tools/zig/run-resource-sweep.sh and to AGENTS.md's Resource Editor tier list.
  - Add a PARITY entry for game-reads-it per kind with its proof and reason.
  - Commit as test(resource-editor):. git status must be clean.
  Done when: result.log has 21 KIND lines, all PASS, and the step exits 0 on Linux.
  - Files: `build.zig`, `Sources/editor/resource_app/scenario.zig`, `tools/zig/fixtures/resource_editor/game-reads-it.auto`, `.github/workflows/cross-platform.yml`, `tools/zig/run-resource-sweep.sh`, `AGENTS.md`, `.planning/phases/06-resource-editor-portable-port/06-PARITY.md`
  - Verify: zig build install-resource-editor && zig build resource-editor-game-reads-it && zig build resource-editor-auto-gui

- [x] **T05: Linux foreground tier run and test-resources-all** `est:2h`
  Why: the roadmap demo requires test-resources-all green with 0 FAIL and a full resource sweep. Per AGENTS.md and D010, the agent cannot run tools/zig/run-resource-sweep.sh (about 27 minutes), so it runs every tier separately in the foreground.
  Do:
  - Run each of the following one at a time, in the foreground with a timeout of at most 10 minutes, never in parallel, and never left in the background:
    - install-game, install-map-editor, install-resource-editor
    - test-resources-all
    - test-resource-model, test-resource-model-comparator, test-resource-core, test-resource-bridge, test-resource-app-logic, test-editor-core, test-editor-kit, test-editor-bridge (use -Dtest-mode=run where the step needs it)
    - resource-editor-host-check, resource-editor-smoke
    - each resource-editor-auto-<ext> (core wpn unt spt msh obt fnc bld bdg pcp eff til 3rd 3rv mip chc cgc mdc gui)
    - resource-editor-game-reads-it
    - map-editor-smoke, map-editor-auto, map-editor-game-reads-it-m3
  - GUI tiers need XDG_RUNTIME_DIR=/run/user/$UID plus the session WAYLAND_DISPLAY, or SDL_VIDEODRIVER=offscreen. If the env is missing, the failure is SdlInitFailed; that is an environment problem, so fix the env and rerun.
  - A Map Editor tier failure is a real regression (AGENTS.md, 3e8afc8a7): fix it, do not classify it.
  - Record every command and exit code in the task summary. State: 'full sweep left to the maintainer'. List the unproved items: macOS, Windows, MFC goldens, GOG goldens, hand try.
  - Commit only if a fix was needed. git status must be clean.
  Done when: every listed tier exits 0 here, or a regression was fixed and re-run.
  - Verify: zig build test-resources-all && zig build test-resource-core -Dtest-mode=run && zig build test-resource-bridge -Dtest-mode=run && zig build resource-editor-smoke && zig build map-editor-smoke

- [x] **T06: Spec amendment and .planning/STATE.md at milestone end** `est:1h`
  Why: the roadmap requires a spec amendment and a STATE.md update. The Linux-first-class and user-data-root entries were done in S01, so S16 adds only its closing entry.
  Do:
  - In docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md, append a dated entry under the existing '## Amendments' sections. Keep the style append-only and CRLF. Record:
    - the resource-editor-game-reads-it design and its per-kind proof table
    - the paste ElementID rule (T01) and A-13/A-16/A-17
    - mfc-item-inventory.json as the frozen source of truth once Sources/src/editor is deleted (tools/zig/mfc_item_inventory.py can then only run from git history; test-resource-model-fidelity reads the JSON, tools/zig/resource_model_test.cpp line 69)
    - the deletion scope (D-26) and whether it is done or still waiting on approval
    - the open win-home items: MFC goldens per kind, B-09.14, B-14.5
  - Rewrite .planning/STATE.md's current-position block for M001 end:
    - S01-S16 status
    - what is verified on Linux (cite the T05 runs)
    - what is open: Johannes's hand try on macOS and Windows release, the win-home goldens and GOG goldens, CI results after the maintainer pushes, the full sweep
  - Update .planning/ROADMAP.md's phase 6 status line if it tracks progress.
  - Do not claim macOS or Windows results.
  - Commit as docs(resource-editor):. git status must be clean.
  Done when: both documents are committed with CRLF and git status is clean.
  - Files: `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`, `.planning/STATE.md`, `.planning/ROADMAP.md`
  - Verify: git diff --check HEAD~1

- [x] **T07: Delete the MFC editor (gated on Johannes's approval, D-26/D035)** `est:1h`
  Why: the MFC editor goes only after every parity row is done, the goldens and test-resources-all pass, and Johannes approves a hand try of the macOS and Windows release builds (06-CONTEXT D-26).
  Gate (do this first):
  - Search .gsd/OVERRIDES.md and .gsd/DECISIONS.md for an explicit approval by Johannes of the hand try and of the MFC deletion.
  - If none is on record, delete nothing. Complete the task with blocker_discovered=true, stating which gates are open (hand try, win-home goldens, pending PARITY rows), so auto mode pauses at the human gate.
  If approved:
  - Run `rg -n 'src/editor|editor\.exe|editor2'` outside .gsd, .planning, zig-out and Sources/src/editor. Fix any build or CI reference. Comment and spec mentions may stay as history. build.zig lines about 1853 and 9955 are comments only.
  - git rm -r Sources/src/editor (this includes Sources/src/editor/bin/editor2.exe) and git rm Sources/src/bin/editor.exe.
  - In Sources/src/A7.sln, remove the 'editor' project at line 195 (GUID {425EDE25-204A-B5C4-9C5F-C77FD3F123E1}), its configuration, nested-project and ProjectDependencies lines. Keep the file's CRLF.
  - In tools/zig/stage.zig, remove only the editor.exe row of copyEditors (line 597). ExcelExporter and ELK stay.
  - Note in tools/zig/mfc_item_inventory.py's header that its inputs are deleted and the committed JSON is now the source of truth.
  - Use the Phase 5 MFC map-editor deletion commit as precedent (git log on .planning/STATE.md mentions it).
  - Commit as chore(resource-editor): remove the MFC editor. git status must be clean.
  Done when, if approved: the commit exists, the three installs, test-resource-model and test-resources-all are green, and stage.zig packaging still runs.
  - Files: `Sources/src/A7.sln`, `tools/zig/stage.zig`, `tools/zig/mfc_item_inventory.py`
  - Verify: zig build install-game && zig build install-map-editor && zig build install-resource-editor && zig build test-resources-all

## Files Likely Touched

- Sources/src/ResourceModel/ui_screen.cpp
- Sources/src/ResourceModel/ui_screen.h
- Sources/src/ResourceModel/ui_screen_test.cpp
- Sources/src/EditorBridge/resource_bridge.cpp
- Sources/src/EditorBridge/resource_bridge.h
- Sources/editor/resource_core/bridge.zig
- Sources/editor/resource_core/fake_bridge.zig
- Sources/editor/resource_core/gui_tools.zig
- Sources/editor/resource_app/c_bridge.zig
- Sources/editor/resource_app/gui_logic.zig
- .planning/phases/06-resource-editor-portable-port/06-PARITY.md
- docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md
- Sources/editor/resource_app/panels.zig
- Sources/editor/resource_app/panels_logic.zig
- Sources/editor/resource_app/settings.zig
- Sources/editor/resource_app/docks.zig
- Sources/editor/resource_app/docks_logic.zig
- Sources/editor/resource_app/edit_logic.zig
- Sources/editor/resource_app/scenario.zig
- Sources/editor/resource_app/main.zig
- build.zig
- tools/zig/fixtures/resource_editor/game-reads-it.auto
- .github/workflows/cross-platform.yml
- tools/zig/run-resource-sweep.sh
- AGENTS.md
- .planning/STATE.md
- .planning/ROADMAP.md
- Sources/src/A7.sln
- tools/zig/stage.zig
- tools/zig/mfc_item_inventory.py
