---
id: T06
parent: S04
milestone: M001
key_files: []
key_decisions:
  - BkResAimedPoint carries degrees at the ABI boundary; Zig side is degree-only.
  - Unified Zig geometry (one ResourceCommand.geometry variant parameterised by channel) stays despite per-channel C ABI.
  - Variable-length aimed-point lists use the T05 two-pass convention: NULL buffer returns size, sized buffer fills.
duration: 
verification_result: mixed
completed_at: 2026-10-05T02:55:29.928Z
blocker_discovered: false
---

# T06: Wired six geometry point and aimed-point channels through the resource bridge ABI, Zig core and fake with undo/redo and save-reopen parity on bld and scp.

**Wired six geometry point and aimed-point channels through the resource bridge ABI, Zig core and fake with undo/redo and save-reopen parity on bld and scp.**

## What Happened

T06 extends T05 unified-geometry with single-point channels (zero_point, entrance) and aimed-point lists (shoot/fire/smoke/directed_explosion_points). resource_bridge.h gained six Get/Set pairs at lines 202-219 with fixed-size payloads for point2 channels and two-pass variable-length output for aimed lists. resource_bridge.cpp at lines 1596-1683 routes each entry through the T05 geometry cache so saved .bld files round-trip _bk_geometry FutureBlob children unchanged. bridge.zig adds .point2 and .aimed GeometryValue variants and the six channel enum tags; fake_bridge.zig returns zero-value defaults and routes writes into the shared (node_id, channel) map. root.zig gained six undo/redo tests at lines 401, 449, 502. resource_bridge_test.cpp got a bld points scenario at lines 469-513 and an scp fire_points parity scenario at 547-560. Degrees-vs-turns conversion stays on the C++ side at the ABI boundary; the Zig AimedPoint struct is degree-only.</narrative>
<parameter name="keyFiles">["Sources/src/EditorBridge/resource_bridge.h", "Sources/src/EditorBridge/resource_bridge.cpp", "Sources/src/EditorBridge/resource_bridge_test.cpp", "Sources/editor/resource_core/root.zig", "Sources/editor/resource_core/bridge.zig", "Sources/editor/resource_core/fake_bridge.zig"]

## Verification

Four tiers green on Linux x64 debug: test-resource-core exit 0, test-resource-bridge exit 0 (21 fixtures plus bld points scenario and scp fire_points parity), test-editor-core exit 0, test-editor-bridge exit 0.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-core -Dtest-mode=run exit 0 pass` | -1 | unknown (coerced from string) | 0ms |
| 2 | `zig build test-resource-bridge -Dtest-mode=run exit 0 pass` | -1 | unknown (coerced from string) | 0ms |
| 3 | `zig build test-editor-core -Dtest-mode=run exit 0 pass` | -1 | unknown (coerced from string) | 0ms |
| 4 | `zig build test-editor-bridge -Dtest-mode=run exit 0 pass` | -1 | unknown (coerced from string) | 0ms |

## Deviations

None.

## Known Issues

None.

## Files Created/Modified

None.
