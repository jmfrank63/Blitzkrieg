---
estimated_steps: 10
estimated_files: 6
skills_used: []
---

# T05: Wired the geometry cells family (passability, locked tiles, transparency lines) through the resource bridge ABI, the Zig resource core, and its fake, with undo/redo and save→reopen round-trips green on bld.

Wire the first geometry family end-to-end against the T03 unified GeometryChannel/GeometryValue shape so the remaining families (T06-T08) have a working template to copy.

Why: cells are the smallest payload family (bytes_grid) and the most common tool shape downstream (every grid-frame sub-editor in S09-S10 edits passability/transparency). Landing cells first establishes the end-to-end pattern — C ABI entry pair, typed item-class read/write, FakeResBridge table, undo/redo variant, save→reopen parity test — that T06-T08 copy once per family. Keep the T03 unified design: do NOT add 13 named ResourceCommand variants; use the single `.geometry` variant parameterised by channel.

Do:
1. Add `BkResGetPassabilityCells` + `BkResSetPassabilityCells`, `BkResGetLockedTiles` + `BkResSetLockedTiles`, `BkResGetTransparencyLines` + `BkResSetTransparencyLines` to `Sources/src/EditorBridge/resource_bridge.h` with fixed-size C structs (no pointers; two-pass variable-length output for the bytes buffer). Match the `BkRes*` entry-point pattern from T02's project+tree group verbatim (`Guarded(...)` wrapper, `BkEditorLastMessage` for status detail, `BkEditorStatus` return).
2. Implement each pair in `resource_bridge.cpp` against `CTreeItem::values` on the typed building item class in `Sources/src/ResourceModel/items/building/`. Preserve MFC-era semantics (grid-of-bytes layout, cell-at-origin convention — derive from the frame sources, not from memory per MEM005). Refusals must change nothing (undo contract).
3. In `Sources/editor/resource_core/bridge.zig`: implement the three new channel cases in `ResBridge.geometryRead` and `.geometryWrite` by calling the matching `BkRes*` entry via the vtable. Keep the single `ResourceCommand.geometry { channel, before, after }` variant from T03; do not fork it.
4. In `Sources/editor/resource_core/fake_bridge.zig`: extend the existing geometry map so the three cells channels round-trip in-memory (same unified map, keyed by `(node_id, channel)` → `GeometryValue`).
5. Extend `Sources/editor/resource_core/history_test.zig` (or the geometry round-trip test in `root.zig`) with: for each of the three channels, a `set → undo → read → assert identity to pre-set` and `set → undo → redo → read → assert identity to post-set`; dirty flag toggles correctly across both.
6. Extend `Sources/src/EditorBridge/resource_bridge_test.cpp` with per-channel bridge tests on `tools/zig/fixtures/resource_editor/bld/project.bld`: open, set a representative grid value, read back → assert identity, save → reopen → read → assert value persists byte-identically through `NResourceModel::Load/Save`.

Done-when: `zig build test-resource-core -Dtest-mode=run` and `zig build test-resource-bridge -Dtest-mode=run` are green with the three cells channels covered; `test-editor-core` and every map-editor tier still green.

## Inputs

- `Sources/src/EditorBridge/resource_bridge.h`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `Sources/editor/resource_core/bridge.zig`
- `Sources/editor/resource_core/fake_bridge.zig`
- `Sources/src/ResourceModel/items/building`
- `tools/zig/fixtures/resource_editor/bld/project.bld`

## Expected Output

- `Sources/src/EditorBridge/resource_bridge.h`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `Sources/editor/resource_core/bridge.zig`
- `Sources/editor/resource_core/fake_bridge.zig`

## Verification

zig build test-resource-core -Dtest-mode=run && zig build test-resource-bridge -Dtest-mode=run && zig build test-editor-core -Dtest-mode=run && zig build test-editor-bridge -Dtest-mode=run
