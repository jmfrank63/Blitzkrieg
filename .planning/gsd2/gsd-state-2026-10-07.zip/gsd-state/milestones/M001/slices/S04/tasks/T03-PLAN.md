---
estimated_steps: 9
estimated_files: 6
skills_used: []
---

# T03: Added Sources/editor/resource_core (bridge.zig + document.zig + ResourceCommand + history alias + fake_bridge.zig) and the test-resource-core tier that round-trips every command variant through undo/redo on the host.

Why: this is the headless core S05 app shell will depend on. It must build on all six targets (incl. `x86_64-windows-gnu`, where the engine C++ does not build) because the Zig app imports it before the C bridge is cImported. Copy the exact `pub const Bridge = struct { ptr, vtable }` shape from `Sources/editor/core/bridge.zig`; alias `History = editor_kit.history.History(ResourceCommand)` (do not rewrite the stack primitive).

Do:
1. Create `Sources/editor/resource_core/` with `root.zig`, `bridge.zig`, `document.zig`, `history.zig`, `fake_bridge.zig`. Register the module in `build.zig` beside `addEditorCore` as `addResourceCore` (consumes `editor_kit`, nothing else).
2. `bridge.zig`: define `Status` enum (reuse `BkEditorStatus` values), `EditError = error{ Refused, Failed, OutOfMemory }`, `pub fn check(Status) EditError!void`, then the `ResBridge` struct with one method per `BkRes*` entry (names mirror the C header; all arguments in Zig native types — fixed-size `[64]u8` for name buffers, slices for variable-length). No `@cImport` here (the map core keeps `bridge.zig` in pure Zig so the module cross-compiles).
3. `document.zig`: per-project mirror held by the core — `path: ?[]u8`, `kind: Kind`, `tree: Tree` (nodes + props by id), `dirty_through_history: bool` (derived from `History.dirty()`), `lock_owner: ?LockOwner`. Expose `apply(Command) !void` which calls the right bridge method and bumps the local mirror.
4. `history.zig`: `ResourceCommand` tagged union covering `.set_prop`, `.insert_node`, `.delete_node` (holds serialised subtree bytes for undo), `.move_node`, `.composite` (gesture of commands), plus one placeholder variant `.geometry` reserved for T04 to extend. `pub fn deinit(self: *ResourceCommand, allocator)` frees owned slices. Alias `Entry = editor_kit.history.Entry(ResourceCommand)` and `History = editor_kit.history.History(ResourceCommand)`.
5. `fake_bridge.zig`: in-memory `FakeResBridge` implementing every `ResBridge` method against a map `{id → Node}` + `{(node_id, prop_id) → Variant}`. Mirror the real refusal rules the core can see: missing-node is `Refused`, out-of-range insert index is `Refused`, duplicate id is `BadArgument`. Include a doc-comment header listing every deliberate simplification (same shape as `Sources/editor/core/fake_bridge.zig`).
6. Wire `test-resource-core` in `build.zig`: a `test_mode==.run` build step over `Sources/editor/resource_core/root.zig` running on all six targets (`x86_64-linux-gnu`, `aarch64-linux-gnu`, `x86_64-windows-msvc`, `x86_64-windows-gnu`, `aarch64-macos`, `x86_64-macos`). Tests must cover: every `ResourceCommand` variant records → undo → redo through `FakeResBridge` + `document` with the mirror restored byte-for-byte; `.composite` collapses as one undo step; the dirty flag follows `History.dirty()`; `markClean` + undo past it clears `clean_depth` as the kit expects.

Done-when: `zig build test-resource-core -Dtest-mode=run` is green on this Linux machine; the step is listed under `zig build --help`; `test-editor-core` (map core) is still green (shared `editor_kit` not regressed).

## Inputs

- `Sources/editor/core/bridge.zig`
- `Sources/editor/core/history.zig`
- `Sources/editor/core/fake_bridge.zig`
- `Sources/editor/core/root.zig`
- `Sources/editor/kit/history.zig`
- `Sources/editor/kit/root.zig`
- `Sources/src/EditorBridge/resource_bridge.h`
- `build.zig`

## Expected Output

- `Sources/editor/resource_core/root.zig`
- `Sources/editor/resource_core/bridge.zig`
- `Sources/editor/resource_core/document.zig`
- `Sources/editor/resource_core/history.zig`
- `Sources/editor/resource_core/fake_bridge.zig`
- `build.zig`

## Verification

zig build test-resource-core -Dtest-mode=run && zig build test-editor-core -Dtest-mode=run
