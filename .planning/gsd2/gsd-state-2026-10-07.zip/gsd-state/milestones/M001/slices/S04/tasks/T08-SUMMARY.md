---
id: T08
parent: S04
milestone: M001
key_files:
  - Sources/src/EditorBridge/resource_bridge.h
  - Sources/src/EditorBridge/resource_bridge.cpp
  - Sources/src/EditorBridge/resource_bridge_test.cpp
  - Sources/editor/resource_core/bridge.zig
  - Sources/editor/resource_core/fake_bridge.zig
  - Sources/editor/resource_core/root.zig
key_decisions:
  - Bridge span marks are a Point2 list, not Vec3: BridgeFrm keeps z at 0, so the ABI signature changed and the Zig channel moved to the points2 family.
  - GeometryChannel.family() is the single source of each channel's payload tag; the fake refuses a mismatched payload as BadArgument.
duration: 
verification_result: passed
completed_at: 2026-10-05T06:34:19.535Z
blocker_discovered: false
---

# T08: Wired formation positions (scp) and bridge span marks (bdg) as flat Point2 lists through the resource bridge ABI, the Zig core and the fake, with undo/redo on a child node and set->save->reopen->read parity on the MFC owner nodes

**Wired formation positions (scp) and bridge span marks (bdg) as flat Point2 lists through the resource bridge ABI, the Zig core and the fake, with undo/redo on a child node and set->save->reopen->read parity on the MFC owner nodes**

## What Happened

An earlier, interrupted session had left the implementation uncommitted in the tree. This session reviewed it and ran the verification tiers. C ABI: BkResGetFormationPositions / BkResSetFormationPositions and BkResGetBridgeSpanMarks / BkResSetBridgeSpanMarks are now real. Bridge span marks changed from BkResVec3 to BkResPoint2 because BridgeFrm keeps z at 0. resource_bridge.h documents MFC's coordinate conventions: absolute AI world units, z dropped, the export subtracts vZeroPos, and which node types normally own each list. In resource_bridge.cpp, the transparency-lines body became the shared GetPoints2/SetPoints2 helpers, parameterised by channel (9 = formation, 10 = span marks). Their old stubs are gone. Persistence reuses the generic points form of the _bk_geometry child element. Zig: GeometryChannel.family() maps each channel to its GeometryValue tag. bridge_span_marks moved to points2. fake_bridge's emptyFor goes through family(), and geometryWrite now refuses a payload of the wrong family with BadArgument. Tests: in root.zig, undo/redo for both channels on an inserted child node with a non-empty before list, plus a wrong-family refusal test. In resource_bridge_test.cpp, PointListsOnOwnerNodes sets distinct lists on the scp formation props node and the bdg begin/center/end spans nodes, none of them the root. It checks the two-pass read rules, bad-argument and unknown-node refusals, save->reopen->read parity, a byte-identical resave, and that a cleared list persists.

## Verification

All four plan tiers exit 0 on Linux x64. test-resource-bridge prints 'Project+Tree OK (21 fixtures)'. Scratch outputs under zig-out/local-test/resource_editor/t02/{scp,bdg}-points2 have timestamps from this run and contain _bk_geometry channel="9" / channel="10" elements with the expected counts, so the new checks ran.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-core -Dtest-mode=run` | 0 | pass | 1000ms |
| 2 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 5000ms |
| 3 | `zig build test-editor-core -Dtest-mode=run` | 0 | pass | 1000ms |
| 4 | `zig build test-editor-bridge -Dtest-mode=run` | 0 | pass | 557000ms |

## Deviations

BkResGet/SetBridgeSpanMarks changed their element type from BkResVec3 to BkResPoint2, as the plan's 'points2 payload' title asks.

## Known Issues

A cleared list persists as an empty _bk_geometry element with count="0" instead of being dropped. It reads back correctly, but it is extra bytes in the saved file. Only Linux was verified; the other targets wait for CI.

## Files Created/Modified

- `Sources/src/EditorBridge/resource_bridge.h`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `Sources/editor/resource_core/bridge.zig`
- `Sources/editor/resource_core/fake_bridge.zig`
- `Sources/editor/resource_core/root.zig`
