---
estimated_steps: 7
estimated_files: 6
skills_used: []
---

# T06: Wired six geometry point and aimed-point channels through the resource bridge ABI, Zig core and fake with undo/redo and save-reopen parity on bld and scp.

Second geometry family. Wire the two payload shapes `point2` (single Point2: zero point, entrance) and `aimed` (list of AimedPoint with angle + cone: shoot/fire/smoke/directed-explosion) through the unified GeometryChannel pattern established by T05.

Why: aimed points carry MFC-era angle semantics (degrees-vs-turns conversion lives on the C++ side; the AimedPoint struct in bridge.zig records degrees). Landing these before formation/bridge-spans isolates the angle-unit question to its own task.

Do:
1. Add six `BkRes[Get|Set]` entry pairs to `resource_bridge.h`+`.cpp` for the two point2 channels (zero_point, entrance) and the four aimed-point channels (shoot_points, fire_points, smoke_points, directed_explosion_points). Fixed-size struct for the single-point channels; two-pass variable-length output for the aimed lists. Preserve MFC degree semantics on the ABI boundary; the typed building/squad item classes may store engine turns internally — convert at the ABI edge, document the conversion in the header comment.
2. Wire the six new channel cases into `ResBridge.geometryRead/Write` in `bridge.zig` and the fake-bridge table in `fake_bridge.zig` (same unified `(node_id, channel) → GeometryValue` map).
3. Extend `test-resource-core` with per-channel undo/redo round-trips. Extend `test-resource-bridge` with set→save→reopen→read parity tests on `bld/project.bld` for zero/entrance and for one of the aimed-point channels; add a parity test on `scp/project.scp` if the squad item class exposes any of these channels (otherwise defer to T07).

Done-when: six new channels covered on both sides; `test-resource-core`, `test-resource-bridge`, `test-editor-core`, `test-editor-bridge` all green.

## Inputs

- `Sources/src/EditorBridge/resource_bridge.h`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `Sources/editor/resource_core/bridge.zig`
- `Sources/editor/resource_core/fake_bridge.zig`
- `Sources/src/ResourceModel/items/building`
- `Sources/src/ResourceModel/items/squad`
- `tools/zig/fixtures/resource_editor/bld/project.bld`
- `tools/zig/fixtures/resource_editor/scp/project.scp`

## Expected Output

- `Sources/src/EditorBridge/resource_bridge.h`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `Sources/editor/resource_core/bridge.zig`
- `Sources/editor/resource_core/fake_bridge.zig`

## Verification

zig build test-resource-core -Dtest-mode=run && zig build test-resource-bridge -Dtest-mode=run && zig build test-editor-core -Dtest-mode=run && zig build test-editor-bridge -Dtest-mode=run
