---
id: T11
parent: S04
milestone: M001
key_files:
  - Sources/src/EditorBridge/resource_bridge.cpp
  - Sources/src/EditorBridge/resource_bridge_test.cpp
  - Sources/src/EditorBridge/session.h
  - Sources/src/EditorBridge/session.cpp
  - tools/zig/fixtures/resource_editor/preview-scene/preview-scene.md
  - tools/zig/fixtures/resource_editor/preview-scene/mesh.tga
  - tools/zig/fixtures/resource_editor/preview-scene/sprite.tga
  - tools/zig/fixtures/resource_editor/preview-scene/particle.tga
  - .github/workflows/cross-platform.yml
  - tools/zig/run-resource-sweep.sh
key_decisions:
  - Full sweep evidence is the maintainer's run after the T11 changes (D010); the agent did not rerun it.
duration: 
verification_result: passed
completed_at: 2026-10-05T08:35:00.718Z
blocker_discovered: false
---

# T11: Preview group (BkResPreview*), captured-frame assertions, resource tiers in CI and the single run-resource-sweep.sh, committed in b8d55b423; the maintainer's full sweep after these changes passed all 18 tiers (VERDICT=PASS).

**Preview group (BkResPreview*), captured-frame assertions, resource tiers in CI and the single run-resource-sweep.sh, committed in b8d55b423; the maintainer's full sweep after these changes passed all 18 tiers (VERDICT=PASS).**

## What Happened

The implementation is committed in b8d55b423. It wires the preview group through resource_bridge.cpp and session.{h,cpp}. resource_bridge_test.cpp captures mesh, sprite and particle frames and requires a non-black-non-magenta share of at least 0.01, skipping when there is no GPU. The three TGAs (640x480, 32 bpp) are committed with preview-scene.md updated. cross-platform.yml gains test-resource-core/-model/-bridge entries. run-resource-sweep.sh is extended and stays the only sweep script; no run-s0*-sweep.sh exists.

Per the 2026-10-05T08:34 override and D010, the agent did not run the sweep (about 27 minutes, above the 10-minute foreground cap). The maintainer ran tools/zig/run-resource-sweep.sh on this Linux x64 machine after the T11 changes. The log (~/gsd-logs/sweep-S04-T11.log, byte-identical to zig-out/local-test/resource_editor/resource-sweep.log, written 15:33, commit at 15:34 the same day) shows 18 tiers, each EXIT=0 RESULT=PASS. They are install-game+install-map-editor, test-resource-model, test-resource-core, test-resource-bridge, test-editor-kit, test-editor-core, all four test-map-editor-* tiers, test-map-editor-engine, test-editor-bridge (541 s), map-editor-host-check, map-editor-smoke, map-editor-auto, -auto-m2, -m3-auto and map-editor-game-reads-it-m3. The log ends with VERDICT=PASS. Preview lines give non-black-non-magenta mesh 0.264867, sprite 0.307223 and particle 0.286986, each with show_status=0 and capture_status=0.

## Verification

Commands run in this task: (1) `cat ~/gsd-logs/sweep-S04-T11.log`: 18 TIER lines, all RESULT=PASS, VERDICT=PASS. (2) `cmp zig-out/local-test/resource_editor/resource-sweep.log ~/gsd-logs/sweep-S04-T11.log`: identical. (3) `git show --stat b8d55b423`: the plan's expected outputs (preview-scene/mesh.tga, sprite.tga, particle.tga) are committed alongside the bridge, test, CI and sweep-script changes. (4) A Python measurement of the committed TGAs (uncompressed truecolour, 640x480x32) gave a non-black-non-magenta share of mesh 0.264867 and sprite 0.307223, identical to the sweep log. Particle measured 0.291686 against the log's 0.286986: the committed capture (14:39) and the sweep's (15:33) are different frames of an animated effect, and both are far above the 0.01 gate. (5) `grep` of cross-platform.yml: resource tier entries for linux x64/arm64, windows msvc, windows-gnu (core only) and macOS arm64/x64. (6) `ls tools/zig/run-s0*-sweep.sh`: none, so one sweep script. The full sweep itself was the maintainer's run; it was not rerun here (D010).

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `cat ~/gsd-logs/sweep-S04-T11.log (maintainer run of bash tools/zig/run-resource-sweep.sh after T11 changes)` | 0 | pass: 18/18 tiers PASS, VERDICT=PASS | 0ms |
| 2 | `cmp zig-out/local-test/resource_editor/resource-sweep.log ~/gsd-logs/sweep-S04-T11.log` | 0 | pass: identical | 0ms |
| 3 | `python3 measure non-black-non-magenta share of tools/zig/fixtures/resource_editor/preview-scene/{mesh,sprite,particle}.tga` | 0 | pass: 0.264867 / 0.307223 / 0.291686, all >= 0.01 | 2000ms |

## Deviations

The plan's verify command (running the full sweep) was not executed by the agent: it exceeds the 10-minute foreground cap. Evidence is the maintainer's run of the same script on this machine (override 2026-10-05T08:34, D010).

## Known Issues

The committed particle.tga is a different frame from the one the sweep captured (0.2917 against 0.2870), because the effect animates. Only Linux x64 was verified. The macOS and Windows CI entries were added but have not run yet; they run when the branch is pushed.

## Files Created/Modified

- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `Sources/src/EditorBridge/session.h`
- `Sources/src/EditorBridge/session.cpp`
- `tools/zig/fixtures/resource_editor/preview-scene/preview-scene.md`
- `tools/zig/fixtures/resource_editor/preview-scene/mesh.tga`
- `tools/zig/fixtures/resource_editor/preview-scene/sprite.tga`
- `tools/zig/fixtures/resource_editor/preview-scene/particle.tga`
- `.github/workflows/cross-platform.yml`
- `tools/zig/run-resource-sweep.sh`
