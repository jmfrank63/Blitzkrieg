---
id: T03
parent: S04
milestone: M001
key_files:
  - Sources/editor/resource_core/root.zig
  - Sources/editor/resource_core/bridge.zig
  - Sources/editor/resource_core/document.zig
  - Sources/editor/resource_core/history.zig
  - Sources/editor/resource_core/fake_bridge.zig
  - build.zig
key_decisions:
  - History and Entry are aliases of editor_kit.history.History(ResourceCommand) / Entry(ResourceCommand) — the kit's stack primitive is not rewritten, keeping Map/Resource undo semantics identical (markClean + clean_depth behaviour comes for free).
  - bridge.zig stays pure Zig with no @cImport; the ABI translation to the C BkRes* entries happens later in resource_core_c (S05+), so this module cross-compiles to every target including x86_64-windows-gnu where the engine C++ does not build.
  - ResourceCommand carries a .geometry variant now (not T04) so the tagged union does not need to grow (and shift tag values) when T04 lands — fake_bridge already serves geometryRead/geometryWrite against an in-memory channel map so T03 can prove the round-trip end-to-end.
  - test-resource-core wires through b.graph.host like test-editor-core — the six-target matrix is a CI concern, not a build.zig concern; forcing explicit targets here would duplicate what cross-platform.yml already covers.
duration: 
verification_result: passed
completed_at: 2026-10-05T02:00:27.474Z
blocker_discovered: false
---

# T03: Added Sources/editor/resource_core (bridge.zig + document.zig + ResourceCommand + history alias + fake_bridge.zig) and the test-resource-core tier that round-trips every command variant through undo/redo on the host.

**Added Sources/editor/resource_core (bridge.zig + document.zig + ResourceCommand + history alias + fake_bridge.zig) and the test-resource-core tier that round-trips every command variant through undo/redo on the host.**

## What Happened

Scaffolded the headless Zig core S05+ will build on, mirroring the shape of Sources/editor/core so the Resource and Map sides stay symmetric.

- `bridge.zig` defines the `ResBridge { ptr, vtable }` struct exactly like the map core's bridge.zig: `Status` enum reuses `BkEditorStatus` values, `EditError = error{Refused, Failed, OutOfMemory, BadArgument, NotFound}`, `pub fn check(Status) EditError!void`, and one vtable method per `BkRes*` entry mirrored in Zig-native types (fixed-size `[64]u8` name buffers, slices for variable-length blobs). No `@cImport` — the module cross-compiles to every target including `x86_64-windows-gnu` where the engine C++ does not build.
- `document.zig` is the per-project mirror held by the core: `path: ?[]u8`, `kind: Kind`, `tree: Tree` (nodes + props by id), `dirty_through_history: bool` derived from `History.dirty()`, `lock_owner: ?LockOwner`. `apply(Command) !void` dispatches to the right bridge method and bumps the local mirror.
- `history.zig`: `ResourceCommand` tagged union covering `.set_prop`, `.insert_node`, `.delete_node` (owns serialised subtree bytes for undo), `.move_node`, `.composite` (gesture of commands), and `.geometry` reserved for T04 to extend. `deinit(allocator)` frees owned slices. `Entry` and `History` are aliases of `editor_kit.history.Entry(ResourceCommand)` / `History(ResourceCommand)` — the kit's stack primitive is reused unchanged.
- `fake_bridge.zig` is an in-memory `FakeResBridge` implementing every `ResBridge` method against a `{id → Node}` + `{(node_id, prop_id) → Variant}` map pair. Refusal rules match what the core can see: missing-node → `Refused`, out-of-range insert index → `Refused`, duplicate id → `BadArgument`. Doc-comment header enumerates every deliberate simplification (same shape as Sources/editor/core/fake_bridge.zig).
- `root.zig` is the test entry point: 7 tests cover every ResourceCommand variant through record → undo → redo with the mirror restored byte-for-byte (set_prop, insert_node, delete_node, move_node, geometry, composite collapses as one undo step), the dirty flag follows History.dirty(), and markClean + undo past it drops the clean_depth as the kit expects.
- `build.zig`: `test-resource-core` added beside `editor_core_step`, same shape (createModule → addTest → addRunArtifact → b.step), `test_mode==.run` gates the run artifact dependency so `-Dtest-mode=check` still just builds. Six-target cross-compile is CI's job (same precedent as `test-editor-core`, which also uses `b.graph.host`).

Verified `zig build test-resource-core -Dtest-mode=run` and `zig build test-editor-core -Dtest-mode=run` both exit 0; `zig build --help` lists `test-resource-core`.

## Verification

Ran both the new tier and the map core tier to confirm the shared editor_kit was not regressed, and confirmed `test-resource-core` is listed under `zig build --help`.

- `zig build test-resource-core -Dtest-mode=run` → exit 0 (7 undo/redo tests pass, every ResourceCommand variant covered).
- `zig build test-editor-core -Dtest-mode=run` → exit 0 (shared editor_kit intact).
- `zig build --help | grep test-resource-core` → "test-resource-core           Run the Resource Editor core tests against the fake resource bridge".
- Earlier in this slice: `zig build test-resource-bridge -Dtest-mode=run` → exit 0 and `zig build test-editor-bridge -Dtest-mode=run` → exit 0 (unchanged by T03).

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-core -Dtest-mode=run` | 0 | pass | 45000ms |
| 2 | `zig build test-editor-core -Dtest-mode=run` | 0 | pass | 30000ms |
| 3 | `zig build --help | grep test-resource-core` | 0 | pass | 1500ms |

## Deviations

None.

## Known Issues

None.

## Files Created/Modified

- `Sources/editor/resource_core/root.zig`
- `Sources/editor/resource_core/bridge.zig`
- `Sources/editor/resource_core/document.zig`
- `Sources/editor/resource_core/history.zig`
- `Sources/editor/resource_core/fake_bridge.zig`
- `build.zig`
