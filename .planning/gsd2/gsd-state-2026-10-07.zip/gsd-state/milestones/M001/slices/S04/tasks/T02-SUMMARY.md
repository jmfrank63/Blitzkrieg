---
id: T02
parent: S04
milestone: M001
key_files:
  - Sources/src/EditorBridge/resource_bridge.h
  - Sources/src/EditorBridge/resource_bridge.cpp
  - Sources/src/EditorBridge/resource_bridge_test.cpp
  - build.zig
key_decisions:
  - Per-session state hangs off BkEditorSession* via a module-private std::map rather than extending BkEditorSession itself — keeps bridge.cpp's shared lifecycle layer untouched and lets T03+ hang additional per-session state (preview scene, geometry caches) off the same map.
  - Node ids are a dense 1..N pre-order index rebuilt wholesale after any Insert/Delete/Move via RebuildIds, instead of stable per-item ids. Correct for S04's test scales and keeps BkResNodes O(N) with no id-reuse bookkeeping; a long-running host that exports ids to callers across edits is T06's problem, not T02's.
  - BkResDeleteNode serializes the removed subtree via NResourceXml::Serialise through a FutureBlob-aware EmitNodeFor so unknown item types round-trip too; the blob is the one-and-only undo payload, so the restore path must parse the same shape and ParseSubtree falls back to FutureBlob when the root tag is unknown to the factory.
  - The safe-save pattern mirrors SaveSessionMap exactly: write to <path>.tmp, read back, byte-compare against the just-rendered bytes, then rename atomically; any divergence refuses the save and clears .tmp. Byte identity on read-back is the only invariant that proves 'the game reads it unchanged' through the editor's own writer.
duration: 
verification_result: passed
completed_at: 2026-10-05T01:49:03.764Z
blocker_discovered: false
---

# T02: Wired BkRes Project+Tree group (New/Open/Save/Close/KindOf/Lock/Nodes/Props/SetProp/Insert/Move/Delete/Restore) over NResourceModel::Load/Save, and extended test-resource-bridge to round-trip all 21 fixtures byte-identical + delete→restore on wpn/msh/pcp.

**Wired BkRes Project+Tree group (New/Open/Save/Close/KindOf/Lock/Nodes/Props/SetProp/Insert/Move/Delete/Restore) over NResourceModel::Load/Save, and extended test-resource-bridge to round-trip all 21 fixtures byte-identical + delete→restore on wpn/msh/pcp.**

## What Happened

T02 fills in the Project+Tree sub-step of the resource bridge C ABI that T01 scaffolded. `resource_bridge.cpp` now owns a module-private `ResourceState` per `BkEditorSession*` (open flag, kind ordinal, path, `NResourceModel::Project`, id↔item maps, parent-of map, and the advisory-lock-file sentinel). The 21-entry kind table (`kKindTable`) orders project tags (`Weapon_Composer_Project`…`GUI_Composer_Project`) with their `ETIT_*_ROOT_ITEM` type codes exactly matching EXTENSIONS.md and MEM005.

Project calls: `BkResNew(kind)` creates an empty `Project` with its typed root through `CTreeItemFactory::Instance().Create(root_type)`; `BkResOpen(path)` reads bytes and calls `NResourceModel::Load` to build the Document + typed root; `BkResSave(path)` renders through `NResourceModel::Save`, uses the SaveSessionMap safe-save pattern — back up any existing destination to `.bak`, write to `.tmp`, read back and byte-compare, rename `.tmp` → final — refusing on any divergence. `BkResClose` resets state and removes the lock sentinel; `BkResKindOf` returns the ordinal. `BkResLock`/`BkResLockOwner` write `<path>.lock` with `<hostname>:<pid>` (cross-platform `getpid`/`_getpid` + `gethostname`/`GetComputerNameA`).

Tree calls: `BkResNodes` emits every node in pre-order (root id=1, then children in storage order) with id/parent/class_type/expand/child_count/display_name — two-pass: null buffer returns count only, short buffer answers `BK_EDITOR_REFUSED`. `BkResProps` reads `SProp` records per node (id/domain_type/value_kind/combo_count/names). `BkResSetProp` finds the SProp by id and writes the text form; `BkResInsertNode` creates via the factory and inserts at index; `BkResDeleteNode` serializes the removed subtree as a `NResourceXml` document into a two-pass byte blob, then erases from the parent; `BkResRestoreNode` parses the blob and inserts, falling back to `FutureBlob` for unknown root tags so unknown subtrees round-trip too; `BkResMoveNode` detaches, re-inserts under the new parent, and refuses cycles.

Helper functions: `SerialiseSubtree`/`ParseSubtree` wrap the removed-subtree blob through `NResourceXml::Serialise`/`Parse`; `EmitNodeFor` handles `FutureBlob` passthrough and `CStatsItem::GetXmlTag()` naming so the typed subtree reproduces the fixture's tag; `LocateInParent` finds the parent's child-vector slot by scanning `MutableChildren()`.

The test tier (`resource_bridge_test.cpp`) was extended from T01's smoke to open each of the 21 fixtures at `tools/zig/fixtures/resource_editor/<ext>/project.<ext>`, call `BkResSave` to `zig-out/local-test/resource_editor/t02/<ext>/project.<ext>`, read both files, and byte-compare. The delete→restore→save round-trip runs on the three representative kinds (wpn stats-only, msh keyframe/mesh, pcp image/particle) picking the first direct child of root as the victim and asserting byte-identity after restore+save. The lock/unlock exercise opens the saved wpn copy, locks, reads the owner, confirms a non-empty host:pid string, and closes. The `BkResNew(wpn)` smoke from T01 is preserved. On a headless host without a GPU, `BkEditorStart` returns `BK_EDITOR_NO_DEVICE` and the test exits 0 with `resource-bridge: skipped: no GPU device`, mirroring the editor-bridge GPU gate — `BK_REQUIRE_ENGINE=1` converts a skip into a fail so CI runners with a device cannot hide a regression as a skip.

## Verification

Ran all three slice-verification commands on Linux x64 debug build: `zig build test-resource-bridge -Dtest-mode=run` (exit 0, "resource-bridge: Project+Tree OK (21 fixtures)"), `zig build test-resource-model -Dtest-mode=run` (exit 0, "COMPARE_SUMMARY exts=21 goldens_present=0 goldens_missing=20 not_applicable=1" — S03 contract preserved), and `zig build test-editor-bridge -Dtest-mode=run` (exit 0, "editor-bridge: PASS"). The scratch output directory `zig-out/local-test/resource_editor/t02/` contains all 21 extension subdirectories with `project.<ext>` files, and `wpn/`, `msh/`, `pcp/` also contain `project.deleterestore.<ext>` artifacts.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 180000ms |
| 2 | `zig build test-resource-model -Dtest-mode=run` | 0 | pass | 60000ms |
| 3 | `zig build test-editor-bridge -Dtest-mode=run` | 0 | pass | 180000ms |

## Deviations

None.

## Known Issues

None.

## Files Created/Modified

- `Sources/src/EditorBridge/resource_bridge.h`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `build.zig`
