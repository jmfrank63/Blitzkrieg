# S04 Replan

**Milestone:** M001
**Slice:** S04
**Blocker Task:** T06
**Created:** 2026-10-05T03:31:29.094Z

## Blocker Description

Hard steer 2026-10-05 (.gsd/OVERRIDES.md): independent review found S03 ResourceModel is a shell (no MFC property tables, non-MFC serialisation, inserted node saves as `<>`), the bridge lock file is `<path>.lock` instead of MFC's `locked_<user>` (D-08), geometry is saved only for the root node and undo of a delete does not restore it, and two sweep scripts exist with pre-existing-failure excuses. S03 is reopened and must close before S04's remaining tasks run.

## What Changed

S04 now depends on the reopened S03. New T07 fixes the bridge-side review findings (locked_<user> lock with atomic create kept; geometry saved for every node; delete->restore restores geometry). Old T07..T10 shift to T08..T11 with unchanged scope, except: T10 export must be checked by the D-11 comparator over exported data (golden comparison stays pending until win-home goldens exist), and T11 uses the single `tools/zig/run-resource-sweep.sh` from S03 T08 instead of a new run-s04-sweep.sh (must-have 9 is superseded accordingly). Every task summary cites only commands really run in that task.
