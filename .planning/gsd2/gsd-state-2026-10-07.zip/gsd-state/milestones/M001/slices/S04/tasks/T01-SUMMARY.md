---
id: T01
parent: S04
milestone: M001
key_files:
  - Sources/src/EditorBridge/resource_bridge.h
  - Sources/src/EditorBridge/resource_bridge.cpp
  - Sources/src/EditorBridge/resource_bridge_test.cpp
  - Sources/src/EditorBridge/guarded.h
  - Sources/src/EditorBridge/bridge_session.h
  - Sources/src/EditorBridge/bridge.cpp
  - build.zig
key_decisions:
  - BkResSession is a typedef over BkEditorSession rather than a disjoint handle — the resource editor reuses the shared lifecycle entry points (BkEditorStart/Stop/SetOverlay/CaptureFrame/Paths/SetMod/Mods/ActiveMod/Frame) unchanged, as the research recommended. Documented in resource_bridge.h's leading comment.
  - Extracted BkEditorSession's complete struct body into bridge_session.h so resource_bridge.cpp can call the shared Guarded template without redefining the opaque type (the forward declaration in bridge.h is not enough — the template body dereferences szMessage).
  - Guarded's shared signature takes SEditorSession* (the base class with szMessage) rather than BkEditorSession* — derived-pointer upcast is automatic at the call sites, and the template body only ever reads szMessage.
  - resource_bridge.cpp compiles into the existing EditorBridge static library (one archive, as the task plan required) rather than a separate archive, so a resource editor executable links one library and gets both ABIs.
  - test-resource-bridge's engine library set matches test-editor-bridge's six engines — the slice plan's 'five engine targets' phrase is read as matching the engine link list, and the plan's wording is ambiguous between 'engine libraries' and 'OS targets'; this task's host-only Linux smoke pass does not foreclose the latter reading for later tasks.
  - Smoke host uses SDL_WINDOW_HIDDEN | SDL_WINDOW_NOT_FOCUSABLE (AGENTS.md Linux pitfall), rdynamic + $ORIGIN rpath on Linux, and copies the no-GPU skip gate from editor_bridge_test.cpp verbatim including BK_REQUIRE_ENGINE=1 for CI runners that must have a device.
duration: 
verification_result: passed
completed_at: 2026-10-05T01:25:08.980Z
blocker_discovered: false
---

# T01: Scaffolded resource bridge C ABI (resource_bridge.h/.cpp with every BkRes* entry point stubbed via shared Guarded), extracted BkEditorSession and Guarded into shared headers so bridge.cpp and resource_bridge.cpp both link one archive, and registered test-resource-bridge smoke tier (green on Linux x64).

**Scaffolded resource bridge C ABI (resource_bridge.h/.cpp with every BkRes* entry point stubbed via shared Guarded), extracted BkEditorSession and Guarded into shared headers so bridge.cpp and resource_bridge.cpp both link one archive, and registered test-resource-bridge smoke tier (green on Linux x64).**

## What Happened

The research named the exact scaffold: an opaque BkResSession typedef over BkEditorSession, extern "C" declarations covering 8 groups (Projects, Tree, References, Geometry get/set pairs, Export, MOD, Preview, Import), stubbed bodies returning BK_EDITOR_OK through a shared Guarded wrapper, a C++ smoke host, and a build.zig step modeled on addEditorBridgeTest. Writing the files was straightforward CRLF-text work; the real finding was that the local Guarded in bridge.cpp dereferenced pSession->szMessage, so extracting it to guarded.h required the compiler to see BkEditorSession as a complete type (not merely bridge.h's forward declaration). First build attempt reproduced that exact error — "member access into incomplete type 'BkEditorSession'" — in resource_bridge.cpp. Fix: extracted BkEditorSession's full struct body (with pWindow, mod state, tileAtlas cache) from bridge.cpp into Sources/src/EditorBridge/bridge_session.h, and rewrote guarded.h's template to take SEditorSession* (the shared base — the only field it touches, szMessage, is on the base). bridge.cpp now includes both shared headers and keeps its anonymous namespace of helpers; resource_bridge.cpp includes the same and gets Guarded via namespace-scope template lookup. The build.zig additions: resource_bridge.cpp joins the EditorBridge static library file list (one archive, as the plan required), and a new addResourceBridge function registers test-resource-bridge as a C++ executable linking the same six engine libraries test-editor-bridge links (EditorBridge/MapFile/Main/RandomMapGen/Formats/Misc/PlatformRuntime + SDL), staged beside Game with rdynamic + $ORIGIN rpath on Linux and SDL_WINDOW_HIDDEN|SDL_WINDOW_NOT_FOCUSABLE on the test window. On a no-GPU host the test prints "skipped: no GPU device" and exits 0 — the same gate editor_bridge_test uses, with BK_REQUIRE_ENGINE=1 turning a skip into a failure on runners that do have a device. The smoke sequence inside the host: BkEditorStart (shared lifecycle), BkResNew(kind=wpn), BkResKindOf, BkResNodes(null-buffer count read), BkResClose, BkEditorStop. All four required tiers (test-resource-bridge, test-editor-bridge, test-editor-core, test-resource-model) are green with -Dtest-mode=run on Linux x64.

## Verification

Ran each of the four tiers the task plan names with -Dtest-mode=run and confirmed exit 0. test-resource-bridge prints "resource-bridge: smoke OK" after the engine starts and the smoke sequence runs. test-editor-bridge (the pre-existing exhaustive engine tier) still finishes with "editor-bridge: PASS" — the shared Guarded extraction and BkEditorSession header split did not regress the map editor. test-editor-core (pure Zig unit tests against FakeBridge) exits 0 silently. test-resource-model (the S03 aggregate scaffold + references + comparator) finishes with the SCAFFOLD gui line and exits 0. Observability evidence saved to zig-out/local-test/resource_editor/t01-smoke.log.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | PASS | 3000ms |
| 2 | `zig build test-editor-bridge -Dtest-mode=run` | 0 | PASS | 405000ms |
| 3 | `zig build test-editor-core -Dtest-mode=run` | 0 | PASS | 1000ms |
| 4 | `zig build test-resource-model -Dtest-mode=run` | 0 | PASS | 1000ms |

## Deviations

The task plan said "Call it from the top-level build() beside addResourceModelAggregateStep" (line ~1384 in build.zig); addResourceBridge is instead called at line ~2210 beside addEditorBridgeTest. Reason: the engine static library handles (editor_bridge, map_file, formats, randommapgen, misc, main, lualib, zlib, platform_runtime, sdl_dynamic) are only in scope at the later call site. The earlier anchor only has `target`, `test_mode`, `toolchain` in scope — not the engine libraries. The resource_bridge is C++ engine code, so this is the only correct call site. No scope collision, no late dependency ordering risk.

## Known Issues

Resource bridge entries are stubs that return BK_EDITOR_OK — real behaviour arrives in T02 (Project+Tree), T03 (Zig resource_core), T04 (Geometry), T05 (Export+MOD+References+Import), T06 (Preview+sweep). Every stub takes its parameters but ignores them. The smoke test does not assert anything about tree content, just that the calls return BK_EDITOR_OK without crashing.

## Files Created/Modified

- `Sources/src/EditorBridge/resource_bridge.h`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `Sources/src/EditorBridge/guarded.h`
- `Sources/src/EditorBridge/bridge_session.h`
- `Sources/src/EditorBridge/bridge.cpp`
- `build.zig`
