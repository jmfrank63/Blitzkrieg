---
estimated_steps: 8
estimated_files: 3
skills_used: []
---

# T02: Wired BkRes Project+Tree group (New/Open/Save/Close/KindOf/Lock/Nodes/Props/SetProp/Insert/Move/Delete/Restore) over NResourceModel::Load/Save, and extended test-resource-bridge to round-trip all 21 fixtures byte-identical + delete→restore on wpn/msh/pcp.

Why: every downstream sub-editor edits the project tree through these calls. The delete→restore round-trip is the serialisation shape every undo step depends on, so it must be byte-identical before any geometry edit is wired on top.

Do:
1. Implement `BkResNew(kind)` → calls `NResourceModel::CTreeItemFactory::Create(root_type_for_kind)`, builds an empty `CProject`, returns a session that owns it. `BkResOpen(path)` reads the file, calls `NResourceModel::Load`, keeps the parsed `Document` + typed root. `BkResSave(path)` uses the safe-save pattern (write to `<path>.tmp`, read back, byte-compare against the just-rendered output, rename to final; `.bak` of the pre-existing target first). Mirror `BkEditorSaveMap`'s read-back verification — do not simplify.
2. Implement `BkResClose`, `BkResKind` (returns a stable kind enum per project extension — one of the 21 from `EXTENSIONS.md`). `BkResLock` + `BkResLockOwner` use a cross-platform advisory lock file beside the project (match the map editor's lock, if one exists; else the simplest `.lock` sentinel with the PID + hostname).
3. Implement `BkResNodes` (two-pass: `out_count` always written; `BK_EDITOR_REFUSED` on short buffer) returning `{id, parent, class_type, display_name_utf8[64], expand, child_count}` per `CTreeItem`. `BkResProps(node_id)` returns `{id, default_name[64], display_name[64], domain_type, value_variant, combo_strings[]}` per `SProp` on that node.
4. Implement `BkResSetProp(node_id, prop_id, variant)` — commits the mutation on `CTreeItem::values`. `BkResInsertNode(parent_id, class_type, index)` — uses factory `Create(class_type)`; `BkResMoveNode(node_id, new_parent, new_index)`. `BkResDeleteNode(node_id)` serialises the removed subtree through `NResourceXml::Serialise` into a caller-owned byte buffer (two-pass: size then write); `BkResRestoreNode(parent, index, bytes, len)` parses the blob back through `NResourceXml::Parse` and inserts.
5. Extend `resource_bridge_test.cpp`: for every one of the 21 fixtures under `tools/zig/fixtures/resource_editor/<ext>/project.<ext>`, open → save (to a temp path under `zig-out/local-test/resource_editor/t02/<ext>/project.<ext>`) → byte-compare. For a representative subset (wpn, msh, pcp — stats-only, keyframe, image), also exercise delete→restore→save with byte-identity. Resolve Data paths case-insensitively via the `DataFile` helper pattern.

Done-when: `zig build test-resource-bridge -Dtest-mode=run` passes with the new Project+Tree sub-step; every fixture round-trips byte-identical; delete→restore round-trips byte-identical on the three representative kinds.

## Inputs

- `Sources/src/EditorBridge/resource_bridge.h`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `Sources/src/ResourceModel/project.h`
- `Sources/src/ResourceModel/project.cpp`
- `Sources/src/ResourceModel/tree_item.h`
- `Sources/src/ResourceModel/factory.h`
- `Sources/src/ResourceModel/xml.h`
- `Sources/src/ResourceModel/variant.h`
- `Sources/src/ResourceModel/prop.h`
- `Sources/src/ResourceModel/items/tree_item_types.h`
- `tools/zig/fixtures/resource_editor/EXTENSIONS.md`
- `tools/zig/fixtures/resource_editor/wpn/project.wpn`
- `tools/zig/fixtures/resource_editor/msh/project.msh`
- `tools/zig/fixtures/resource_editor/pcp/project.pcp`

## Expected Output

- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge.h`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`

## Verification

zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model -Dtest-mode=run && zig build test-editor-bridge -Dtest-mode=run
