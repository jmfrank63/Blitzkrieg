---
estimated_steps: 1
estimated_files: 4
skills_used: []
---

# T07: Bridge review fixes: MFC locked_<user> lock, geometry saved for every node, delete->restore restores geometry

Tests first in `resource_bridge_test.cpp`. (1) Lock: replace `state.szPath + ".lock"` (resource_bridge.cpp ~994/1040) with MFC's scheme from `Sources/src/editor/ParentFrame.cpp:1550-1595`: a `locked_<user>` file in the project's directory, enumerate `locked_*` to detect another user's lock, warn + read-only/take-over semantics per D-08; keep the atomic exclusive create from 0b37480f9; release on close. Test: two sessions with different user names, foreign lock detected, take-over, release removes the file, no stray `<path>.lock`. Use XDG_DATA_HOME/BK_* seams and zig-out/local-test copies only. (2) Geometry: persist geometry for every node that carries it (not only the root) in MFC's element layout from the S03 items; test set geometry on a non-root node -> save -> reopen -> equal. (3) `BkResDeleteNode` snapshot includes the subtree's geometry; `BkResRestoreNode` restores it; test delete->restore->save byte-identical to before the delete for a node with geometry.

## Inputs

- `Sources/src/editor/ParentFrame.cpp`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `.planning/phases/06-*/06-CONTEXT.md`
- `.gsd/OVERRIDES.md`

## Expected Output

- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`

## Verification

zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-core -Dtest-mode=run && zig build test-resource-model -Dtest-mode=run && zig build test-editor-bridge -Dtest-mode=run
