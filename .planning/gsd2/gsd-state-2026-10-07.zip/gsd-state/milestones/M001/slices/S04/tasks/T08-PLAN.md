---
estimated_steps: 1
estimated_files: 6
skills_used: []
---

# T08: Geometry formation + bridge span marks families (points2 payload) against scp/bdg

Unchanged scope from the former T07: add `BkRes[Get|Set]FormationPositions` and `BkRes[Get|Set]BridgeSpanMarks` (two-pass flat Point2 list) against the faithful S03 squad and bridge items, MFC coordinate conventions documented in the header; wire channels in bridge.zig + fake_bridge.zig; per-channel undo/redo in test-resource-core; set->save->reopen->read parity on scp/bdg fixtures, including on non-root nodes.

## Inputs

- `Sources/src/ResourceModel/items/squad`
- `Sources/src/ResourceModel/items/bridge`
- `tools/zig/fixtures/resource_editor/scp/project.scp`
- `tools/zig/fixtures/resource_editor/bdg/project.bdg`

## Expected Output

- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/editor/resource_core/bridge.zig`
- `Sources/editor/resource_core/fake_bridge.zig`

## Verification

zig build test-resource-core -Dtest-mode=run && zig build test-resource-bridge -Dtest-mode=run && zig build test-editor-core -Dtest-mode=run && zig build test-editor-bridge -Dtest-mode=run
