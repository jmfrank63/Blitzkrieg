---
estimated_steps: 1
estimated_files: 5
skills_used: []
---

# T10: Export, MOD, References, Import groups + fake-side coverage

Scope from the former T09 (BkResExport/ExportStatsOnly/Batch, RefList for all 20 EReferenceType, ModSettings get/set, PackMod via native zip, ImportFromGame for sprite/infantry with honest REFUSED stubs elsewhere, fake bridge tables). Change: export results are checked with the S03 D-11 comparator over exported data (engine readers, exact floats); where no MFC golden exists the test reports `pending: golden missing` and is not counted as parity done.

## Inputs

- `Sources/src/ResourceModel/references.cpp`
- `Sources/src/ResourceModel/comparator.cpp`
- `Sources/editor/kit/files.zig`
- `tools/zig/fixtures/resource_editor/references_root`

## Expected Output

- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/editor/resource_core/fake_bridge.zig`

## Verification

zig build test-resource-core -Dtest-mode=run && zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model -Dtest-mode=run && zig build test-editor-bridge -Dtest-mode=run
