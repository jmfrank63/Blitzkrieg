---
estimated_steps: 7
estimated_files: 7
skills_used: []
---

# T04: Blocker: T04 scope (13 geometry kinds × ~15 sub-steps across 7 files) exceeds a single auto-mode iteration — escalating for split before implementation.

Why: these get/set pairs ARE the atomic undo units for every downstream sub-editor tool (S06..S14). Each pair must round-trip through the core's `ResourceCommand.geometry` variants and `FakeResBridge` so S06+ can test tool behaviour against the fake before the real engine is in the loop.

Do:
1. Enumerate the geometry edit kinds the research names: passability cells, locked/unlocked tiles, transparency cells, zero point, entrance point, shoot/fire/smoke/directed-explosion points (angle + cone), one-way transparency lines, formation positions (squad), bridge span marks, mission objectives, chapter/campaign crosses, particle/effect keyframes. For each: define a C struct in `resource_bridge.h` (fixed-size, no pointers), add `BkResGet<Kind>` / `BkResSet<Kind>` entry points to the header + impl, implement each against `CTreeItem::values` on the typed item class (keep MFC-era semantics for angle degrees vs engine turns; preserve the undo contract that a refusal changes nothing).
2. Replace the T03 placeholder `.geometry` variant with one named variant per kind in `ResourceCommand` (`.passability`, `.zero_point`, `.entrance`, `.trans_line`, `.shoot_point`, `.fire_point`, `.smoke_point`, `.directed_explosion`, `.formation_slot`, `.bridge_span_mark`, `.objective`, `.cross`, `.keyframe`). Each holds `before` and `after` payloads sized to the kind. Extend `deinit` to free any owned slices (e.g. keyframe arrays).
3. Extend `FakeResBridge` with in-memory tables for each kind (keyed by node id). Extend `test-resource-core` with per-kind undo→redo→undo round-trip assertions: identity on get after undo, identity on get after redo-then-undo, dirty flag follows every mutation.
4. Extend `resource_bridge_test.cpp` with per-kind get/set tests against the typed item classes on representative fixtures (bld for passability, scp for formation, bdg for span marks, pcp for keyframes, mip for objectives, cgc for crosses) — set a value, read back, assert identity, save, re-open, assert the value persists.

Done-when: `zig build test-resource-core -Dtest-mode=run` and `zig build test-resource-bridge -Dtest-mode=run` both green with the per-kind sub-step included; every `ResourceCommand` variant has at least one undo→redo test; map-editor tiers still green.

## Inputs

- `Sources/src/EditorBridge/resource_bridge.h`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `Sources/editor/resource_core/bridge.zig`
- `Sources/editor/resource_core/history.zig`
- `Sources/editor/resource_core/fake_bridge.zig`
- `Sources/src/ResourceModel/items/building`
- `Sources/src/ResourceModel/items/bridge`
- `Sources/src/ResourceModel/items/squad`
- `Sources/src/ResourceModel/items/particle`
- `Sources/src/ResourceModel/items/mission`
- `Sources/src/ResourceModel/items/campaign`
- `tools/zig/fixtures/resource_editor/bld/project.bld`
- `tools/zig/fixtures/resource_editor/scp/project.scp`
- `tools/zig/fixtures/resource_editor/bdg/project.bdg`
- `tools/zig/fixtures/resource_editor/pcp/project.pcp`
- `tools/zig/fixtures/resource_editor/mip/project.mip`
- `tools/zig/fixtures/resource_editor/cgc/project.cgc`

## Expected Output

- `Sources/src/EditorBridge/resource_bridge.h`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `Sources/editor/resource_core/bridge.zig`
- `Sources/editor/resource_core/history.zig`
- `Sources/editor/resource_core/fake_bridge.zig`
- `Sources/editor/resource_core/document.zig`

## Verification

zig build test-resource-core -Dtest-mode=run && zig build test-resource-bridge -Dtest-mode=run && zig build test-editor-core -Dtest-mode=run && zig build test-editor-bridge -Dtest-mode=run
