---
id: T04
parent: S04
milestone: M001
key_files:
  - .gsd/milestones/M001/slices/S04/tasks/T04-SUMMARY.md (this file)
key_decisions:
  - Escalated instead of partially implementing: T04 as written is ~1500-2500 lines spanning 13 independently-verifiable kinds across 7 files; shipping a fraction would leave the Zig core and C ABI in incompatible half-replaced states and silently regress the slice. The responsible move is one task per geometry family so each landing is verifiable in isolation.
  - Flagged the T04 plan's shape disagreement with T03: T03 already landed a unified GeometryChannel/GeometryValue design (one vtable pair, one union, one fake-bridge map); T04 asks to replace that with 13 named variants and 13 tables. That is a mid-slice direction change, not an extension, and should be resolved by plan-slice (keep unified vs go per-kind) before any code lands.
  - Did not touch any files or run any build steps — the auto.lock + git tree stay in exactly the state T03 left them in, so slice-replan can rebuild from a clean baseline.
duration: 
verification_result: untested
completed_at: 2026-10-05T02:06:37.036Z
blocker_discovered: true
---

# T04: Blocker: T04 scope (13 geometry kinds × ~15 sub-steps across 7 files) exceeds a single auto-mode iteration — escalating for split before implementation.

**Blocker: T04 scope (13 geometry kinds × ~15 sub-steps across 7 files) exceeds a single auto-mode iteration — escalating for split before implementation.**

## What Happened

T04 as planned is a multi-day change surface that cannot be delivered responsibly inside one auto-mode iteration without producing broken intermediate state. Reporting as a blocker so the slice replan step can split it before any code is written.

**What T04 asks for, concretely**

1. **Sources/src/EditorBridge/resource_bridge.h / resource_bridge.cpp** — define 13 fixed-size C structs (passability cells, locked tiles, transparency lines, zero point, entrance, shoot/fire/smoke/directed-explosion points, formation positions, bridge span marks, mission objectives, chapter crosses, campaign crosses, particle/effect keyframes) and add a matching `BkResGet<Kind>` + `BkResSet<Kind>` pair per kind, each wired through `CTreeItem::values` on the typed item class (bld/scp/bdg/pcp/mip/cgc/…). That is 13 structs + 26 entry points on top of the current 328-line header.

2. **Sources/src/EditorBridge/resource_bridge_test.cpp** — a per-kind set/read/save/re-open/read test against the six representative fixtures (bld, scp, bdg, pcp, mip, cgc). That is 13 new test blocks each exercising a real round-trip through NResourceModel::Load/Save on a real binary fixture.

3. **Sources/editor/resource_core/history.zig** — replace the single `.geometry` variant with 13 named variants (`.passability`, `.zero_point`, `.entrance`, `.trans_line`, `.shoot_point`, `.fire_point`, `.smoke_point`, `.directed_explosion`, `.formation_slot`, `.bridge_span_mark`, `.objective`, `.cross`, `.keyframe`), each with before/after payloads sized to the kind, and extend `deinit` to free owned slices per variant.

4. **Sources/editor/resource_core/fake_bridge.zig** — one in-memory table per kind keyed by node id (currently a single unified `{(node, channel) -> GeometryValue}` map).

5. **Sources/editor/resource_core/root.zig / document.zig** — per-kind undo→redo→undo round-trip assertions for every one of the 13 variants, plus dirty-flag assertions.

**Why this is a blocker, not an ordinary big task**

- The slice contract already pre-declared a *unified* geometry shape in T03 (`GeometryChannel` enum covering all 16 kinds + a single `GeometryValue` union covering the 5 payload shapes, served through one `geometryRead/Write` vtable pair in both `ResBridge` and `FakeResBridge`). Replacing that with 13 named variants on the Zig side, 13 struct/entry pairs on the C side, and 13 fake-bridge tables fights the design T03 just landed — it is a direction change inside a slice, not an extension.

- The MFC-era C++ item classes (`Sources/src/ResourceModel/items/{building,bridge,squad,particle,mission,campaign}`) each expose geometry via different `CTreeItem::values` layouts (angles vs turns, degrees vs radians, grid-of-bytes vs point-list, keyframe arrays of varying struct sizes). Each kind needs its own typed read/write against the right value id — all 13 cannot share a template. The research in S04 CONTEXT recorded six of these layouts; the other seven still need to be derived from the frame sources (same pattern as MEM005 for the extension map).

- Round-tripping byte-identically through `NResourceModel::Load/Save` on real fixtures (bld/scp/bdg/pcp/mip/cgc) requires the save path to serialise exactly the bytes the game reader expects. For some kinds (keyframes especially) the on-disk shape is non-trivial and the parity check cannot be eyeballed — it needs a per-kind TGA or byte-measurement, same as the S01 spike contract.

- The current green state (`test-resource-core`, `test-resource-bridge`, both map-editor tiers) is wide and must stay green through every intermediate commit. Landing 13 kinds in one patch risks a cascade failure where any one kind's regression blocks the slice. Smaller tasks per kind (or per family: cells, points, aimed points, keyframes) make each landing independently verifiable.

**Recommended split (what plan-slice should produce next)**

- T04a: C struct + ABI pair + Zig variant + fake entry + round-trip test for the **cells family** (passability, locked tiles, transparency grid) against bld.
- T04b: Same for the **point family** (zero point, entrance) against bld/scp.
- T04c: Same for the **aimed-point family** (shoot/fire/smoke/directed-explosion) against the appropriate unit fixture.
- T04d: Same for **formation positions** against scp.
- T04e: Same for **bridge span marks** against bdg.
- T04f: Same for **mission objectives + chapter/campaign crosses** against mip/cgc.
- T04g: Same for **particle/effect keyframes** against pcp (highest risk — variable-length arrays, round-trip needs byte parity).

Each of T04a..T04g is one afternoon of work with its own verification; the slice contract (every ResourceCommand variant has an undo/redo round-trip, every kind round-trips through save/reopen) is preserved at the slice level, not at the task level.

**What I did not do and why**

- Did not write any production code or tests. Starting a 13-kind change and landing a fraction of it would leave the Zig core in a half-replaced state (old `.geometry` variant still live, some new variants added) and the C ABI in a partial state, both of which would silently fail the slice verification and block downstream tasks.
- Did not call `gsd_replan_slice` here because the summary tool's `blockerDiscovered: true` + `escalation` payload is the auto-mode path for exactly this case; the slice-replan skill will trigger from the escalation.

**State left on disk**

- Working tree is clean (`git status --short` returns empty); no partial edits need rolling back.
- All T03 artifacts still green: `test-resource-core`, `test-resource-bridge`, `test-editor-core`, `test-editor-bridge` all pass as of T03's commit (7776ceb86).
- The T03-declared unified `GeometryChannel`/`GeometryValue` shape is still in place in `Sources/editor/resource_core/bridge.zig` lines 181–240 and `FakeResBridge.geometryRead/Write` at `fake_bridge.zig:513–598`; the T04 split should decide whether to keep that unified shape (one `.geometry` variant parameterised by channel) or follow the T04 plan's "13 named variants" direction.

## Verification

No implementation was attempted, so no verification was run beyond baseline state checks:

- Confirmed working tree clean (`git status --short` → empty).
- Confirmed last commit is T03 (`7776ceb86 test: Added Sources/editor/resource_core …`) — T04 has no prior partial state.
- Confirmed T01/T02/T03 summaries all exist under `.gsd/milestones/M001/slices/S04/tasks/`.
- Did not re-run the four verification tiers from the task plan (`test-resource-core`, `test-resource-bridge`, `test-editor-core`, `test-editor-bridge`) because nothing was changed; T03's summary already records them green at commit 7776ceb86.</verification>
<parameter name="verificationEvidence">[{"command": "git status --short", "exitCode": 0, "verdict": "pass (clean tree)", "durationMs": 120}, {"command": "git log --oneline -3", "exitCode": 0, "verdict": "pass (T03 is HEAD, no partial T04 state)", "durationMs": 90}, {"command": "ls .gsd/milestones/M001/slices/S04/tasks/", "exitCode": 0, "verdict": "pass (T01/T02/T03 summaries present, T04 plan present, no stale T04 artifacts)", "durationMs": 15}]

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| — | No verification commands discovered | — | — | — |

## Deviations

Entire task deferred — no files modified. See narrative for the per-family split recommendation.

## Known Issues

T04 plan still references a single .geometry variant replacement; T03 already shipped the unified GeometryChannel/GeometryValue design that would survive if the slice chose to keep it. plan-slice should resolve this before T04a lands.

## Files Created/Modified

- `.gsd/milestones/M001/slices/S04/tasks/T04-SUMMARY.md (this file)`
