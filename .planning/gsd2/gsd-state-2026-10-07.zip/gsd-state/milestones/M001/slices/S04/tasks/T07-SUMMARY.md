---
id: T07
parent: S04
milestone: M001
key_files:
  - Sources/src/EditorBridge/resource_bridge.cpp
  - Sources/src/EditorBridge/resource_bridge.h
  - Sources/src/EditorBridge/resource_bridge_test.cpp
  - Sources/editor/resource_core/document.zig
key_decisions:
  - Lock is per folder `locked_<user>` exactly as MFC; same-user file counts as held; exclusive create plus re-enumeration makes cross-user races back off instead of double-holding.
  - Added BkResLockTakeOver to the C ABI for D-08's take-over; read-only is the host simply not locking. The Zig vtable is not extended yet (S05+).
  - User name test seam: BK_RESOURCE_EDITOR_USER.
  - Geometry is stored as `_bk_geometry` elements inside the owning item's element (stripped and re-injected on every write), with a `path` attribute fallback for items lacking their own element.
duration: 
verification_result: passed
completed_at: 2026-10-05T06:18:59.212Z
blocker_discovered: false
---

# T07: Resource bridge now uses MFC's per-folder locked_<user> lock with a take-over entry, saves geometry inside every owning node's element, and carries subtree geometry through delete->restore byte-identically.

**Resource bridge now uses MFC's per-folder locked_<user> lock with a take-over entry, saves geometry inside every owning node's element, and carries subtree geometry through delete->restore byte-identically.**

## What Happened

Lock: replaced the `<path>.lock` sentinel with MFC's CParentFrame::LockFile scheme (D-08). AcquireLock enumerates `locked_*` in the project folder; another user's file -> BK_EDITOR_REFUSED naming the owners; the same user's file is treated as already held (MFC semantics). The atomic exclusive create ("wbx") from 0b37480f9 is kept, plus a second enumeration after the create so two different users racing both back off rather than both holding. User name comes from the BK_RESOURCE_EDITOR_USER test seam, else GetUserNameA / getpwuid / $USER, sanitised for file names. New C entry BkResLockTakeOver removes other users' lock files and takes the lock (D-08's take-over; read-only is the host's choice of not locking). BkResLockOwner now returns the comma-separated owners of all locked_* files. BkResClose removes the session's lock file. Header doc updated.

Geometry: the old scheme pushed `_bk_geometry` FutureBlob children into the item tree, which is lost under parents that do not serialise childs and under static-children reconciliation. Now geometry is written as `_bk_geometry` elements inside the owning item's own element: BkResSave renders via NResourceModel::Save, re-parses (Serialise is idempotent per xml.h), strips every `_bk_geometry`, and injects the session map by walking items in parallel with their `childs` entries (WriteGeometry/InjectGeometry). Items with no own element fall back to the nearest ancestor element with a `path` attribute. BkResOpen reads them back with ReadGeometry; items keep the elements in their layout as unknown fields, which the strip on every write neutralises. Projects without geometry take the unchanged fast path, so fixture round-trips stay byte-identical.

Delete/restore: SerialiseSubtree now writes the subtree's geometry into the delete blob; BkResDeleteNode still drops the removed ids' geometry; BkResRestoreNode reads the blob's geometry back onto the restored (old) ids.

Tests (resource_bridge_test.cpp): two-session lock test (second session is a bare BkEditorSession via bridge_session.h; users via the seam) covering own-lock re-entry, foreign refusal naming alice, no file left by a refused lock, LockOwner, take-over, release on close, and no stray locked_*/.lock. Geometry test on the wpn fixture: zero point/cells on a root child and zero point/shoot point on the deepest node, save -> reopen -> equal, reopened save byte-identical, delete child (subtree incl. deep node) -> geometry gone -> restore under old id -> geometry back -> save byte-identical to the pre-delete save. Inspected the saved XML: geometry sits in nested item elements.

## Verification

Ran in this task on Linux x64: zig build test-resource-bridge -Dtest-mode=run (rc 0, "resource-bridge: Project+Tree OK (21 fixtures)", new lock and geometry checks included); zig build test-resource-core -Dtest-mode=run (rc 0, rerun after the document.zig doc-comment edit, rc 0); zig build test-resource-model -Dtest-mode=run (rc 0, VERDICT=PASS (goldens pending)); zig build test-editor-bridge -Dtest-mode=run (rc 0, editor-bridge: PASS, 537 s). The other Map Editor tiers were not run in this task.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | ✅ pass | 7000ms |
| 2 | `zig build test-resource-core -Dtest-mode=run` | 0 | ✅ pass | 1000ms |
| 3 | `zig build test-resource-model -Dtest-mode=run` | 0 | ✅ pass (goldens pending) | 24000ms |
| 4 | `zig build test-editor-bridge -Dtest-mode=run` | 0 | ✅ pass | 537000ms |

## Deviations

Added a header entry (BkResLockTakeOver) and a doc-comment fix in Sources/editor/resource_core/document.zig, beyond the two planned files. Geometry layout is the port's `_bk_geometry` element in the owning item's element, not an MFC frame own_data layout: MFC keeps frame geometry in frame data that is not ported yet, so no MFC element layout exists for per-node geometry.

## Known Issues

The `path` fallback (geometry on a node under a parent that does not write childs) is implemented but has no dedicated test; the wpn test nodes all have their own element. Map Editor tiers other than test-editor-bridge were not rerun in this task (the change only touches resource_bridge.cpp in the shared EditorBridge archive).

## Files Created/Modified

- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge.h`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `Sources/editor/resource_core/document.zig`
