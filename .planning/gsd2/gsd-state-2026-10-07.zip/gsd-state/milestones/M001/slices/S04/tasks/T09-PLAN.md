---
estimated_steps: 1
estimated_files: 6
skills_used: []
---

# T09: Geometry mission objectives + chapter/campaign crosses + particle/effect keyframes families against mip/cgc/pcp

Unchanged scope from the former T08: five BkRes[Get|Set] pairs (MissionObjectives, ChapterCrosses, CampaignCrosses, ParticleKeyframes, EffectKeyframes) against the faithful S03 items; extend GeometryValue additively if crosses carry more than a Point2; per-channel undo/redo; set->save->reopen parity on mip/chc/cgc/pcp/eff with byte identity through NResourceModel Load/Save.

## Inputs

- `Sources/src/ResourceModel/items/mission`
- `Sources/src/ResourceModel/items/campaign`
- `Sources/src/ResourceModel/items/particle`
- `tools/zig/fixtures/resource_editor/mip/project.mip`
- `tools/zig/fixtures/resource_editor/cgc/project.cgc`
- `tools/zig/fixtures/resource_editor/pcp/project.pcp`

## Expected Output

- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/editor/resource_core/bridge.zig`

## Verification

zig build test-resource-core -Dtest-mode=run && zig build test-resource-bridge -Dtest-mode=run && zig build test-editor-core -Dtest-mode=run && zig build test-editor-bridge -Dtest-mode=run && zig build test-resource-model -Dtest-mode=run
