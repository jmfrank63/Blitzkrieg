---
id: T10
parent: S04
milestone: M001
key_files:
  - Sources/src/EditorBridge/resource_bridge.cpp
  - Sources/src/EditorBridge/resource_bridge.h
  - Sources/src/EditorBridge/resource_bridge_test.cpp
  - Sources/src/ResourceModel/exporter.h
  - Sources/src/ResourceModel/exporter.cpp
  - Sources/editor/resource_core/bridge.zig
  - Sources/editor/resource_core/fake_bridge.zig
  - Sources/editor/resource_core/root.zig
  - build.zig
  - docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md
key_decisions:
  - Exporters register per sub-editor slice via NResourceModel::RegisterExporter; until then BkResExport refuses the kind instead of emitting partial data.
  - Sprite import is refused: MFC has no .san reverse path; only unt import is implemented (port of CAnimationFrame::GetRPGStats).
  - ModSettings mirrors MFC's MOD dialog fields, not invented bake knobs.
  - Missing MFC goldens are reported as 'pending: golden missing' and not counted as parity.
duration: 
verification_result: passed
completed_at: 2026-10-05T07:29:34.936Z
blocker_discovered: false
---

# T10: Wired the BkRes Export/ExportStatsOnly/Batch, RefList (all 20 EReferenceType), ModSettings get/set, PackMod (native zip) and ImportFromGame (unt imported; spt and other kinds refused by name) groups through the resource bridge, Zig core and fake. The D-11 golden check reports pending for all 21 kinds because no MFC goldens exist yet.

**Wired the BkRes Export/ExportStatsOnly/Batch, RefList (all 20 EReferenceType), ModSettings get/set, PackMod (native zip) and ImportFromGame (unt imported; spt and other kinds refused by name) groups through the resource bridge, Zig core and fake. The D-11 golden check reports pending for all 21 kinds because no MFC goldens exist yet.**

## What Happened

Added a new NResourceModel exporter registry in Sources/src/ResourceModel/exporter.{h,cpp}. Each sub-editor slice registers its own exporter there. Until it does, BkResExport refuses that kind rather than writing partial game data. In resource_bridge.cpp, the RefList group enumerates every EReferenceType through the S03 references API. ModSettings carries the fields from MFC's MOD dialog (export dir, name, version, description). PackMod writes the archive with the native zip storage. ImportFromGame imports infantry (unt) through the engine's operator& and a line-for-line port of CAnimationFrame::GetRPGStats. Sprite (spt) import is refused: MFC only ever composes .san packs and has no reverse path. Other kinds are refused, naming the kind. resource_bridge.h gained the matching declarations. bridge.zig, fake_bridge.zig and root.zig gained the vtable entries, fake tables and undo-independent coverage tests. build.zig adds exporter.cpp to the build. The spec now records the import and export refusal policy and the MOD settings shape. The D-11 golden check runs the S03 comparator on exported data. No MFC goldens are tracked yet, so each of the 21 kinds prints `pending: golden missing` and none counts as parity done (GOLDEN_SUMMARY extensions=21 pass=0 pending=21).

## Verification

Ran all four plan verification tiers in the foreground on Linux x64; all exited 0. The test-resource-bridge log shows REF counts for all 20 reference types, e.g. E_FUNC_PARTICLES_REF=291 and E_ACTIONS_REF=0. It also shows GOLDEN_SUMMARY pending=21 and Project+Tree OK on 21 fixtures.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-core -Dtest-mode=run` | 0 | pass | 1000ms |
| 2 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 14000ms |
| 3 | `zig build test-resource-model -Dtest-mode=run` | 0 | pass | 21000ms |
| 4 | `zig build test-editor-bridge -Dtest-mode=run` | 0 | pass | 550000ms |

## Deviations

ImportFromGame for sprite is refused instead of implemented, because MFC itself has no sprite import path; the reason is recorded in the spec. Per-kind exporters are deferred to their sub-editor slices, so BkResExport refuses every kind that has not registered one.

## Known Issues

The D-11 export parity check is pending for all 21 kinds until goldens are exported on win-home (tools/zig/win-home/export-goldens.ps1). Only Linux x64 was verified; macOS and Windows still need CI.

## Files Created/Modified

- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge.h`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `Sources/src/ResourceModel/exporter.h`
- `Sources/src/ResourceModel/exporter.cpp`
- `Sources/editor/resource_core/bridge.zig`
- `Sources/editor/resource_core/fake_bridge.zig`
- `Sources/editor/resource_core/root.zig`
- `build.zig`
- `docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md`
