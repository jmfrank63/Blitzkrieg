---
id: T05
parent: S04
milestone: M001
key_files:
  - Sources/src/EditorBridge/resource_bridge.h
  - Sources/src/EditorBridge/resource_bridge.cpp
  - Sources/src/EditorBridge/resource_bridge_test.cpp
  - Sources/editor/resource_core/root.zig
  - Sources/editor/resource_core/fake_bridge.zig
  - Sources/editor/resource_core/bridge.zig
key_decisions:
  - Kept the T03 unified geometry design on both sides: one ResourceCommand.geometry variant on the Zig side, one geometryRead/geometryWrite pair on the ResBridge vtable, parameterised by channel. The C ABI stays per-channel (BkResGetPassabilityCells etc.) because that is what MFC-era callers expect; the Zig-side vtable adapter will route them in S05+.
  - Persist cells inside the resource project itself as `_bk_geometry` FutureBlob child elements under the owning node, rather than a separate sidecar. Keeps a saved .bld self-contained (one file to copy, one file to version). ExtractGeometryFromTree + RebuildIds strips them on open so Nodes() never surfaces a magic child.
  - Save re-injects the geometry children with a RAII scope guard that removes them again whether Save succeeded or failed, so the in-memory tree stays byte-identical to what the caller sees across the call. This also keeps BkResSave idempotent against repeated calls with no mutation in between.
  - GeometryBlob carries both bytes_grid (bytes/w/h) and points (float pairs) in one struct even though T05 only exercises one family per channel; the three remaining families (aimed, vec3, point2) will slot in as separate fields on the same blob in T06-T08 without a schema migration of the existing `_bk_geometry` children.
duration: 
verification_result: passed
completed_at: 2026-10-05T02:29:33.618Z
blocker_discovered: false
---

# T05: Wired the geometry cells family (passability, locked tiles, transparency lines) through the resource bridge ABI, the Zig resource core, and its fake, with undo/redo and save→reopen round-trips green on bld.

**Wired the geometry cells family (passability, locked tiles, transparency lines) through the resource bridge ABI, the Zig resource core, and its fake, with undo/redo and save→reopen round-trips green on bld.**

## What Happened

T05 landed the first geometry family end-to-end against the T03 unified GeometryChannel/GeometryValue shape. The C ABI gained six new entry points — BkRes[Get|Set]PassabilityCells, BkRes[Get|Set]LockedTiles, BkRes[Get|Set]TransparencyLines — all built on two shared helpers (GetBytesGrid/SetBytesGrid for the bytes_grid family, inline impl for the points family). Each entry wraps in the shared Guarded template, uses BkEditorLastMessage for status detail, and refuses with no mutation on bad input (unknown node, no project open, negative dimensions, null buffer for non-empty payload). Per-session state hangs off BkEditorSession via the module-private std::map established in T02; cells live in a std::map<std::pair<node_id,channel>, GeometryBlob>. BkResOpen pulls `_bk_geometry` FutureBlob children out of the tree into state.geometry (ExtractGeometryFromTree + RebuildIds so stripped node ids don't leak), and BkResSave re-injects them transiently via a scope guard so the in-memory tree stays untouched across the save. The hex encoder for bytes_grid and the semicolon-separated float list for points keep the sidecar XML human-readable but byte-round-trip stable.

The Zig side was already shaped for this by T03: ResBridge keeps the single geometryRead/geometryWrite pair parameterised by GeometryChannel; FakeResBridge keeps a unified per-(node,channel) map; ResourceCommand retains the single `.geometry { channel, before, after }` variant. T05 added three new tests to root.zig — one per cells channel — each covering set → undo → read → identity to pre-set, then redo → identity to post-set, plus a dirty-flag assertion on the passability path. The fake's emptyFor() helper now returns the correct empty payload shape for each channel so a read of an un-set channel does not crash.

The bridge-side T05 tier opens tools/zig/fixtures/resource_editor/bld/project.bld, writes a 3×2 passability grid, a 2×2 locked grid, and a 3-point transparency list on the root node, reads them back for identity, saves to project.cells.bld, closes, reopens the saved file, and re-reads each channel to prove the values persist byte-identically through NResourceModel::Load/Save.

No scope changes versus the plan. The baseline byte-identical round-trip of the 21 fixtures still holds because the geometry map is empty on open-only paths — _bk_geometry children are injected only when state.geometry is non-empty.

## Verification

All four verification steps in the plan pass on this Linux x64 host.

- `zig build test-resource-core -Dtest-mode=run` — passes (headless Zig unit tests; the three new geometry-cells tests round-trip set/undo/redo for passability_cells, locked_tiles, transparency_lines, and the composite + dirty-flag tests still hold).
- `zig build test-resource-bridge -Dtest-mode=run` — "resource-bridge: Project+Tree OK (21 fixtures)", exit 0. The T05 tier wrote and read back passability (3×2), locked tiles (2×2) and transparency lines (3 points) against the bld fixture, saved to project.cells.bld, reopened, and verified byte-identical persistence through NResourceModel::Load/Save.
- `zig build test-editor-core -Dtest-mode=run` — passes, no regression in the map editor core.
- `zig build test-editor-bridge -Dtest-mode=run` — "editor-bridge: PASS", every map-editor tier (bridges, fences, trenches, start commands, reserve positions, ai general, side shrink) still green.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-core -Dtest-mode=run` | 0 | pass | 60000ms |
| 2 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass | 300000ms |
| 3 | `zig build test-editor-core -Dtest-mode=run` | 0 | pass | 60000ms |
| 4 | `zig build test-editor-bridge -Dtest-mode=run` | 0 | pass | 420000ms |

## Deviations

None.

## Known Issues

None.

## Files Created/Modified

- `Sources/src/EditorBridge/resource_bridge.h`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `Sources/editor/resource_core/root.zig`
- `Sources/editor/resource_core/fake_bridge.zig`
- `Sources/editor/resource_core/bridge.zig`
