# S04: S04

**Goal:** Stand up the resource bridge ABI (`Sources/src/EditorBridge/resource_bridge.h` + impl) and the Zig headless `resource_core` (document, command union, undo/redo, fake bridge) that S05+ build on. After S04: `test-resource-core` green on all six targets, `test-resource-bridge` green on the five engine targets (data-only sub-steps everywhere; preview sub-step gated by GPU and skipped on headless CI with "no GPU device"), every `ResourceCommand` variant has an undo/redo round-trip in `test-resource-core`, and `BkResPreviewBegin`/`BkResPreviewShow` produce a captured TGA for one mesh unit, one sprite object and one particle source within the S01-measured tolerance (and >=1% non-black-non-magenta share on an engine-capable host). The S03 ResourceModel API (`CProject`, `CTreeItem`, `CTreeItemFactory`, references, comparator) stays untouched; the shared lifecycle entry points (`BkEditorStart`, `BkEditorStop`, `BkEditorSetOverlay`, `BkEditorCaptureFrame`, `BkEditorPaths`, `BkEditorSetMod`) are reused from `bridge.cpp` without re-implementation, and every map-editor tier (`test-editor-core`, `test-map-editor-*`, `test-editor-bridge`, `map-editor-*`) stays green.
**Demo:** `test-resource-bridge` and `test-resource-core` are green on all six targets (core on all six, bridge on the five engine targets). Headless core round-trips every command through undo/redo. `BkResPreview*` builds a preview frame using the S01-measured scene shape; the captured frame reproduces the S01 spike within tolerance.

## Must-Haves

- 1) `Sources/src/EditorBridge/resource_bridge.h` + `resource_bridge.cpp` exist; all `BkRes*` entry points wrap bodies in the shared `Guarded(...)` adapter and return `BkEditorStatus`; opaque `BkResSession *` is distinct from `BkEditorSession *` or is the same handle (document the choice in the header and keep it consistent). 2) `Sources/editor/resource_core/` builds as a pure Zig module importing `editor_kit`; its `root.zig` re-exports `bridge`, `history`, `document`, `fake_bridge`. 3) `test-resource-core` is wired as a `test_mode==.run` build step and runs on all six targets (incl. `x86_64-windows-gnu`), covering: every `ResourceCommand` variant round-trips undo→redo→undo through `FakeResBridge` with identity in document bytes; the dirty flag and save mark behave like map's `History`; a composite gesture collapses into one undo step. 4) `test-resource-bridge` is wired as a C++ host executable in `Sources/src/EditorBridge/` (parallel to `editor_bridge_test.cpp`) that links `ResourceModel` + the resource bridge; sub-steps for Project+Tree, Geometry, Export+MOD+Refs+Import, and Preview; each sub-step runs on the five engine targets; the Preview sub-step logs "skipped: no GPU device" and exits 0 when no device. 5) Every one of the 21 fixture projects under `tools/zig/fixtures/resource_editor/<ext>/` opens through `BkResOpen`, serialises through `BkResSave` with byte-identity (safe-save: temp + read-back + compare + rename). 6) `BkResDeleteNode` returns a serialised XML blob that `BkResRestoreNode` round-trips at the same parent + index; the subtree bytes are byte-identical through `NResourceXml`. 7) `BkResPreviewBegin(kind) + BkResPreviewShow(project) + BkEditorCaptureFrame` writes a TGA whose non-black-non-magenta share is >= 1% for one mesh unit, one sprite object and one particle source fixture; captures are committed under `tools/zig/fixtures/resource_editor/preview-scene/` and overwrite the S01 stand-in captures. 8) `test-resource-model` + `test-editor-core` + every map-editor tier remain green on this Linux machine. 9) `tools/zig/run-s04-sweep.sh` exists (mirrors `run-s02-sweep.sh`/`run-s03-sweep.sh` PREEXISTING-signature classification) and prints `S04 VERDICT=PASS` with every tier logged.

## Proof Level

- This slice proves: Contract — the slice adds a public ABI (resource bridge) and a public Zig surface (resource_core); every entry point must have at least one call-site test, every command union variant must round-trip undo→redo. Preview is proven by a captured TGA measured in-code, not eyeballed (06-PARITY graphics-claims rule).

## Integration Closure

The slice closes the S03→S05 seam: S05 (ResourceEditor app shell) imports `resource_core` and loads `resource_bridge.h` via `@cImport`; the fake bridge lets S05 build the app shell + its tests before the real adapter is wired on every host. Boundary verified by: (a) `test-resource-core` passing with `FakeResBridge` only, (b) `test-resource-bridge` passing with the real adapter on engine targets, (c) map-editor tiers staying green (shared `addEditorBridge` not regressed). Downstream S06..S15 consume the geometry get/set pairs declared here as the atomic undo units for every sub-editor tool.

## Verification

- Resource bridge reuses `BkEditorLastMessage` for status detail (owned by session, valid until next call) — no new log channel. Debug tracing routes through existing `DebugTrace` (needs `BK_DEBUG_LOG=1` in release). Captured preview TGAs under `zig-out/local-test/resource_editor/` serve as the agent-visible evidence; the sweep log at `zig-out/local-test/resource_editor/s04-sweep.log` is the agent-friendly summary (one PASS/FAIL per tier, final `S04 VERDICT=`). Failure modes: a GPU-less host logs "skipped: no GPU device" and exits 0 for the preview tier (same pattern as `test-editor-bridge`'s GPU gate).

## Tasks

- [x] **T01: Scaffolded resource bridge C ABI (resource_bridge.h/.cpp with every BkRes* entry point stubbed via shared Guarded), extracted BkEditorSession and Guarded into shared headers so bridge.cpp and resource_bridge.cpp both link one archive, and registered test-resource-bridge smoke tier (green on Linux x64).** `est:4-6h`
  Why: every later task needs a header to add entry points to and a build step to run them from. The map bridge's shape (opaque handle, status enum, `Guarded(...)` wrapper, `BkEditorLastMessage` ownership rule, two-pass variable-length output, fixed-size char buffers) is the pattern to copy verbatim — do not invent an alternative.
  - Files: `Sources/src/EditorBridge/resource_bridge.h`, `Sources/src/EditorBridge/resource_bridge.cpp`, `Sources/src/EditorBridge/resource_bridge_test.cpp`, `Sources/src/EditorBridge/guarded.h`, `build.zig`
  - Verify: zig build test-resource-bridge -Dtest-mode=run && zig build test-editor-bridge -Dtest-mode=run && zig build test-editor-core -Dtest-mode=run && zig build test-resource-model -Dtest-mode=run

- [x] **T02: Wired BkRes Project+Tree group (New/Open/Save/Close/KindOf/Lock/Nodes/Props/SetProp/Insert/Move/Delete/Restore) over NResourceModel::Load/Save, and extended test-resource-bridge to round-trip all 21 fixtures byte-identical + delete→restore on wpn/msh/pcp.** `est:6-8h`
  Why: every downstream sub-editor edits the project tree through these calls. The delete→restore round-trip is the serialisation shape every undo step depends on, so it must be byte-identical before any geometry edit is wired on top.
  - Files: `Sources/src/EditorBridge/resource_bridge.cpp`, `Sources/src/EditorBridge/resource_bridge.h`, `Sources/src/EditorBridge/resource_bridge_test.cpp`
  - Verify: zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model -Dtest-mode=run && zig build test-editor-bridge -Dtest-mode=run

- [x] **T03: Added Sources/editor/resource_core (bridge.zig + document.zig + ResourceCommand + history alias + fake_bridge.zig) and the test-resource-core tier that round-trips every command variant through undo/redo on the host.** `est:6-8h`
  Why: this is the headless core S05 app shell will depend on. It must build on all six targets (incl. `x86_64-windows-gnu`, where the engine C++ does not build) because the Zig app imports it before the C bridge is cImported. Copy the exact `pub const Bridge = struct { ptr, vtable }` shape from `Sources/editor/core/bridge.zig`; alias `History = editor_kit.history.History(ResourceCommand)` (do not rewrite the stack primitive).
  - Files: `Sources/editor/resource_core/root.zig`, `Sources/editor/resource_core/bridge.zig`, `Sources/editor/resource_core/document.zig`, `Sources/editor/resource_core/history.zig`, `Sources/editor/resource_core/fake_bridge.zig`, `build.zig`
  - Verify: zig build test-resource-core -Dtest-mode=run && zig build test-editor-core -Dtest-mode=run

- [x] **T04: Blocker: T04 scope (13 geometry kinds × ~15 sub-steps across 7 files) exceeds a single auto-mode iteration — escalating for split before implementation.** `est:8-10h`
  Why: these get/set pairs ARE the atomic undo units for every downstream sub-editor tool (S06..S14). Each pair must round-trip through the core's `ResourceCommand.geometry` variants and `FakeResBridge` so S06+ can test tool behaviour against the fake before the real engine is in the loop.
  - Files: `Sources/src/EditorBridge/resource_bridge.h`, `Sources/src/EditorBridge/resource_bridge.cpp`, `Sources/src/EditorBridge/resource_bridge_test.cpp`, `Sources/editor/resource_core/bridge.zig`, `Sources/editor/resource_core/history.zig`, `Sources/editor/resource_core/fake_bridge.zig`, `Sources/editor/resource_core/document.zig`
  - Verify: zig build test-resource-core -Dtest-mode=run && zig build test-resource-bridge -Dtest-mode=run && zig build test-editor-core -Dtest-mode=run && zig build test-editor-bridge -Dtest-mode=run

- [x] **T05: Wired the geometry cells family (passability, locked tiles, transparency lines) through the resource bridge ABI, the Zig resource core, and its fake, with undo/redo and save→reopen round-trips green on bld.** `est:4-6h`
  Wire the first geometry family end-to-end against the T03 unified GeometryChannel/GeometryValue shape so the remaining families (T06-T08) have a working template to copy.
  - Files: `Sources/src/EditorBridge/resource_bridge.h`, `Sources/src/EditorBridge/resource_bridge.cpp`, `Sources/src/EditorBridge/resource_bridge_test.cpp`, `Sources/editor/resource_core/bridge.zig`, `Sources/editor/resource_core/fake_bridge.zig`, `Sources/editor/resource_core/history_test.zig`
  - Verify: zig build test-resource-core -Dtest-mode=run && zig build test-resource-bridge -Dtest-mode=run && zig build test-editor-core -Dtest-mode=run && zig build test-editor-bridge -Dtest-mode=run

- [x] **T06: Wired six geometry point and aimed-point channels through the resource bridge ABI, Zig core and fake with undo/redo and save-reopen parity on bld and scp.** `est:5-7h`
  Second geometry family. Wire the two payload shapes `point2` (single Point2: zero point, entrance) and `aimed` (list of AimedPoint with angle + cone: shoot/fire/smoke/directed-explosion) through the unified GeometryChannel pattern established by T05.
  - Files: `Sources/src/EditorBridge/resource_bridge.h`, `Sources/src/EditorBridge/resource_bridge.cpp`, `Sources/src/EditorBridge/resource_bridge_test.cpp`, `Sources/editor/resource_core/bridge.zig`, `Sources/editor/resource_core/fake_bridge.zig`, `Sources/editor/resource_core/history_test.zig`
  - Verify: zig build test-resource-core -Dtest-mode=run && zig build test-resource-bridge -Dtest-mode=run && zig build test-editor-core -Dtest-mode=run && zig build test-editor-bridge -Dtest-mode=run

- [x] **T07: Bridge review fixes: MFC locked_<user> lock, geometry saved for every node, delete->restore restores geometry** `est:4-6h`
  Tests first in `resource_bridge_test.cpp`. (1) Lock: replace `state.szPath + ".lock"` (resource_bridge.cpp ~994/1040) with MFC's scheme from `Sources/src/editor/ParentFrame.cpp:1550-1595`: a `locked_<user>` file in the project's directory, enumerate `locked_*` to detect another user's lock, warn + read-only/take-over semantics per D-08; keep the atomic exclusive create from 0b37480f9; release on close. Test: two sessions with different user names, foreign lock detected, take-over, release removes the file, no stray `<path>.lock`. Use XDG_DATA_HOME/BK_* seams and zig-out/local-test copies only. (2) Geometry: persist geometry for every node that carries it (not only the root) in MFC's element layout from the S03 items; test set geometry on a non-root node -> save -> reopen -> equal. (3) `BkResDeleteNode` snapshot includes the subtree's geometry; `BkResRestoreNode` restores it; test delete->restore->save byte-identical to before the delete for a node with geometry.
  - Files: `Sources/src/EditorBridge/resource_bridge.cpp`, `Sources/src/EditorBridge/resource_bridge.h`, `Sources/src/EditorBridge/resource_bridge_test.cpp`, `Sources/editor/resource_core/fake_bridge.zig`
  - Verify: zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-core -Dtest-mode=run && zig build test-resource-model -Dtest-mode=run && zig build test-editor-bridge -Dtest-mode=run

- [x] **T08: Geometry formation + bridge span marks families (points2 payload) against scp/bdg** `est:4-6h`
  Unchanged scope from the former T07: add `BkRes[Get|Set]FormationPositions` and `BkRes[Get|Set]BridgeSpanMarks` (two-pass flat Point2 list) against the faithful S03 squad and bridge items, MFC coordinate conventions documented in the header; wire channels in bridge.zig + fake_bridge.zig; per-channel undo/redo in test-resource-core; set->save->reopen->read parity on scp/bdg fixtures, including on non-root nodes.
  - Files: `Sources/src/EditorBridge/resource_bridge.h`, `Sources/src/EditorBridge/resource_bridge.cpp`, `Sources/src/EditorBridge/resource_bridge_test.cpp`, `Sources/editor/resource_core/bridge.zig`, `Sources/editor/resource_core/fake_bridge.zig`, `Sources/editor/resource_core/history_test.zig`
  - Verify: zig build test-resource-core -Dtest-mode=run && zig build test-resource-bridge -Dtest-mode=run && zig build test-editor-core -Dtest-mode=run && zig build test-editor-bridge -Dtest-mode=run

- [x] **T09: Geometry mission objectives + chapter/campaign crosses + particle/effect keyframes families against mip/cgc/pcp** `est:6-8h`
  Unchanged scope from the former T08: five BkRes[Get|Set] pairs (MissionObjectives, ChapterCrosses, CampaignCrosses, ParticleKeyframes, EffectKeyframes) against the faithful S03 items; extend GeometryValue additively if crosses carry more than a Point2; per-channel undo/redo; set->save->reopen parity on mip/chc/cgc/pcp/eff with byte identity through NResourceModel Load/Save.
  - Files: `Sources/src/EditorBridge/resource_bridge.h`, `Sources/src/EditorBridge/resource_bridge.cpp`, `Sources/src/EditorBridge/resource_bridge_test.cpp`, `Sources/editor/resource_core/bridge.zig`, `Sources/editor/resource_core/fake_bridge.zig`, `Sources/editor/resource_core/history_test.zig`
  - Verify: zig build test-resource-core -Dtest-mode=run && zig build test-resource-bridge -Dtest-mode=run && zig build test-editor-core -Dtest-mode=run && zig build test-editor-bridge -Dtest-mode=run && zig build test-resource-model -Dtest-mode=run

- [x] **T10: Export, MOD, References, Import groups + fake-side coverage** `est:6-8h`
  Scope from the former T09 (BkResExport/ExportStatsOnly/Batch, RefList for all 20 EReferenceType, ModSettings get/set, PackMod via native zip, ImportFromGame for sprite/infantry with honest REFUSED stubs elsewhere, fake bridge tables). Change: export results are checked with the S03 D-11 comparator over exported data (engine readers, exact floats); where no MFC golden exists the test reports `pending: golden missing` and is not counted as parity done.
  - Files: `Sources/src/EditorBridge/resource_bridge.h`, `Sources/src/EditorBridge/resource_bridge.cpp`, `Sources/src/EditorBridge/resource_bridge_test.cpp`, `Sources/editor/resource_core/bridge.zig`, `Sources/editor/resource_core/fake_bridge.zig`
  - Verify: zig build test-resource-core -Dtest-mode=run && zig build test-resource-bridge -Dtest-mode=run && zig build test-resource-model -Dtest-mode=run && zig build test-editor-bridge -Dtest-mode=run

- [x] **T11: Preview group, captured-frame assertion, CI wiring, single resource sweep** `est:8-10h`
  Scope from the former T10 (BkResPreviewBegin/Show/Stop/Playback/Camera; capture unt/spt/eff TGAs with hard non_black_non_magenta_share >= 0.01, GPU-less skip; commit captures + update preview-scene.md; CI entries for test-resource-bridge on five engine targets and test-resource-core on all six). Change: no run-s04-sweep.sh; extend and run the single `tools/zig/run-resource-sweep.sh` from S03 T08 (no pre-existing classification). Summary cites only this task's sweep run.
  - Files: `Sources/src/EditorBridge/resource_bridge.h`, `Sources/src/EditorBridge/resource_bridge.cpp`, `Sources/src/EditorBridge/resource_bridge_test.cpp`, `tools/zig/preview_scene_spike.cpp`, `tools/zig/fixtures/resource_editor/preview-scene/preview-scene.md`, `.github/workflows/cross-platform.yml`, `tools/zig/run-resource-sweep.sh`
  - Verify: bash tools/zig/run-resource-sweep.sh && grep -q 'VERDICT=PASS' zig-out/local-test/resource_editor/resource-sweep.log

## Files Likely Touched

- Sources/src/EditorBridge/resource_bridge.h
- Sources/src/EditorBridge/resource_bridge.cpp
- Sources/src/EditorBridge/resource_bridge_test.cpp
- Sources/src/EditorBridge/guarded.h
- build.zig
- Sources/editor/resource_core/root.zig
- Sources/editor/resource_core/bridge.zig
- Sources/editor/resource_core/document.zig
- Sources/editor/resource_core/history.zig
- Sources/editor/resource_core/fake_bridge.zig
- Sources/editor/resource_core/history_test.zig
- tools/zig/preview_scene_spike.cpp
- tools/zig/fixtures/resource_editor/preview-scene/preview-scene.md
- .github/workflows/cross-platform.yml
- tools/zig/run-resource-sweep.sh
