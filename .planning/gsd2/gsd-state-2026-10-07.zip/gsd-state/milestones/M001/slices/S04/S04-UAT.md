# S04: S04 — UAT

**Milestone:** M001
**Written:** 2026-10-05T08:35:56.416Z

# S04 UAT

**UAT Type:** artifact-driven, automated tiers on Linux x64.

## Preconditions
- Linux x64 machine with Zig 0.16 and a GPU-capable session.
- Branch feat/resource-editor at or after commit b8d55b423.

## Steps
1. Run `zig build test-resource-core -Dtest-mode=run`. Expected: exit 0, and every command variant round-trips through undo and redo.
2. Run `zig build test-resource-bridge -Dtest-mode=run`. Expected: exit 0. All 21 fixtures save byte-identically, delete then restore is identical, and the preview sub-step reports mesh, sprite and particle shares of at least 0.01.
3. Run `tools/zig/run-resource-sweep.sh`. This takes about 27 minutes, so the maintainer runs it. Expected: 18 tiers PASS and `VERDICT=PASS`.
4. Open the TGAs in tools/zig/fixtures/resource_editor/preview-scene/. Expected: a visible mesh, sprite and particle scene.

## Edge cases
- On a host with no GPU, the preview sub-step logs "skipped: no GPU device" and exits 0.
- The particle capture varies between runs because the effect animates. Only the 1% threshold is asserted.

## Not Proven By This UAT
- macOS and Windows results. The CI entries are added but have not run.
- Any app UI. That belongs to S05.
