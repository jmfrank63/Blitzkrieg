---
estimated_steps: 7
estimated_files: 5
skills_used: []
---

# T01: Scaffolded resource bridge C ABI (resource_bridge.h/.cpp with every BkRes* entry point stubbed via shared Guarded), extracted BkEditorSession and Guarded into shared headers so bridge.cpp and resource_bridge.cpp both link one archive, and registered test-resource-bridge smoke tier (green on Linux x64).

Why: every later task needs a header to add entry points to and a build step to run them from. The map bridge's shape (opaque handle, status enum, `Guarded(...)` wrapper, `BkEditorLastMessage` ownership rule, two-pass variable-length output, fixed-size char buffers) is the pattern to copy verbatim — do not invent an alternative.

Do:
1. Write `Sources/src/EditorBridge/resource_bridge.h` (CRLF): `extern "C"` block, opaque `BkResSession` (or document that it aliases `BkEditorSession *`; the research notes the shared lifecycle entry points are reused unchanged — pick ONE and say so in the header's leading comment), group-section comments for Projects / Tree / References / Geometry / Export / MOD / Preview / Import, forward declarations for every entry point the research names (BkResNew, BkResOpen, BkResSave, BkResClose, BkResKind, BkResLock, BkResLockOwner, BkResNodes, BkResProps, BkResSetProp, BkResInsertNode, BkResDeleteNode, BkResRestoreNode, BkResMoveNode, BkResRefList, BkResExport, BkResExportStatsOnly, BkResBatch, BkResModSettingsGet, BkResModSettingsSet, BkResPackMod, BkResImportFromGame, BkResPreviewBegin, BkResPreviewShow, BkResPreviewStop, BkResPreviewPlayback, BkResPreviewCamera, plus the geometry get/set pairs listed in the research). Each declaration gets a short doc comment explaining the status codes it returns.
2. Write `Sources/src/EditorBridge/resource_bridge.cpp` (CRLF) with every entry point stubbed as `return Guarded(session, [&]{ return BK_EDITOR_OK; });` — enough to compile and link against the existing session. Reuse `Guarded`, `BkEditorLastMessage`, and the session-message buffer by extracting them into a shared header (`Sources/src/EditorBridge/guarded.h`) if they are not already — do not duplicate.
3. Wire a new `addResourceBridge` function in `build.zig` modelled on `addEditorBridge` (around line 5927). It must: compile `resource_bridge.cpp` into the `editor_bridge` static library (one archive — `resource_bridge.cpp` lives beside `bridge.cpp` and shares its include paths), and register a `b.step("test-resource-bridge", ...)` that gates `test_mode==.run` and lists five engine targets (match the `test-resource-model` target list in `addResourceModelAggregateStep`). Call it from the top-level `build()` beside `addResourceModelAggregateStep`.
4. Write `Sources/src/EditorBridge/resource_bridge_test.cpp` (CRLF) as the smoke host: calls `BkEditorStart` with the hidden-window pattern (SDL_WINDOW_HIDDEN | SDL_WINDOW_NOT_FOCUSABLE), then `BkResNew(kind=wpn)`, `BkResClose`, `BkEditorStop`. On no-GPU: logs "skipped: no GPU device" and exits 0 (copy the exact gate from `editor_bridge_test.cpp`). Linux pitfalls to reuse: `rdynamic` + `$ORIGIN` rpath on the executable, 16 MiB worker-thread stack, stop `ISFX` before module unload.

Done-when: `zig build test-resource-bridge` is green on this Linux machine (smoke only); `zig build test-editor-bridge` + `test-editor-core` + `test-resource-model` all still green (shared lifecycle not regressed).

## Inputs

- `Sources/src/EditorBridge/bridge.h`
- `Sources/src/EditorBridge/bridge.cpp`
- `Sources/src/EditorBridge/session.h`
- `Sources/src/EditorBridge/session.cpp`
- `tools/zig/editor_bridge_test.cpp`
- `Sources/src/ResourceModel/project.h`
- `Sources/src/ResourceModel/factory.h`
- `.gsd/milestones/M001/slices/S04/S04-RESEARCH.md`

## Expected Output

- `Sources/src/EditorBridge/resource_bridge.h`
- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `Sources/src/EditorBridge/guarded.h`
- `build.zig`

## Verification

zig build test-resource-bridge -Dtest-mode=run && zig build test-editor-bridge -Dtest-mode=run && zig build test-editor-core -Dtest-mode=run && zig build test-resource-model -Dtest-mode=run

## Observability Impact

test-resource-bridge host prints a one-line per-call status trail to stderr; captured in zig-out/local-test/resource_editor/.
