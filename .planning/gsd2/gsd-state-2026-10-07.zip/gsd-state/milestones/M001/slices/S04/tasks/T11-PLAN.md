---
estimated_steps: 1
estimated_files: 7
skills_used: []
---

# T11: Preview group, captured-frame assertion, CI wiring, single resource sweep

Scope from the former T10 (BkResPreviewBegin/Show/Stop/Playback/Camera; capture unt/spt/eff TGAs with hard non_black_non_magenta_share >= 0.01, GPU-less skip; commit captures + update preview-scene.md; CI entries for test-resource-bridge on five engine targets and test-resource-core on all six). Change: no run-s04-sweep.sh; extend and run the single `tools/zig/run-resource-sweep.sh` from S03 T08 (no pre-existing classification). Summary cites only this task's sweep run.

## Inputs

- `Sources/src/EditorBridge/bridge.cpp`
- `tools/zig/preview_scene_spike.cpp`
- `tools/zig/run-resource-sweep.sh`
- `.github/workflows/cross-platform.yml`

## Expected Output

- `tools/zig/fixtures/resource_editor/preview-scene/mesh.tga`
- `tools/zig/fixtures/resource_editor/preview-scene/sprite.tga`
- `tools/zig/fixtures/resource_editor/preview-scene/particle.tga`
- `zig-out/local-test/resource_editor/resource-sweep.log`

## Verification

bash tools/zig/run-resource-sweep.sh && grep -q 'VERDICT=PASS' zig-out/local-test/resource_editor/resource-sweep.log

## Override 2026-10-05T08:34

The maintainer ran the full sweep after the T11 changes (committed b8d55b423): log ~/gsd-logs/sweep-S04-T11.log, identical to zig-out/local-test/resource_editor/resource-sweep.log; 18 tiers PASS, VERDICT=PASS. Per D010 the agent does not rerun it; verification is reading that log and measuring the committed captures.
