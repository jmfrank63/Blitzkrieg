---
id: S04
parent: M001
milestone: M001
provides:
  - BkRes* C ABI
  - resource_core Zig module with FakeResBridge
  - BkResPreview* with captured frames
  - run-resource-sweep.sh
requires:
  []
affects:
  []
key_files:
  - Sources/src/EditorBridge/resource_bridge.h
  - Sources/src/EditorBridge/resource_bridge.cpp
  - Sources/src/EditorBridge/resource_bridge_test.cpp
  - Sources/editor/resource_core/
  - tools/zig/run-resource-sweep.sh
  - tools/zig/fixtures/resource_editor/preview-scene/
key_decisions: []
patterns_established:
  - (none)
observability_surfaces:
  - none
drill_down_paths:
  []
duration: ""
verification_result: passed
completed_at: 2026-10-05T08:35:56.415Z
blocker_discovered: false
---

# S04: S04

**Resource bridge C ABI (BkRes*) plus the headless Zig resource_core with undo/redo and a fake bridge, with a measured preview frame per kind; test-resource-core and test-resource-bridge are green on Linux x64.**

## What Happened

S04 added Sources/src/EditorBridge/resource_bridge.{h,cpp}. The BkRes* entry points cover Project and Tree (new, open, save, close, lock, nodes, props, insert, move, delete, restore), Geometry get/set, Export, MOD, References, Import and Preview. They share the map bridge's Guarded adapter and session header. Sources/editor/resource_core/ is a pure Zig module (bridge, history, document, fake_bridge) in which every ResourceCommand variant round-trips through undo and redo against FakeResBridge. All 21 fixture projects open and save byte-identically through the bridge, and delete then restore of a subtree is byte-identical. T11 added the BkResPreview* group. It captures a mesh, a sprite and a particle frame, requires a non-black-non-magenta share of at least 1%, and skips when there is no GPU. The captured TGAs are committed under tools/zig/fixtures/resource_editor/preview-scene/. The resource tiers were added to cross-platform.yml, and tools/zig/run-resource-sweep.sh stays the single sweep script. The maintainer ran the full sweep on this Linux machine after the T11 changes (D010): 18 of 18 tiers PASS and VERDICT=PASS. That covers test-resource-model, -core and -bridge and every map-editor tier, so the kit extraction and shared bridge have not regressed.

## Verification

Re-checked in this closeout: zig-out/local-test/resource_editor/resource-sweep.log has 18 RESULT=PASS lines and ends with VERDICT=PASS. Preview shares in that log are mesh 0.2649, sprite 0.3072 and particle 0.2870, each with show_status=0 and capture_status=0. The three preview TGAs are present in the repo. `zig build test-resource-core -Dtest-mode=run` exits 0, with the output cached. git status is clean. The full sweep was run by the maintainer, not by the agent. macOS and Windows results are not seen: those CI entries were added but have not run, because the branch is not pushed.

## Requirements Advanced

None.

## Requirements Validated

None.

## New Requirements Surfaced

None.

## Requirements Invalidated or Re-scoped

None.

## Operational Readiness

None.

## Deviations

None.

## Known Limitations

Only Linux x64 was verified. The macOS and Windows CI tiers run once the branch is pushed.

## Follow-ups

None.

## Files Created/Modified

None.
