# S04 Research: resource_bridge.h + BkRes ABI + Zig resource_core (commands + undo) + fake bridge

**Gathered:** 2026-10-05
**Depth:** Targeted — all patterns established locally; no novel technology.

---

## Summary

S04 is a well-patterned slice. Every construct it needs has a direct analogue already working for the Map Editor (`bridge.h`, `core/bridge.zig`, `core/fake_bridge.zig`, `kit/history.zig`). The risk is scope breadth (the BkRes ABI covers ~8 groups) and the Preview path (`BkResPreviewBegin` / `BkResPreviewShow`), which requires the engine's data-only startup and `IVisObjBuilder`, mirroring work done in S01. There is zero boilerplate to recover — every file must be written from scratch, following the map bridge pattern exactly.

---

## What Exists

### `Sources/src/EditorBridge/` (existing — map bridge only)

No `resource_bridge.h` or `BkRes*` file exists. S04 creates both from scratch.

Files already present: `bridge.h`, `bridge.cpp`, `catalogue.cpp`, `filters.cpp`, `session.cpp`, `session_fields.cpp`, `session_groups.cpp`, `session.h`, `session_layers.cpp`, `session_records.cpp`, `session_rmg.cpp`, `session_terrain.cpp`, `session_vso.cpp`, `world.cpp`, `world.h`.

### Map Bridge ABI Pattern (`bridge.h`)

The header is a pure C ABI (`extern "C"`) with:
- One status enum: `BkEditorStatus` (values `BK_EDITOR_OK` … `BK_EDITOR_FAILED`)
- One opaque session handle: `typedef struct BkEditorSession BkEditorSession;`
- Entry points named `BkEditor<Verb><Noun>`, all returning `BkEditorStatus`
- Plain C structs with fixed-size char arrays (64-byte names, 128-byte paths, 1024-byte roots); **never pointers into heap-allocated strings**
- Two-pass pattern for variable-length output: `out_count` always written; too-small buffer returns `BK_EDITOR_REFUSED`
- `BkEditorLastMessage(session)` — never null, valid until next call on the same session
- `BkEditorSetOverlay(session, callback, user)` — the ImGui overlay wiring
- `BkEditorCaptureFrame` — used by the S01 spike and relevant to `BkResPreviewShow`

The spec confirms: resource bridge shares **the same lifecycle entry points** (`BkEditorStart`/`Stop`, `Mods`/`SetMod`, `Paths`, `SetOverlay`, `CaptureFrame`, `GpuDevice`, `Resize`) with the map bridge, and adds new groups under `BkRes*` prefix.

### Zig Map Core (`Sources/editor/core/`)

`root.zig` re-exports: `bridge`, `fake_bridge`, `document`, `history`, `editor`, `tools`, `tools_vso`, `tools_groups`, `tools_ai`, `tools_heights`, `tools_damage`, `tools_fields`, `filters`, `layers`, `settings`, `checks`, `rmg`, `composers`, `records`.

**`bridge.zig`** defines a Zig `Bridge` struct (vtable interface): one method per C entry point, all in pure Zig types so the module builds on every target including `x86_64-windows-gnu`. Layout: `pub const Bridge = struct { ptr: *anyopaque, vtable: *const VTable, ... }`. Each method delegates to `vtable.fn(ptr, ...)`. No C types ever cross this boundary.

**`history.zig`** (map core) defines `Command` (a tagged union: `.paint`, `.add`, `.place`, `.delete`, `.multi_delete`, `.diplomacy`, `.record_edit`, `.record_add`, `.record_delete`, `.edit`, `.composite`), then aliases `Entry = kit_history.Entry(Command)` and `History = kit_history.History(Command)`.

**`fake_bridge.zig`** implements `FakeBridge` — an in-memory implementation of the same `Bridge` vtable. Its extensive doc comment lists exactly how it differs from the real bridge (no file, no terrain function, no engine, any name accepted, edits accepted before map open, etc.). It is the test double that `test-editor-core` uses. Production uses `c_bridge.zig`, which `@cImport`s the real `bridge.h`.

### Kit (`Sources/editor/kit/history.zig`)

Generic `History(Command)` parameterised over any command type. Provides:
- `undo_stack` / `redo_stack` as `ArrayListUnmanaged`
- `clean_depth: ?usize` (save mark)
- `revision: u32` (UI rebuild signal)
- `record()` / `undo()` / `redo()` / `markClean()` / `dirty()` / `canUndo()` / `canRedo()`

The resource core instantiates its own `ResourceCommand` union and aliases `History = kit_history.History(ResourceCommand)`.

### ResourceModel Public Surface (S03 output)

Key types available to `resource_bridge.cpp`:
- `NResourceModel::CVariant` — 9-type variant (`EKind`: NULL/INT/FLOAT/BOOL/STR/VEC3/COLOR/COMBO/REF)
- `NResourceModel::SProp` — `{nId, szDefaultName, szDisplayName, nDomenType, value, szStrings}`, `CPropVector`
- `NResourceModel::CTreeItem` — base tree node with `nItemType`, `values`, `treeItemList` (unique_ptr children), `parse(node)` / `serialise(node)`, future-blob preservation
- `NResourceModel::CProject` — `{NResourceXml::Document, unique_ptr<Root>}`, `Load()` / `Save()`
- `NResourceModel::CTreeItemFactory` — `Create(int nType)` → `unique_ptr<CTreeItem>`, `Register()`
- `NResourceModel::EReferenceType` (20 types), `CLocalizationItem`, AI-class / player-sides combos

### Build Wiring (from `build.zig`)

- **`test-editor-core`** (line 2826): pure Zig module test, `root.zig` → imports `editor_kit`, runs on every target, no engine. Added to `test_step`.
- **`test-editor-bridge`** (line 5927): C++ executable `tools/zig/editor_bridge_test.cpp`, links `editor_bridge` static lib + full engine (MapFile, Main, RandomMapGen, Formats, Misc, PlatformRuntime, SDL). Staged beside game installation; needs Data. Has `has_side_effects = true`.
- **`addEditorBridge`** (line 3840): builds a static library from `Sources/src/EditorBridge/*.cpp` with all engine include paths. The kit module adds `Sources/src/EditorBridge` as an include path so `host.zig` can `@cImport("bridge.h")`.

The resource bridge follows the same wiring:
- `test-resource-core`: Zig module test, `Sources/editor/resource_core/root.zig`, imports `editor_kit`, no engine → runs on all 6 targets
- `test-resource-bridge`: C++ executable linking `ResourceModel` static lib + a new `resource_bridge.cpp` from `EditorBridge/`. Because ResourceModel is pure data/XML (no GPU), it does **not** need the full engine for the data-only round-trip tests; however preview tests require the engine.

---

## BkRes ABI Groups (from spec `2026-09-30-portable-resource-editor-design.md` §3)

The spec enumerates 8 groups for the `BkRes*` prefix, new beyond the shared lifecycle:

1. **Projects:** `BkResNew(kind)`, `BkResOpen(path)`, `BkResSave(path)` (safe-save: temp + read-back + compare + rename), `BkResClose`, `BkResKind`, `BkResLock` / `BkResLockOwner`
2. **Tree:** `BkResNodes(out, total)` — returns `{id, parent, class_type, display_name, expand, child_count}`; `BkResProps(node, out, total)` — returns `{id, names, domain_type, value_text/int/float, combo_strings}`; `BkResSetProp`, `BkResInsertNode(parent, class, index)`, `BkResDeleteNode` (returns serialised subtree for undo), `BkResRestoreNode(serialised, parent, index)`, `BkResMoveNode`
3. **References:** `BkResRefList(type, out, total)` for every `EReferenceType`
4. **Geometry edits:** per-kind get/set pairs for passability cells, locked/unlocked tiles, transparency, zero point, entrance, shoot/fire/smoke/directed-explosion points (angle + cone), one-way transparency lines, formation positions, bridge span marks, mission objectives, chapter/campaign crosses, particle/effect keyframes. Each get/set pair is the undo/redo atomic unit.
5. **Export:** `BkResExport(flags)`, `BkResExportStatsOnly`, `BkResBatch(kind|all, src, dst, flags)` — each returning `SExportReport {written, skipped, warnings[]}`
6. **MOD:** `BkResModSettings` get/set, `BkResPackMod`
7. **Preview:** `BkResPreviewBegin(kind)` (builds empty `IScene` with game camera, no terrain except road3d/river3d), `BkResPreviewShow(project)` (exports into preview temp storage, builds via `IVisObjBuilder`), `BkResPreviewStop`, `BkResPreviewPlayback(run/stop)`, `BkResPreviewCamera(…)`
8. **Import:** `BkResImportFromGame(path)` — builds a project from an existing runtime resource folder

---

## Natural Seams (Task Decomposition Hints)

**T01 — C header + scaffold + data-only build step**
Write `Sources/src/EditorBridge/resource_bridge.h`: opaque `BkResSession`, `BkResStatus`, shared lifecycle reuse declarations, stub group comments. Write `resource_bridge.cpp` with `Guarded`-wrapped stubs returning `BK_EDITOR_OK`. Wire `addResourceBridge` in `build.zig` (mirrors `addEditorBridge`). Write `test-resource-bridge` C++ host (mirrors `editor_bridge_test.cpp`) with a minimal smoke test that calls `BkEditorStart` / `BkResNew` / `BkResClose` / `BkEditorStop`. `test-resource-bridge` green (smoke only).

**T02 — Project group + Tree group (read path)**
Implement `BkResNew`, `BkResOpen`, `BkResSave`, `BkResClose`, `BkResKind`, `BkResLock`/`BkResLockOwner` against `NResourceModel::CProject`. Implement `BkResNodes` and `BkResProps` (tree read). Write `BkResDeleteNode` (returns serialised XML blob), `BkResRestoreNode`, `BkResInsertNode`, `BkResMoveNode`, `BkResSetProp`. Extend `test-resource-bridge` with round-trip tests for every one of the 21 fixture projects.

**T03 — Zig resource_core: bridge.zig + history.zig + document.zig + fake_bridge.zig**
Mirror `Sources/editor/core/bridge.zig`: define `ResBridge` vtable interface (one method per `BkRes*` entry). Define `ResourceCommand` union (`set_prop`, `insert_node`, `delete_node`, `move_node`, plus one variant per geometry edit kind). Alias `History = kit_history.History(ResourceCommand)`. Write `document.zig` (per-project mirror: tree, props, dirty flag, path, kind, lock). Write `fake_bridge.zig` (`FakeResBridge` in-memory, no engine). Wire `test-resource-core` Zig step (no engine, all 6 targets). Tests: undo/redo round-trips every `ResourceCommand` variant through `document` and `FakeResBridge`; dirty flag; save mark; composite gesture.

**T04 — Geometry get/set groups**
Implement all geometry `BkRes*` entry points in `resource_bridge.cpp`. Add corresponding `ResourceCommand` geometry variants in the core. Test every get/set/undo/redo pair via `FakeResBridge`.

**T05 — Export, MOD, References, Import**
Implement `BkResExport`, `BkResExportStatsOnly`, `BkResBatch`, `BkResRefList`, `BkResModSettings`, `BkResPackMod`, `BkResImportFromGame`. Extend `test-resource-bridge` with batch export tests and `RefList` round-trips.

**T06 — Preview (`BkResPreview*`), sweep + CI**
Implement `BkResPreviewBegin`, `BkResPreviewShow` (preview temp storage + `IVisObjBuilder`), `BkResPreviewStop`, `BkResPreviewPlayback`, `BkResPreviewCamera`. Captured frame test (mirrors S01 spike: one mesh, one sprite, one particle, within measured tolerance). Wire `test-resource-bridge` engine-path tests (engine-required gate). Add CI workflow entries. Author `run-s04-sweep.sh` (mirrors `run-s03-sweep.sh`). All 17+ tiers green.

---

## First Proof / Highest Risk

**Preview (`BkResPreviewBegin` / `BkResPreviewShow`) is the highest risk.** It requires:
- A data-only engine startup with `IVisObjBuilder` available
- A preview temp storage overlay (an editor temp folder mounted over the data storage)
- The export path exercised to prove the export → preview round-trip

The S01 spike already measured the tolerance for mesh/sprite/particle, so the camera shape and scene setup are known. The risk is that `IVisObjBuilder` may behave differently from the map session path (which uses `IScene` directly). This should be isolated in T06 and gated behind the engine-availability check already established for the map editor (skip with "skipped: no GPU device" on Linux CI).

**Second risk: `BkResDeleteNode` / `BkResRestoreNode` serialisation format.** The undo contract requires restoring a subtree to the exact same index. The serialised blob (XML fragment) must be identity-round-trippable through `NResourceXml`. This can be verified in T02 without needing the engine.

---

## Implementation Constraints

- `resource_bridge.cpp` must live inside `Sources/src/EditorBridge/` to be picked up by `addEditorBridge` (or a parallel `addResourceBridge` that shares the same include paths).
- The shared lifecycle functions (`BkEditorStart`, `BkEditorStop`, `BkEditorSetOverlay`, etc.) are **already implemented** in `bridge.cpp` and **shared** — `resource_bridge.cpp` does not re-implement them.
- `test-resource-core` is pure Zig, no engine, and must pass on all 6 targets (Linux x64, macOS arm64, macOS x64, Windows MSVC, Windows GNU, and the cross targets in CI).
- `test-resource-bridge` requires the engine for preview tests; on Linux CI (no GPU) the preview tier is skipped with "skipped: no GPU device". The data-only test tier (round-trips, geometry, export, import) should run without a GPU.
- Line endings CRLF for all new text files (`.gitattributes`). CRLF in `.h`, `.cpp`, `.zig`.
- The `resource_core` Zig module takes a `ResBridge` interface value (vtable), not a concrete type — so `test-resource-core` passes `FakeResBridge` and the app passes the real C bridge adapter.

---

## Verification

After S04:
- `zig build test-resource-core` — green on all 6 targets
- `zig build test-resource-bridge` — green on engine-available targets; data-only sub-steps green on all
- Every command in the `ResourceCommand` union has an undo/redo test in `test-resource-core`
- `BkResPreview*` produces a captured frame within S01-measured tolerance (one mesh unit, one sprite object, one particle source)
- Existing map editor tiers remain green (the shared bridge library must not regress): `test-editor-bridge`, `map-editor-host-check`, `map-editor-smoke`, `map-editor-auto`, `map-editor-auto-m2`, `map-editor-m3-auto`, `map-editor-game-reads-it-m3`

---

## Don't Hand-Roll

- **Zig interface vtable pattern**: copy the exact `pub const Bridge = struct { ptr, vtable }` shape from `Sources/editor/core/bridge.zig`. Do not invent an alternative.
- **`History(T)`**: import from `editor_kit`, do not rewrite. The resource core's only job is to define its `ResourceCommand` union.
- **Safe-save (`BkResSave`)**: replicate the map editor's save pattern (write to `.bak`, read back, compare, rename) — do not simplify. The spec explicitly names this.
- **`BkEditorGuarded` wrapper**: all bridge entry points wrap their body in `Guarded(…)` (the map bridge's exception-to-status adapter). Reuse this, do not hand-roll error propagation.
