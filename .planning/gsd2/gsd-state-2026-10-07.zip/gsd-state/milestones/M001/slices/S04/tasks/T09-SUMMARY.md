---
id: T09
parent: S04
milestone: M001
key_files:
  - Sources/src/EditorBridge/resource_bridge.cpp
  - Sources/src/EditorBridge/resource_bridge_test.cpp
  - Sources/editor/resource_core/bridge.zig
  - Sources/editor/resource_core/root.zig
key_decisions:
  - Crosses and objectives stay Point2 lists: MFC stores exactly one CVec2 per mission/placeholder/chapter/objective, so GeometryValue was not extended.
  - Keyframes keep the T01-declared BkResVec3 shape; MFC framesList entries are (time, value) pairs, and z passes through unchanged rather than being dropped.
  - The points and vec3 families share one stride-generic emit/parse path in resource_bridge.cpp (ListStride) and one GeometryBlob.points vector.
duration: 
verification_result: passed
completed_at: 2026-10-05T06:48:49.067Z
blocker_discovered: false
---

# T09: Wired mission objectives, chapter/campaign crosses (Point2 lists) and particle/effect keyframes (Vec3 lists) through the resource bridge ABI with save->reopen byte parity on mip/chc/cgc/pcp/eff, and per-channel undo/redo in the Zig core

**Wired mission objectives, chapter/campaign crosses (Point2 lists) and particle/effect keyframes (Vec3 lists) through the resource bridge ABI with save->reopen byte parity on mip/chc/cgc/pcp/eff, and per-channel undo/redo in the Zig core**

## What Happened

Replaced the ten NotImplemented stubs (BkRes[Get|Set]{MissionObjectives,ChapterCrosses,CampaignCrosses,ParticleKeyframes,EffectKeyframes}) in resource_bridge.cpp. Added channels 11..15 to the C++ GeometryChannel enum. MFC's ChapterFrm/CampaignFrm/MissionFrm keep each cross/objective as one CVec2 (mission/placeholder/chapter vPosOnMap, objective vPosOnMap), so channels 11..13 reuse the existing GetPoints2/SetPoints2 helpers and GeometryValue was not extended. Keyframes (14, 15) get a vec3 family: GetVec3List/SetVec3List store 3n floats in GeometryBlob.points; EmitGeometryChild/ParseGeometryChild now serialise the points and vec3 families with one stride-generic path (ListStride = 2 or 3), as `x,y,z;...` inside `_bk_geometry`. On the Zig side the enum and family() already covered 11..15 (from T03/T08); bridge.zig got the doc rationale, and root.zig gained undo/redo coverage: the T08 child-node test now loops over all five points2 owner channels, and a new test round-trips both keyframe channels through apply/undo/redo with z preserved and refuses a Point2 payload on a keyframe channel. resource_bridge_test.cpp's owner-node helper became a template over BkResPoint2/BkResVec3 and runs set->read, refusals, save->reopen->read, byte-identical resave and clear on mip (objectives +232), chc (chapter missions +242, places +246), cgc (campaign chapters +252), pcp (generate density +140, speed +144) and eff (animations +33). The stub check that used BkResSetParticleKeyframes was dropped (BkResExport still covers the "unbuilt entry point fails loudly" rule).

## Verification

All five plan commands passed on Linux x64. Confirmed the new bridge cases actually ran: zig-out/local-test/resource_editor/t02/{mip-objectives,chc-chapter-crosses,cgc-campaign-crosses,pcp-particle-keyframes,eff-effect-keyframes}/ were written by this run and contain `_bk_geometry` channels 11..15 with the expected lists, and the resaved files are byte-identical to the saved ones (the test asserts this).

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `zig build test-resource-core -Dtest-mode=run` | 0 | pass | 15000ms |
| 2 | `zig build test-resource-bridge -Dtest-mode=run` | 0 | pass (21 fixtures + 5 new owner-node list cases) | 10000ms |
| 3 | `zig build test-editor-core -Dtest-mode=run` | 0 | pass | 1000ms |
| 4 | `zig build test-resource-model -Dtest-mode=run` | 0 | pass | 20000ms |
| 5 | `zig build test-editor-bridge -Dtest-mode=run` | 0 | pass | 531000ms |

## Deviations

The plan named mip/cgc/pcp in the title and mip/chc/cgc/pcp/eff in the body; all five are covered. Owner nodes for the bridge test are list containers (objectives, chapter missions/places, campaign chapters, particle track items, effect animations); MFC keeps each position on the individual child props item, so a later editor may map list entries onto children. That is S05+ UI work and does not change the ABI.

## Known Issues

Negative zero is written as "-0" in the saved text. It reads back equal and the resave stays byte-identical. As in T08, a cleared list is still saved as an empty `_bk_geometry` element instead of being removed.

## Files Created/Modified

- `Sources/src/EditorBridge/resource_bridge.cpp`
- `Sources/src/EditorBridge/resource_bridge_test.cpp`
- `Sources/editor/resource_core/bridge.zig`
- `Sources/editor/resource_core/root.zig`
