---
estimated_steps: 8
estimated_files: 4
skills_used: []
---

# T02: Fix the ResourceModel and EditorBridge Windows MSVC build: windows.h min/max macros, plus a guard against regressions

Hard steer 2026-10-06T20:28, a maintainer-reproduced failure. On win-home (D:\bk-ci at c70116a62, Zig 0.16 at C:\Users\jmfrank\scoop\apps\zig\0.16.0\zig.exe, BK_REQUIRE_ENGINE=1) 'zig build test-editor-bridge -Dtarget=x86_64-windows-msvc -Dtest-mode=run' fails: 'expected unqualified-id' at std::min/std::max in Sources/src/ResourceModel/compose.cpp:491, items/building/building_export.cpp:412-432 and :589, items/bridge/bridge_export.cpp:255-257 and more; and in items/stats_export.cpp:233 'too few arguments provided to function-like macro invocation' plus an incompatible-operands error. Cause: windows.h defines min/max macros.

Steps:
1. Check how the existing Sources/src engine code avoids the macros (NOMINMAX in compile flags or a common header, or (std::min)(...) / std::max<T>(...)). Follow that convention.
2. Fix every occurrence across all of Sources/src/ResourceModel and Sources/src/EditorBridge (grep for std::min( / std::max( and bare min( / max( uses; about 12 files at the time of planning). Prefer defining NOMINMAX on the ResourceModel and EditorBridge compile flags in build.zig for Windows targets, and also make the sources robust where the engine does. Keep CRLF.
3. Add a cheap guard so it cannot come back: a Windows MSVC cross-compile of the ResourceModel sources (and EditorBridge) in a fast tier that needs no run, or a grep-style lint test that fails on bare std::min( / std::max( in those folders when NOMINMAX is not guaranteed. Wire it into an existing tier (for example test-resource-model or test-editor-core). Write the guard first and see it fail on the current tree.
4. Prove on Linux: test-resource-model, test-resource-bridge, test-editor-bridge, test-editor-core.
5. Prove natively on win-home over ssh: copy the changed files into D:\bk-ci (detached worktree at c70116a62; 'git -C D:\bk-ci reset --hard <sha>' after the maintainer pushes, or scp the files). With the 0.16 zig run, for -Dtarget=x86_64-windows-msvc: test-resource-model, test-resource-bridge, test-editor-bridge (BK_REQUIRE_ENGINE=1) and test-editor-core; and for -Dtarget=x86_64-windows-gnu: test-editor-core. Report these as native Windows results, and claim no macOS or CI result that was not seen.
6. Before completing, git status must show no file touched by this task as modified or untracked. Do not push; the maintainer pushes and relays CI. Verify with plain zig build commands only.

## Inputs

- `.gsd/OVERRIDES.md`
- `Sources/src/ResourceModel/compose.cpp`
- `Sources/src/ResourceModel/items/building/building_export.cpp`
- `Sources/src/ResourceModel/items/bridge/bridge_export.cpp`
- `Sources/src/ResourceModel/items/stats_export.cpp`
- `build.zig`

## Expected Output

- `Sources/src/ResourceModel and Sources/src/EditorBridge compile for x86_64-windows-msvc`
- `a min/max guard wired into a fast tier`
- `win-home native run results recorded in the task summary`

## Verification

zig build test-resource-model && zig build test-resource-bridge && zig build test-editor-bridge && zig build test-editor-core
