# S18: Windows MinGW editor tier fix after S17 T04

**Goal:** Make the Windows MinGW 'Editor core tier' green again after S17/T04 without breaking MSVC or Linux. Link MSVC runtime libraries only for abi == .msvc, link imm32 per toolchain, and build every test tier for the requested -Dtarget. This is hard steer D056, the S17 CI follow-up, which lives in S18 because S17 is closed.
**Demo:** On win-home, zig build test-editor-core -Dtest-mode=run passes for both -Dtarget=x86_64-windows-gnu and -Dtarget=x86_64-windows-msvc, and the Linux native tiers stay green.

## Must-Haves

- On win-home (Zig 0.16, D:\bk-ci), zig build test-editor-core -Dtest-mode=run passes for x86_64-windows-gnu and x86_64-windows-msvc, and so do the other editor test tiers that share the kit. The step names show the requested target instead of 'native'. On Linux, test-editor-core, test-editor-bridge, the test-map-editor-* tiers, test-resource-model and test-resource-bridge pass. Nothing is pushed. git status is clean.

## Proof Level

- This slice proves: Native Windows runs on win-home over ssh and native Linux runs. CI is relayed by the maintainer after the push.

## Verification

- Run the task and slice verification checks for this slice.

## Tasks

- [x] **T01: Fix the Windows MinGW Editor core tier: MSVC runtime libraries only for abi msvc, every test tier built for the requested target** `est:2h`
  Hard steer D056, a CI follow-up to S17/T04. CI run 37521060859 at c70116a62: Windows MinGW now FAILS the 'Editor core tier'. It passed before T04. Reproduced natively on win-home (Zig 0.16 at C:\Users\jmfrank\scoop\apps\zig\0.16.0\zig.exe, worktree D:\bk-ci): 'zig build test-editor-core -Dtarget=x86_64-windows-gnu -Dtest-mode=run' fails at 'compile test Debug native' with "unable to find dynamic system library 'vcruntimed'", because the test command carries -lvcruntimed.
  - Files: `build.zig`
  - Verify: zig build test-editor-core && zig build test-editor-bridge && zig build test-resource-model -Dtest-mode=run && zig build test-resource-bridge && zig build test-editor-core -Dtarget=x86_64-windows-gnu && zig build test-editor-core -Dtarget=x86_64-windows-msvc

## Files Likely Touched

- build.zig
