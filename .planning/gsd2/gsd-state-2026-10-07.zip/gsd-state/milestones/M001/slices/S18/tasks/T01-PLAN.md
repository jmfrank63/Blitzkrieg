---
estimated_steps: 6
estimated_files: 1
skills_used: []
---

# T01: Fix the Windows MinGW Editor core tier: MSVC runtime libraries only for abi msvc, every test tier built for the requested target

Hard steer D056, a CI follow-up to S17/T04. CI run 37521060859 at c70116a62: Windows MinGW now FAILS the 'Editor core tier'. It passed before T04. Reproduced natively on win-home (Zig 0.16 at C:\Users\jmfrank\scoop\apps\zig\0.16.0\zig.exe, worktree D:\bk-ci): 'zig build test-editor-core -Dtarget=x86_64-windows-gnu -Dtest-mode=run' fails at 'compile test Debug native' with "unable to find dynamic system library 'vcruntimed'", because the test command carries -lvcruntimed.

There are two causes:
(1) T04 links vcruntimed for editor_kit / editor_core / resource_core on every Windows target (build.zig at about lines 2968, 2986 and 3006) instead of only when target.result.abi == .msvc. Compare the guarded pattern at about line 10651. Fix: link the MSVC runtime libraries (vcruntime/vcruntimed and any other MSVC-only libraries) only for abi == .msvc. Link imm32 only where the target's toolchain provides it (build.zig about lines 4624 and 9820). For a GNU target, either link imm32 the way the MapEditor exe already does successfully on MinGW, or define IMGUI_DISABLE_WIN32_DEFAULT_IME_FUNCTIONS.
(2) The editor test tiers still compile for 'native' instead of the requested -Dtarget. Fix: build every test tier (test-editor-core, test-map-editor-*, test-editor-bridge, test-resource-* and any other test step that shares the editor kit or resource core) for the requested target.

Prove the fix on win-home over ssh. Update D:\bk-ci with 'git -C C:\Users\jmfrank\source\repos\jmfrank63\Blitzkrieg fetch origin feat/resource-editor' then 'git -C D:\bk-ci reset --hard FETCH_HEAD', or scp the changed files into D:\bk-ci before the maintainer pushes. Run 'zig build test-editor-core -Dtarget=x86_64-windows-gnu -Dtest-mode=run' and the same command with -Dtarget=x86_64-windows-msvc, plus the other editor test tiers that share the kit, for both targets. Use the 0.16 zig there, not the default 0.17. On Linux, keep the native tiers green.

Do not push; the maintainer pushes and relays CI. Claim no CI result that was not seen; report the win-home runs as native Windows results. Write files with CRLF. git status must be clean at the end. Verify with plain zig build commands only.

## Inputs

- `build.zig`
- `.gsd/OVERRIDES.md`
- `.github/workflows/cross-platform.yml`

## Expected Output

- `MSVC runtime libraries linked only for abi == .msvc in build.zig`
- `imm32 linked, or IMGUI_DISABLE_WIN32_DEFAULT_IME_FUNCTIONS defined, correctly for GNU and MSVC Windows targets`
- `Every test tier built for the requested -Dtarget`
- `Native win-home evidence for x86_64-windows-gnu and x86_64-windows-msvc, plus Linux native tier results`

## Verification

zig build test-editor-core && zig build test-editor-bridge && zig build test-resource-model -Dtest-mode=run && zig build test-resource-bridge && zig build test-editor-core -Dtarget=x86_64-windows-gnu && zig build test-editor-core -Dtarget=x86_64-windows-msvc

## Observability Impact

On win-home, the gnu test-editor-core run no longer shows 'compile test Debug native' or -lvcruntimed; the step names show the requested target.
