---
id: T01
parent: S18
milestone: M001
key_files:
  - build.zig
key_decisions: []
duration: 
verification_result: mixed
completed_at: 2026-10-06T20:39:19.721Z
blocker_discovered: false
---

# T01: Verified the already-committed fix (e60a216dd): editor test tiers build for the requested -Dtarget and only abi==msvc gets MSVC library paths; MinGW and MSVC editor-core pass natively on win-home.

**Verified the already-committed fix (e60a216dd): editor test tiers build for the requested -Dtarget and only abi==msvc gets MSVC library paths; MinGW and MSVC editor-core pass natively on win-home.**

## What Happened

On inspection, build.zig at HEAD already contains the fix, committed in e60a216dd before this task ran. The kit, core and resource-core test modules use `target` instead of the host, call addMsvcLibraryPaths only when target.result.abi == .msvc, and no longer link vcruntimed on MinGW. imm32 is linked from editor_imgui for every Windows target. I made no source changes in this task. Because e60a216dd is not pushed, the win-home worktree D:\bk-ci (at c70116a62) could not be updated by fetch. I copied HEAD's build.zig into it with scp and ran the checks there with the 0.16 zig. While I was working, a concurrent GSD task (the min/max steer) began modifying other files in the tree; those changes are not mine and I did not touch or commit them.

## Verification

Linux native: test-editor-core, test-editor-bridge, test-resource-model -Dtest-mode=run, test-resource-bridge, then test-editor-core cross-compiled for x86_64-windows-gnu and x86_64-windows-msvc (-Dtest-mode=compile). The chain exited 0. win-home (native Windows, zig 0.16, D:\bk-ci with HEAD build.zig): test-editor-core -Dtest-mode=run passed for x86_64-windows-gnu and x86_64-windows-msvc (exit 0). test-editor-kit and test-resource-core -Dtest-mode=run also passed for both targets. CI results were not seen. Full sweep left to the maintainer.

## Verification Evidence

| # | Command | Exit Code | Verdict | Duration |
|---|---------|-----------|---------|----------|
| 1 | `{"command":"zig build test-editor-core && test-editor-bridge && test-resource-model -Dtest-mode=run && test-resource-bridge && test-editor-core -Dtarget=x86_64-windows-gnu/msvc -Dtest-mode=compile (Linux)","exitCode":0,"verdict":"pass","durationMs":1500000}` | -1 | unknown (coerced from string) | 0ms |
| 2 | `{"command":"win-home: zig build test-editor-core -Dtarget=x86_64-windows-gnu -Dtest-mode=run","exitCode":0,"verdict":"pass","durationMs":60000}` | -1 | unknown (coerced from string) | 0ms |
| 3 | `{"command":"win-home: zig build test-editor-core -Dtarget=x86_64-windows-msvc -Dtest-mode=run","exitCode":0,"verdict":"pass","durationMs":60000}` | -1 | unknown (coerced from string) | 0ms |
| 4 | `{"command":"win-home: zig build test-editor-kit and test-resource-core -Dtarget=x86_64-windows-gnu/msvc -Dtest-mode=run","exitCode":0,"verdict":"pass","durationMs":120000}` | -1 | unknown (coerced from string) | 0ms |

## Deviations

No code change: the fix was already committed in e60a216dd, so this task only verified it, including native win-home runs with HEAD's build.zig copied in by scp.

## Known Issues

test-resource-app-logic fails on Windows for both gnu and msvc with "coff does not support linking multiple objects into one" at the resource-app-c-bridge object compile. It fails identically at c70116a62 on a native target, so it is pre-existing and not caused by this fix. Not addressed here. The working tree currently holds another task's uncommitted min/max changes, which are not part of T01.

## Files Created/Modified

- `build.zig`
