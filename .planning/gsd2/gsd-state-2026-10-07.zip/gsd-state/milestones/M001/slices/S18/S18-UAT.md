# S18: Windows MinGW editor tier fix after S17 T04 — UAT

**Milestone:** M001
**Written:** 2026-10-06T21:12:36.266Z

# S18 UAT

UAT Type: command-run (Linux native + win-home over ssh)

## Preconditions
- Worktree at d44d957a4, clean.
- win-home worktree D:\bk-ci synced to the same tree, Zig 0.16 at C:\Users\jmfrank\scoop\apps\zig\0.16.0\zig.exe.

## Steps
1. On Linux run `zig build test-editor-core`, `zig build test-editor-bridge`, `zig build test-resource-model -Dtest-mode=run`, `zig build test-resource-bridge`. Expected: all exit 0.
2. On win-home run `zig build test-editor-core -Dtarget=x86_64-windows-gnu -Dtest-mode=run`. Expected: exit 0, no vcruntimed link error.
3. On win-home run the same with `-Dtarget=x86_64-windows-msvc`. Expected: exit 0.
4. `git status --short`. Expected: empty.

## Edge cases
- Step names show the requested target, not 'native'.
- Cached builds can return instantly; use a clean cache to force a rebuild if in doubt.

## Not Proven By This UAT
- macOS and Windows CI results (the maintainer pushes and relays CI).
- Re-running the test-map-editor-* tiers.
