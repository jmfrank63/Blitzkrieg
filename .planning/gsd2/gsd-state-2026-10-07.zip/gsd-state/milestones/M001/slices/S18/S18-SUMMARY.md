---
id: S18
parent: M001
milestone: M001
provides:
  - (none)
requires:
  []
affects:
  []
key_files: []
key_decisions: []
patterns_established:
  - (none)
observability_surfaces:
  - none
drill_down_paths:
  []
duration: ""
verification_result: passed
completed_at: 2026-10-06T21:12:36.265Z
blocker_discovered: false
---

# S18: Windows MinGW editor tier fix after S17 T04

**MSVC runtime libraries are linked only for abi msvc and every editor test tier is built for the requested -Dtarget, so test-editor-core passes on Windows gnu and msvc.**

## What Happened

T01 fixed the CI regression (run 37521060859 at c70116a62) in build.zig. The MinGW 'Editor core tier' failed with "unable to find dynamic system library 'vcruntimed'" because the MSVC runtime libraries were linked for every Windows target. They are now linked only when abi == .msvc, imm32 is linked per toolchain, and every test tier is built for the requested -Dtarget, so step names show the target instead of 'native'. The fix is in commits e60a216dd and d44d957a4. A follow-up also made the ResourceModel, EditorBridge and tools/zig tests compile on Windows (min/max lint, audit-windows-minmax step).

## Verification

Re-run at closeout on Linux: zig build test-editor-core, test-editor-bridge, test-resource-model -Dtest-mode=run and test-resource-bridge all exited 0. On win-home (D:\bk-ci, Zig 0.16), zig build test-editor-core -Dtest-mode=run exited 0 for x86_64-windows-gnu and x86_64-windows-msvc. Those two Windows builds returned in about 3 seconds with no output, so they were likely served from the build cache. The earlier T01 session ran the other Windows tiers on win-home. win-home's build.zig hash matches the local one. git status is clean and nothing was pushed. The test-map-editor-* tiers were not re-run at closeout. CI on macOS and Windows is left to the maintainer after the push.

## Requirements Advanced

None.

## Requirements Validated

None.

## New Requirements Surfaced

None.

## Requirements Invalidated or Re-scoped

None.

## Operational Readiness

None.

## Deviations

None.

## Known Limitations

None.

## Follow-ups

None.

## Files Created/Modified

None.
