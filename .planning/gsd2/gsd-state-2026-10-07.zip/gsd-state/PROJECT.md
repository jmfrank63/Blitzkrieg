# Project

## What This Is

Blitzkrieg Reloaded — a port of the 2003 real-time tactics game *Blitzkrieg* and its authoring tools to a portable, modern stack. The game and engine remain C++ and are built across targets by `zig build` (Zig 0.16) for Windows x64 (MSVC), macOS arm64, macOS x64, and Linux x64. The authoring tools are being rewritten as Zig applications on top of Dear ImGui (`Sources/editor`), talking to the engine through a C-ABI boundary at `Sources/src/EditorBridge`.

The game itself is already building and running portably. The Map Editor (one of five planned editors) has shipped three milestones (phase 3/4/5) and now builds and runs on Linux as well as macOS and Windows. The next large piece of work is the Resource Editor — the MFC `editor.exe` that produced the game's shipped `Data/` — which is 64,028 lines of MFC-ridden C++, built only for Windows, shipped as a checked-in binary, and used by content authors to compose units, buildings, bridges, particles, missions and 18 other resource kinds.

## Core Value

<!-- This is the primary value anchor for prioritization and tradeoffs.
     If scope must shrink, this should survive. -->

The Resource Editor must be able to open, edit, and export every resource kind the shipped game ships with, in a form the game loads **unchanged**, on at least one modern platform (macOS arm64 is the home dev platform; Windows x64 is the parity oracle; Linux x64 is this agent machine's native target). "The game reads it unchanged" is the irreducible contract — if scope must shrink, the sub-editors still cover every parity row and the export still produces game-readable data; the editor UI's polish can shrink before the data correctness does.

## Project Shape

<!-- Drives questioning depth in downstream stages. `simple` → short plain-text
     rounds, fast PROJECT/CONTEXT/REQUIREMENTS writes. `complex` → researched
     3–4-option questions with an "Other — let me discuss" hatch.
     Default to `complex` when uncertain. -->

- **Complexity:** complex
- **Why:** 64k lines of MFC to disentangle; 21 sub-editors each with its own tree, properties, overlays, previews and export; cross-platform GPU preview; byte- and field-equal parity against a Windows-only oracle (`editor.exe` on win-home); seven test tiers already established by the Map Editor must be re-established for resources plus one new "the game reads it" tier.

## Current State

- **Game and engine:** built portably by `zig build` on Windows MSVC, macOS arm64, macOS x64, Linux x64. CI (`.github/workflows/cross-platform.yml`) is green across all six matrix targets.
- **Map Editor (phases 2–5):** complete through M3 (random map templates, minimap tools, parity). Built and running on Linux (merge `1d7264fd6`), macOS, Windows. All Map Editor test tiers (`test-editor-core`, `test-map-editor-{view,panels,testlaunch,auto,engine}`, `test-editor-bridge`, `map-editor-{host-check,smoke,auto,auto-m2,m3-auto,game-reads-it-m3}`) are green on this Linux machine.
- **Resource Editor (phase 6, this milestone):** ported to the portable stack (S01-S16); all 21 kinds open, edit and export, and `resource-editor-game-reads-it` proves the game reads one export per kind. All 20 MFC goldens are committed; `test-resource-model-comparator` at `b8aa895bb` reports pass=10 accepted=10 fail=0 pending=0, and the maintainer's full Linux sweep at `b8aa895bb` is VERDICT=PASS (41 tiers). The MFC editor (`Sources/src/editor` with `editor2.exe`, `Sources/src/bin/editor.exe`, its `A7.sln` entry and the `stage.zig` `copyEditors` row) was deleted in `c6b4329c6` (D037, D050); `PRE_DELETE = b8aa895bb00efb2fdac28096656dcf26984e3f87` is the commit from which MFC goldens can be regenerated. Still open: the maintainer's full sweep on `c6b4329c6`, Johannes's hand try on macOS and Windows release, the GOG goldens, and CI after push.
- **Phases 7 (ELK), 8 (small tools), 999.1/999.2 (random map gen fast polygon fill, derived textures/compression installer):** scoped in `.planning/phases/` but not started. Later than this milestone.

## Architecture / Key Patterns

- **Build:** `build.zig` is the single source of truth. Never run `zig fmt build.zig`; run `zig test tools/zig/build_hermeticity_test.zig` after editing it. Install step for Linux puts artifacts in `zig-out/game/linux/x86_64/release/`.
- **Three-layer editor pattern** (established by Map Editor, extended by this milestone):
  - Zig **app** (`Sources/editor/app`): SDL3 host, ImGui, panels, auto-driver, test launch — platform concerns.
  - Zig **core** (`Sources/editor/core`): headless, std-only, runs against a fake bridge for tests.
  - C **bridge** (`Sources/src/EditorBridge`): flat C ABI, plain structs with fixed-size fields, integer handles, `BkEditorStatus` + `BkEditorLastMessage`, every entry point in `Guarded`, no C++ exception crosses the boundary.
- **C++ engine, C ABI boundary, Zig everything above the boundary.** The game engine (`Main`, `Scene`, `Anim`, `GFX/GFXGPU`, `Image`, `StreamIO`) remains C++. All new tooling above the bridge is Zig. The new `ResourceModel` library (introduced by this milestone) is portable C++ because it contains the MFC-stripped tree items and export code that is "correct by definition" (it produced shipped `Data/`).
- **Verification ladder:** static → command → behavioural → human. "All steps done" is not verification; evidence is tests, captured TGA/PNG measured by code, or the engine's own readers reading the output.
- **CRLF everywhere** (`.gitattributes`), including new files.
- **Settings seams:** `BK_*_SETTINGS` environment variables redirect user files for tests; `XDG_DATA_HOME` redirects user roots. Tests never touch the user's own saves, settings or cloud sync.
- **Linux pitfalls already solved** (reuse): executables that load engine modules need `rdynamic` and a `$ORIGIN` rpath; worker threads need the default 16 MiB stack; hidden test windows use `SDL_WINDOW_HIDDEN | SDL_WINDOW_NOT_FOCUSABLE`; stop `ISFX` before modules unload; resolve Data paths case-insensitively (`DataFile` helper in `tools/zig/editor_bridge_test.cpp`).
- **Commit style:** conventional prefix with scope, e.g. `feat(resource-editor): ...`, `fix(editor): ...`, `test(...)`, `docs(...)`. Agent does not push; the maintainer merges and pushes.

## Capability Contract

See `.gsd/REQUIREMENTS.md` for the explicit capability contract, requirement status, and coverage mapping.

## Milestone Sequence

<!-- Check off milestones as they complete. One-liners should describe intent, not implementation detail. -->

- [ ] M001: Portable Resource Editor — port the 64k-line MFC `editor.exe` to the portable Zig+ImGui+C++ editor stack across macOS, Windows and Linux, with every parity row proven by evidence; shared editor kit extracted from the Map Editor on the way in; MFC editor deleted on the way out.
