# Requirements

This file is the explicit capability and coverage contract for the project.

## Active

### R001 — Extract a shared Zig editor kit (`Sources/editor/kit`) from the Map Editor containing history/undo, Files + safe-save paths, settings, autosave, shipped-path detection, SDL host, ImGui backend, Windows CRT and console, BK_EDITOR_AUTO parser/driver/TGA compare, picture cache, file dialogs, test launch. Map Editor moves onto the kit first with no behaviour change. The kit must have no dependency on the engine bridge so ELK can consume it in phase 7.
- Class: core-capability
- Status: active
- Description: Extract a shared Zig editor kit (`Sources/editor/kit`) from the Map Editor containing history/undo, Files + safe-save paths, settings, autosave, shipped-path detection, SDL host, ImGui backend, Windows CRT and console, BK_EDITOR_AUTO parser/driver/TGA compare, picture cache, file dialogs, test launch. Map Editor moves onto the kit first with no behaviour change. The kit must have no dependency on the engine bridge so ELK can consume it in phase 7.
- Why it matters: Reuse: the Resource Editor needs the same host/UX plumbing. Without the kit it would be copy-paste and would drift. ELK depends on the same extraction.
- Source: spec
- Primary owning slice: M001/S02
- Supporting slices: M001/S05
- Validation: unmapped
- Notes: Spec D-02. Extraction is a move not a copy. Must keep every Map Editor tier green on Linux after extraction.

### R002 — Portable `ResourceModel` C++ library at `Sources/src/ResourceModel`: no MFC, no Windows API, no UI. Contains `CVariant` replacement, `SProp`, `CTreeItem`, item factory, every tree item class of every sub-editor, project XML load/save with `operator&( IDataTree & )` serialisation unchanged, reference lists, export per sub-editor, batch export with `-f`/`-os` and up-to-date check.
- Class: core-capability
- Status: active
- Description: Portable `ResourceModel` C++ library at `Sources/src/ResourceModel`: no MFC, no Windows API, no UI. Contains `CVariant` replacement, `SProp`, `CTreeItem`, item factory, every tree item class of every sub-editor, project XML load/save with `operator&( IDataTree & )` serialisation unchanged, reference lists, export per sub-editor, batch export with `-f`/`-os` and up-to-date check.
- Why it matters: The model and export code is "correct by definition" because it produced shipped `Data/`. Keeping it in C++ (stripped of MFC) means Zig never re-implements it; the Resource Editor is a UI shell on top of this library.
- Source: spec
- Primary owning slice: M001/S03
- Supporting slices: M001/S06, M001/S07, M001/S08, M001/S09, M001/S10, M001/S11, M001/S12, M001/S13, M001/S14, M001/S15
- Validation: unmapped
- Notes: Spec D-04. `CString` → `std::string`; registry → settings passed in; message boxes → returned diagnostics. Built by `build.zig` on every target that builds the engine C++. Hard steer 2026-10-05 (D006): "every tree item class" means the full MFC property table (names, DT_* types, defaults, order) and the `operator&( IDataTree & )` serialisation of every MFC tree item, checked by test-resource-model against an inventory generated from Sources/src/editor (e.g. weapon 48, mesh-tree 108 properties). A shell item class without its property table does not count.

### R003 — `resource_bridge.h` with `BkRes*` C ABI inside the existing `EditorBridge` library. Shares `BkEditorStart`/`Stop`, data-only start, Mods, Paths, SetOverlay, CaptureFrame, GpuDevice, Resize, Guarded, status + message rules. Groups: Projects, Tree, References, Geometry edits (set+get for exact undo), Export (ExportStatsOnly, Batch), MOD (ModSettings, PackMod), Preview, Import.
- Class: integration
- Status: active
- Description: `resource_bridge.h` with `BkRes*` C ABI inside the existing `EditorBridge` library. Shares `BkEditorStart`/`Stop`, data-only start, Mods, Paths, SetOverlay, CaptureFrame, GpuDevice, Resize, Guarded, status + message rules. Groups: Projects, Tree, References, Geometry edits (set+get for exact undo), Export (ExportStatsOnly, Batch), MOD (ModSettings, PackMod), Preview, Import.
- Why it matters: The Zig core and app talk to `ResourceModel` only through this flat C ABI. Everything that goes through here is testable headlessly and crosses the Zig/C++ boundary without C++ exception propagation.
- Source: spec
- Primary owning slice: M001/S04
- Supporting slices: M001/S05, M001/S06..M001/S15
- Validation: unmapped
- Notes: Spec D-03. Plain structs with fixed-size fields, integer handles. NO_DEVICE kept separate from BAD_ARGUMENT.

### R004 — Zig `resource_core` (`Sources/editor/resource_core`) headless library. Document per sub-editor kind (tree mirror, props, dirty flag, path, kind, lock state). Generic commands: `SetProp`, `InsertNode`, `DeleteNode` (subtree snapshot), `MoveNode`. One command per geometry edit (passability, points, zero point, entrance, lines, formation, crosses, keyframes), recording before/after state. One open project per sub-editor kind, retained when switching sub-editors.
- Class: core-capability
- Status: active
- Description: Zig `resource_core` (`Sources/editor/resource_core`) headless library. Document per sub-editor kind (tree mirror, props, dirty flag, path, kind, lock state). Generic commands: `SetProp`, `InsertNode`, `DeleteNode` (subtree snapshot), `MoveNode`. One command per geometry edit (passability, points, zero point, entrance, lines, formation, crosses, keyframes), recording before/after state. One open project per sub-editor kind, retained when switching sub-editors.
- Why it matters: The core runs against a fake bridge so command/undo/redo paths are tested without SDL, ImGui, or the engine. Keeping engine-computed changes as recorded before/after state (never re-running engine functions on undo) is the lesson from the Map Editor's terrain paint.
- Source: spec
- Primary owning slice: M001/S04
- Supporting slices: M001/S06..M001/S15
- Validation: unmapped
- Notes: Spec D-05, D-06. Std-only; SDL/ImGui/C ABI live only in the app.

### R005 — `ResourceEditor` application (Zig app at `Sources/editor/resource_app`, binary `ResourceEditor`) with docking ImGui layout (project tree left, property inspector right, preview centre, bottom dock for thumbnail list and keyframe curve, sub-editor toolbar under menu, status bar), Editors menu + combo switch between 21 sub-editors, extension-based auto-switch on open, last-active remembered. Covers §A shared features of 06-PARITY.md.
- Class: primary-user-loop
- Status: active
- Description: `ResourceEditor` application (Zig app at `Sources/editor/resource_app`, binary `ResourceEditor`) with docking ImGui layout (project tree left, property inspector right, preview centre, bottom dock for thumbnail list and keyframe curve, sub-editor toolbar under menu, status bar), Editors menu + combo switch between 21 sub-editors, extension-based auto-switch on open, last-active remembered. Covers §A shared features of 06-PARITY.md.
- Why it matters: This is the user-visible shell. All of §A hangs off it: New/Open/Save, MOD settings, Export, PAK, picture options, directories, batch, run game, references, inspector, etc.
- Source: spec
- Primary owning slice: M001/S05
- Supporting slices: M001/S06..M001/S15
- Validation: unmapped
- Notes: Spec D-21 and 06-PARITY.md §A rows A-01..A-39.

### R006 — 21 sub-editors ported with model + export + preview + tools: Unit, Infantry, Squad, Weapon, Mine, Particle, Sprite, Effect, Building, Object, Fence, Bridge, Trench, Mission, Chapter, Campaign, Medal, Terrain, 3D Road, 3D River, GUI. Each sub-editor delivers: golden parity comparison, import-and-export round trip on shipped samples, undo/redo tests for every tool, one preview shot measured from captured frame, one `BK_EDITOR_AUTO` scenario.
- Class: core-capability
- Status: active
- Description: 21 sub-editors ported with model + export + preview + tools: Unit, Infantry, Squad, Weapon, Mine, Particle, Sprite, Effect, Building, Object, Fence, Bridge, Trench, Mission, Chapter, Campaign, Medal, Terrain, 3D Road, 3D River, GUI. Each sub-editor delivers: golden parity comparison, import-and-export round trip on shipped samples, undo/redo tests for every tool, one preview shot measured from captured frame, one `BK_EDITOR_AUTO` scenario.
- Why it matters: The whole point of the port. Every parity row in 06-PARITY.md §B must be `done` with evidence before the MFC editor can be deleted.
- Source: spec
- Primary owning slice: M001/S06, M001/S07, M001/S08, M001/S09, M001/S10, M001/S11, M001/S12, M001/S13, M001/S14, M001/S15
- Supporting slices: M001/S03, M001/S04
- Validation: unmapped
- Notes: Spec D-22, D-28. GUI editor was switched off in MFC; it comes last and edits the current UI XML, proven by the game loading an edited screen.

### R007 — Project save uses the Map Editor's safe save (temp file, read back, compare, rename), with one `.bak` per session holding the version from when the project was opened (replacing MFC `backup.tmp`). Autosave and crash recovery operate as in Map Editor D-19..D-22 of phase 3. A failed save leaves the file and the dirty flag as they were.
- Class: continuity
- Status: active
- Description: Project save uses the Map Editor's safe save (temp file, read back, compare, rename), with one `.bak` per session holding the version from when the project was opened (replacing MFC `backup.tmp`). Autosave and crash recovery operate as in Map Editor D-19..D-22 of phase 3. A failed save leaves the file and the dirty flag as they were.
- Why it matters: A failed export or save must never destroy user work. This is table-stakes continuity; MFC's `backup.tmp` was fragile.
- Source: spec
- Primary owning slice: M001/S05
- Supporting slices: M001/S02
- Validation: unmapped
- Notes: Spec D-08, A-05, A-39. Autosave + recovery is new vs MFC.

### R008 — MFC's `locked_<username>` file is preserved: editor writes its own lock on open and, when another user's lock is present, warns and offers read-only open or take over.
- Class: continuity
- Status: active
- Description: MFC's `locked_<username>` file is preserved: editor writes its own lock on open and, when another user's lock is present, warns and offers read-only open or take over.
- Why it matters: Content authors share project files across machines; silent concurrent edits would corrupt projects.
- Source: spec
- Primary owning slice: M001/S05
- Supporting slices: M001/S03
- Validation: unmapped
- Notes: Spec D-08, A-06.

### R009 — MOD settings (`mod.xml`, seeding `modobjects.xml` from `editor\modobjects.xml`) ported. "Compress MOD to PAK" uses a native zip writer (no `zip.exe`) in the format `StreamIOZig/zip.zig` reads, and the storage must mount the result in a test.
- Class: core-capability
- Status: active
- Description: MOD settings (`mod.xml`, seeding `modobjects.xml` from `editor\modobjects.xml`) ported. "Compress MOD to PAK" uses a native zip writer (no `zip.exe`) in the format `StreamIOZig/zip.zig` reads, and the storage must mount the result in a test.
- Why it matters: MFC shelled out to `zip.exe` which is Windows-only and not portable. A native writer removes an external dependency and runs on every target.
- Source: spec
- Primary owning slice: M001/S05
- Supporting slices: M001/S03
- Validation: unmapped
- Notes: Spec D-14, A-08, A-10.

### R010 — Picture options (brightness, contrast, gamma, `gamma.cfg` searched upward, applied live to preview), Set Directories (source root, export root, game exe, game args), background colour as a preview setting.
- Class: primary-user-loop
- Status: active
- Description: Picture options (brightness, contrast, gamma, `gamma.cfg` searched upward, applied live to preview), Set Directories (source root, export root, game exe, game args), background colour as a preview setting.
- Why it matters: Authors use picture options and directories constantly. Picture options also drive the export's gamma correction (writes `gamma.cfg`).
- Source: spec
- Primary owning slice: M001/S05
- Validation: unmapped
- Notes: Spec D-19, A-12, A-16, A-18.

### R011 — Batch mode: command-line `ResourceEditor --batch <ext|all> <sourceDir> <destDir> [-f] [-os]` (data-only startup, no window, runs in CI) and Tools → Batch Mode panel (src, dst, mask, -f, -os, progress, failure list, missing `gamma.cfg` report). `all` (new relative to MFC) runs every extension in the MFC frame order. Up-to-date check (`FindMaximalSourceTime` / `FindMinimalExportFileTime`) preserved.
- Class: operability
- Status: active
- Description: Batch mode: command-line `ResourceEditor --batch <ext|all> <sourceDir> <destDir> [-f] [-os]` (data-only startup, no window, runs in CI) and Tools → Batch Mode panel (src, dst, mask, -f, -os, progress, failure list, missing `gamma.cfg` report). `all` (new relative to MFC) runs every extension in the MFC frame order. Up-to-date check (`FindMaximalSourceTime` / `FindMinimalExportFileTime`) preserved.
- Why it matters: Content authors run batch exports when mods are rebuilt. Running it headlessly in CI gates every change.
- Source: spec
- Primary owning slice: M001/S05
- Supporting slices: M001/S03
- Validation: unmapped
- Notes: Spec D-15, A-20, A-21.

### R012 — Tools → Run Blitzkrieg (F7) launches the Game beside the editor with the editor test profile, windowed, with `-mod=<exportMod>` and configured game args. Reuses the Map Editor's test-launch (phase 3 D-02/D-05/D-09).
- Class: primary-user-loop
- Status: active
- Description: Tools → Run Blitzkrieg (F7) launches the Game beside the editor with the editor test profile, windowed, with `-mod=<exportMod>` and configured game args. Reuses the Map Editor's test-launch (phase 3 D-02/D-05/D-09).
- Why it matters: Authors verify a resource by actually running the game against it. F7 is the main inner-loop step after Export.
- Source: spec
- Primary owning slice: M001/S05
- Supporting slices: M001/S02
- Validation: unmapped
- Notes: Spec D-14, A-22. The test-launch module moves into the shared kit.

### R013 — One generic ImGui property inspector handles every `DT_*` domain type: `DT_DEC`, `DT_STR`, `DT_BOOL`, `DT_FLOAT`, `DT_COMBO`, `DT_BROWSE`, `DT_COLOR`, and the ~20 `DT_*_REF` reference types. Reference pickers are searchable lists; browse opens a file dialog relative to the source root; colour has a swatch; multi-select has its own dialog.
- Class: primary-user-loop
- Status: active
- Description: One generic ImGui property inspector handles every `DT_*` domain type: `DT_DEC`, `DT_STR`, `DT_BOOL`, `DT_FLOAT`, `DT_COMBO`, `DT_BROWSE`, `DT_COLOR`, and the ~20 `DT_*_REF` reference types. Reference pickers are searchable lists; browse opens a file dialog relative to the source root; colour has a swatch; multi-select has its own dialog.
- Why it matters: The inspector is used in every sub-editor. One widget per type (not per sub-editor) is what makes 21 editors tractable.
- Source: spec
- Primary owning slice: M001/S05
- Supporting slices: M001/S03
- Validation: unmapped
- Notes: Spec D-21, A-29..A-32. Reference lists are built from storage, not from Windows directory listings.

### R014 — Import from game data: MFC's dead Ctrl+I handler is implemented as building a project of the right kind from a runtime resource folder (e.g. `1.xml` and companions) through the same `operator&` code. Graphics-source fields stay empty when source files are not found; an export with no graphics sources writes the stats and leaves the existing exported graphics untouched.
- Class: core-capability
- Status: active
- Description: Import from game data: MFC's dead Ctrl+I handler is implemented as building a project of the right kind from a runtime resource folder (e.g. `1.xml` and companions) through the same `operator&` code. Graphics-source fields stay empty when source files are not found; an export with no graphics sources writes the stats and leaves the existing exported graphics untouched.
- Why it matters: Most shipped resources have no project file (only `WinSniper.unt`, 13 old `.unt` files and one `current.msh` are in-repo; others live in GOG mods). Without Import there is no way to open and re-export the vast majority of shipped resources.
- Source: spec
- Primary owning slice: M001/S04
- Supporting slices: M001/S06, M001/S07, M001/S08, M001/S09, M001/S10, M001/S11, M001/S12, M001/S13, M001/S14, M001/S15
- Validation: unmapped
- Notes: Spec D-13, A-36.

### R015 — Tools → Export RPG Stats only (Ctrl+R) available for every sub-editor (MFC wired it for Infantry only).
- Class: primary-user-loop
- Status: active
- Description: Tools → Export RPG Stats only (Ctrl+R) available for every sub-editor (MFC wired it for Infantry only).
- Why it matters: Lets authors update stats without re-generating graphics, which saves minutes on every tweak and is the only path when graphics sources are absent (after Import).
- Source: spec
- Primary owning slice: M001/S05
- Supporting slices: M001/S06..M001/S15
- Validation: unmapped
- Notes: Spec D-13, A-19.

### R016 — Undo/redo for every edit in every sub-editor, including geometry edits (passability brush strokes, point moves, keyframe edits, formation drag). Drag or paint stroke = one gesture.
- Class: differentiator
- Status: active
- Description: Undo/redo for every edit in every sub-editor, including geometry edits (passability brush strokes, point moves, keyframe edits, formation drag). Drag or paint stroke = one gesture.
- Why it matters: MFC had no undo outside the GUI editor. This is the single biggest UX improvement and is non-negotiable for the port's exit.
- Source: spec
- Primary owning slice: M001/S04
- Supporting slices: M001/S06..M001/S15
- Validation: unmapped
- Notes: Spec D-05, A-38. Each sub-editor plan must include undo/redo tests for every one of its tools.

### R017 — Preview is the window background through the engine's `IGFX::SetOverlay` path (same path the Map Editor uses), with ImGui docked on top. Preview scene is a new bridge path (`BkResPreviewBegin(kind)`, `BkResPreviewShow(project)`) that builds an empty `IScene` with a game-like camera and no terrain; Road/River load `maps\road3d` / `maps\river3d` as MFC did. The preview is built by exporting into a temp preview storage mounted over data, then building the object through `IVisObjBuilder` — so the preview is itself a test of the export. Rebuilds after edits are debounced. Overlays are drawn with ImGui draw lists from world-to-screen projections, not with the engine's `DrawRects`.
- Class: integration
- Status: active
- Description: Preview is the window background through the engine's `IGFX::SetOverlay` path (same path the Map Editor uses), with ImGui docked on top. Preview scene is a new bridge path (`BkResPreviewBegin(kind)`, `BkResPreviewShow(project)`) that builds an empty `IScene` with a game-like camera and no terrain; Road/River load `maps\road3d` / `maps\river3d` as MFC did. The preview is built by exporting into a temp preview storage mounted over data, then building the object through `IVisObjBuilder` — so the preview is itself a test of the export. Rebuilds after edits are debounced. Overlays are drawn with ImGui draw lists from world-to-screen projections, not with the engine's `DrawRects`.
- Why it matters: Previews are what authors see on every edit. Using the real export path means a visible preview is a running correctness check of the export; using ImGui draw lists avoids the renderer limits the Map Editor's yaw measurement surfaced.
- Source: spec
- Primary owning slice: M001/S04
- Supporting slices: M001/S01, M001/S05, M001/S06..M001/S15
- Validation: unmapped
- Notes: Spec D-16, D-18, A-37.

### R018 — The preview scene is spiked and measured on 1 mesh unit, 1 sprite object and 1 particle source before any sub-editor depends on it. Measured from captured frames (`BkEditorCaptureFrame`), not assumed.
- Class: quality-attribute
- Status: active
- Description: The preview scene is spiked and measured on 1 mesh unit, 1 sprite object and 1 particle source before any sub-editor depends on it. Measured from captured frames (`BkEditorCaptureFrame`), not assumed.
- Why it matters: Phase 3's D-12 yaw measurement showed the renderer breaks silently with non-game cameras. Measuring first means the preview architecture is validated before 15 sub-editors are built on it.
- Source: spec
- Primary owning slice: M001/S01
- Validation: unmapped
- Notes: Spec D-17.

### R019 — DXT pixel tolerance between the old editor's DXT encoder and the portable `NDxt` is measured in slice 1, not guessed. `_h.dds` (ARGB8888) is byte-identical.
- Class: quality-attribute
- Status: active
- Description: DXT pixel tolerance between the old editor's DXT encoder and the portable `NDxt` is measured in slice 1, not guessed. `_h.dds` (ARGB8888) is byte-identical.
- Why it matters: Without a measured tolerance, downstream golden comparisons have no credible pass/fail bar. A guessed tolerance either hides real regressions or produces flaky passes.
- Source: spec
- Primary owning slice: M001/S01
- Supporting slices: M001/S03, M001/S06..M001/S15
- Validation: unmapped
- Notes: Spec D-11, risk section. Hard steer 2026-10-05 (D007): the tolerance is measured on several shipped DXT1, DXT3 and DXT5 `_c.dds` from Data/ (incl. alpha), not on random noise; the file list and numbers live in dxt-tolerance.json and the comparator's DXT gate reads them. Re-measurement is S03 T07.

### R020 — Parity oracle: MFC `editor.exe` is run in batch mode on win-home against (a) in-repo projects, (b) GOG mod projects referenced by path only (never committed), (c) repo-owned fixtures (at least one per extension with small generated source art). Only goldens of repo-owned inputs are committed to `tools/zig/fixtures/resource_editor/`. The goldens stay after the MFC editor is deleted.
- Class: quality-attribute
- Status: active
- Description: Parity oracle: MFC `editor.exe` is run in batch mode on win-home against (a) in-repo projects, (b) GOG mod projects referenced by path only (never committed), (c) repo-owned fixtures (at least one per extension with small generated source art). Only goldens of repo-owned inputs are committed to `tools/zig/fixtures/resource_editor/`. The goldens stay after the MFC editor is deleted.
- Why it matters: Without a frozen reference, "unchanged" has no meaning. The goldens outlive the MFC editor itself; they are how future ports stay honest.
- Source: spec
- Primary owning slice: M001/S01
- Supporting slices: M001/S06..M001/S16
- Validation: unmapped
- Notes: Spec D-12. Hard steer 2026-10-05 (D007): goldens are MFC exports (game data), not project XML. They cannot be generated on the Linux machine; S03 T06 ships the win-home generation kit and keeps the golden comparison reporting `pending: golden missing`. No golden comparison counts as done until the win-home goldens are committed and pass.

### R021 — Project XML round-trip for every one of the 21 extensions, over every project in Data/Editor/TestProjects and every fixture: load → save → reload is content-equal; an MFC project opened and saved without edits is byte-identical (MFC indentation and element order), with every exception listed in the spec with its reason; open, save, open, save is idempotent. A node inserted through the model saves as valid MFC XML (never `<>`), and MFC can read what the port writes. Unknown nodes (unknown class types) are preserved through a save.
- Class: quality-attribute
- Status: active
- Description: Project XML round-trip for every one of the 21 extensions, over every project in Data/Editor/TestProjects and every fixture: load → save → reload is content-equal; an MFC project opened and saved without edits is byte-identical (MFC indentation and element order), with every exception listed in the spec with its reason; open, save, open, save is idempotent. A node inserted through the model saves as valid MFC XML (never `<>`), and MFC can read what the port writes. Unknown nodes (unknown class types) are preserved through a save.
- Why it matters: Projects are shared with MFC during the transition; non-idempotent save would silently rewrite others' projects or lose data for unknown classes.
- Source: spec
- Primary owning slice: M001/S03
- Validation: unmapped
- Notes: Spec D-07, D-11. Tightened by the hard steer 2026-10-05 (D006).

### R022 — Per-stats-type comparator in C++: reads both sides with the engine's own reader (`GameDB::ReadRPGStats`, `GetAddStats`, `GetGameStats`, `ParticleSourceData`, `fmtEffect`, `fmtTerrain`, `fmtVSO`) and compares every field (floats exactly). Fails on any field it does not know, so new fields cannot slip through.
- Class: quality-attribute
- Status: active
- Description: Per-stats-type comparator in C++: reads both sides with the engine's own reader (`GameDB::ReadRPGStats`, `GetAddStats`, `GetGameStats`, `ParticleSourceData`, `fmtEffect`, `fmtTerrain`, `fmtVSO`) and compares every field (floats exactly). Fails on any field it does not know, so new fields cannot slip through.
- Why it matters: "The game reads it unchanged" is the irreducible contract. The game's own readers are the authority; eyeballing is forbidden. Failing on unknown fields catches silent new fields.
- Source: spec
- Primary owning slice: M001/S03
- Supporting slices: M001/S06..M001/S15
- Validation: unmapped
- Notes: Spec D-11. Hard steer 2026-10-05 (D007): the comparator compares exported game data, never project XML, accepts real MFC exports, and is proven on shipped Data/ stats (self-equal passes; one-ulp float change, dropped and extra field fail). S03 T06.

### R023 — `BK_EDITOR_AUTO` extended with Resource Editor actions: `editor=<kind>`, `select=<node path>`, `set=<prop>=<value>`, `export`, `batch=<args>`, `undo`, `redo`. `zig build resource-editor-auto` runs open → edit → undo → save → export → shot → compare → test-launch → quit.
- Class: operability
- Status: active
- Description: `BK_EDITOR_AUTO` extended with Resource Editor actions: `editor=<kind>`, `select=<node path>`, `set=<prop>=<value>`, `export`, `batch=<args>`, `undo`, `redo`. `zig build resource-editor-auto` runs open → edit → undo → save → export → shot → compare → test-launch → quit.
- Why it matters: Automated end-to-end scenarios in CI cover the user journeys that unit tests cannot — command composition, undo across operations, UI → export → game-reads-it.
- Source: spec
- Primary owning slice: M001/S05
- Supporting slices: M001/S06..M001/S15, M001/S16
- Validation: unmapped
- Notes: Spec test tiers section.

### R024 — `build.zig` steps mirror the Map Editor: `install-resource-editor`, `test-resource-core`, `test-resource-model`, `test-resource-bridge`, `resource-editor-host-check`, `resource-editor-smoke`, `resource-editor-auto`, `resource-editor-game-reads-it`, `test-resources-all`. `.github/workflows/cross-platform.yml` gets the resource tiers next to the map editor's in `macos-platform` and `windows-platform` jobs; kit/core tier runs in all six jobs.
- Class: operability
- Status: active
- Description: `build.zig` steps mirror the Map Editor: `install-resource-editor`, `test-resource-core`, `test-resource-model`, `test-resource-bridge`, `resource-editor-host-check`, `resource-editor-smoke`, `resource-editor-auto`, `resource-editor-game-reads-it`, `test-resources-all`. `.github/workflows/cross-platform.yml` gets the resource tiers next to the map editor's in `macos-platform` and `windows-platform` jobs; kit/core tier runs in all six jobs.
- Why it matters: The Map Editor's tiers are the proven template; the Resource Editor needs the same CI gating so no regression hides.
- Source: spec
- Primary owning slice: M001/S05
- Supporting slices: M001/S03, M001/S04, M001/S16
- Validation: unmapped
- Notes: Spec D-24, integration points.

### R025 — Packaging: `tools/zig/stage.zig` gains `--resource-editor <bin>` like `--map-editor`, and `ResourceEditor` is staged beside `Game` and `MapEditor` on every platform package. In 06-16 the MFC `editor.exe` is removed from `stage.zig`'s `copyEditors` entry.
- Class: launchability
- Status: active
- Description: Packaging: `tools/zig/stage.zig` gains `--resource-editor <bin>` like `--map-editor`, and `ResourceEditor` is staged beside `Game` and `MapEditor` on every platform package. In 06-16 the MFC `editor.exe` is removed from `stage.zig`'s `copyEditors` entry.
- Why it matters: The editor must land in packages the same way the game and the Map Editor do; the Windows-only checked-in `editor.exe` goes away.
- Source: spec
- Primary owning slice: M001/S05
- Supporting slices: M001/S16
- Validation: unmapped
- Notes: Spec D-25.

### R026 — GUI editor (MFC `CGUIFrame`/`GUIFrame2.cpp`, switched off in MFC) is ported last against the game's current UI screen XML (`Data/UI/*.xml`), including Lua screens and scaling. Proven when the game loads a screen the editor has edited. Covers place/move/resize/copy/cut/paste, template tree, align menu, property tree for controls.
- Class: core-capability
- Status: active
- Description: GUI editor (MFC `CGUIFrame`/`GUIFrame2.cpp`, switched off in MFC) is ported last against the game's current UI screen XML (`Data/UI/*.xml`), including Lua screens and scaling. Proven when the game loads a screen the editor has edited. Covers place/move/resize/copy/cut/paste, template tree, align menu, property tree for controls.
- Why it matters: The spec says "all editors are ported and all features are implemented" (D-22). The GUI editor is the hardest because its format has moved on since MFC; it comes last so the shared infrastructure is proven first.
- Source: spec
- Primary owning slice: M001/S15
- Supporting slices: M001/S16
- Validation: unmapped
- Notes: Spec D-22, 06-PARITY B-21. Paste must give unique ElementIDs (D036, S15 review fix): a pasted window keeps its id when unused in the target screen, otherwise gets the next free id (also inside pasted subtrees), reassignments reported in status line and log, undo restores; proved through the engine's UI reader in M001/S16/T01.

### R027 — Dead or intent-unclear MFC commands (SaveMapObjects, Ack Import/Export, Effect "Interpolate Vector Items", `ID_EDIT_CROSSETS`) are investigated by the owning sub-editor plan. If intent is clear, implement; if not, mark the parity row "no behaviour in MFC" with the reason.
- Class: core-capability
- Status: active
- Description: Dead or intent-unclear MFC commands (SaveMapObjects, Ack Import/Export, Effect "Interpolate Vector Items", `ID_EDIT_CROSSETS`) are investigated by the owning sub-editor plan. If intent is clear, implement; if not, mark the parity row "no behaviour in MFC" with the reason.
- Why it matters: Silently dropping features would violate the "all features implemented" guarantee. Documenting dead-end commands with evidence lets the parity exit criterion complete honestly.
- Source: spec
- Primary owning slice: M001/S06, M001/S07, M001/S12, M001/S13
- Supporting slices: M001/S05
- Validation: unmapped
- Notes: Spec D-23. A-23, B-02.4, B-08.4, B-18.4.

### R028 — Help menu: Help (F1) shows the shortcut list and links the spec, because `reshelp.chm` is not in the repository. About dialog present.
- Class: admin/support
- Status: active
- Description: Help menu: Help (F1) shows the shortcut list and links the spec, because `reshelp.chm` is not in the repository. About dialog present.
- Why it matters: Spec D-23: the `.chm` is gone; a shortcut list + spec link preserves the Help affordance without reconstructing legacy help infrastructure.
- Source: spec
- Primary owning slice: M001/S05
- Validation: unmapped
- Notes: Spec D-23, A-25, A-26.

### R029 — Linux x64 is a first-class target for the Resource Editor and the shared editor kit, alongside macOS arm64/x64 and Windows x64 MSVC. All Resource Editor tiers (and Map Editor tiers under the extracted kit) are green on Linux. Reuse Map Editor Linux solutions: `rdynamic` + `$ORIGIN` rpath, 16 MiB worker stacks, hidden-window flags, ISFX stop-before-unload, case-insensitive `DataFile`.
- Class: launchability
- Status: active
- Description: Linux x64 is a first-class target for the Resource Editor and the shared editor kit, alongside macOS arm64/x64 and Windows x64 MSVC. All Resource Editor tiers (and Map Editor tiers under the extracted kit) are green on Linux. Reuse Map Editor Linux solutions: `rdynamic` + `$ORIGIN` rpath, 16 MiB worker stacks, hidden-window flags, ISFX stop-before-unload, case-insensitive `DataFile`.
- Why it matters: Newer-than-spec instruction. The Map Editor Linux merge (`1d7264fd6`) sets the pattern; the agent machine is Linux so Linux is the native development target.
- Source: user
- Primary owning slice: M001/S02
- Supporting slices: M001/S05, M001/S16
- Validation: unmapped
- Notes: Overrides spec deferred Linux-app note. Must be recorded in the spec per AGENTS.md rule.

### R030 — Settings live in `<UserRoot>resourceeditor/resourceeditor.cfg` (test seam `BK_RESOURCE_EDITOR_SETTINGS`): source root, export root, game args, picture defaults, background colour, recent files (kit's 10), autosave, last sub-editor, panel layout. The editor never reads the Windows registry. User content (projects, settings, recent files) lives under the kit's user-data root, never beside the executable; paths stored inside projects are relative where the format allows (so later editor cloud sync can be added without rework).
- Class: operability
- Status: active
- Description: Settings live in `<UserRoot>resourceeditor/resourceeditor.cfg` (test seam `BK_RESOURCE_EDITOR_SETTINGS`): source root, export root, game args, picture defaults, background colour, recent files (kit's 10), autosave, last sub-editor, panel layout. The editor never reads the Windows registry. User content (projects, settings, recent files) lives under the kit's user-data root, never beside the executable; paths stored inside projects are relative where the format allows (so later editor cloud sync can be added without rework).
- Why it matters: Spec D-10 for the settings location; the user-data-root rule is a newer-than-spec constraint from the "editor cloud sync will be designed later" note — this milestone must not block it.
- Source: spec
- Primary owning slice: M001/S05
- Supporting slices: M001/S02
- Validation: unmapped
- Notes: Spec D-10 + newer-than-spec cloud-sync-ready rule.

### R032 — Final sweep (slice 16) passes: `test-resources-all` with 0 FAIL; `resource-editor-game-reads-it` with one resource per sub-editor kind loads and the game plays cleanly; every repo-owned golden equal in CI; every GOG golden equal on win-home; every 06-PARITY.md row `done` or `no behaviour in MFC`; Johannes's hand try approved on macOS release and Windows release.
- Class: launchability
- Status: active
- Description: Final sweep (slice 16) passes: `test-resources-all` with 0 FAIL; `resource-editor-game-reads-it` with one resource per sub-editor kind loads and the game plays cleanly; every repo-owned golden equal in CI; every GOG golden equal on win-home; every 06-PARITY.md row `done` or `no behaviour in MFC`; Johannes's hand try approved on macOS release and Windows release.
- Why it matters: This is the testable exit criterion. "All parity rows done" is the summary; the sweep is the proof.
- Source: spec
- Primary owning slice: M001/S16
- Validation: unmapped
- Notes: Spec D-29.

## Validated

### R031 — The MFC editor is deleted at the end of M001: `Sources/src/editor`, `Sources/src/bin/editor.exe`, `Sources/src/editor/bin/editor2.exe`, the `A7.sln` entry, and the `stage.zig` `copyEditors` entry. Only after all parity rows are done with evidence, all goldens pass, `test-resources-all` passes, and Johannes approves hand try on macOS + Windows. The goldens stay.
- Class: launchability
- Status: validated
- Description: The MFC editor is deleted at the end of M001: `Sources/src/editor`, `Sources/src/bin/editor.exe`, `Sources/src/editor/bin/editor2.exe`, the `A7.sln` entry, and the `stage.zig` `copyEditors` entry. Only after all parity rows are done with evidence, all goldens pass, `test-resources-all` passes, and Johannes approves hand try on macOS + Windows. The goldens stay.
- Why it matters: Keeping the MFC editor around after the port confuses packaging and authors. Deletion is the exit event. Preserving goldens means future ports can be checked against the same reference without the MFC editor needing to run.
- Source: spec
- Primary owning slice: M001/S16
- Validation: c6b4329c6 deletes the MFC editor; PRE_DELETE b8aa895bb recorded in docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md and 06-PARITY.md; comparator pass=10 accepted=10 fail=0 pending=0 and full Linux sweep VERDICT=PASS at b8aa895bb.
- Notes: Spec D-26, D-29. Approval for the deletion is on record (D037, 2026-10-06, before the hand try and the MFC goldens). D043 held S16/T07 until a later steer released it; golden rounds 2-6 and the batch export (D044-D049, S16/T10-T15) ran before it. D050 (hard steer 2026-10-06T16:12) released T07: all 20 MFC goldens are committed (3rd and 3rv exported by hand in MFC's GUI because MFC's batch export of them crashes), test-resource-model-comparator at b8aa895bb reports pass=10 accepted=10 fail=0 pending=0, and the maintainer's full Linux sweep at b8aa895bb is VERDICT=PASS (41 tiers). The deletion is done in c6b4329c6 'chore(resource-editor): remove the MFC editor' (Sources/src/editor with bin/editor2.exe, Sources/src/bin/editor.exe, the A7.sln entry, the stage.zig copyEditors row). PRE_DELETE = b8aa895bb00efb2fdac28096656dcf26984e3f87 is recorded in the spec and 06-PARITY.md as the commit from which MFC goldens can be regenerated. The goldens stay. The maintainer runs the full sweep on c6b4329c6; the hand try on macOS and Windows release stays open under R032.

## Deferred

### R033 — Editor cloud sync for all editors (future design).
- Class: continuity
- Status: deferred
- Description: Editor cloud sync for all editors (future design).
- Why it matters: Content authors across machines; relevant later.
- Source: user
- Validation: n/a
- Notes: Deferred per newer-than-spec instruction. Not built here, but must not be blocked: user content under kit's user-data root; paths relative inside projects where the format allows.

### R034 — Batch export straight into a PAK (export + pack in one step).
- Class: operability
- Status: deferred
- Description: Batch export straight into a PAK (export + pack in one step).
- Why it matters: Convenience; not needed for parity.
- Source: spec
- Validation: n/a
- Notes: Spec deferred ideas.

### R035 — Removing `Common/LegacyUiCompat.h` (Stingray shim).
- Class: constraint
- Status: deferred
- Description: Removing `Common/LegacyUiCompat.h` (Stingray shim).
- Why it matters: It stays while the MFC map editor and MFC ELK still include it. Phase 7 (ELK portable port) removes it.
- Source: spec
- Validation: n/a
- Notes: Spec deferred ideas.

## Out of Scope

### R036 — New resource kinds or editing features beyond MFC parity (e.g. a new unit-stats balancing view, a diff between mods).
- Class: anti-feature
- Status: out-of-scope
- Description: New resource kinds or editing features beyond MFC parity (e.g. a new unit-stats balancing view, a diff between mods).
- Why it matters: Scope control. New features belong in a later phase; this one is a port.
- Source: spec
- Validation: n/a
- Notes: Spec. The on-purpose additions (undo, safe save, autosave, recovery, Import, Export stats only everywhere) are listed in-scope.

## Traceability

| ID | Class | Status | Primary owner | Supporting | Proof |
|---|---|---|---|---|---|
| R001 | core-capability | active | M001/S02 | M001/S05 | unmapped |
| R002 | core-capability | active | M001/S03 | M001/S06, M001/S07, M001/S08, M001/S09, M001/S10, M001/S11, M001/S12, M001/S13, M001/S14, M001/S15 | unmapped |
| R003 | integration | active | M001/S04 | M001/S05, M001/S06..M001/S15 | unmapped |
| R004 | core-capability | active | M001/S04 | M001/S06..M001/S15 | unmapped |
| R005 | primary-user-loop | active | M001/S05 | M001/S06..M001/S15 | unmapped |
| R006 | core-capability | active | M001/S06, M001/S07, M001/S08, M001/S09, M001/S10, M001/S11, M001/S12, M001/S13, M001/S14, M001/S15 | M001/S03, M001/S04 | unmapped |
| R007 | continuity | active | M001/S05 | M001/S02 | unmapped |
| R008 | continuity | active | M001/S05 | M001/S03 | unmapped |
| R009 | core-capability | active | M001/S05 | M001/S03 | unmapped |
| R010 | primary-user-loop | active | M001/S05 | none | unmapped |
| R011 | operability | active | M001/S05 | M001/S03 | unmapped |
| R012 | primary-user-loop | active | M001/S05 | M001/S02 | unmapped |
| R013 | primary-user-loop | active | M001/S05 | M001/S03 | unmapped |
| R014 | core-capability | active | M001/S04 | M001/S06, M001/S07, M001/S08, M001/S09, M001/S10, M001/S11, M001/S12, M001/S13, M001/S14, M001/S15 | unmapped |
| R015 | primary-user-loop | active | M001/S05 | M001/S06..M001/S15 | unmapped |
| R016 | differentiator | active | M001/S04 | M001/S06..M001/S15 | unmapped |
| R017 | integration | active | M001/S04 | M001/S01, M001/S05, M001/S06..M001/S15 | unmapped |
| R018 | quality-attribute | active | M001/S01 | none | unmapped |
| R019 | quality-attribute | active | M001/S01 | M001/S03, M001/S06..M001/S15 | unmapped |
| R020 | quality-attribute | active | M001/S01 | M001/S06..M001/S16 | unmapped |
| R021 | quality-attribute | active | M001/S03 | none | unmapped |
| R022 | quality-attribute | active | M001/S03 | M001/S06..M001/S15 | unmapped |
| R023 | operability | active | M001/S05 | M001/S06..M001/S15, M001/S16 | unmapped |
| R024 | operability | active | M001/S05 | M001/S03, M001/S04, M001/S16 | unmapped |
| R025 | launchability | active | M001/S05 | M001/S16 | unmapped |
| R026 | core-capability | active | M001/S15 | M001/S16 | unmapped |
| R027 | core-capability | active | M001/S06, M001/S07, M001/S12, M001/S13 | M001/S05 | unmapped |
| R028 | admin/support | active | M001/S05 | none | unmapped |
| R029 | launchability | active | M001/S02 | M001/S05, M001/S16 | unmapped |
| R030 | operability | active | M001/S05 | M001/S02 | unmapped |
| R031 | launchability | validated | M001/S16 | none | c6b4329c6 deletes the MFC editor; PRE_DELETE b8aa895bb recorded in docs/superpowers/specs/2026-09-30-portable-resource-editor-design.md and 06-PARITY.md; comparator pass=10 accepted=10 fail=0 pending=0 and full Linux sweep VERDICT=PASS at b8aa895bb. |
| R032 | launchability | active | M001/S16 | none | unmapped |
| R033 | continuity | deferred | none | none | n/a |
| R034 | operability | deferred | none | none | n/a |
| R035 | constraint | deferred | none | none | n/a |
| R036 | anti-feature | out-of-scope | none | none | n/a |

## Coverage Summary

- Active requirements: 31
- Mapped to slices: 31
- Validated: 1 (R031)
- Unmapped active requirements: 0
