#!/usr/bin/env bash
# Re-run `gsd headless auto` until the active milestone is complete, GSD reports a blocker,
# or five runs in a row change neither HEAD nor GSD's state line. One status line per run
# goes to supervise.status. Waits for any running gsd to finish before starting.
set -u
cd "$HOME/Projects/Blitzkrieg" || exit 1
export PATH="$HOME/.nvm/versions/node/v23.6.1/bin:$PATH"
LOG="$HOME/gsd-logs/blitzkrieg-auto.log"
STATUS="$HOME/gsd-logs/supervise.status"
while pgrep -x gsd >/dev/null; do sleep 30; done
idle=0
last=""
while true; do
  before=$(git rev-parse HEAD)
  gsd headless --timeout 604800000 auto >> "$LOG" 2>&1 < /dev/null
  rc=$?
  after=$(git rev-parse HEAD)
  q=$(timeout 120 gsd headless query 2>/dev/null)
  summary=$(printf '%s' "$q" | python3 -c '
import json,sys
try:
    t=sys.stdin.read(); d=json.loads(t[t.find("{"):]); s=d["state"]; p=s["progress"]
    m=s.get("activeMilestone") or {}
    t=s.get("activeTask") or {}
    print("milestone=%s slices=%d/%d tasks=%d/%d task=%s phase=%s blockers=%d next=%s/%s" % (m.get("id"), p["slices"]["done"], p["slices"]["total"], p.get("tasks",{}).get("done",0), p.get("tasks",{}).get("total",0), t.get("id"), s["phase"], len(s["blockers"]), d["next"].get("action"), d["next"].get("unitType")))
except Exception as e:
    print("query-failed", e)')
  echo "$(date -Is) rc=$rc commits=$(git rev-list --count $before..$after) dirty=$(git status --short | wc -l) $summary" >> "$STATUS"
  if [ "$before" = "$after" ] && [ "$summary" = "$last" ]; then idle=$((idle+1)); else idle=0; fi
  last="$summary"
  case "$summary" in
    *"phase=complete"*|*"milestone=None"*) echo "$(date -Is) STOP milestone complete" >> "$STATUS"; exit 0;;
  esac
  if [ "$rc" = 10 ] || printf '%s' "$summary" | grep -q "blockers=[1-9]"; then echo "$(date -Is) STOP blocked" >> "$STATUS"; exit 10; fi
  if [ "$rc" = 11 ]; then echo "$(date -Is) STOP cancelled" >> "$STATUS"; exit 11; fi
  if [ "$idle" -ge 5 ]; then echo "$(date -Is) STOP no progress in 5 runs" >> "$STATUS"; exit 2; fi
  sleep 30
done
