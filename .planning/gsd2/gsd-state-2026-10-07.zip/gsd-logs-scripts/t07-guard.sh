#!/usr/bin/env bash
# Stops GSD when it is about to dispatch M001/S16/T07 while the deletion is on hold.
tail -n0 -F ~/gsd-logs/blitzkrieg-auto.log | while read -r line; do
  case "$line" in
    *"execute-task"*"M001/S16/T07"*|*"Executing M001/S16/T07"*|*"S16/T07"*"dispatch"*)
      pkill -f "bash .*gsd-logs/[s]upervise3.sh"
      for p in $(ps -eo pid,args | awk '$2=="gsd"{print $1}'); do kill $p; done
      echo "$(date -Is) GUARD stopped GSD before T07: $line" >> ~/gsd-logs/supervise.status
      exit 0;;
  esac
done
