#!/usr/bin/env bash
# Re-run `gsd headless auto` until the active milestone is complete, GSD reports a blocker,
# or three runs in a row make no commit. Writes one status line per run to supervise.status.
set -u
cd "$HOME/Projects/Blitzkrieg" || exit 1
export PATH="$HOME/.nvm/versions/node/v23.6.1/bin:$PATH"
LOG="$HOME/gsd-logs/blitzkrieg-auto.log"
STATUS="$HOME/gsd-logs/supervise.status"
idle=0
while true; do
  before=$(git rev-parse HEAD)
  gsd headless --timeout 604800000 auto >> "$LOG" 2>&1 < /dev/null
  rc=$?
  after=$(git rev-parse HEAD)
  q=$(timeout 120 gsd headless query 2>/dev/null)
  summary=$(printf '%s' "$q" | python3 -c '
import json,sys
try:
    d=json.load(sys.stdin); s=d["state"]; p=s["progress"]
    m=s.get("activeMilestone") or {}
    print("milestone=%s slices=%d/%d tasks=%d/%d phase=%s blockers=%d next=%s" % (m.get("id"), p["slices"]["done"], p["slices"]["total"], p["tasks"]["done"], p["tasks"]["total"], s["phase"], len(s["blockers"]), d["next"].get("action")))
except Exception as e:
    print("query-failed", e)')
  echo "$(date -Is) rc=$rc commits=$(git rev-list --count $before..$after) $summary" >> "$STATUS"
  if [ "$before" = "$after" ]; then idle=$((idle+1)); else idle=0; fi
  case "$summary" in
    *"phase=complete"*|*"activeMilestone"*"None"*) echo "$(date -Is) STOP milestone complete" >> "$STATUS"; exit 0;;
  esac
  if [ "$rc" = 10 ] || printf '%s' "$summary" | grep -q "blockers=[1-9]"; then echo "$(date -Is) STOP blocked" >> "$STATUS"; exit 10; fi
  if [ "$rc" = 11 ]; then echo "$(date -Is) STOP cancelled" >> "$STATUS"; exit 11; fi
  if [ "$idle" -ge 3 ]; then echo "$(date -Is) STOP no progress in 3 runs" >> "$STATUS"; exit 2; fi
  sleep 20
done
